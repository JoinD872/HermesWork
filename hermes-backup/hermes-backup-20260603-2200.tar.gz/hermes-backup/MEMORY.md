GitHub PAT 实际位置在 /root/.hermes/scripts/hermes-backup.sh（不在 .env），用户 JoinD872，仓库 JoinD872/HermesWork（私人），Token 前缀 ghp_6q...XGvJ。以后查 GitHub 认证先看 backup.sh。
§
用户云端迭代工作流 — 主力走 GitHub：文件放 JoinD872/HermesWork/workspace/，用户在网页版改，我读+改+提交推送。不走百度网盘/飞书云盘。补充：Google Drive 用于 Obsidian Cloud Inbox（HermesInbox/ 文件夹，每30min拉取到 Vault 收件箱），仅做灵感投递不用于代码迭代。
§
## 低频流程索引（详情查对应 skill）
宠物技能设计：skill `pet-skill-design-workflow` | crawl4ai：skill `community-scraping` | 日记格式：skill `obsidian`
§
## 图片理解
首选 DeepSeek V4 原生 Vision。备用 `mmx vision describe`。不用 MCP understand_image（404）。
§
## Windows/黑翼
SSH: `ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37`，工作目录 E:\Hermes\。两台机器：desktop-tg4loen（在线）+ 笔记本（离线30天+）。
小红书 headless 被拦（300012），需用户桌面非 headless 浏览器配合。
§
知乎已升级为官方API：ZHIHU_ACCESS_SECRET存于.env，developer.zhihu.com，每天1000次免费搜索，替代SearXNG间接方式。
§
## 通知与日记偏好
无事不通知；cron 用 silent script + deliver=local。Vault/日记默认被动，不主动读/写，等用户问再说。日记路径：~/.hermes/ObsidianVault/日记/ | 模板在 模板/日记模板.md
§
AI 偏好：Gemini "回答简短、语言贫乏、刻意迎合"；GPT "内容衍生多、思维更广"。不要 yes-man，要能发散碰撞的对话伙伴。
§
Codex CLI 已从 0.125.0 升级到 0.133.0（2026-05-23）。Codex 没有持久记忆——每次 exec 都是独立会话，派发给它时必须显式附带上下文（用户偏好、skill 知识等）。高推理模式：`codex exec -c 'reasoning_effort="high"'`。
§
## VPS/cron 自动化
IP 192.3.241.244 | SSH 端口2222 | Xray 8081 VLESS+WS → CF Tunnel | cron no_agent script 只写文件名不加 shell 前缀
§
## 协作模型 V2（2026-06-01 经 Codex 迭代确认）

### 六个参与方
小H（主控）、Codex（外脑）、小策（方案官）、小研（调研/验证/沉淀官）、黑翼（风控官）、老V（执行官）

### Codex 规则
强默认前置参与所有任务。跳过需显式记录状态+原因：called / skipped_quota(附原因) / lite_check(说明覆盖)。配额耗尽时不阻塞。

### 路由细则
中风险：小策必参与。小研按需（资料核验/事实准确性/可行性/工具对比/效果验证时触发）。老V按需（有执行时）。黑翼不参与。
高风险：小策必参与。黑翼必参与。小研按需（同中风险触发）。老V按需。
低风险：小H处理。但写入文件/改配置/部署/调API/付费/权限变更不得小H直接执行，必须走老V。

### 用户确认闸门
高风险/不可逆/付费/权限/生产/隐私操作，执行前小H必须确认：方案+影响+风险+回滚。用户必须明确确认，沉默不算授权。

### 冲突仲裁优先级
安全/权限边界 > 用户当前指令 > 用户原始目标 > SOUL.md/memory规则 > 小H判断。可验证事实校正所有层级。高风险冲突不得静默合并。
§
2026-06-02 修复 daily_diary.sh 三大 bug：① MONTH_DIR 在循环中被覆写导致新日记放错月份目录 → 改用 INBOUND_MONTH 隔离；② 内容检测通过行数对比误判已填日记为"空"→ 改用 Python re 截取 # YYYY-MM-DD 后实际文本，>10字判定有内容；③ rclone timeout 120s 内嵌套目录列表超时 → 已无更好方案，注意 cron 在 00:00 UTC 运行。
§
## 上下文压缩锚定协议（2026-06-02 确立）
每次看到 `[CONTEXT COMPACTION — REFERENCE ONLY]` 时，在回复前执行：
1. 提取摘要中 ## Active Task 的内容
2. 与用户最新消息做语义对比
3. 如果话题明显不同（如「攻略」vs「笔记」），标记为「话题已切换」，忽略旧 Active Task
4. 用工具确认当前工作状态（pwd/ls/read_file），基于真实状态回复
5. 如果话题相关或相同，正常继续