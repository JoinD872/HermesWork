---
name: debugging-tools
description: Terminal-based debugging for Python and Node.js — pdb, debugpy, remote-pdb, node inspect, Chrome DevTools Protocol. When a test fails, a process misbehaves, or you need to inspect intermediate state beyond console.log/print.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [debugging, python, nodejs, pdb, debugpy, node-inspect, cdp, breakpoints]
    related_skills: [systematic-debugging, test-driven-development]
risk: write-safe
---

# Debugging Tools

Terminal-based debugging for Python and Node.js processes. This skill covers the **tool** side — how to launch, attach, set breakpoints, and inspect state. For the **process** of systematic root-cause investigation, see `systematic-debugging`.

## Quick Decision Table

| Scenario | Tool | Skill Reference |
|----------|------|-----------------|
| Quick local inspection in Python | `breakpoint()` + pdb | `references/python-debugging.md` |
| Launch a Python script under debugger | `python -m pdb` | `references/python-debugging.md` |
| Debug a pytest test | `pytest --pdb` | `references/python-debugging.md` |
| Remote-attach to a long-lived Python process | `debugpy` | `references/python-debugging.md` |
| Simplest remote Python debug from terminal | `remote-pdb` + `nc` | `references/python-debugging.md` |
| Post-mortem on Python exception | `pdb.post_mortem()` | `references/python-debugging.md` |
| Quick Node.js inspection | `node inspect` REPL | `references/node-debugging.md` |
| Attach to a running Node.js process | `kill -SIGUSR1 <pid>` + `node inspect -p` | `references/node-debugging.md` |
| Scriptable multi-breakpoint Node debugging | CDP via `chrome-remote-interface` | `references/node-debugging.md` |
| Heap snapshots / CPU profiles (Node) | CDP `HeapProfiler` / `Profiler` | `references/node-debugging.md` |

## Common Patterns

### Local workflow (both languages)

1. Insert `breakpoint()` (Python) or add `--inspect-brk` (Node) at the suspect spot
2. Run the code normally
3. When execution pauses, inspect locals, step through, evaluate expressions
4. **Remove the breakpoint before committing**

### Remote/headless workflow

For long-lived processes (gateway, daemon, subprocess):

1. Add remote debug hook (debugpy.listen or remote-pdb)
2. Start/restart the process
3. Attach client (IDE or `nc` for remote-pdb)
4. Trigger the code path you want to debug
5. Inspect state when it pauses

### Avoiding Pitfalls

- **pytest + xdist = no pdb.** Add `-p no:xdist` or `-n 0` to debug tests.
- **`PYTHONBREAKPOINT=0`** disables `breakpoint()`. Check env if it doesn't trigger.
- **Sourcemaps matter.** Node.js breakpoints in TypeScript hit emitted JS, not `.ts`, unless sourcemaps are loaded.
- **Don't commit breakpoints.** Use `rg -n 'breakpoint\\(\\)|set_trace\\(|debugpy\\.listen' --type py` to check before pushing.
- **Processes that fork.** pdb does not follow forks. Debug one process at a time.

## Hermes-Specific Recipes

### Debug gateway (Python — use remote-pdb)

```python
from remote_pdb import set_trace
set_trace(host="127.0.0.1", port=4444)
# Then in another terminal: nc 127.0.0.1 4444
```

### Debug TUI (Node — attach to running process)

```bash
kill -SIGUSR1 "$(pgrep -f 'ui-tui/dist/entry')"
node inspect ws://$(curl -s http://127.0.0.1:9229/json/list | python3 -c "import sys,json; print(json.load(sys.stdin)[0]['webSocketDebuggerUrl'])")
```

## Reference Files

- `references/python-debugging.md` — Full Python debugger guide (pdb, debugpy, remote-pdb)
- `references/node-debugging.md` — Full Node.js debugger guide (node inspect, CDP)
