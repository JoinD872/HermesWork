# Python Debugging (pdb + debugpy + remote-pdb)

## Overview

Three tools, picked by situation:

| Tool | When |
|---|---|
| **`breakpoint()` + pdb** | Local, interactive, simplest. Add `breakpoint()` in the source, run normally, get a REPL at that line. |
| **`python -m pdb`** | Launch an existing script under pdb with no source edits. Useful for quick poking. |
| **`debugpy`** | Remote / headless / "attach to already-running process." Talks DAP, scriptable from terminal, works for long-lived processes (gateway, daemon, PTY children). |

**Start with `breakpoint()`.** It's the cheapest thing that works.

## pdb Quick Reference

Inside any pdb prompt `(Pdb)`:

| Command | Action |
|---|---|
| `h` / `h cmd` | help |
| `n` | next line (step over) |
| `s` | step into |
| `r` | return from current function |
| `c` | continue |
| `unt N` | continue until line N |
| `j N` | jump to line N (same function only) |
| `l` / `ll` | list source / full function |
| `w` | where (stack trace) |
| `u` / `d` | move up / down in the stack |
| `a` | print args of the current function |
| `p expr` / `pp expr` | print / pretty-print expression |
| `display expr` | auto-print expr on every stop |
| `b file:line` | set breakpoint |
| `b func` | break on function entry |
| `cl N` | clear breakpoint N |
| `tbreak file:line` | one-shot breakpoint |
| `!stmt` | execute arbitrary Python |
| `interact` | drop into full Python REPL (Ctrl+D to exit) |
| `q` | quit |

## Recipes

### Local breakpoint

```python
def compute(x, y):
    result = some_helper(x)
    breakpoint()           # drops into pdb here
    return result + y
```

### Launch a script under pdb (no source edits)

```bash
python -m pdb path/to/script.py arg1 arg2
```

### Debug a pytest test

```bash
# Drop to pdb on failure:
pytest tests/path/to/test_file.py::test_name --pdb -p no:xdist

# Drop to pdb at the START:
pytest tests/path/to/test_file.py::test_name --trace -p no:xdist
```

**IMPORTANT:** pdb does NOT work under pytest-xdist. Always add `-p no:xdist`.

### Post-mortem on any exception

```python
import pdb, sys
try:
    run_the_thing()
except Exception:
    pdb.post_mortem(sys.exc_info()[2])
```

### Remote debug with debugpy

```bash
# Install
pip install debugpy

# Launch with wait-for-client
python -m debugpy --listen 127.0.0.1:5678 --wait-for-client your_script.py

# Attach to already-running process
python -m debugpy --listen 127.0.0.1:5678 --pid <pid>
```

### Simplest remote debug — remote-pdb

```bash
pip install remote-pdb
```

In code:
```python
from remote_pdb import set_trace
set_trace(host="127.0.0.1", port=4444)   # blocks until connection
```

Then from terminal:
```bash
nc 127.0.0.1 4444
# You get a (Pdb) prompt.
```

## Hermes-Specific Processes

### Gateway / tui_gateway — use remote-pdb

```python
from remote_pdb import set_trace
set_trace(host="127.0.0.1", port=4444)   # in the RPC handler
```

Trigger the action, then `nc 127.0.0.1 4444` in another terminal.

### _SlashWorker subprocess

Same pattern — `remote-pdb` with `set_trace()` inside the worker's `exec` path.

### Tests

Always add `-p no:xdist`. Run without the hermetic wrapper for debugging:
```bash
source .venv/bin/activate
python -m pytest tests/foo_test.py::test_bar --pdb
```

## Common Pitfalls

1. **pdb under pytest-xdist silently does nothing.** Always use `-p no:xdist` or `-n 0`.
2. **`breakpoint()` in CI hangs the process.** Never commit it.
3. **`PYTHONBREAKPOINT=0`** disables all `breakpoint()` calls. Check env.
4. **`debugpy.listen` without `wait_for_client()`** — execution continues and first breakpoint may fire before client attaches.
5. **Attach to PID fails on hardened kernels** — `ptrace_scope=1` (Ubuntu default). Workaround: run under debugpy from the start.
6. **Threads** — pdb only debugs the current thread.
7. **asyncio** — pdb works in coroutines but `await` inside pdb requires Python 3.13+.
8. **`scripts/run_tests.sh`** strips credentials and sets `HOME=<tmpdir>`. Debug with raw pytest first.

## Verification Checklist

- [ ] After `pip install debugpy`, confirm: `python -c "import debugpy; print(debugpy.__version__)"`
- [ ] For remote debug, confirm port is listening: `ss -tlnp | grep 5678`
- [ ] First breakpoint actually hits
- [ ] No stray `breakpoint()` / `set_trace()` in committed code
