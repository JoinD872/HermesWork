# Bash → Python 迁移案例：daily_diary.sh → daily_diary.py

**日期：** 2026-06-03
**涉及文件：** `~/.hermes/scripts/daily_diary.sh` → `~/.hermes/scripts/daily_diary.py`
**关联技能：** `software-development:code-repair-loop`

## 背景

`daily_diary.sh` 是 UTC 00:00 执行的 cron no_agent 脚本，职责：
1. 从 Google Drive 拉回用户编辑过的日记 → 检查是否有内容 → 同步到 Vault
2. 创建今天的新日记（本地 .md + Drive Google Doc）
3. 删除空日记

## 故障历史

| 日期 | 故障 | 修复 |
|------|------|------|
| 05-25 | 内容检测通过行数对比误判已填日记为"空" | 改用 Python re 提取 # YYYY-MM-DD 后实际文本，>10字判定有内容 |
| 05-30 | MONTH_DIR 在循环中被覆写导致新日记放错月份目录 | 用 INBOUND_MONTH 隔离 |
| 06-02 | rclone timeout 120s 嵌套目录列表超时 | 无更好方案，记录为已知限制 |
| 06-03 | Drive 上残留旧格式 `日记MD/` 目录造成 `cp` 目标不存在 → `set -e` 炸全家 | 跳过非月份目录 + mkdir -p 兜底（临时补丁） |

第 4 轮修复后用户反应：「这个CRON，每次修，每次都会有新问题；怎么办？」

## 触发重构评估门

满足 Q2（3+ 个不同边缘情况）+ Q3（每次修复引出新 bug）→ 触发门。

### Codex 审查发现

Codex 审查了完整脚本和故障日志，发现了小H 没发现的更深层问题：

1. **Drive 上 `日记MD/` 目录嵌套 26 层**（约 499 个垃圾文件），旧的 include/exclude 顺序反了所以每次都会被拉回来
2. **rclone delete 对 Google Docs 无效**（Drive 上存储名不含 .md）
3. **当前补丁（跳过非月份目录）只是堵漏**，明天换个边缘情况还会炸

结论：**坚决重写 Python**（5/5 推荐）。

## Codex 输出审查发现

Codex 写的 Python 脚本中，rclone 的 `--include` 和 `--exclude` 顺序反了：

```python
# ❌ Codex 写的（错误顺序）
"--include", "/日记/*/*-日记.md",
"--exclude", "/日记/日记MD/**",   # 永远走不到这里！

# ✅ 修正后（正确顺序）
"--exclude", "/日记/日记MD/**",   # 先排除
"--include", "/日记/*/*-日记.md", # 再包含有效路径
```

**教训**：Codex 能力强大但仍会犯低级错误。每轮 Codex 输出必须逐段审查才能部署。

## 新脚本设计要点

| 方面 | 旧脚本（bash） | 新脚本（Python） |
|------|---------------|-----------------|
| 错误处理 | `set -euo pipefail` 一键炸全家 | 分步 try/except，一步失败不影响后续 |
| 目录过滤 | 无（靠循环里检查） | rclone `--exclude` + Python `re.match` 双重过滤 |
| 空日记处理 | rclone delete（无效） | 跳过不处理 |
| 文件操作 | sed/cp/rm | shutil.copy2，保留 mtime |
| 超时控制 | timeout 命令包裹 | subprocess.run(timeout=120) |
| 时区 | TZ=Asia/Shanghai 环境变量 | Python timezone(timedelta(hours=8)) |

## 关键数据

- 全量备份：`/tmp/diary-backup-1780499073/`
- Drive 垃圾清除：**499 个文件**（26 层嵌套）已删除
- cron 更新：脚本由 `daily_diary.sh` → `daily_diary.py`，old script 保留不删
- 验证结果：exit 0，幂等安全
