# 日记同步修复案例 — 2026-05-30

## 背景

daily_diary.sh 和 pull_user_notes.sh 存在嵌套目录 bug：日志MD/ 目录不断自我嵌套，导致：
1. Google Drive 上出现 `日记/日记MD/日记MD/日记MD/...` 无限嵌套（6+ 层，~42 个文件）
2. 用户写的 7 篇日记中只有 1 篇被成功同步回本地 Vault
3. 用户反馈「我有7篇日记，你为什么只找到一篇」

## 根因

| 根因 | 说明 |
|------|------|
| 日记MD/ 回推循环 | pull_user_notes.sh 全量拉取 Drive（含 日记MD/）→ 又把拉回的 .md 推回 日记MD/ → 每次运行在 Drive 上产生更深嵌套 |
| include 无根锚定 | `--include "日记/2026-05-29-日记.md"` 递归匹配 `日记/日记MD/2026-05-29-日记.md` 等子目录中的同名文件 |
| 仅拉取昨天 | `$YESTERDAY` 变量限制只处理前一天 → 历史日记永远不补拉 |
| wc -c 大小比较 | Google Docs 导出格式变化导致文件大小不稳定 → 误判为用户「没写内容」→ 删除有内容的日记 |

## 修复

| 修改项 | 文件 | 变更 |
|--------|------|------|
| 删除日记MD/上传逻辑 | daily_diary.sh | `rclone copy ...日记MD/` 整段删除 |
| include 根锚定 | daily_diary.sh | `--include "/$DIARY_SUB/*-日记.md"` 加 `/` 前缀 |
| 历史补拉 | daily_diary.sh | `YESTERDAY` → for 循环遍历所有 `*-日记.md` |
| 内容检测 | daily_diary.sh | `wc -c` → `grep status` + `wc -l` 双检测 |
| 两步法拉取 | pull_user_notes.sh | Step1 排除 日记/*，Step2 精确到 日记/ 子目录 |
| 删除日记MD/同步 | pull_user_notes.sh | Step3 整段删除 |

## 生产数据事故

Codex 子代理在清理 Drive 上的嵌套目录时，执行了 `rclone delete` 删除了 5 篇有用户内容的 Google Docs（误判为「空模板」）。

### 原因
- 子代理看到 rclone 输出 `-1 日记/2026-05-24-日记.md` → 误认为 `-1` 表示空文件
- 实际 `-1` 是 Google Docs 的 rclone 大小占位符，不代表文件为空

### 恢复
- 小H 在委托子代理前已手动拉取所有日记的 .md 版本到 `/tmp/diary_pull/`
- 数据无损恢复（cp 回 Vault + rclone --drive-import-formats md 重新上传到 Drive）

### 教训
1. 委托子代理做清理/删除操作前，必须标注 SAFE/ZONE 白名单
2. 子代理返回后必须验证「有意外删除吗？」——不要假设子代理正确判断了数据边界
3. 涉及远程存储的清理，先手动拉取全量本地备份再执行
