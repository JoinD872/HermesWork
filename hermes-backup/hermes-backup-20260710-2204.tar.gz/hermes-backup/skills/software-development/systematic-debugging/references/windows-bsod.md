---
name: windows-bsod-diagnostics
description: 通过SSH远程诊断Windows蓝屏（BSOD）的标准流程 — 事件日志分析、BugCheck解码、dump配置检查、驱动版本审计、根因出具修复方案
tags: [windows, bsod, crash, diagnostics, troubleshooting, intel-rst]
category: devops
risk: write-safe
---

# Windows BSOD 远程诊断

## 触发条件

用户报告桌面Windows电脑蓝屏/突然重启/黑屏/崩溃，且该电脑可通过SSH（Tailscale/内网）远程访问。

## 前置条件

- SSH密钥配置在 ~/.ssh/ 下
- 目标电脑的IP/主机名和用户名在memory中
- 确认机器是否还在线（蓝屏后可能自动重启，SSH通常可用）

## 标准诊断流程（6步）

### Step 1: 快速连接检查

```bash
ssh -i ~/.ssh/id_ed25519 -o ConnectTimeout=10 user@host "echo CONNECTED && systeminfo | findstr /B /C:\"OS Name\" /C:\"System Boot Time\""
```

- 如果连接失败：说明机器关机或网络中断，告知用户需手动重启后重试
- 如果连接成功：注意 `System Boot Time` — **刚重启3分钟内说明是蓝屏后自动重启**

### Step 2: 检查崩溃历史（Event 41 + 1001）

Windows用两个关键Event ID记录异常：

| Event ID | 来源 | 含义 |
|----------|------|------|
| **41** (Kernel-Power) | Microsoft-Windows-Kernel-Power | 系统未正常关机 — 蓝屏/断电/硬重启都会产生 |
| **1001** (BugCheck) | WER-SystemErrorReporting | 蓝屏错误报告 — **有41无1001=重要信号** |

**查询命令：**
```batch
# 蓝屏BugCheck记录（最近10条）
wevtutil qe System /c:10 /f:text /q:"Event[System[(EventID=1001)]]"

# 异常断电/重启记录（最近10条）
wevtutil qe System /c:10 /f:text /q:"Event[System[(EventID=41)]]"

# 最近30条System错误
wevtutil qe System /c:30 /f:text /q:"Event[System[(Level=2)]]"
```

**解码BugCheck代码：**
- `0x00000050` = PAGE_FAULT_IN_NONPAGED_AREA（内存/驱动问题）
- `0x0000001A` = MEMORY_MANAGEMENT（内存管理异常）
- `0x0000007A` = KERNEL_DATA_INPAGE_ERROR（磁盘/存储驱动问题）
- `0x000000D1` = DRIVER_IRQL_NOT_LESS_OR_EQUAL（驱动问题）
- `0x0000009F` = DRIVER_POWER_STATE_FAILURE（电源/睡眠驱动）
- `0x00000024` = NTFS_FILE_SYSTEM（磁盘/文件系统）

BugCheck 1001的描述字段中，`(参数1, 参数2, 参数3, 参数4)` 对应具体的错误详情。

### Step 3: 检查dump文件生成情况

**蓝屏没有dump = 存储子系统在崩溃时已经挂了，这是一个重要线索。**

```batch
# 查看dump配置
reg query "HKLM\SYSTEM\CurrentControlSet\Control\CrashControl"
# 重点: CrashDumpEnabled 值含义 — 0=无, 1=完整, 2=内核, 3=小内存, 7=自动

# 检查dump文件是否存在
dir C:\Windows\Minidump /b
dir C:\Windows\MEMORY.DMP /b
```

**无dump + 有Event 41无Event 1001 = 存储驱动或磁盘子系统崩溃**（这是与普通内存蓝屏的关键区分信号）

### Step 4: 检查存储驱动（Intel RST / NVMe）

这是ASUS/Intel主板的**头号BSOD元凶**。

```batch
# 查看所有Intel驱动列表（过滤出RST/Optane相关）
driverquery /si | findstr /i "rst intel iaStor"

# 查看RST VMD驱动版本
wmic path Win32_PnPSignedDriver where "DeviceName like '%%Intel RST%%'" get DeviceName,DriverVersion,DriverDate

# 或通过设备管理器路径查驱动文件版本
wmic datafile where name='C:\\Windows\\System32\\drivers\\iaStorAC.sys' get Version,LastModified /format:value
```

**已知高风险版本模式：**
| 驱动 | 高风险版本 | 问题 |
|------|-----------|------|
| Intel RST VMD | 19.5.x (2023年) | 在Z690/B660主板上触发0x50/0x1A |
| Intel RST (非VMD) | 18.x-19.x | 与NVMe SSD交互的内存管理bug |
| Intel Optane Pinning | 任何与RST配套版本 | 后台持续与RST驱动交互，提高崩溃频率 |

**修复：** 更新到Intel官网最新版（20.x+），或切换到Windows原生NVMe驱动。

### Step 5: 检查Windows版本和驱动更新时间线

```batch
# 查看最新更新的驱动（按时间排序）
wevtutil qe System /c:20 /f:text /q:"Event[System[Provider[@Name='Microsoft-Windows-WindowsUpdateClient']]]"

# 查看系统架构信息
systeminfo | findstr /B /C:"OS Name" /C:"OS Version" /C:"System Boot Time" /C:"System Up Time"

# 主板信息
wmic baseboard get Manufacturer,Product,Version
```

### Step 6: 检查其他相关异常事件

```batch
# 硬件错误事件（WHEA-Logger — 可能指向CPU/内存物理问题）
wevtutil qe System /c:5 /f:text /q:"Event[System[Provider[@Name='Microsoft-Windows-WHEA-Logger']]]"

# 磁盘错误
wevtutil qe System /c:10 /f:text /q:"Event[System[Provider[@Name='disk']]]"

# 最近的错误（Level=2是所有错误）
wevtutil qe System /c:30 /f:text /q:"Event[System[(Level=2)]]"
```

## 根因判断决策树

```
有Event 1001 + 有dump
  ├─ 0x50/0x1A → 内存或存储驱动，检查RST版本
  ├─ 0xD1 → 具体驱动冲突，检查最近更新的驱动
  └─ 其他 → 解码BugCheck参数，查对应KB

无Event 1001 + 无dump + 有Event 41
  ├─ 安装了Intel RST + Optane → 🔴 存储驱动崩溃（最高概率）
  ├─ 高频发生（一天2次+）→ 🔴 驱动/硬件问题，非偶发电源
  └─ 有WHEA Logger硬件错误 → 🟡 可能硬件问题（CPU/内存）

有Event 41 + 有Event 1001 + 无dump
  → dump写入失败，蓝屏时磁盘已不可用，优先检查存储驱动

仅Event 41（偶发，几周一次）
  → 可能电源问题/插头松动/ups异常，非系统问题
```

## 修复方案（按优先级）

### P0: 更新Intel RST VMD驱动（最高效）
```batch
# 下载新版Intel RST驱动
# Intel官网: https://www.intel.com/content/www/us/en/download/19512/
# 或主板厂商官网（ASUS/MSI/Gigabyte）的对应型号支持页面
```

### P1: 开启Full Memory Dump（为下次做准备）
```batch
reg add "HKLM\SYSTEM\CurrentControlSet\Control\CrashControl" /v CrashDumpEnabled /t REG_DWORD /d 1 /f
```
或通过 `write_file` 工具直接写reg文件。

### P2: 切换到Windows原生NVMe驱动（备选）
设备管理器 → 存储控制器 → Intel RST VMD Controller → 更新驱动 → 浏览 → 从列表选取 → 标准NVM Express控制器。

### P3: 内存硬件诊断
```batch
# 计划在下次重启时运行Windows内存诊断
mdsched.exe
```

## 报告模版

```
## 🔍 蓝屏诊断报告

### 崩溃历史
- 最近N次异常重启：时间线
  - YYYY-MM-DD HH:MM — Event 41（异常关机）
  - ...

### ✅ 已确认事实
| 检查项 | 结果 |
|--------|------|
| Minidump 目录 | [为空/有文件] |
| BugCheck 代码 | [0xXXXX / 无] |
| 崩溃转储配置 | [CrashDumpEnabled=X] |

### 🎯 根因判断
[一句话结论，概率]

### 🔧 修复方案
1. [P0方案]
2. [P1方案]
3. [P2方案]
```

## 常见陷阱

1. **PowerShell通过SSH的转义问题** — `$_` 会被bash截取，导致cmdlet失败。优先用`wevtutil`（cmd原生工具）而非PowerShell的`Get-WinEvent`。如必须用PowerShell，写成.ps1脚本再执行。
2. **Event 41单独出现不是蓝屏** — 可能是用户长按电源键、断电、插头松动。必须有Event 1001或错误日志佐证才是蓝屏。
3. **新版RST驱动文件名已变更** — 老驱动叫iaStorAC.sys/iaStorAV.sys，新版可能叫iaStorVD.sys。用driverquery查更可靠。
4. **Intel Optane后台进程** — 即使没开启Optane加速，安装的UWP应用也会启动RST Middleware后台服务，持续与驱动交互。
5. **英文版命令** — Windows中文版的事件描述是乱码/中文，但Event ID和BugCheck代码是通用的，只看数字。

## 参考资料

参考文件：`intel-rst-bsod-known-issues.md`
