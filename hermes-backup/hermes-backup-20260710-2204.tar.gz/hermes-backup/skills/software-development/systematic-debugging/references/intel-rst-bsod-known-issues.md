# Intel RST VMD / Optane 驱动 BSOD 已知问题

## 概述

Intel Rapid Storage Technology (RST) VMD驱动是Windows BSOD的头号元凶之一，特别是在ASUS Z690/Z790/B660/B760主板上。该驱动管理NVMe SSD的VMD（Volume Management Device）控制器。

## 高风险版本

| 驱动版本 | 日期 | 风险等级 | 说明 |
|----------|------|---------|------|
| 19.5.x | 2023年 | 🔴 高 | 已知在12/13代酷睿平台上触发0x50和0x1A，已多次被用户报告 |
| 20.0.x | 2024年初 | 🟡 中 | 部分修复但仍偶发 |
| 20.1.x+ | 2024年中+ | ✅ 当前推荐 | 大版本修复，BSOD报告显著减少 |

## 典型BugCheck代码

- **0x00000050 (PAGE_FAULT_IN_NONPAGED_AREA)** — RST驱动尝试访问已释放的内存页
  - 参数1: 访问的内存地址
  - 参数2: 0=读取操作 / 1=写入操作
  - 参数3: 引用该地址的指令指针
- **0x0000001A (MEMORY_MANAGEMENT)** — 内存管理结构损坏，RST驱动的NVMe命令队列管理bug
- **0x0000007A (KERNEL_DATA_INPAGE_ERROR)** — 页面文件读写失败，存储驱动层问题
- **0x000000D1 (DRIVER_IRQL_NOT_LESS_OR_EQUAL)** — 驱动在错误IRQL级别访问内存，iaStorVD.sys/iaStorAC.sys

## 为什么文档没有dump文件

这是诊断中最关键的线索：

1. RST驱动崩溃 → Windows触发BugCheck
2. 系统试图向磁盘写入dump文件
3. **但RST驱动已崩溃，NVMe控制器无法响应I/O请求**
4. dump写入失败 → Minidump目录为空，MEMORY.DMP不存在
5. Event 1001（BugCheck报告）也不会生成
6. 只有Event 41（Kernel-Power：未正常关机）被系统记录

**模式对应：Event 41 多 + Event 1001 无 + Minidump 空 = 存储驱动层崩溃（典型RST）**

## Intel Optane 应用的影响

即使没有配置Optane加速，以下组件也可能在后台运行：
- `RstMwService.exe` — RST Middleware 服务
- `RstHSA.Wpf.exe` — RST用户界面进程
- `AppUp.IntelOptaneMemoryandStorageManagement` — UWP应用

这些进程定期与RST驱动通信（Storage Command、Identify、Get Log Page等NVMe命令），可能在特定操作下触发驱动bug。

## 主板常见搭配

| 主板芯片组 | CPU架构 | 受RST影响 |
|------------|---------|-----------|
| Z690 | 12代 Alder Lake | 🔴 高 |
| B660 | 12代 Alder Lake | 🔴 高 |
| Z790 | 13/14代 Raptor Lake | 🟡 中（部分BIOS版本）|
| B760 | 13/14代 Raptor Lake | 🟡 中 |
| H610 | 12/13/14代 | 🟢 低（通常不用VMD）|

## 修复验证方法

更新驱动后验证是否解决：
```batch
# 查看当前驱动版本
wmic path Win32_PnPSignedDriver where "DeviceName like '%%Intel RST%%'" get DriverVersion
# 期望: >= 20.0.x

# 同时检查是否有对应System事件
wevtutil qe System /c:5 /f:text /q:"Event[System[(EventID=1001)]]"
# 期望: 无新BugCheck记录（已修复）
```
