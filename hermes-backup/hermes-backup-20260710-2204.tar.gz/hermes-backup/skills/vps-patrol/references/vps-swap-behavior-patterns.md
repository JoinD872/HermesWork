# VPS Swap 使用行为模式

本文件记录这台 2.4GiB RAM VPS 的 Swap 历史行为模式，帮助 patrol 区分「正常」和「异常」Swap 状态。

## VPS 硬件基线

| 参数 | 值 |
|------|-----|
| 物理内存 | 2.4GiB |
| Swap 分区 | 1.2GiB（/dev/vda3）|
| 长期运行进程 | Hermes Gateway (~400MiB / 15.8%), systemd-journald (~164MiB), fail2ban (~122MiB), tailscaled (~81MiB) |
| 典型 uptime | 60+ 天 |

## 正常 Swap 模式

**状态范围：** Swap 55–70%（约 660–850MiB / 1.2GiB）

**根因：** 内核在长时间运行（>30 天）后将不活跃进程的内存页换出到 Swap。这是 Linux 的正常行为，不是内存泄漏。

**特征：**
- Available 内存持续在 1.2–1.5GiB 之间（物理内存充裕）
- Swap 用量稳定或缓慢波动，不持续增长
- 进程列表中有长时间运行的大型守护进程（Hermes Gateway、journald、fail2ban）
- 无单进程异常占用 >25% 物理内存（Hermes Gateway ~15.8% 为正常基线）

**结论：** 无需处理。70% 以下的 Swap 配合 1.4GiB 可用内存是健康状态。

## 关注信号（Swap 需要排查）

| 信号 | 严重度 | 说明 |
|------|--------|------|
| Swap > 80% | 🟡 关注 | 接近 Swap 容量上限，可能导致 OOM |
| Swap 连续增长（3+ 次 patrol 持续上升）| 🟡 关注 | 可能有内存泄漏或新增异常进程 |
| Available < 500MiB + Swap > 70% | 🔴 严重 | 物理内存紧张，系统正在全面使用 Swap |
| 有进程占用 > 25% RSS | 🟡 关注 | 可能是旧版 gateway 残留（见 references/stale-high-memory-processes.md）|

## 历史快照

| 日期 | Swap | Available | Mem 已用 | 备注 |
|------|------|-----------|----------|------|
| 2026-06-05 | 976MiB (81%) | ~400MiB | 1.8GiB | openclaw-gateway 残留 861MB → 修复后降至 ~660MiB |
| 2026-06-07 | ~660MiB (55%) | ~1.5GiB | ~900MiB | 修复后基线 |
| 2026-07-04 | 850MiB (66%) | 1.4GiB | 1.0GiB | 正常范围，系统运行 61 天 |

## 快速诊断命令

```bash
# 检查 Swap 趋势
free -h | grep Swap

# 检查是否有旧版残留进程（>25% RSS 且无活跃连接）
ps aux --sort=-%mem | head -5

# 检查是否接近 OOM
cat /proc/sys/vm/min_free_kbytes
