# 高内存残留进程案例

## 发现记录（2026-06-05）

巡检发现 VPS swap 占用 976Mi/1.2Gi（81%），根因是 openclaw-gateway 残留进程。

### 进程详情

| 属性 | 值 |
|------|-----|
| 进程名 | openclaw-gateway |
| 类型 | Node.js 进程（/usr/bin/node） |
| PID | 249400 |
| 内存占用 | 861MB RSS（34% 物理内存） |
| 监听端口 | 127.0.0.1:18789（loopback 仅本机） |
| 活跃连接数 | **0**（`ss -tnp | grep 18789` 无结果） |
| 启动时间 | 2026-05-08（已跑 28 天） |
| 守护方式 | systemd --user 服务 |
| 软件版本 | OpenClaw Gateway v2026.4.14 |
| 现行替代 | Hermes Agent 自有 gateway（Python，218MB） |

### 识别模式

```
# 1. 发现异常大进程
ps aux --sort=-%mem | head -10

# 2. 如果是 gateway 类进程，检查活跃连接
ss -tnp | grep <port>

# 3. 检查是否为旧版/被替换的系统
cat /proc/<pid>/cmdline | tr '\0' ' '
systemctl --user status <service> 2>/dev/null
```

### 典型场景

- 旧版 AI gateway（如 OpenClaw）被 Hermes Agent 替换后未自动停止
- 升级后旧版服务进程残留
- 迁移过程中停服步骤被遗漏

### 修复方法

```bash
systemctl --user stop openclaw-gateway
systemctl --user disable openclaw-gateway
```

释放 ~861MB 物理内存，swap 使用率从 81% 降至接近 0。
