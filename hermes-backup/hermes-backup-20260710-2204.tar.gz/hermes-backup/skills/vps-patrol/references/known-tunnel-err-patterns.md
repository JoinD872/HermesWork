# 已知 Cloudflare Tunnel ERR 模式

本文件记录 VPS Cloudflare Tunnel 的已知/周期性 ERR 模式，帮助区分「已知条件」和「新发故障」。

## open.cloudjoind.com → localhost:18789

**出现频率**：每次 patrol 均有记录（持续性）
**症状**：
```
ERR error="Unable to reach the origin service. The service may be down or it may not be responding to traffic from cloudflared: dial tcp [::1]:18789: connect: connection refused"
```

**根因**：Tunnel 配置中有一项 `open.cloudjoind.com` 指向 `http://localhost:18789`，但该端口**无任何服务在监听**。这不是 nginx 或 cloudflared 本身的故障——是 tunnel 配置指向了一个不存在的 origin。

**诊断确认**：
```bash
# 检查 18789 是否有进程监听
ss -tlnp | grep 18789
# 若返回空 → 确认为已知条件，非新发故障
```

**采取行动**：无行动必要。Tunnel 整体健康度不受影响（其他 entry 如 proxy.cloudjoind.com 正常运行）。若用户需要，可清理 tunnel config 中的该 entry。

**历史**：首次发现于 2026-05-xx，多轮 patrol 均报告，持续为已知条件。

## 如何判断已知 vs 新发 ERR

| 特征 | 已知条件 | 新发故障 |
|------|---------|---------|
| ERR 文本 | `dial tcp [::1]:18789: connect: connection refused` | 其他端口或不同错误文本 |
| 影响范围 | 仅 `open.cloudjoind.com` 子域名 | 影响主入口 `proxy.cloudjoind.com` |
| nginx 状态 | ✅ 正常运行 | ❌ 可能已停止 |
| 出现频率 | 每次 patrol 都有 | 新出现，之前无此记录 |
