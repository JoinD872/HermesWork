---
name: hermes-internals
description: Hermes Agent 内部机制核心知识 — Frozen Snapshot Pattern、Session 管理/Reset 策略、Memory 三层模型（Session/Checkpoint/Memory）、字符限制、Skills 三级加载、视觉方案演变、DeepSeek 缓存架构
version: 1.2.0
metadata:
  hermes:
    tags: [hermes, internals, memory, session, skills, vision, caching, deepseek, opencode-go]
risk: read-only
---

# Hermes Internals

## ❄️ Frozen Snapshot Pattern（最重要）

**Session 期间对 MEMORY.md 的修改，下个 session 才生效。**

> "The system prompt injection is captured once at session start and never changes mid-session. When the agent adds/removes memory entries during a session, the changes are persisted to disk immediately but won't appear in the system prompt until the next session starts."

**实际影响**：
- `memory` 工具的 add/replace 操作 → disk 立即写入，下次 session 生效
- 我现在 session 里更新的记忆，刷新页面/重连后才能在 prompt 里看到
- 每次 session 开始时 prompt 里显示的 `%` 利用率是**上个 session 结束时**的快照

## 🔄 Session 管理机制

### Session 生命周期

```
用户发消息 → get_or_create_session() 检查 session 是否存在
  ├ 存在且有效 → 继续当前 session
  ├ 存在但过期 → 自动 reset，开新 session
  └ 不存在 → 创建新 session
```

### Session Reset 策略

配置在 `config.yaml / gateway.json` 的 `session_reset` 段：

| mode | 行为 | 默认 |
|------|------|------|
| `none` | 永不过期，仅靠压缩管理上下文 | **当前默认**（2026年7月从 both 改为 none） |
| `idle` | 闲置 N 分钟后 reset（默认 1440min=24h） | |
| `daily` | 每天特定时间 reset（默认 4:00） | |
| `both` | 两者取先触发 | 旧默认 |

### 只有以下情况才会开新 session

1. **用户显式 `/new` 或 `/reset`** — gateway 层拦截，agent 收不到这条消息
2. **Gateway 重启后 `gateway_auto_continue_freshness`（默认 3600s=1h）超时** — 旧 session 标记为 stale，下条消息开新的
3. **上下文压缩** — 内部切子 session，但对用户透明
4. **配置了 daily/idle reset** — 按策略自动 reset

### 关键限制：agent 不能触发 /new

`/new` 在 gateway 层被截获，当前 agent（LLM）看不到这条消息，也**无法在执行过程中触发 session reset**。

### Checkpoint 工作流（当前推荐方案）

因 agent 无法自触发 `/new`，需要用户配合的 checkpoint 机制：

```
你说"新问题"或"保存进度"
  ↓ 我写 projects/<name>/checkpoint.md
  ↓ 我告诉你已保存，请你发 /new
  ↓ 你发 /new
  ↓ 新 session 启动，我读 checkpoint 继续
```

### Session/Checkpoint/Memory 三层模型

| 层 | 持久性 | 内容 | 管理方式 |
|----|--------|------|---------|
| **Session** | 临时 | 当前讨论、推理过程、临时方案、调试日志 | /new 后消失 |
| **Checkpoint** | 文件级 | 项目状态、当前进展、决策记录 | 写入 `projects/<name>/checkpoint.md` |
| **Memory** | 永久（注入 system prompt） | 稳定环境信息、长期偏好、不变配置 | `memory` 工具，受 memory-governance 约束 |

详见 `hermes/memory-governance`（三层分类法）和 `hermes/memory-hygiene`（过期/验证/容量/清理）。

详见 `references/session-management.md`（代码级 session 创建路径、/new 处理流程、检查命令）。

## 📏 Memory 字符限制（bounded memory）

- `MEMORY.md` 上限：**5,000 chars**（config: `memory_char_limit: 5000`）
- `USER.md` 上限：**2,750 chars**（config: `user_char_limit: 2750`）
- 满了会自动 consolidation（合并/替换旧记忆）
- 当前利用率在每次 session 启动时显示，如：`[67% — 1,478/2,200 chars]`

**记忆必须精简**，不能往里塞大量原始内容。

详见 `hermes/memory-governance`（记忆写入纪律：三层分类法）和 `hermes/memory-hygiene`（过期/验证/容量管理）。

## 📚 Skills 三级加载（Progressive Disclosure）

```
Level 0: skills_list() → [{name, description, category}, ...] (~3k tokens)
Level 1: skill_view(name) → 完整内容 + metadata（实际使用时才加载）
Level 2: skill_view(name, path) → 具体引用文件（最细粒度）
```

agent 调用 skill 时按需加载，不是全量加载。

## 🆕 Skills 新字段（我的 skills 缺的）

SKILL.md 支持但我目前没用到的字段：

```yaml
platforms: [macos, linux]        # OS 限制
metadata:
  hermes:
    fallback_for_toolsets: [web]  # 条件激活
    requires_toolsets: [terminal]  # 依赖条件
    config:                        # 安装时用户配置
      - key: my.setting
        description: "..."
        default: "value"
        prompt: "Prompt for setup"
```

## 🗂️ OpenClaw 迁移状态

**重要发现**：OpenClaw workspace 文件夹没有自动迁移。

```
OpenClaw 旧数据:  ~/.openclaw/workspace/knowledge/
  deep-learning.md   ← 还在这里！
  network.md         ← 还在这里！

Hermes skills:      ~/.hermes/skills/knowledge/  ← 不存在，未迁移
```

如果要从 OpenClaw 迁移 knowledge 文件，需要手动复制到 `~/.hermes/skills/`。

迁移命令 `hermes claw migrate` 只迁移人格/记忆/技能/消息配置/凭据，不迁移 workspace 普通文件。

## 🖼️ 视觉识别（2026-07-08 更新 — OpenCode Go 迁移）

**当前方案（全部走 OpenCode Go 订阅，零额外成本）**：

| 方式 | 模型 | provider | 说明 |
|------|------|---------|------|
| `vision_analyze` tool（主路径） | `minimax-m3` | `custom:opencode-go` → OpenAI 格式 | Go 订阅内，cost=0 |
| 备用 | `gpt-4o` | GitHub Models（免费） | 仅当 Go 不可用时降级 |

**不再使用**：
- DeepSeek V4 Flash 原生视觉（用户要求非订阅付费 API 不用）
- Volcengine Ark doubao（网络不通）
- MiniMax MCP understand_image（平台 404）

**OpenCode Go 配置关键点**：

```
base_url: https://opencode.ai/zen/go/v1
key_env: OPENCODE_GO_KEY  （在 ~/.hermes/.env 中）
主模型: deepseek-v4-flash
视觉模型: minimax-m3
```

`minimax-m3` 支持视觉输入，但需注意：
- 走 OpenAI 格式的 `/v1/chat/completions` 即可（不需切 Anthropic 格式）
- 通过 Go 订阅测试通过：`"Blonde girl, futuristic blue suit."`

Go 可用模型共 20 个，其中支持视觉的已验证：`minimax-m3`（通过 Anthropic 和 OpenAI 双格式）。`mimo-v2-omni` 理论上支持但当前返回 500（上游问题）。

**VPS 视觉模型配置方案汇总**（截至 2026-07-08）：

| 层 | 模型 | 配置方式 | 成本 |
|----|------|---------|------|
| 🥇 主力 | Go minimax-m3 | `auxiliary.vision` → `custom:opencode-go` | Go 订阅已付 |
| 🥈 备用 | GitHub Models gpt-4o | 直接写 api_key（不走 key_env，防 Copilot handler） | 免费 |
| ❌ 停用 | DeepSeek V4 Flash 直连 | `fallback_providers` 保留但用户要求不用 | 付费 API |

### 视觉模型配置避坑

#### GitHub Models（ghp_ prefix 触发 Copilot handler）
GitHub 经典 PAT（`ghp_*`）会在 Hermes provider 解析时触发 Copilot OAuth 检测，导致 provider 被重写为 `copilot` 并返回 `client=None`。解决方案：**直接写 `api_key` 字段到 config.yaml**，不走 `key_env`。

#### OpenCode Go（provider 格式）
`custom:opencode-go` 格式在 `resolve_vision_provider_client()` 中可能解析失败（同样的 Copilot handler 问题）。用显式 `base_url` + `api_key` + `provider: custom` 代替。

**`vision_analyze` 机制**（底层不变）：有两层路径

1️⃣ **原生 fast path**（当前未使用，因主模型已切到 Go）
- 条件：`_should_use_native_vision_fast_path()` 返回 `True`
- 行为：下载图片 → base64 → 构建 `_multimodal` tool-result 信封 → 嵌入主模型上下文
- 适用：Anthropic、OpenAI、Gemini 3.x、任何设置 `model.supports_vision: true` 的 provider

2️⃣ **辅助 LLM 路径**（当前使用，Go minimax-m3）
- 通过 `resolve_vision_provider_client()` 获取辅助视觉客户端
- 路由链：`auxiliary.vision` 配置 → fallback auto → fallback OpenRouter → fallback Nous

## 💾 DeepSeek 缓存架构（关键知识）

DeepSeek 的 Context Caching on Disk 是**服务端自动触发**的 byte 级前缀匹配缓存，无需 API 标记。

### 与 Hermes 交互的关键点

| 模块 | 状态 | 代码位置 |
|------|------|---------|
| `_cached_system_prompt` 会话内 frozen | ✅ 正确 | `run_agent.py:6056-6281` |
| 工具 schema 通过 `tools` 参数传递（不在 system prompt 文本中） | ⚠️ 常被误解 | `run_agent.py:10025-10028` |
| `_format_tools_for_system_message()` 只用于 trajectory | ⚠️ 容易误认 | `run_agent.py:4803-4825` |
| `/compress` → 必然破坏缓存 | 权衡（防 OOM > 缓存） | `run_agent.py:10722-10724` |
| `_deterministic_call_id` 防 UUID 破坏缓存 | ✅ 已做 | `run_agent.py:6655-6663` |
| `extract_cache_stats()` 读缓存统计 | 取决于 DeepSeek 是否返回字段 | `chat_completions.py:615-627` |

详见 `references/deepseek-caching.md`（含完整机制说明、代码位置索引、常见误解纠正、实测数据、跨频道缓存共享分析）

## ⚠️ OpenCode Go / 自定义 Provider 配置陷阱

详见 `references/provider-pitfalls.md`（key_env auxiliary 中不生效、Go 不支持闭源模型、provider:auto+显式base_url不兼容、视觉模型兼容性等踩坑记录）。

## 🔬 缓存诊断工作流（2026-05-17 实测验证）

当需要验证 DeepSeek（或其他 OpenAI 兼容 provider）的缓存是否生效时：

### 1. 确认 toolsets 一致
```python
from model_tools import get_tool_definitions
tools = get_tool_definitions(enabled_toolsets=["hermes-cli", "browser"], quiet_mode=True)
names = sorted(t["function"]["name"] for t in tools)
```
- `registry.get_definitions()` 内部用 `sorted(tool_names)` — 注册顺序跨会话稳定
- 各 profile 的 toolsets 必须完全一致，否则 system prompt 中的 skills 索引不同 → 前缀不同

### 2. 运行 `--verbose` 观察缓存统计
```bash
hermes chat -q "调用一次工具任务" --verbose
```
关键日志行：
```
API Response received - Model: deepseek-v4-flash
  Usage: CompletionUsage(..., prompt_tokens=20225, ...,
    prompt_tokens_details=PromptTokensDetails(cached_tokens=640),
    prompt_cache_hit_tokens=640,
    prompt_cache_miss_tokens=19585)
```

### 3. 解读缓存数据

| 轮次 | 典型命中率 | 说明 |
|------|-----------|------|
| 第 1 轮（冷启动）| ~3% | 仅共享前缀（默认 SOUL.md 路由规则 ~2.1KB 中已被缓存的部分）|
| 第 2 轮（同会话）| **~100%** | system prompt + 历史全部命中，仅新增 tool result 未命中 |
| 跨频道同 profile | 共享 ~2.1KB 前缀 | 频道独有 SOUL.md 需各自冷却 |

实测数据（2026-05-17, deepseek-v4-flash）：
```
Call #1: cache=640/20225 (3% hit) — cold start
Call #2: cache=20352/20420 (100% hit) — prefix fully cached, only 68 miss tokens
```

### 4. 跨频道缓存共享模型

各频道（小策/黑翼/小研/老V）运行在同一 default profile 下，共享：
```
[default SOUL.md (2.1KB, 路由规则)]  ← 所有频道共享
[per-profile SOUL.md (3.5-4.3KB)]    ← 频道独有
[per-profile MEMORY.md (0.4-3KB)]    ← 频道独有
[volatile: timestamp + memory snap]  ← 每次 session 不同
```

Feishu adapter：per-profile SOUL.md + MEMORY.md 通过 `channel_prompt` 机制注入为 `ephemeral_system_prompt`，拼接到 `_cached_system_prompt` 尾部（`feishu.py:2258-2285`）。详见 `hermes-per-channel-profile-injection` skill。

### 5. 失败模式速查

| 现象 | 原因 |
|------|------|
| 全程 0% 命中 | toolsets 不一致 / provider 不支持缓存 |
| 第 2 轮仍 < 50% | system prompt 在轮次间被重建（检查是否切换模型/重载工具）|
| 跨频道 < 10% 共享 | 频道独有 SOUL.md 不同 → 前缀从该处开始分叉 |
| 压缩后 0% | 必然行为（见 `_invalidate_system_prompt`），压缩和缓存不可兼得 |

## 💰 费用追踪

Hermes TUI 层内置 `show_cost` 配置项（当前 `config.yaml: show_cost: false`），但实际计费追踪需要对接 provider 的余额 API。

另见独立 skill `api-cost-tracking`（含 DeepSeek 余额 API 实现、V4 Flash/V4 Pro 定价表、人民币计价报告格式）。