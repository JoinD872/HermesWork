# OpenCode Go / 自定义 Provider 配置坑点

## 坑 1：key_env 在 auxiliary 中不生效

**问题**：`custom_providers` 中配置了 `key_env: OPENCODE_GO_KEY`，但 `auxiliary.vision` 和 `auxiliary.compression` 引用时，provider 解析失败。

**原因**：`custom:opencode-go` 格式在 `resolve_vision_provider_client()` 中被 Copilot handler 拦截（ghp_ 前缀触发 PAT 检测），导致 provider 被重写为 `copilot`，返回 `client=None`。

**修复**：在 `auxiliary.xxx` 中显式填写 `base_url` 和 `api_key`，不走key_env：
```yaml
auxiliary:
  vision:
    provider: custom        # 不要用 custom:opencode-go
    model: minimax-m3
    base_url: https://opencode.ai/zen/go/v1
    api_key: sk-b6C...      # 直接写
```

## 坑 2：Go 订阅不支持 gpt-4o 等闭源模型

**问题**：将辅助模型设为 `gpt-4o` 时压缩报 401："Model gpt-4o is not supported"。

**原因**：OpenCode Go 只有开源/开放模型（deepseek-v4-flash, minimax-m3, qwen3.7-max, glm-5.2 等），没有 gpt-4o、Claude 等闭源模型。

**修复**：使用 Go 支持的模型，如：
```
compression → deepseek-v4-flash
vision      → minimax-m3
```

## 坑 3：`provider: auto` + 显式 base_url 不兼容

**问题**：`provider: auto` 自身会遍历所有可选 provider，和显式 `base_url` 语义冲突。

**修复**：显式指定 `provider: custom` + 具体 `base_url` + `api_key`，不要用 `auto`。

## 坑 4：Go 视觉模型选择有限

已验证的 Go 视觉模型：
- ✅ **minimax-m3** — 通过 OpenAI 格式 `/v1/chat/completions` 和 Anthropic 格式 `/v1/messages` 双验证可用
- ❌ **mimo-v2-omni** — 名称暗示 multimodal，但返回 500（上游问题）
- ❌ **glm-5.2 / qwen3.7-max / kimi-k2.7-code / deepseek-v4-pro** — 均不支持 image input

## 坑 5：主模型系统 prompt 的 supports_vision

当主模型 provider 不支持视觉时（如 Go 的 deepseek-v4-flash 通过 Go 的 OpenAI 代理不支持图片），需关闭：
```yaml
model:
  supports_vision: false
  image_input_mode: text
```
否则主模型会尝试 native vision fast path 并失败。

## 汇总：Go 订阅推荐配置

| 用途 | provider | model | key |
|------|----------|-------|-----|
| 主模型 | `custom:opencode-go` 或 `custom` | `deepseek-v4-flash` | `OPENCODE_GO_KEY` |
| 辅助视觉 | `custom` + 显式 base_url + api_key | `minimax-m3` | 直接写入 config.yaml |
| 辅助压缩 | `custom` + 显式 base_url + api_key | `deepseek-v4-flash` | 直接写入 config.yaml |
| 备用视觉 | `custom` + 显式 base_url + api_key | `gpt-4o`（仅 GitHub Models） | 直接写入 config.yaml（不走 key_env 防 Copilot 拦截）|
