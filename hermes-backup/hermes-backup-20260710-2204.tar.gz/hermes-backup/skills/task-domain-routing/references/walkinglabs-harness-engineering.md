# Learn Harness Engineering — 课程要点摘录

来源：https://github.com/walkinglabs/learn-harness-engineering
中文版：docs/zh/lectures/
5531 stars, 12 lectures, 6 projects

## 核心论点

模型再聪明，没有好的 Harness（环境/状态/验证/控制）就不可靠。

Anthropic 对照实验：同一模型（Opus 4.5），同一提示（"构建2D复古游戏编辑器"）：
- 无 Harness：20 分钟 $9 → 废品
- 有 Harness（规划器+生成器+评估器）：6 小时 $200 → 可玩游戏

模型没变，变的是 Harness。

## 12 讲大纲

| 讲 | 主题 | 核心观点 |
|----|------|---------|
| 01 | 为什么有能力的 Agent 还是失败 | 不是模型问题，是环境问题 |
| 02 | Harness 到底是什么 | 5 个子系统：指令/状态/验证/范围/会话生命周期 |
| 03 | 仓库即规范 | 所有上下文必须在仓库中结构化管理 |
| 04 | 一个大指令文件为什么失败 | 渐进式披露 vs 巨量提示词 |
| 05 | 跨会话连续性 | 状态持久化 + 显式恢复路径 |
| 06 | 初始化需要自己的阶段 | init.sh 等启动检查 |
| 07 | Agent 贪多嚼不烂 | 范围控制：WIP=1，一次一个功能 |
| 08 | Feature List 是 Harness 原语 | 结构化的进度追踪 |
| 09 | 提前宣告完成 | 三层终止检查：lint→测试→端到端 |
| 10 | 端到端测试改变结果 | 只有跑通过的才算数 |
| 11 | 可观测性属于 Harness | 日志/指标/追踪内置 |
| 12 | 会话必须留下干净状态 | 清理+交接说明 |

## 5 个 Harness 子系统

1. **指令（Instructions）**：AGENTS.md / CLAUDE.md / 渐进式披露结构
2. **状态（State）**：progress.md / feature_list / git log → 持久化到磁盘
3. **验证（Verification）**：测试 / lint / 类型检查 / 冒烟测试
4. **范围（Scope）**：一次一个功能，不越界，不重写功能列表隐藏问题
5. **会话生命周期（Session Lifecycle）**：开始时 init.sh，结束时清理检查清单

## 三句箴言

> 模型决定写什么代码，HARNESS 管控何时、何地以及如何写。
> Harness 不会让模型更聪明，它让模型的输出更可靠。
> 写得越多，完成得越少（贪多嚼不烂，数据为证）。
