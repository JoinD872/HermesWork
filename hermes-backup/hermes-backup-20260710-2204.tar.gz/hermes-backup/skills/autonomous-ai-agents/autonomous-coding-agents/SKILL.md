---
name: autonomous-coding-agents
description: Spawn external autonomous coding agents from the terminal — Claude Code (Anthropic), Codex (OpenAI), OpenCode (open source). PR review, parallel worktrees, session management, cost monitoring. One umbrella for all CLI coding agents.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [coding-agent, claude-code, codex, opencode, autonomous, refactoring, pr-review]
    related_skills: [github-pr-workflow, github-code-review, systematic-debugging]
risk: write-dangerous
---

# Autonomous Coding Agents

Delegate coding tasks to external CLI agents. This umbrella covers three tools for the same job: spawning an autonomous coding agent that reads, writes, runs commands, and manages git.

## Decision Table: Which Agent to Use

| Factor | Claude Code | Codex | OpenCode |
|--------|-------------|-------|----------|
| **Backend** | Anthropic Claude | OpenAI (GPT-5.5) | Provider-agnostic (OpenRouter, etc.) |
| **Auth** | OAuth or ANTHROPIC_API_KEY | ChatGPT Plus tokens or OPENAI_API_KEY | Any provider key |
| **Install** | `npm i -g @anthropic-ai/claude-code` | `npm i -g @openai/codex` | `npm i -g opencode-ai` |
| **One-shot mode** | `-p` flag | `exec` subcommand | `run` subcommand |
| **PTY needed** | TUI needs tmux; `-p` works without | Needs pty | `run` works without pty; TUI needs pty |
| **Cost model** | API billing (~$0.05+ per session) | ChatGPT Plus ($20/mo included) | Your provider's billing |
| **Best for** | Heavy multi-turn coding | Cost-effective all-purpose | Provider flexibility |

See the full reference docs for each:
- `references/claude-code.md` — Full Claude Code CLI reference
- `references/codex.md` — Full Codex CLI reference + usage rules
- `references/opencode.md` — Full OpenCode CLI reference

## Common Patterns

### PR Review (any agent)

```bash
# Create a temp review environment
REVIEW=$(mktemp -d)
git clone --depth 1 https://github.com/user/repo.git $REVIEW
cd $REVIEW
git fetch origin pull/42/head:pr-42
git checkout pr-42
# Now run agent-specific review command
```

### Parallel Worktrees (any agent)

```bash
git worktree add -b fix/issue-78 /tmp/issue-78 main
git worktree add -b fix/issue-99 /tmp/issue-99 main
# Launch separate agent sessions in each worktree
```

### Session Management

- All agents store session history locally (~/.claude/sessions/, ~/.codex/sessions/, ~/.opencode/sessions/)
- Sessions auto-expire (Claude Code: 5h; Codex: varies)
- Use `--continue` or `--resume <id>` to reconnect to previous sessions

### Cost & Performance

- Always set `--max-turns` (or equivalent) to prevent runaway loops
- For simple tasks, use cheaper models (Claude Haiku, Codex default)
- For reviews/analysis only, restrict tool permissions (`--allowedTools "Read"`)
- Use `--bare` (Claude Code) or `--yolo` (Codex) for CI/automation to skip interactive dialogs

## Pitfalls (All Agents)

1. **Require a git repo** — Codex and OpenCode refuse to run outside one. Claude Code warns but continues.
2. **Session costs accumulate** — each session has a base context cost (~$0.05). Start fresh for distinct tasks.
3. **PTY or tmux required for interactive** — one-shot commands work without; multi-turn sessions need a terminal wrapper.
4. **PATH mismatch** — the agent's shell may resolve different binaries. Verify with `which -a`.
5. **Cleanup** — always clean up worktrees (`git worktree remove`) and kill leftover processes (tmux, background agents).

## Verification

Smoke-test any newly installed agent:

```bash
# Claude Code
claude -p "Respond with: CLAUDE_SMOKE_OK" --allowedTools "Read" --max-turns 1

# Codex
codex exec "Respond with: CODEX_SMOKE_OK"

# OpenCode
opencode run "Respond with: OPENCODE_SMOKE_OK"
```
