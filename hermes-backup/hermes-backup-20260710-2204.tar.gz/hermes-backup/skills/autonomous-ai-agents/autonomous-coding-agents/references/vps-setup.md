# VPS Codex Setup (RackNerd, LA)

**Verified:** 2026-05-25

## Installation

```
which codex        → /usr/bin/codex
npm list -g @openai/codex  → @openai/codex@0.125.0
```

Symlink: `/usr/bin/codex → ../lib/node_modules/@openai/codex/bin/codex.js`

## Authentication

**Mode:** `chatgpt` (ChatGPT Plus tokens, NOT API key)

Config: `~/.codex/auth.json`
```json
{
  "auth_mode": "chatgpt",
  "OPENAI_API_KEY": null,
  "tokens": {
    "id_token": "...",
    "access_token": "...",
    "refresh_token": "...",
    "account_id": "326952f0-..."
  }
}
```

Tokens auto-refresh. No `OPENAI_API_KEY` env var needed — the user's ChatGPT Plus subscription covers it.

## Model

GPT-5.5 (confirmed in `~/.codex/config.toml` via `[tui.model_availability_nux] "gpt-5.5" = 1`).

## Config

`~/.codex/config.toml`:
```toml
[projects."/root"]
trust_level = "trusted"

[tui.model_availability_nux]
"gpt-5.5" = 1
```

## Usage Pattern

- Requires `pty=true` in terminal calls
- Requires a git repo (use `mktemp -d && git init` for scratch)
- Sandbox mode: `--full-auto` for workspace-write; `--yolo` for no restrictions
