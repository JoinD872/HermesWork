# Codex 协作案例：VPS 网络优化（2026-05-26）

本案例展示了 Codex 多轮收敛模式在真实任务中的完整流程。

## 任务背景

用户要求优化 VPS 网络性能。VPS 为 RackNerd 洛杉矶机房，2核/2.4GB/43GB，运行 Xray（VLESS+WS+CF Tunnel）、nginx、Docker、cloudflared、Tailscale。

## 完整流程

### 第一轮：小H出方案

小H 先独立检查了系统状态：BBR 已启用 ✅，但发现 RPS 关闭、TCP Fast Open 未启用、ulimit 过低（1024）、`tcp_slow_start_after_idle` 未优化。出了 6 条优化建议。

### 第二轮：Codex 评审

小H 调用 Codex 评审方案：

```
codex exec "Review this VPS network optimization plan..."
```

Codex 返回逐条评审（见下面关键发现）。

### 第三轮：小H收敛 + 实测诊断

根据 Codex 的反馈，小H：
- 撤回了 RPS 优化（Codex 指出双核 VPS 上可能增加缓存开销，实测 CPU 软中断已均衡）
- 撤回了 TCP Fast Open（Codex 指出对吞吐量帮助有限）
- 撤回了 TCP 缓冲区调整（Codex 指出 2.4GB 内存经不起造）
- 补充了 `ip_local_port_range` 和 `tcp_max_syn_backlog`（Codex 建议的）
- 先做了多节点速度测试（发现真实带宽 ~53 Mbps，不是 kernel 瓶颈）

### 第四轮：执行 + 验证

最终只落了 4 条低风险 sysctl，零网络足迹变化。验证端口清单、外部连通性均正常。

## Codex 评审的关键发现

| 小H 原方案 | Codex 评审结论 | 最终决策 |
|-----------|---------------|---------|
| 开启 RPS | 双核可能增加缓存开销，先查 NET_RX | ❌ 撤回（已验证 NET_RX 已均衡）|
| 开启 TCP Fast Open | 只改善握手延迟，不改善吞吐量 | ❌ 撤回 |
| TCP 缓冲区调大 | 2.4GB 内存可能内存压力 | ❌ 撤回 |
| 提升 ulimit | 正确，但需要 systemd 服务级修改 | ⚠️ 确认但暂缓 |
| — | **补充** ip_local_port_range 扩到 10000-65535 | ✅ 执行 |
| — | **补充** tcp_max_syn_backlog 提到 8192 | ✅ 执行 |
| tcp_slow_start_after_idle=0 | 合理 | ✅ 执行 |
| tcp_mtu_probing=1 | 合理 | ✅ 执行 |

## 经验教训

1. **先测速再调优** — 原始方案假设瓶颈在内核参数，实测发现带宽 ~53 Mbps 已是 RackNerd 套餐上限，sysctl 调了也提不了多少
2. **CPU steal 查了再动手** — 本机 steal=0%，宿主机没超售，排除了最坏情况
3. **多节点测试很重要** — 首次只测了一个节点（2.4 MB/s），多测后才发现是端点问题，不是 VPS 带宽
4. **风控优先于性能** — 用户明确要求不改端口、不加服务、不暴露直连 IP，这决定了 REALITY 节点等方案不可行

## 最终结果

用户评价："很好。这次碰撞确实比单独用小H强。"
