# Claude Code CLI Reference

## Overview

Anthropic's autonomous coding agent CLI. V2.x reads files, writes code, runs shell commands, spawns subagents, manages git.

## Installation & Auth

```bash
npm install -g @anthropic-ai/claude-code
claude auth login                    # Browser OAuth
claude auth login --console          # API key billing
claude --version                     # Verify v2.x+
```

## Print Mode (One-Shot, Preferred)

```bash
claude -p "Add error handling to all API calls in src/" --allowedTools "Read,Edit" --max-turns 10
```

Key flags: `-p` (print mode), `--output-format json`, `--max-turns N`, `--max-budget-usd N`, `--allowedTools`, `--dangerously-skip-permissions`, `--bare` (fastest startup), `--fallback-model haiku`

### Structured JSON Output

```bash
claude -p 'Refactor auth.py' --output-format json --max-turns 5
```
Returns `{ type, subtype, result, session_id, num_turns, total_cost_usd, usage }`.

### Piped Input

```bash
cat src/auth.py | claude -p 'Review this code for bugs' --max-turns 1
git diff HEAD~3 | claude -p 'Summarize these changes'
```

### Session Continuation

```bash
# Continue most recent session in this directory
claude -p 'Continue the refactor' --continue

# Resume by session ID
claude -p 'What did you do?' --resume <session-id>
```

## Interactive Mode (via tmux)

```bash
tmux new-session -d -s claude-work -x 140 -y 40
tmux send-keys -t claude-work 'cd /project && claude' Enter
sleep 5 && tmux send-keys -t claude-work Enter              # Trust dialog
sleep 3 && tmux send-keys -t claude-work Down Enter         # Permissions dialog
tmux send-keys -t claude-work 'Refactor auth to JWT' Enter
sleep 15 && tmux capture-pane -t claude-work -p -S -50     # Monitor
tmux send-keys -t claude-work '/exit' Enter                 # Exit
```

## Key CLI Flags

| Flag | Effect |
|------|--------|
| `-p, --print` | Non-interactive one-shot mode |
| `-c, --continue` | Resume most recent conversation |
| `-r, --resume <id>` | Resume specific session |
| `--fork-session` | Create new session ID when resuming |
| `--model <name>` | `sonnet`, `opus`, `haiku` |
| `--effort <level>` | `low`, `medium`, `high`, `max`, `auto` |
| `--max-turns <n>` | Limit agentic loops (print mode only) |
| `--max-budget-usd <n>` | Cap API spend |
| `--dangerously-skip-permissions` | Auto-approve ALL tool use |
| `--allowedTools <tools>` | Whitelist specific tools |
| `--disallowedTools <tools>` | Blacklist specific tools |
| `--output-format <fmt>` | `text`, `json`, `stream-json` |
| `--json-schema <schema>` | Force structured JSON output |
| `--bare` | Skip hooks, plugins, MCP, CLAUDE.md |
| `--append-system-prompt <text>` | Add to system prompt |
| `--worktree` | Run in isolated git worktree |
| `--from-pr <number>` | Resume session linked to a PR |

### Tool Name Syntax for --allowedTools

```
Read                    # All file reading
Edit                    # File editing (existing)
Write                   # File creation (new)
Bash                    # All shell commands
Bash(git *)             # Git commands only
WebSearch               # Web search
mcp__server__tool       # MCP tools
```

## Slash Commands (Interactive)

| Command | Purpose |
|---------|---------|
| `/help` | Show all commands |
| `/compact [focus]` | Compress context to save tokens |
| `/clear` | Wipe conversation history |
| `/context` | Visualize context usage |
| `/cost` | View token usage breakdown |
| `/review` | Request code review of current changes |
| `/security-review` | Security analysis |
| `/plan [desc]` | Enter Plan mode |
| `/model [model]` | Switch models mid-session |
| `/effort [level]` | Set reasoning effort |
| `/init` | Create CLAUDE.md |
| `/exit` or `Ctrl+D` | End session |

## Hooks — Automation on Events

Configure in `.claude/settings.json`:

```json
{
  "hooks": {
    "PostToolUse": [{
      "matcher": "Write(*.py)",
      "hooks": [{"type": "command", "command": "ruff check --fix $CLAUDE_FILE_PATHS"}]
    }]
  }
}
```

## CLAUDE.md — Project Context

Claude Code auto-loads `CLAUDE.md` from project root. Be specific about architecture, commands, and standards.

## Custom Subagents

Define in `.claude/agents/*.md`:
```markdown
---
name: security-reviewer
model: opus
tools: [Read, Bash]
---
You are a senior security engineer. Review code for vulnerabilities.
```

## Cost Tips

- Use `--max-turns` to prevent runaway loops (start with 5-10)
- Use `--effort low` for simple tasks
- Use `--allowedTools` to restrict capabilities
- Use `--model haiku` for cheap tasks
- Pipe input instead of having Claude read files
- Use `/compact` in interactive sessions at >70% context usage
- Use `--no-session-persistence` in CI

## Pitfalls

1. Interactive mode REQUIRES tmux — Claude Code is a full TUI app
2. `--dangerously-skip-permissions` dialog defaults to "No, exit" — send Down then Enter
3. Closes issues with referenced keywords (Closes/Fixes/Resolves #N)
4. Session resumption requires same working directory
5. Background tmux sessions persist — clean up with `tmux kill-session -t <name>`
6. Context degrades above 70% usage — use `/compact` proactively
