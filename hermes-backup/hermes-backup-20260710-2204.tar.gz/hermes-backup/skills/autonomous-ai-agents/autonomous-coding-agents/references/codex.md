# Codex CLI Reference

## Overview

OpenAI's autonomous coding agent CLI. Uses GPT-5.5 via ChatGPT Plus ($20/mo) or API key billing.

## Installation & Auth

```bash
npm install -g @openai/codex
# If using ChatGPT Plus (no API key needed):
# Codex auto-stores tokens in ~/.codex/auth.json with auth_mode: "chatgpt"
# If using API key: set OPENAI_API_KEY env var
```

**Must run inside a git repository.** For scratch work: `cd $(mktemp -d) && git init`.

## One-Shot Tasks

```bash
codex exec 'Add dark mode toggle to settings'
```

For scratch work outside a repo:
```bash
codex exec 'Build a snake game in Python' --workdir $(mktemp -d)
```

## Background Mode (Long Tasks)

```bash
terminal(command="codex exec --full-auto 'Refactor the auth module'", workdir="~/project", background=true, pty=true)
# Returns session_id
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")
process(action="submit", session_id="<id>", data="yes")
process(action="kill", session_id="<id>")
```

## Key Flags

| Flag | Effect |
|------|--------|
| `exec "prompt"` | One-shot execution, exits when done |
| `--full-auto` | Sandboxed but auto-approves file changes |
| `--yolo` | No sandbox, no approvals (fastest, most dangerous) |

## PR Reviews

```bash
REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW
cd $REVIEW && gh pr checkout 42
codex review --base origin/main
```

## Parallel Worktrees

```bash
git worktree add -b fix/issue-78 /tmp/issue-78 main
codex --yolo exec 'Fix issue #78. Commit when done.' --workdir /tmp/issue-78
```

## Usage Rules

### 1. Default workflow: draft v0 → Codex → v1

**Do not produce output to the user before Codex has seen it.** My draft is always v0. Codex reviews/iterates before it reaches v1.

Flow: 用户需求 → 我出draft v0 → Codex审查/碰撞 → 我收敛成v1 → 输出给用户

The core value of Codex is **a different perspective** — it catches blind spots I would never catch even on a second review.

**Pre-commit checklist:**
- [ ] Has Codex seen this?
- [ ] Is this a plan/proposal/decision about what to do?
- [ ] Am I gating Codex into "coding only"?

### 2. "Plan decision" fallacy

A **plan** I intend to propose = output → Codex must see it first.
A **diagnosis** of what's wrong = output → Codex must see it first.
A **decision** between approaches = output → Codex must see it first.

**Stop before typing "we should..."** — delegate to Codex first.

### 3. Always verify before answering

Check `which codex && codex --version && cat ~/.codex/auth.json | python3 -c "import json,sys; d=json.load(sys.stdin); print('auth:', d.get('auth_mode'))"` — don't reason from general knowledge.

### 4. Privacy

Codex CLI has no separate privacy setting. Control is in ChatGPT Settings → Data Controls → Improve the model for everyone → OFF. Session history is local in `~/.codex/sessions/`.

## Pitfalls

- `--reasoning-effort` flag NOT supported in Codex v0.133.0
- Check `which codex` and `npm list -g @openai/codex` before claiming it needs setup
- On this VPS: installed at `/usr/bin/codex`, uses ChatGPT Plus tokens
- When user says your analysis is wrong → delegate to Codex immediately with full context
