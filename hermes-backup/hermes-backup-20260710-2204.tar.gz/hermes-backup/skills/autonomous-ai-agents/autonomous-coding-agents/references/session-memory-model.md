# Codex 会话与记忆模型

> 最后更新：2026-05-26
> 来源：实测 Codex CLI 0.133.0

## 核心结论

**Codex 没有持久记忆（persistent memory）。** 每次 `exec` 调用都是全新会话，不知道你的偏好、不知道 Hermes skill 库、不知道之前的协作约定。

## 能力矩阵

| 能力 | Codex | Hermes |
|------|-------|--------|
| 跨会话记忆 | ❌ 无 | ✅ MEMORY.md 自动注入 |
| 单 exec 上下文 | ✅ 当前调用的完整上下文 | ✅ 连续对话 |
| TUI 回溯 | ⚠️ `resume --last` 可回滚最近一次交互式会话 | ✅ 自动保持 |
| 长期知识沉淀 | ❌ 无 skill/memory 系统 | ✅ skill + memory |
| exec 间关联 | ❌ 每次独立 | ✅ 连续 |

## 执行模式区别

### `codex exec "xxx"`（当前模式）
- 每次调用全新会话
- 完全不知道外部上下文
- 需要手动在 prompt 中喂背景

### `codex resume --last`
- 恢复上一次**交互式**会话（`codex` 不带子命令时的 TUI 模式）
- 使用 `--include-non-interactive` 可回溯 exec 会话

### `codex fork --last`
- 派生上一次会话做新任务

## 对小H的启示

1. **delegate 给 Codex 时，必须在 prompt 里带上关键上下文：**
   - 用户偏好（简洁？详细？中文？）
   - 相关的 Hermes skill 说明
   - 当前任务的历史背景

2. **无法依赖 Codex "记住"协作约定。** 比如工作流模式（quick/converge/deep）这类信息，需要在每次调用时传递。

3. **建议的 prompt 前缀：**
   ```
   小H的协作背景：用户偏好详细报告，中文回复。
   相关 skill 概要：[security-preflight/codex-execution-contract 的关键规则]
   当前任务：[具体需求]
   ```

## 相关命令

```bash
# 查看可用会话
codex resume --help

# 恢复最近的交互会话
codex resume --last

# 恢复最近的 exec 会话（含非交互式）
codex resume --last --include-non-interactive
```
