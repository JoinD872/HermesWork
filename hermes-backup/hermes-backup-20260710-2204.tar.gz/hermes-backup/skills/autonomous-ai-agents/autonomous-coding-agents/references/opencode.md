# OpenCode CLI Reference

## Overview

Provider-agnostic open-source autonomous coding agent. Supports any LLM backend (OpenRouter, Anthropic, OpenAI, etc.) via provider configuration.

## Installation & Auth

```bash
npm i -g opencode-ai@latest
opencode auth login                    # Add provider API keys
opencode auth list                     # Verify configured providers
```

## One-Shot Tasks

```bash
opencode run 'Add retry logic to API calls and update tests'
```

Attach context files: `-f config.yaml -f .env.example`

| Flag | Use |
|------|-----|
| `run 'prompt'` | One-shot execution and exit |
| `--continue` / `-c` | Continue the last session |
| `--session <id>` / `-s` | Continue a specific session |
| `--agent <name>` | Choose agent (build or plan) |
| `--model provider/model` | Force specific model |
| `--format json` | Machine-readable output |
| `--file <path>` / `-f` | Attach file to message |
| `--thinking` | Show model thinking blocks |
| `--variant <level>` | Reasoning effort (high, max, minimal) |

## Interactive Sessions

```bash
terminal(command="opencode", workdir="~/project", background=true, pty=true)
# Send prompt
process(action="submit", session_id="<id>", data="Implement OAuth refresh")
# Monitor
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")
# Exit — use Ctrl+C, NOT /exit
process(action="write", session_id="<id>", data="\x03")
```

### TUI Keybindings

| Key | Action |
|-----|--------|
| Enter | Submit message (press twice if needed) |
| Tab | Switch between agents (build/plan) |
| Ctrl+P | Command palette |
| Ctrl+X L | Switch session |
| Ctrl+X M | Switch model |
| Ctrl+X N | New session |
| Ctrl+C | Exit |

### Resuming Sessions

```bash
opencode -c                # Continue last session
opencode -s ses_abc123     # Specific session
```

## PR Review

```bash
opencode pr 42
```

## Cost Management

```bash
opencode stats
opencode stats --days 7 --models anthropic/claude-sonnet-4
```

## Pitfalls

1. `/exit` is NOT a valid command — opens agent selector. Use Ctrl+C to exit TUI.
2. PATH mismatch can select wrong binary. Verify with `which -a opencode`.
3. Enter may need to be pressed twice to submit in TUI.
4. Avoid sharing one workdir across parallel OpenCode sessions.
5. `opencode run` does NOT need pty. Interactive TUI does.
