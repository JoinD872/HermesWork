# Upgrade Evaluation Methodology

Systematic approach for evaluating Hermes Agent version upgrades against our specific setup.

## Template

```
## Hermes vX.Y.Z Evaluation

**Current version:** vA.B.C
**Target version:** vX.Y.Z (YYYY.M.D)
**Release tag:** vYYYY.M.D
**Since previous:** N commits · M merged PRs · F files changed · +I/-D insertions/deletions

### Feature Cross-Reference

| Feature | Relevance | Our Usage | Value |
|---------|-----------|-----------|-------|
| Feature A | Direct / Indirect / None | We use it via ... | ⭐⭐⭐⭐⭐ |
| Feature B | Direct / Indirect / None | Not relevant because ... | ❌ |

### Risk Assessment

| Factor | Assessment |
|--------|-----------|
| Change magnitude | Files changed / insertions |
| Time since release | Fresh / 24h+ / Hotfix available |
| Hotfix relevance | Fixes things we use? |
| Test coverage | ~17K tests |

### Decision

**升 / 不升**

Top 3 reasons:
1. ...
2. ...
3. ...
```

## Per-Release Tracking

### v0.15.0 (2026.5.28) + v0.15.1 (2026.5.29) — The Velocity Release + Patch

**Decision: 升**

**Context:** Upgraded from v0.14.0 (2026.5.16). Same-day hotfix v0.15.1 fixed dashboard infinite reload, Docker `--insecure` split, MCP bare-command PATH resolution, kanban worker SIGTERM.

**High-value improvements:**
- **session_search rewritten**: 4,500× faster, zero LLM cost (our provider: auto → free)
- **Kanban grown into multi-agent platform**: 104 PRs — per-task model overrides, swarm topology, scheduled tasks, worktree-per-task
- **Cold start**: -1s launch, 47% fewer per-conversation function calls
- **run_agent.py refactor**: 16,083 → 3,821 lines (-76%), behavior unchanged
- **Promptware defense**: three-layer guard against Brainworm-class attacks
- **Skill bundles**: one slash command loads full workflow

**Ignored:**
- Bitwarden Secrets Manager (single API key, no need)
- ntfy platform (use Feishu + Telegram)
- TUI orchestrator (gateway-only)
- xAI deep integration (no xAI primary)
- Krea 2 / FAL image gen (stable MiniMax pipeline)
- Dashboard fixes (don't use dashboard)

**Risks:**
- 1,766 files changed, 288K insertions, 37K deletions
- v0.15.0 released 13h before evaluation; v0.15.1 hotfix 5h old
- Fast team response (hotfix in 13h) = good sign
- 17K tests, none of our active features had identified regressions

### v0.14.0 (2026.5.16)

**Decision: 升**

Upgraded from v0.11.0. Major improvements to gateway stability, kanban, and session search.

### v0.11.0 (2026.4.23)

**Decision: 升**

Upgraded from pre-v0.11.0. 1,556 commits, 761 merged PRs. Key win: session_search, cron toolset filtering.
