# Customizing Hermes Tool Behavior

This reference documents the pattern used to add a configurable path whitelist to the `write_file` tool for Obsidian Vault integration.

## Pattern: Config-Backed Tool Security Gate

### When to Use

When you need to restrict a built-in tool's behavior based on config.yaml settings, without breaking existing functionality for paths outside the restriction zone.

### Implementation Steps

1. **Locate the tool file** in `~/.hermes/hermes-agent/tools/<tool>.py`
2. **Add a config loading function** with thread-safe caching:

```python
_CONFIG_CACHE: dict | None = None
_CONFIG_LOCK = threading.Lock()

def _load_my_config() -> dict:
    global _CONFIG_CACHE
    if _CONFIG_CACHE is not None:
        return _CONFIG_CACHE
    with _CONFIG_LOCK:
        if _CONFIG_CACHE is not None:
            return _CONFIG_CACHE
        try:
            from hermes_cli.config import load_config
            cfg = load_config()
            my_cfg = cfg.get("security", {}).get("my_feature", {})
        except Exception:
            my_cfg = {}
        result = {
            "enabled": my_cfg.get("enabled", False),
            # ... your config fields with defaults
        }
        _CONFIG_CACHE = result
        return result
```

3. **Add a checking function** with these invariants:
   - **Disabled by default**: when config is missing or `enabled: false`, skip all checks
   - **Outside scope, skip**: only apply to paths under your feature's root
   - **Path normalization**: use `os.path.realpath(os.path.expanduser(...))` to prevent `../` and symlink bypasses
   - **Clear Chinese error messages** guiding the user to the allowed action

4. **Hook into the tool function**: add a single call after existing security checks:

```python
vault_err = _check_my_feature(path, task_id)
if vault_err:
    return tool_error(vault_err)
```

### Config Format (config.yaml)

```yaml
security:
  my_feature:
    enabled: true
    root: "~/.hermes/ObsidianVault"
    writable_dirs:
      - "allowed_dir_1"
      - "allowed_dir_2"
    draft_only_dirs:
      - "forbidden_dir_1"
      - "forbidden_dir_2"
```

### Pitfalls

- **Default disabled**: if config section is missing, `_load_my_config()` must return `enabled: false` so existing behavior is unchanged
- **Path traversal**: always use `realpath` not `abspath` — symlinks in allowed directories can point to forbidden directories
- **Thread safety**: the lock+cache pattern prevents repeated config reads on every tool call
- **Directory granularity**: check the top-level directory under the root, not individual files — keeps the config simple and the check O(1)
- **Backup before editing**: always `cp file_tools.py file_tools.py.bak.$(date +%Y%m%d-%H%M%S)` before modifying
