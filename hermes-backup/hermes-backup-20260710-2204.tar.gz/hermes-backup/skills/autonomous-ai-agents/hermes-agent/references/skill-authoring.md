# Skill Authoring Guide

Authoring a Hermes Agent SKILL.md file. Two locations:

1. **User-local:** `~/.hermes/skills/<category>/<name>/SKILL.md` — personal. Created via `skill_manage(action='create')`.
2. **In-repo:** `skills/<category>/<name>/SKILL.md` in the hermes-agent repo — shipped with the package. Use `write_file` + `git add`.

## Required Frontmatter

- Starts with `---` as the first bytes (no leading whitespace)
- Closes with `\n---\n` before body
- `name` field present (lowercase, hyphens, ≤64 chars)
- `description` field present, ≤1024 chars
- Non-empty body after closing `---`

Recommended shape (not all enforced by validator):
```yaml
---
name: my-skill-name
description: Use when <trigger>. <one-line behavior>.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [short, descriptive, tags]
    related_skills: [other-skill, another-skill]
---
```

## Size Limits

- Description: ≤1024 chars (enforced)
- Full SKILL.md: ≤100,000 chars (enforced, ~36k tokens)
- Aim for 8-14k chars. Beyond 20k, split into `references/*.md`.

## Peer-Matched Structure

```
# <Title>

## Overview
One or two paragraphs: what and why.

## When to Use
- Bulleted triggers
- "Don't use for:" counter-triggers

## <Topic sections specific to the skill>

## Common Pitfalls
Numbered list of mistakes and their fixes.

## Verification Checklist
- [ ] Checkbox list of post-action verifications
```

## Directory Placement

```
skills/<category>/<name>/SKILL.md
```

Available categories: `autonomous-ai-agents`, `creative`, `data-science`, `devops`, `email`, `gaming`, `github`, `media`, `mlops/*`, `productivity`, `research`, `smart-home`, `software-development`. Pick the closest — don't invent new top-level categories casually.

## Common Pitfalls

1. **Using `skill_manage(action='create')` for in-repo skills.** It writes to `~/.hermes/skills/`, not the repo tree. Use `write_file` for in-repo creation.
2. **Leading whitespace before `---`.** The validator checks `content.startswith("---")`.
3. **Description too generic.** Start with "Use when ..." and describe the *trigger class*, not one task.
4. **Writing a skill that duplicates a peer.** Prefer extending existing skill over creating narrow sibling.
5. **Current session won't see new skill.** Verify in a fresh session or via `skill_view` with exact path.
