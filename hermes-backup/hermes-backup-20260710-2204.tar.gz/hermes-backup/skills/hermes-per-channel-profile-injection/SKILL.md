---
name: hermes-per-channel-profile-injection
description: Hermes multi-group (Feishu/Telegram/Discord) per-chat_id profile SOUL.md + MEMORY.md injection via channel_prompt mechanism. Gateway runs single default profile; per-channel identity is injected at the MessageEvent layer.
risk: write-dangerous
---

# Hermes Per-Channel Profile SOUL + Memory Injection

## Background

Hermes Gateway runs a single instance on the `default` profile — it **only loads global files**:
- `~/.hermes/SOUL.md`
- `~/.hermes/memories/MEMORY.md`

Per-profile files under `profiles/<name>/SOUL.md` and `profiles/<name>/memories/MEMORY.md` are **NOT loaded by the gateway**. Restarting doesn't fix this — they're not on the load path.

## Architecture: channel_prompt Injection

All multi-channel platform adapters (Telegram/Discord/Slack) inject per-channel system prompt via the `MessageEvent.channel_prompt` field.

**Message flow:**
```
Message arrives
  → Adapter builds MessageEvent(chat_id, channel_prompt=...)
  → Gateway run_sync()
  → combined_ephemeral = context_prompt + channel_prompt + ephemeral_system_prompt
  → AIAgent(ephemeral_system_prompt=combined_ephemeral)
  → LLM receives the correct persona prompt
```

`channel_prompt` is per-message, injected at API-call time only, **not** part of the cached system prompt. This keeps `_cached_system_prompt` stable across channels for prefix cache optimization.

## Implementation Status (2026-05-17)

**Feishu adapter IS implemented.** `FeishuAdapter._resolve_profile_channel_prompt()` at `feishu.py:2258` covers all MessageEvent construction points (text messages, reaction synthetic events, card action events).

### Current profile_map (feishu.py:2263-2269)

| chat_id | profile dir | identity |
|---------|-------------|----------|
| `oc_cc9c8289c9520ff326578703ff17392c` | `vps-technician/` | 老V |
| `oc_5a883cbe523b1a93ee269bba2f8536a0` | `game-designer/` | 小策 |
| `oc_8391fa2b38acbd759ff75ab3616d5d1f` | `game-designer/` | 小策 (alt) |
| `oc_6dbf15aa718c29adca8d085017930a71` | `health/` | 黑翼 (replaced 小健) |
| `oc_ec9adb3139cd38ac706cd7a54c4d059d` | `researcher/` | 小研 |

Note: directory name `health/` now serves the 黑翼 identity. Changing identity requires only updating `profiles/<name>/SOUL.md` and `memories/MEMORY.md` — no feishu.py code changes.

### Cross-channel cache impact

channel_prompt is appended to `_cached_system_prompt` via `ephemeral_system_prompt` (appended at `run_agent.py:11905`). All channels share the first ~2.1KB of default SOUL.md prefix (DeepSeek prefix cache shared). Only the last cache unit (per-channel SOUL.md + MEMORY.md) needs independent caching. See `hermes-internals` skill `references/deepseek-caching.md` for the full analysis.

## Identity Migration Workflow

When repurposing an existing profile for a new identity (no code changes needed):

### Step 1: Update SOUL.md
```bash
# Rewrite profile identity
# File: ~/.hermes/profiles/<name>/SOUL.md
```
- The profile directory name stays the same (avoids feishu.py profile_map changes)
- Only file content changes

### Step 2: Replace MEMORY.md
```bash
# Replace profile memory
# File: ~/.hermes/profiles/<name>/memories/MEMORY.md
```

### Step 3: Update routing table
Edit `~/.hermes/SOUL.md`:
- Change the routing table entry (chat_id → new identity name)
- Replace the identity description section

### Step 4: Restart gateway
```bash
systemctl --user restart hermes-gateway
# or
hermes gateway restart
```

### What NOT to change
- Profile directory name (`profiles/<name>/`)
- Feishu adapter `profile_map` mapping (chat_id → directory name stays unchanged)
- Config files or cron jobs referencing the profile

### Verification
After restart, send a message in the target group chat. The new identity's channel_prompt is injected via the existing `_resolve_profile_channel_prompt()` mechanism. Check gateway logs for errors:
```bash
journalctl --user -u hermes-gateway --no-pager -n 20
```

## Implementation Steps (if adding a new platform)

### 1. Add a `_resolve_profile_channel_prompt` method

In the platform adapter class:

```python
def _resolve_profile_channel_prompt(self, chat_id: str) -> str:
    from pathlib import Path
    import os

    _profile_map = {
        "oc_cc9c8289c9520ff326578703ff17392c": "vps-technician",
        "oc_5a883cbe523b1a93ee269bba2f8536a0": "game-designer",
        "oc_6dbf15aa718c29adca8d085017930a71": "health",
        "oc_ec9adb3139cd38ac706cd7a54c4d059d": "researcher",
    }
    profile_name = _profile_map.get(chat_id)
    if not profile_name:
        return ""

    profile_dir = Path(os.path.expanduser("~/.hermes")) / "profiles" / profile_name
    if not profile_dir.is_dir():
        return ""

    parts = []
    for rel in ("SOUL.md", "memories/MEMORY.md"):
        path = profile_dir / rel
        if path.is_file():
            content = path.read_text(encoding="utf-8").strip()
            if content:
                parts.append(content)
    return "\n\n".join(parts)
```

### 2. Inject into all MessageEvent construction points

Every `MessageEvent(` call site needs `channel_prompt`:

```python
normalized = MessageEvent(
    ...
    channel_prompt=self._resolve_profile_channel_prompt(chat_id) or None,
)
```

Must handle: text messages, reaction events, card action events, any other synthetic event type.

### 3. Validate syntax

```bash
cd ~/.hermes/hermes-agent
python -m py_compile gateway/platforms/feishu.py
```

### 4. Restart gateway

```bash
hermes gateway restart
# or
systemctl --user restart hermes-gateway
```

## Casual / No-Agenda Channel Pattern

A new channel type introduced 2026-06-02: 闲聊频道 (casual chat).

### Use case

A dedicated group chat where the user wants to chat casually without:
- Task execution (no file writes, no tool calls, no config changes)
- Knowledge base updates (no memory writes, no diary entries)
- Codex delegation (not worth the cost for casual chat)
- Cron delivery / notifications

### Implementation approach

Two layers of isolation:

**Layer 1: SOUL.md routing table** — Add a routing row for the new chat_id with a "闲聊小H" identity that explicitly states: "no tasks, no work, just chat."

**Layer 2: channel_prompt (feishu.py profile_map)** — Map the new chat_id to a profile that has a minimal SOUL.md defining the casual persona. Can either:
- (a) Create a new profile dir (e.g. `profiles/casual/`) with a short SOUL.md — requires adding to feishu.py `_profile_map`
- (b) Reuse an existing profile but rely entirely on the SOUL.md routing table injection — simpler, no code change

Option (b) is preferred for minimal risk: the routing table in the system prompt is enough to tell the agent "this is a casual channel, don't execute tasks."

### Casual persona definition (SOUL.md entry)

```
### 🗣️ 闲聊小H
- 纯聊天模式，不输出方案、代码、研究结论、知识库
- 不建立知识点，不写日记，不写 memory
- 用户可以聊任何事——吐槽工作、游戏感想、对某个事情的想法
- 小H可以展开聊、跟着思路发散、分享自己的「看法」
- 不把用户的任何话当「任务」执行
- 退出这个频道时，这段对话就像没发生过一样
- Codex 不参与（不值得花那钱），回复标 Codex：0轮
```

### Behavioral difference matrix

| 事项 | 闲聊群 | 正常群（DM/工作群） |
|------|--------|-------------------|
| 任务执行 | ❌ 不执行 | ✅ 默认 |
| 知识库/memory | ❌ 不写入 | ✅ 维护 |
| Codex 参与 | ❌ 不叫 | ✅ 按需求 |
| cron 投递 | ❌ 不投递 | ✅ 默认 |
| 上下文压缩 | ✅ 正常 | ✅ 正常 |
| 费用显示 | — 随用户偏好 | — 随用户偏好 |

### Setup steps

1. User creates a new Feishu group, adds the bot
2. User sends the new chat_id to 小H
3. 小H adds a routing row in `~/.hermes/SOUL.md`
4. (Optional) 小H adds the casual persona definition to SOUL.md
5. No gateway restart needed — SOUL.md is read per-session

## Key Lessons

1. **Restarting doesn't fix SOUL/MEMORY not loading** — they're not on the load path
2. **Profile dir SOUL/MEMORY are for `hermes chat --profile <name>`**, not for gateway messages
3. **channel_prompt** is the platform adapter layer injection point. Telegram/Discord/Slack already use this for per-channel prompts
4. **Feishu adapter originally omitted this** — it was patched in. Now complete as of feishu.py:2258
5. **Casual channels** are a new pattern: no profile injection needed, just SOUL.md routing + persona definition. The least-invasive approach avoids code changes entirely.

## Reference: Telegram/Discord channel_prompt usage

Telegram (`gateway/platforms/telegram.py`):
```python
_channel_prompt = resolve_channel_prompt(self.config.extra, thread_id_str or _chat_id_str, ...)
return MessageEvent(..., channel_prompt=_channel_prompt)
```

Discord (`gateway/platforms/discord.py`):
```python
_channel_prompt = self._resolve_channel_prompt(channel_id, parent_id)
return MessageEvent(..., channel_prompt=_channel_prompt)
```

`resolve_channel_prompt()` is defined in `gateway/platforms/base.py`. It reads `config.extra.get("channel_prompts")`. The per-profile approach reads files directly, same effect with less config overhead.