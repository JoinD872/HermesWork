---
name: vps-ssh-unreachable-troubleshooting
description: VPS 能 Ping 通但 SSH 无法连接的诊断与修复流程
category: devops
tags: [vps, ssh, racknerd, troubleshooting]
risk: read-only
---

# VPS SSH 连接问题排查

## 典型症状
- VPS Ping 得通（ICMP 正常）
- SSH 连接被拒绝（Connection refused）
- 端口 22/密码/密钥全部失败

## 诊断决策树

```
1. VPS Ping 不通
   → 硬件/网络故障，登录控制面板检查
   → 找 VNC/KVM/Serial Console

2. VPS Ping 通，SSH 全部端口拒绝
   → SSH 服务未启动 or 监听非标准端口
   → 通过 VNC 登录 VPS

3. VNC 里执行诊断
   systemctl status ssh        # Debian/Ubuntu 用 ssh，CentOS 用 sshd
   ss -tlnp | grep ssh         # 查看 SSH 实际监听端口
   grep "^Port" /etc/ssh/sshd_config
```

## 常见原因 & 解法

| 原因 | VNC 诊断命令 | 修复命令 |
|------|-------------|---------|
| SSH 服务未安装 | `systemctl status ssh` → Unit not found | `apt update && apt install openssh-server -y` |
| SSH 服务停止 | status 显示 `inactive` | `systemctl enable --now ssh` |
| 监听非标准端口 | `ss -tlnp \| grep ssh` | 确认端口后用 `ssh -p <端口>` 连接 |
| 防火墙阻止 | `iptables -L -nv` | `iptables -F` 清空规则测试 |
| 密码/密钥错误 | auth 日志 | `passwd root` 重置密码 |
| Root 登录被禁 | `grep PermitRootLogin /etc/ssh/sshd_config` | VNC 里改回 `yes` 或建普通用户 |

## 关键发现（2026-05-03）

| 项目 | 发现 |
|------|------|
| OS | Ubuntu 24.04.4 LTS on RackNerd |
| SSH 服务名 | `ssh`（不是 `sshd`，Systemd 用 `systemctl`） |
| 默认 SSH 端口 | **2222**（不是 22，装系统时自动配置） |
| SSH 状态检查 | `systemctl status ssh` + `sshd -t`（语法测试） |
| Fail2Ban | 已预装运行（自 2026-04-24），47k+ 次暴力破解被拦截 |
| 攻击来源 | 大量自动化 bot，目标端口 22/2222 |

## 本地 SSH 连不上但 VNC 正常的排查顺序

```bash
# 1. 确认端口（VNC 里查）
grep "^Port" /etc/ssh/sshd_config

# 2. 本地用正确端口连接
ssh -p 2222 root@192.3.241.244

# 3. 查本地出口 IP
curl -s ifconfig.me

# 4. 在 VPS 里查是否被 Fail2Ban 封了
fail2ban-client status sshd
# 如果被封：fail2ban-client set sshd unbanip <你的IP>
```

## ⚠️ 关键发现：SSH 非交互式登录失败

**问题现象**：本地 SSH 密码正确，但 `Permission denied (publickey,password)` 反复失败，同时 VNC 里密码登录正常。

**根本原因**：SSH 密码认证需要 `/dev/tty`（交互式终端），非交互式脚本/终端无法弹出密码输入提示。

**解法**：给 VPS 添加 SSH 公钥，实现免密码登录：
```bash
# VNC 里执行（一次性）
mkdir -p ~/.ssh && chmod 700 ~/.ssh
echo "<你的ED25519公钥>" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
systemctl restart ssh
```

之后本地即可：`ssh -i ~/.ssh/id_ed25519 -p 2222 root@192.3.241.244`

## 修复后必做
1. 安装 Fail2Ban 防暴力破解：`apt install fail2ban -y`
2. 确认 fail2ban 启动：`systemctl status fail2ban`
3. 添加本地 SSH 公钥到 authorized_keys（避免下次再踩 TTY 坑）

## 预防措施
- 定期检查 SSH 服务状态
- 用 Fail2Ban 自动屏蔽攻击 IP
- 不要关闭 VNC/控制面板访问方式

## ⚠️ tmpfs 配置丢失问题（2026-05-03 新发现）

**现象**：nginx 启动失败，错误 `failed to start A high performance web server`
**原因**：`/tmp` 是 tmpfs（内存文件系统），重启后清空。配置放在 `/tmp/` 会丢失。

**受影响的配置路径**：
- `/etc/nginx/sites-enabled/` 下的 symlink 如果指向 `/tmp/xxx.conf`，重启后 symlink dangling
- Docker tmpfs 挂载同理

**解法**：配置文件必须放在持久化目录：
```bash
# 错误示例
/tmp/vpsfiles.conf → /etc/nginx/sites-enabled/vpsfiles  # 重启后丢失

# 正确示例
/etc/nginx/sites-available/vpsfiles → /etc/nginx/sites-enabled/vpsfiles  # 持久化
```

**检查方法**：
```bash
# 查 symlink 是否有效
ls -la /etc/nginx/sites-enabled/
# dangling symlink 会显示：vpsfiles -> /tmp/xxx.conf (红色或打叉)

# 查 tmpfs 挂载
df -h | grep tmpfs
mount | grep tmpfs
```

**预防**：所有配置文件必须放在 `/etc/` `/usr/local/` `/var/` 等持久化目录，禁止放在 `/tmp/`。
