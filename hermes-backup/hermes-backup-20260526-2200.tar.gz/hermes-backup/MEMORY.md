GitHub PAT 实际位置在 /root/.hermes/scripts/hermes-backup.sh（不在 .env），用户 JoinD872，仓库 JoinD872/HermesWork（私人），Token 前缀 ghp_6q...XGvJ。以后查 GitHub 认证先看 backup.sh。
§
用户云端迭代工作流 — 主力走 GitHub：文件放 JoinD872/HermesWork/workspace/，用户在网页版改，我读+改+提交推送。不走百度网盘/飞书云盘。补充：Google Drive 用于 Obsidian Cloud Inbox（HermesInbox/ 文件夹，每30min拉取到 Vault 收件箱），仅做灵感投递不用于代码迭代。
§
## Google Sheets 宠物技能设计工作流（2026-05-07 确立）

**主表格**：159VrH0vBDT41xHGZnuzCoYxUE7i6u1xvEJvlFKYqUsw（宠物技能设计）
**Drive 素材根文件夹**：1pOtpgVsnMONss2GrsSUv0PUahSmnn5t2（每个宠物一个同名子文件夹）
**Github Repo**：JoinD872/HermesWork（public，sucai/ 目录存技能参考图）

**完整链路**：Google Drive 读素材 → 写动作/特效描述到表格 → pollinations.ai 生图 → GitHub Contents API 上传 → IMAGE 公式嵌入表格
**规范**：先中文草案确认方向再生成；回合制小技能1.5-3s，大招2.5-4s；姿态参考隼龙低桩横刀
**Skill 已建**：/root/.hermes/skills/pet-skill-design-workflow/SKILL.md
§
## 图片理解（2026-05-09 更新 — 切 DeepSeek V4 原生 Vision）

**首选**：DeepSeek V4 原生 Vision（直接通过文字引用图片路径或 URL）
**备用**：`mmx vision describe <图片路径>`（仅当 DeepSeek Vision 不可用时）
**不再使用**：MCP `understand_image`（平台级 404）

注意：`mmx vision describe` 对某些图片可能静默返回 exit_code=1（`input sensitive`），此时降级到浏览器截图等方式。
§
## 用户 Windows 桌面 SSH + 黑翼 Agent（2026-05-17）
SSH: `ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37`。Tailscale IP 100.86.150.37，joind（Windows本地用户，非Tailscale），工作目录 E:\Hermes\。DERP relay ~180ms。已验证 2026-05-10。

健康助手 profile（`oc_6dbf15...a71`）已于 2026-05-17 改为「黑翼」——私人PC管家，专管 DESKTOP-TG4LOEN。目录名仍为 `health/` 不动 feishu.py。原有 小健 已删除。
§
用户有两台 Windows 电脑通过 Tailscale 连接：desktop-tg4loen（上海宝山，在线，已SSH打通）+ 笔记本（已离线30+天）。

## 小红书爬取限制（2026-05-18）
小红书 headless 浏览器**无论 VPS (LA) 还是上海桌面都被拦**（错误码 300012「IP存在风险」）——这是 headless 检测而非 IP 归属地问题。唯一有效方案：用户桌面已打开的**非 headless 浏览器**（如 360ChromeX），但需用户手动配合，无法 SSH 自动化。
§
知乎已升级为官方API：ZHIHU_ACCESS_SECRET存于.env，developer.zhihu.com，每天1000次免费搜索，替代SearXNG间接方式。
§
Hermes 采用低耗职能角色模型：小H为主控官，小策为方案官，老V为执行官，小研为调研/验证/沉淀官，黑翼为风控官；低风险小H直接处理，中高风险按职能协作，高风险需风控审查。
§
用户厌恶"无事通知"——所有定期后台 cron job（Cloud Inbox 拉取/Vault 同步等）必须用 silent script + deliver=local。仅在有实际内容时才输出，无内容时完全静默。
§
Vault/日记：维持被动模式，不主动读取日记内容。等用户说「写好了」或问题需要查笔记时再读。
§
ChatGPT Plus 续费方式：Apple 美区 App Store 内购。流程：支付宝买美区 Apple Gift Card → 兑换到美区 Apple ID → App Store 余额扣款。OpenAI 拦不到这笔支付。
§
AI 偏好：Gemini "回答简短、语言贫乏、刻意迎合"；GPT "内容衍生多、思维更广"。不要 yes-man，要能发散碰撞的对话伙伴。
§
## 外部执行器决策（2026-05）
Codex: ✅ 已安装可用。GPT-5.5，走Plus订阅零额外费。小H自主决定何时用，低难度也参与试跑（用完再调）。推理深度默认medium，高难度用high/xhigh。额度用完时Codex报错再跳过。
Reasonix: dormant，不安装，方法论已吸收到 code-repair-loop skill。
报告附加: 每次回复末尾附任务难度标注：低/中/高。
§
## VPS 关键事实
IP: 192.3.241.244 (RackNerd LA, 2核/2.4G/43GB) | SSH: 端口2222, 仅公钥登录
Fail2Ban 已运行 | BBR+fq 已开启 | 访问不了epicgames.com相关站
代理: Xray(8081, VLESS+WS) → Cloudflare Tunnel, 无直连节点
§
Codex CLI 已从 0.125.0 升级到 0.133.0（2026-05-23）。Codex 没有持久记忆——每次 exec 都是独立会话，派发给它时必须显式附带上下文（用户偏好、skill 知识等）。高推理模式：`codex exec -c 'reasoning_effort="high"'`。
§
自我修复难度评级规则：难度不只看任务表面复杂度，更要看修复是否彻底。同一个bug反复出现（修了2次以上还犯），自动升一级。评「低难度」意味着我认为修复很彻底，若有遗漏就评假了。
§
## 费用追踪已改为「同轮次双查法」（2026-05-26）
旧版文件差值法被 cron 污染导致误差。新方法：回复开始时 `bash balance_report.sh start`，结束时 `bash balance_report.sh end`，差值 = 本次精确消费。skill `api-cost-tracking` 已同步更新。
§
## cron-no-agent-script-rule（新 skill，2026-05-26）
no_agent=true 的 cron 的 script 字段只写文件名，不加 shell 前缀。API 层已加固（shell 前缀检测），5 处技能文档毒源已清理。
§
crawl4ai 已安装 `/root/.crawl4ai-venv/`，Reddit JSON API 可用（绕过VPS IP 403封锁）。助手脚本 `/root/.hermes/scripts/crawl4ai_reddit.py`：`python crawl4ai_reddit.py <subreddit> [limit]`。仅 Reddit 能用（小红书/nitter 不行）。不集成进早报 cron，仅作 curl 403 时的 fallback。