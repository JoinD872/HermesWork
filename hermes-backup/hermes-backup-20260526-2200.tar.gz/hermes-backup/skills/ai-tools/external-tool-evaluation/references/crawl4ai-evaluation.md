# Crawl4AI 评估 — 2026-05-26

## 基本信息

| 指标 | 数值 |
|------|------|
| GitHub Stars | 66.4k |
| 最新版本 | v0.8.6 (Apache 2.0) |
| 依赖 | Playwright 浏览器后端 (~113MB Chromium) |
| 安装 | `pip install -U crawl4ai` + `crawl4ai-setup` |
| 安装耗时 | ~3min (pip) + ~2min (下载 Chromium) |

## 核心能力与实测结果

### Reddit 绕过 — ✅ 最大价值
之前 VPS IP (192.3.241.244) 被 Reddit 封锁，curl 全部 403。crawl4ai 用 Playwright 浏览器后端可成功获取数据：

| 目标 | 结果 | 速度 |
|------|------|------|
| Reddit JSON API (`/r/subreddit/hot/.json`) | ✅ 全部跨越 4 个子版 | ~1.1s/次 |
| old.reddit.com HTML | ✅ 17,865 chars 全内容 | ~2.1s |
| Reddit 新版HTML (Cloudflare) | ⚠️ 230 chars (被拦截) | ~1s |
| Reddit r/VPS HTML (Cloudflare绕过) | ✅ 8,834 chars | ~1.9s |

**出人意料**：甚至基础模式（无 magic/stealth）就能过 Reddit 封锁，说明 Playwright 浏览器后端自带的 HTTP 层指纹就足够绕过 Reddit 的 IP 级封锁。

### 小红书 — ❌ 失败
Tencent EdgeOne 在传输层直接拦截 headless Playwright 连接（60s timeout），curl 可通但页面是 Vue SPA 无内容。所有 anti-bot 模式均无效。

### nitter.net (X/Twitter) — ❌ 失败
Anti-bot 检测拦截。

### 知乎 API — ⚠️ 需要鉴权
curl + `.env` 中的 `ZHIHU_ACCESS_SECRET` 正常工作，crawl4ai 不带鉴权时返回 `Authorization failed`。知乎已有稳定的 curl 方案，不依赖 crawl4ai。

## 与 Hermes 现有方案对比

| 场景 | 旧方案 | crawl4ai | 结论 |
|------|--------|----------|------|
| Reddit 爬取 | ❌ curl 403 | ✅ 能获取 JSON + HTML | **替换** |
| 社区常规爬取 (V2EX/知乎/B站) | ✅ curl + Python 解析 | 可用但无优势 | 不动 |
| 文档站全量抓取 | 逐页 browser_navigate | 深爬 (BFS/DFS) 一次性搞定 | **候选** |
| 反封锁攻坚 (小红书等) | ❌ 均失败 | ❌ 同样失败 | 无帮助 |
| 页面 → Markdown | browser_console innerText | 自动生成干净 Markdown | 可选增强 |

## 决策

**试验（experiment）** 级别接入。

只用于 Reddit 爬取（已验证的最大价值场景），不替换现有 Hermes 爬虫流程，不创建独立 Agent，不接入 federation 系统。

### 最小接入方案

```python
# 仅在需要 Reddit 数据时调用
import asyncio, json, re
from crawl4ai import AsyncWebCrawler
from crawl4ai.async_configs import CrawlerRunConfig, CacheMode

async def fetch_reddit(subreddit, limit=5):
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(
            url=f"https://www.reddit.com/r/{subreddit}/hot/.json?limit={limit}",
            config=CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
        )
        if not result.success:
            return None
        m = re.search(r"```(?:json)?\s*(.*?)```", result.markdown, re.DOTALL)
        raw = m.group(1).strip() if m else result.markdown.strip()
        data = json.loads(raw)
        return [p["data"] for p in data["data"]["children"]]
```

已验证的稳定子版（~1s/次）：r/unrealengine, r/VPS, r/LocalLLaMA, r/MachineLearning。

### 未来候选场景
- 文档站批量深爬（如 UE5 文档替代站全量抓取）
- 需要结构化 CSS/XPath 抽取的固定格式页面

## 注意事项

- v0.8.6 刚遭遇过 litellm PyPI 供应链投毒事件（已修复），后续版本升级需关注依赖链安全
- 2.4GB 内存 VPS 上按需启动（不常驻），资源压力可控
- 非 no_agent cron 场景慎用（LLM 驱动方式启动 crawl4ai 会增加 token 消耗）
