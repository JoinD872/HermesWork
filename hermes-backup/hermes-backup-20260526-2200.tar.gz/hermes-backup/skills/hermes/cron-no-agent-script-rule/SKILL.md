---
description: |
  ⚠️ no_agent=true cron 的 script 字段——必须只写文件名，不要加 bash/python3 前缀。
  这是反复踩坑的 bug，加载此 skill 后必须检查。

## 规则

当 `no_agent=true` 创建或更新 cron job 时：

```bash
# ✅ 正确——只写文件名
script="my_script.sh"
script="vault_ingest.py"

# ❌ 错误——会被当作文件路径，导致 "Script not found"
script="bash ~/.hermes/scripts/my_script.sh"
script="python3 ~/.hermes/scripts/vault_ingest.py"
```

## 原因

`no_agent=true` 的 cron 调度器直接用 `exec` / `subprocess` 执行脚本——script 字段被当作 `~/.hermes/scripts/` 下的文件路径来解析，不经过 shell 解析。调度器自动根据扩展名选择解释器（`.sh`→bash, `.py`→Python）。

## 校验清单

创建/修改 no_agent=true 的 cron job 时：

1. [ ] script 字段是否只包含文件名或相对路径？
2. [ ] 是否不以 `bash`、`python3`、`python`、`sh`、`node` 等前缀开头？
3. [ ] 文件是否确实存在于 `~/.hermes/scripts/` 下？
4. [ ] 文件是否有 shebang（可选但推荐）？
5. [ ] `deliver=local` 是否显式设置？（no_agent cron 不设 deliver=local 会发到用户聊天）

## 解释器自动选择

| 扩展名 | 解释器 |
|--------|--------|
| `.sh` / `.bash` | `/bin/bash` |
| `.py` / 其他 | `sys.executable` (当前 Python) |
