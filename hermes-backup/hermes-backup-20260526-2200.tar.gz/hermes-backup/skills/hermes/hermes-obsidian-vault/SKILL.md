---
name: hermes-obsidian-vault
description: 完整生命周期管理 Hermes × Obsidian Vault 知识库——从目录设计、write_file 路径白名单实现、安全测试到 multi-phase 落地
risk: write-safe
version: 1.0
created: 2026-05-23
tags: [hermes, obsidian, vault, knowledge-base, file-security, multi-phase]
related_skills:
  - hermes-internals
  - federation-protocol-v320
  - low-cost-federation
---

# Hermes × Obsidian Vault 落地指南

> 让小H 将复盘、callback、研究报告、灵感等产出整理为 Markdown 写入 Obsidian Vault，配合四职能低耗模型多角色协作。

---

## 总体架构

```
小H（总控+测试写入）
  ├── 老V（系统层：建目录、配白名单、备份、安全审计）
  └── 小策（方案层：模板设计、分类规则）
```

三阶段落地：

| 阶段 | 目标 | 前置条件 |
|------|------|---------|
| Phase 1 | Vault 搭建 + 白名单 + 本地备份 | 无（从零开始） |
| Phase 2 | callback → Vault 管道 | Phase 1 稳定 ≥24h |
| Phase 3 | Cloud Inbox + 多端同步 | Phase 2 稳定 ≥3天 |

---

## Phase 1：Vault 搭建与安全配置

### 目录结构设计原则

1. **中文命名** — 用户偏好中文目录名（如 `00_收件箱-AI/` 而非 `00_Inbox-AI/`）
2. **数字前缀排序** — 按使用频率排序：`00_`（最常用）→ `10_` → `20_` → `40_` → `50_`，无数字的放末尾
3. **写权限分层** — 只允许小H自动写 3 个目录，其他只能通过 `00_收件箱-AI/` 出草稿

### 推荐的最终目录结构

```
~/.hermes/ObsidianVault/
├── 00_收件箱-AI/         # 小H自动写入唯一入口
├── 00_收件箱-人工/       # 手动/云端入口，小H不自动写
├── 10_文献笔记/          # 小研报告、早报提炼
├── 20_项目文档/          # 草稿走收件箱
├── 30_永久笔记/          # 人工晋升区
├── 40_复盘归档/          # 排障/callback归档
├── 50_Hermes架构/       # 架构文档
├── 灵感创意/             # 草稿走收件箱
└── 模板/                # 小策/人工维护
```

### 白名单规则

| 权限 | 目录 |
|------|------|
| ✅ 小H自动写 | `00_收件箱-AI/` `10_文献笔记/` `40_复盘归档/` |
| ❌ 小H禁写（草稿走收件箱） | `20_项目文档/` `30_永久笔记/` `50_Hermes架构/` `灵感创意/` |
| ❌ 小H日常禁写 | `模板/` `00_收件箱-人工/` |

### 草稿约定

当小H需要向禁写目录输出内容时：
1. 写入 `00_收件箱-AI/`
2. frontmatter 标注：
   ```yaml
   status: draft
   target_dir: 20_项目文档
   promotion_required: true
   ```

### write_file 路径白名单实现

在 `tools/file_tools.py` 中新增：

```python
def _check_obsidian_vault_path(path: str, task_id: str = "default") -> str | None:
    """检查路径是否在 Obsidian Vault 白名单内。不在白名单则返回错误信息。"""
```

核心安全要点：
- 使用 `os.path.realpath()`（而非 `abspath`）防止 symlink 绕过
- 使用 `os.path.expanduser()` 展开 `~`
- 配置缺失时（`enabled: false` 或不存在）默认不启用，不误伤系统
- 不在 Vault 内的路径跳过检查，行为不变

### config.yaml 配置

```yaml
security:
  obsidian_vault:
    enabled: true
    root: "~/.hermes/ObsidianVault"
    writable_dirs:
      - "00_收件箱-AI"
      - "10_文献笔记"
      - "40_复盘归档"
    draft_only_dirs:
      - "20_项目文档"
      - "30_永久笔记"
      - "50_Hermes架构"
      - "灵感创意"
```

### 验证清单（13 项）

| # | 验证项 | 预期 |
|---|--------|------|
| 1 | 目录结构创建（9个） | ✅ |
| 2 | 模板创建（3个） | ✅ |
| 3-5 | 可写目录写入 | ✅ 成功 |
| 6-9 | 禁写目录写入 | ❌ 被拒，返回中文错误 |
| 10 | `../` 绕过 | ❌ 被拒（realpath 解析后拦截） |
| 11 | symlink 绕过 | ❌ 被拒（realpath 解析为目标目录后判断） |
| 12 | Vault 外写入 | ✅ 不受影响 |
| 13 | tar 本地备份 | ✅ |

### 回滚方案

```bash
# 恢复 file_tools.py
cp tools/file_tools.py.bak.<timestamp> tools/file_tools.py

# 恢复 config.yaml
cp ~/.hermes/config.yaml.bak.<timestamp> ~/.hermes/config.yaml

# 删除 Vault
rm -rf ~/.hermes/ObsidianVault/
```

### Phase 1.2：观察期（GPT 推荐）

Phase 1 完成后，建议先观察 24-48 小时再进 Phase 2，而不是立即启用 callback 管道。

**观察期禁止事项**：
- ❌ vault-digest cron
- ❌ callback 协议修改
- ❌ Cloud Inbox（已单独完成可跳过此限制）
- ❌ rclone crypt / Git / Syncthing

**每日检查项**：
1. 3 个允许目录可写；6 个禁写目录被拒
2. Vault 外写入不受影响
3. tar 本地备份成功
4. 测试文件已清理

**进入 Phase 2 的条件**：观察 24-48h 无异常 + 白名单无误伤 + 禁写目录无污染。

---

## Phase 2：callback → Vault 管道

（待建设——需要修改 `federation-protocol-v320` 的 payload 规范，新增 `meta.vault` 字段）

### callback payload 扩展

```json
{
  "payload": {
    "summary": "...",
    "key_findings": [],
    "action_items": [],
    "meta": {
      "vault": true,                    // 可选，缺省 false
      "vault_target": "40_复盘归档",    // 目标目录
      "vault_template": "复盘模板"      // 使用的模板
    }
  }
}
```

### vault-digest cron

每日扫描 `~/.hermes/federation/callbacks/archive/`，筛选有 `key_findings` 或 `action_items` 且 `meta.vault: true` 的 callback，按模板写入 Vault。

---

## Phase 3：Cloud Inbox 与多端同步

（待建设——可选的 rclone crypt / Syncthing / Git 同步层）

### Cloud Inbox 架构

用户通过 Google Drive（或其他云盘）投递灵感 → VPS 定时拉回 `00_收件箱-人工/` → 小H 整理。

### 同步策略推荐

| 需求 | 方案 | 成本 |
|------|------|------|
| 只备份 | rclone crypt | 免费 |
| 多端编辑 | Syncthing + 单主库规则 | 免费 |
| 版本历史 | Git | 免费 |
| 省心多端 | Obsidian Sync / Headless | 付费 |

### Google Drive OAuth 授权

参见 `references/rclone-headless-oauth.md`。核心步骤：

1. VPS 上启动 `rclone authorize "drive"` 监听 127.0.0.1:53682
2. socat 转发公网端口 53683 → 127.0.0.1:53682
3. 用户访问 `http://VPS_IP:53683/auth?state=...` 完成授权
4. Google 回调后手动将 URL 中 127.0.0.1 替换为 VPS IP，完成认证

**⚠️ GFW 注意**：OAuth 的 token exchange 阶段（`oauth2.googleapis.com/token`）在 GFW 内不可达。
- ❌ 不能在用户本地 Windows（上海）上跑 `rclone authorize`
- ✅ 必须在 VPS（洛杉矶）上跑 `rclone authorize`，用户只通过浏览器做授权操作
- 详细记录见 `vps-oauth-proxy` 的 `references/rclone-gdrive-config.md` 中 `GFW 关键坑` 一节

---

## 模板设计

3 个标准模板位于 `模板/` 目录下：

| 模板 | 用途 | 字段特点 |
|------|------|---------|
| 复盘模板 | 排障、巡检、架构复盘 | 背景→问题→排查→根因→方案→验证→后续动作 |
| 文献模板 | 研究报告、资料摘要 | 来源→核心结论→详情→对Hermes的价值 |
| 收件箱模板 | 灵感、待整理 | target_dir + promotion_required + to_memory 判断 |

### 输出标准化要求

所有 Markdown 文件应包含：

```yaml
---
title: "标题"
date: YYYY-MM-DD
source: Chat / Web / GitHub / PDF
tags: [#标签1, #标签2]
type: recap / literature / inbox
status: completed / processed / draft
---
```

并保留双链候选区和后续动作区。

---

## Federation callback 集成（vault_ingest.py）

已通过 `~/.hermes/scripts/vault_ingest.py` 自动入库。该脚本扫描两个来源写入 Vault：

**来源 A：cron 输出** — 扫描 `~/.hermes/cron/output/{job_id}/` 下的新 .md 文件，写入 `40_复盘归档/{date}-{name}.md`

**来源 B：联邦回执（小研研究报告）** — 扫描 `~/.hermes/federation/callbacks/` 下的新 .json 文件，根据 task_id 自动分类入库：

| task_id 前缀 | 目标目录 | 处理方式 |
|-------------|---------|---------|
| MINIMAX_DAILY / MINIMAX_SCAN | 10_文献笔记 | key_findings+action_items 结构化写入 |
| RESEARCH | 10_文献笔记 | 同上 |
| PAIN (健康) | 10_文献笔记 | 同上 |
| UE5WP / UE5 | 10_文献笔记 | 同上 |
| vps-patrol | 40_复盘归档 | 直接归档 |
| 其他 | 00_收件箱-AI | 等待处理的收件箱 |

状态追踪由 `~/.hermes/config/vault-ingest-state.json` 维护，避免重复入库。

详见 `references/phase1.5-2-implementation.md`。

## 输出标准化

所有写入 Vault 的 Markdown 文件应遵循：

```markdown
---
title: "{{标题}}"
date: YYYY-MM-DD
source: Chat / Web / Github / PDF / 其他
tags: [#Hermes, #标签]
status: completed / draft / processed
type: recap / literature / inbox
---

# 标题

## 核心结论
- 点1
- 点2

## 详情
...

## 后续动作
- 是否固化进 Memory
- 是否归档项目文档

---
双链候选：
- [[相关文档]]
标签：#标签
```

**强制要求：**
- 必须含 YAML frontmatter
- 必须包含双链候选区（`[[相关文档]]`）
- 必须包含后续动作区
- 避免冗余的描述性文字；直接写结论和关键数据

## 常见陷阱

| 陷阱 | 说明 | 预防 |
|------|------|------|
| 测试笔记残留 | 验证完成后测试文件未清理，污染 Vault | 验证成功后立即清理测试产物 |
| 收件箱堆积 | AI 向收件箱写入草稿后无人整理 | 建议每周自动汇总过期收件箱成 digest |
| 多层 live sync 混用 | rclone + Syncthing + Git 同时运行导致冲突 | 只保留一层 live sync，其余做备份层 |
| 目录结构漂移 | AI 把文件写错目录（taxonomy drift） | 白名单 + 模板约束 |

## 参考文档

- `references/phase1-implementation-20260523.md` — Phase 1 实际执行记录（目录创建、白名单代码实现、验证细节）
- `references/phase1.5-2-implementation.md` — Phase 1.5（Cloud Inbox）和 Phase 2（vault_ingest.py）实施记录
- `references/token-cost-estimate.md` — 小研 token 成本估算报告
- `references/rclone-headless-oauth.md` — 无头服务器 rclone Google Drive OAuth 授权方法
- `references/cloud-inbox-pipeline.md` — Google Drive → Obsidian Vault 云收件箱管道
- `references/daily-diary-system.md` — 每日日记自动化系统（创建、清理、同步）

## 模板文件

标准模板文件（可复制使用）：

| 文件 | 用途 |
|------|------|
| `templates/复盘模板.md` | 排障、巡检、架构复盘 |
| `templates/文献模板.md` | 研究报告、资料摘要 |
| `templates/收件箱模板.md` | 灵感、待整理内容（含 draft/target_dir 标记） |
