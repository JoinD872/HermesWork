---
name: community-scraping
description: 社区情报爬取完整指南 — 7个社区的爬取方式、凭据位置、去重规则、排除范围、异常处理。供小研使用。
risk: write-dangerous
version: 1.0.0
created: 2026-05-18
---

# 社区情报爬取指南（小研专用）

## 概述

每日北京时间 08:00 触发，从 7 个社区爬取 Hermes Agent / DeepSeek / MiniMax / Gemini / ChatGPT / 大模型技术优化相关情报，汇总成早报。

## 凭据位置

所有 Token/Cookie 存在：`/root/.hermes/credentials/social_scraper.json`

```json
{
  "x": {
    "bearer_token": "...",
    "auth_token": "...", 
    "ct0": "..."
  },
  "discord": {
    "bot_token": "...",
    "guild_id": "1492858402060107787",
    "channels": {
      "task_board": "1492919523698020442"
    }
  }
}
```

## ❌ 排除内容（看到直接丢弃）
- UE5 / 虚幻引擎5 相关
- 游戏开发相关（Unity、Godot、蓝图、C++游戏等）
- 本地模型（ollama、llama.cpp、text-generation-webui、本地部署等任何"本地运行"内容）

## 🔴 X/Twitter 红线规则
- **仅限每日早报定时任务中使用**
- **任何时候用户要求立即/按需爬取内容，禁止使用 X/Twitter**
- 这是为了降低账号被封的风险

## 7个社区爬取方式

### 1. X/Twitter — Timeline Only（已验证可稳定工作）
- **只使用** timeline endpoint：`GET https://x.com/i/api/2/timeline/home.json?count=20`
- **禁止使用** search/adaptive/graphql 端点（不可靠或已废弃）
- Headers：
  - `Authorization: Bearer {bearer_token}`
  - `x-csrf-token: {ct0}`
  - `x-twitter-auth-type: OAuth2Session`
  - `Cookie: auth_token={auth_token}; ct0={ct0}`
  - `User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36`
  - `Origin: https://x.com`
  - `Referer: https://x.com/`
- 返回 JSON，从 `globalObjects.tweets` 提取，`globalObjects.users` 提取用户信息
- 如果首页推文没有技术相关内容，标 🟡 "今日无技术相关内容"，**不要标 🔴**
- ⚠️ 不要在日志中输出 auth_token、ct0、Bearer 值

### 2. Discord
- Bot Token 方式认证：`Authorization: Bot {bot_token}`
- 端点：`GET https://discord.com/api/v10/channels/1492919523698020442/messages?limit=5`
- 读取 #任务看板 频道的 Bot 状态信息

### 3. V2EX — 二级降级解析（已验证 2026-05-20）
```bash
curl -s -A "Mozilla/5.0" -L "https://www.v2ex.com/" -o /tmp/v2ex.html
```

**第一级：CSS 提取（优先）**
```bash
grep -oP 'item_title.*?href="\K/t/[0-9]+' /tmp/v2ex.html
```
通常可提取 40-50 条话题链接。

**第二级：正则 fallback（CSS 提取 < 5 条时降级）**
```bash
grep -Eo 'href="/t/[0-9]+"' /tmp/v2ex.html | sort -u
```
/t/ 链接格式稳定，至少可提取 10+ 条唯一链接。

**第三级：debug 保存（前两级都 < 3 条时）**
保存前 2000 字符供排查：
```bash
head -c 2000 /tmp/v2ex.html > /tmp/v2ex_debug.html
```

**关键原则**：不因 CSS 选择器失效就直接报 🔴。正则 fallback 能兜住。

### 4. B站
```bash
curl -s -A "Mozilla/5.0" "https://api.bilibili.com/x/web-interface/popular?ps=10"
curl -s -A "Mozilla/5.0" "https://api.bilibili.com/x/web-interface/search/all/v2?keyword=DeepSeek"
```
- 公开 API，无需认证
- 结果在 `data.list[]` 中

### 5. Reddit

> ⚠️ VPS IP（192.3.241.244）从 2026-05-23 起被 Reddit 封锁（HTTP 403）。
> 裸 curl 方式已不可用。**下方 crawl4ai 方案是已验证的绕过方案。**

**推荐方案：使用 crawl4ai 绕过封锁（2026-05-26 已验证）**

crawl4ai（`/root/.crawl4ai-venv/bin/python`）用 Playwright 浏览器后端做 HTTP 请求，可绕过 Reddit 的 IP 级封锁。安装方式：
```
python3 -m venv /root/.crawl4ai-venv
/root/.crawl4ai-venv/bin/pip install -U crawl4ai
/root/.crawl4ai-venv/bin/crawl4ai-setup
```
首次安装会下载 Playwright Chromium（约 113MB）。

```python
import asyncio, json, re
from crawl4ai import AsyncWebCrawler
from crawl4ai.async_configs import CrawlerRunConfig, CacheMode

async def fetch_reddit(subreddit, limit=5):
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(
            url=f"https://www.reddit.com/r/{subreddit}/hot/.json?limit={limit}",
            config=CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
        )
        if not result.success:
            return None
        # 从 markdown 代码块提取 JSON
        m = re.search(r"```(?:json)?\s*(.*?)```", result.markdown, re.DOTALL)
        raw = m.group(1).strip() if m else result.markdown.strip()
        data = json.loads(raw)
        return [p["data"] for p in data["data"]["children"]]
```

已验证的稳定子版（~1s/次）：
- `r/unrealengine` — UE5 开发讨论
- `r/VPS` — VPS 主机评测
- `r/LocalLLaMA` — 本地大模型
- `r/MachineLearning` — ML 学术

注意：新版 Reddit HTML 仍被 Cloudflare 拦截（仅返回 ~230 chars），`.json` API 端点和 `old.reddit.com` HTML 正常工作。优先用 JSON API。详见 `references/crawl4ai-reddit-results.md`。

**旧方案（curl，已失效）**：
```bash
curl -s -A "Mozilla/5.0" "https://www.reddit.com/r/LocalLLaMA/hot.json"
curl -s -A "Mozilla/5.0" "https://www.reddit.com/r/MachineLearning/hot.json"
curl -s -A "Mozilla/5.0" "https://www.reddit.com/r/artificial/hot.json"
```
结果在 `data.children[].data`

### 6. GitHub
```bash
curl -s -H "Accept: application/vnd.github+json" "https://api.github.com/search/repositories?q=deepseek&sort=stars&order=desc&per_page=5"
```
- 搜索关键词：deepseek, Hermes+Agent, LLM+optimization, MiniMax

### 7. 知乎（官方 API）
✅ 知乎数据开放平台 `developer.zhihu.com` 已注册，`ZHIHU_ACCESS_SECRET` 存于 `.env`。

```bash
source /root/.hermes/.env 2>/dev/null

# 知乎搜索
curl -s -G 'https://developer.zhihu.com/api/v1/content/zhihu_search' \
  --data-urlencode 'Query=DeepSeek' \
  -d 'Count=5' \
  -H "Authorization: Bearer $ZHIHU_ACCESS_SECRET" \
  -H "X-Request-Timestamp: $(date +%s)" \
  -H 'Content-Type: application/json'

# 知乎热榜
curl -s -G 'https://developer.zhihu.com/api/v1/content/hot_list' \
  -H "Authorization: Bearer $ZHIHU_ACCESS_SECRET" \
  -H "X-Request-Timestamp: $(date +%s)" \
  -H 'Content-Type: application/json'
```

响应格式：`{"Code":0,"Message":"success","Data":{"Items":[...]}}`
Items 包含：`Title`, `ContentText`, `Url`, `AuthorName`, `VoteUpCount`, `CommentCount`, `EditTime`

免费额度：每天 1000 次搜索 + 10 次热榜。
原先的 SearXNG 间接方式作为备用降级。

## 去重规则

### 跨源去重
- 标题完全一致 → 合并
- 标题包含关系（A是B的子串或反之）→ 合并
- 相似度 > 70%（编辑距离/公共子串比例）→ 合并
- 合并后注明「同时出现在 [来源A]、[来源B]」

### 跨天去重
- 读取 `/root/.hermes/cron/output/` 最近3天的早报文件
- 已出现过的标题/URL 跳过

### 源内去重
- 相同 URL/ID 只保留一条

## 异常处理 / 错误分级（必须遵循）

### 错误分级表
| 情况 | 级别 | 说明 |
|------|:----:|------|
| HTTP 200 + 正常数据 | ✅ | 正常绿 |
| HTTP 200 + 返回数据量少但非空 | 🟢 | 如实汇报即可 |
| HTTP 200 + 空结果（技术无相关内容） | 🟡 | "今日无相关更新" |
| HTTP 4xx/5xx 请求失败 | 🟡 | 请求异常 |
| 解析失败但原始数据存在 | 🟡 | "解析异常，已保存 debug" |
| 网络不可达（timeout/DNS） | 🔴 | "服务不可达" |
| 凭据过期（401） | 🟡 | "凭据需更新" |
| rate limit（429/403） | 🟡 | "已限流" |

### 核心原则
- **只有网络层不可达才标 🔴**
- 其他所有情况（空结果、解析失败、限流、凭据过期）都降级为 🟡
- 每个社区最多重试 2 次，间隔 5 秒
- 不要因为单一社区失败就导致整份报告失败

## GitHub PAT 安全注意事项
- **不要复用**备份脚本（hermes-backup.sh）或聊天记录中已出现的 PAT
- 旧 PAT 应视为已泄露，不要在任何新代码中引用
- 如果需要 GitHub 认证，要求用户创建全新的最小权限 PAT
- 新 PAT 写入环境变量 `GITHUB_TOKEN`，不写死进脚本

## Cron Job 执行注意事项

每日早报由 cron job (22c677b8acac) 定期触发。编写 cron prompt 时需注意：

### 嵌入精确命令，而非引用 skill

Cron agent **不会自动加载**被引用的 skill。以下写法会失败：
```
详见 community-scraping skill
```

正确做法——把精确的可执行命令直接嵌入 cron prompt（用 python3 从 social_scraper.json 读取凭据后执行 curl）。

如果必须引用 skill，需将该 skill 加入 cron job 的 `skills` 列表（如 `cronjob action=update skills=["devops:community-scraping"]`）。

### 凭据读取方式

- social_scraper.json：用 `python3 -c "import json; json.load(open(...))"` 读取
- .env 变量：用 `source /root/.hermes/.env` 加载后用 `$VAR_NAME` 引用
- 禁止将凭据明文硬编码到 cron prompt 中

### Reddit IP 封锁

2026-05-23 起，VPS IP（192.3.241.244）被 Reddit 网络策略封锁（HTTP 403 `blocked due to a network policy`）。**裸 curl 已不可用**，但已找到绕过方案：

- ✅ **crawl4ai**（Playwright 浏览器后端）可绕过封锁 — 详见上方 `### 5. Reddit` 的 crawl4ai 方案
- ✅ **old.reddit.com** HTML 版本也可用
- 不要在失败后反复重试 curl

### 凭据有效性验证原则

Cron 报告凭据过期（401/403）时，先手动测试验证：
```
从 social_scraper.json 读取凭据后直接 curl 目标 API
```
很多时候凭据是好的，只是 agent 用了错误的命令格式。

## 季度维护
- 每 3 个月检查一次各社区的接口是否变化
- 上次检查：2026-05-18
- 下次检查：2026-08-18
