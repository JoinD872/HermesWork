---
name: vps-oauth-proxy
description: 无浏览器 VPS 上完成 CLI 工具 OAuth 授权的方法——端口转发 + 人工修正回调 URL。适用于 rclone/gsutil/aws-cli/gh CLI 等需要浏览器授权的工具
risk: read-safe
version: 1.0
created: 2026-05-23
tags:
  - vps
  - oauth
  - rclone
  - credential
  - headless
---

# VPS OAuth 代理 — 无浏览器环境下的授权方法

## 问题背景

VPS（如本机 RackNerd 192.3.241.244）没有图形界面和浏览器，但许多 CLI 工具（rclone、gcloud、aws、gh CLI 等）的首次授权需要打开浏览器完成 OAuth 流程。

## 核心思路

利用 VPS 的公网 IP + 端口转发工具（socat），将 OAuth 本地回环服务器暴露到公网，用户从自己的机器访问并完成授权。

## 通用步骤

### 1. 安装 socat（如未安装）

```bash
which socat || apt-get install -y socat
```

### 2. 放行端口（UFW）

```bash
ufw allow <端口号>/tcp comment "OAuth temp"
```

### 3. 启动 OAuth 授权 + socat 转发

```
步骤 A：启动 CLI 工具的 OAuth 授权命令
        → 它会监听在 127.0.0.1:<端口>（通常是 53682 或 8080）
步骤 B：启动 socat，把 0.0.0.0:<公网端口> 转发到 127.0.0.1:<OAuth端口>
        socat TCP-LISTEN:<公网端口>,reuseaddr,fork TCP:127.0.0.1:<OAuth端口>
```

### 4. 给用户授权链接

```
http://<VPS公网IP>:<公网端口>/auth?state=...
```

### 5. 用户操作流程

1. 打开上面的链接 → 跳转到 Google/GitHub/其他 OAuth 提供方的登录页
2. 登录账户，点击「允许」
3. 授权后会跳转到 `http://127.0.0.1:<OAuth端口>/auth?code=...` （页面打不开）
4. **用户手动修改浏览器地址栏**：把 `127.0.0.1:<OAuth端口>` 改成 `<VPS公网IP>:<公网端口>`
5. 按回车 → 授权完成，页面显示「Success!」

### 6. 收尾

```bash
# 移除 UFW 规则
ufw delete allow <公网端口>/tcp
# 关闭 socat 和 OAuth 进程
kill %1 %2 2>/dev/null
```

## 实战案例：rclone Google Drive 授权

### 完整命令序列

```bash
# 1. 后台启动 rclone 授权（监听 127.0.0.1:53682）
rclone authorize "drive" > /tmp/rclone_auth.log 2>&1 &

# 2. 确认端口已监听
sleep 2
ss -tlnp | grep 53682

# 3. 放行 UFW
ufw allow 53683/tcp comment "rclone OAuth temp"

# 4. 启动 socat 转发（公网端口 53683 → VPS 127.0.0.1:53682）
socat TCP-LISTEN:53683,reuseaddr,fork TCP:127.0.0.1:53682 &

# 5. 提取授权 URL
cat /tmp/rclone_auth.log | grep "go to the following link"

# 6. 给用户公网 URL
# http://192.3.241.244:53683/auth?state=...

# （用户完成授权操作）

# 7. 完成授权后清理
ufw delete allow 53683/tcp
pkill -f "rclone authorize" 2>/dev/null
pkill -f "socat.*53683" 2>/dev/null
rm -f /tmp/rclone_auth.log
```

### 验证授权结果

```bash
# 查看 token 是否已写入
cat ~/.config/rclone/rclone.conf
# 检查是否有 token 字段
rclone ls <remote-name>: 2>&1 | head -5
```

## 常见陷阱

| 陷阱 | 说明 | 解法 |
|------|------|------|
| socat 端口冲突 | rclone 已占 53682，socat 无法 bind 同一端口 | socat 用不同端口（如 53683），让用户修正 URL 时一起改端口号 |
| UFW 拦截 | INPUT 策略 DROP，未放行的端口外部不可达 | `ufw allow <端口>` 或 `ufw allow from <特定IP> to any port <端口>` |
| iptables DNAT 失效 | PREROUTING DNAT 到 127.0.0.1 回程路由异常 | 改用 socat 端口转发，更可靠 |
| 用户浏览器跳转后打不开 | Google 回调到 127.0.0.1 用户本机，不是 VPS | 用户手动改地址栏：127.0.0.1:53682 → VPS_IP:公网端口 |
| OAuth 超时 | 授权码有效期短（通常 5-10 分钟） | 提前准备好所有步骤，用户操作要连贯 |
| 多用户同时授权 | socat fork 模式允许多连接，但 state 参数要匹配 | 一次只做一个 OAuth 流程，完成后立刻清理 |

## 参考文档

- `references/rclone-gdrive-config.md` — rclone Google Drive 具体配置记录，含完整命令序列和已知问题

---

## 替代方案

| 方案 | 优点 | 缺点 |
|------|------|------|
| socat 端口转发 | 轻量、无需额外工具 | 用户需手动修正 URL |
| Cloudflare Tunnel 代理 | 无需暴露额外端口 | 配置复杂，需修改 tunnel yaml |
| 用户本地装 CLI 授权 | 流程最顺畅 | 用户需在自己机器安装对应 CLI |
| SSH 端口转发 | 安全 | 用户需 SSH 客户端和 VPS 私钥 |
