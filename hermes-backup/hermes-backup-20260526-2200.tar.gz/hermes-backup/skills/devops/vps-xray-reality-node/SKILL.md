---
name: vps-xray-reality-node
description: 在 VPS 上用 Xray 新建 VLESS+REALITY 节点——协议/端口选型、密钥生成、config 配置、伪装验证、Shadowrocket+V2RayN 双端客户端配置生成
tags: [vps, xray, reality, vless, shadowrocket, v2rayn, proxy]
---

# VPS VLESS+REALITY 节点搭建

在已有 Xray 的 VPS 上，新增一个 VLESS+REALITY 入站节点，用于 Shadowrocket (iOS) 和 V2RayN (Windows) 双端代理。

## 前置条件

- VPS 已安装 Xray（`/usr/local/bin/xray`）
- Xray systemd 服务已启用
- root 或 sudo 权限
- 目标端口未被占用（推荐 443 或高位端口 8443）

## 步骤

### 1. 检查现有配置

```bash
cat /usr/local/etc/xray/config.json     # 查看现有 inbounds
ss -tlnp | grep -E '(xray|443|8443)'    # 检查端口占用
ufw status                               # 检查防火墙放行
```

### 2. 生成密钥对

```bash
xray x25519                              # PrivateKey + PublicKey
xray uuid                                # 客户端 UUID
```

输出示例：
```
PrivateKey: aL_z0lyqc92Z...
PublicKey: zvx9w9S8BQXp...
UUID: 5f83b823-43ef-4951-81b4-ab6beae32a0c
```

### 3. 选择伪装目标域名

REALITY 会将非代理流量转发到目标网站，使 TLS 握手看起来像正常的 HTTPS。

**推荐目标**：
- `www.apple.com` — 苹果，适用于 Shadowrocket 用户场景
- `www.microsoft.com` — 微软
- `www.amazon.com` — 亚马逊
- `www.cloudflare.com` — Cloudflare

用 openssl 验证目标域名可达：
```bash
echo "" | openssl s_client -connect www.apple.com:443 -servername www.apple.com 2>&1 | grep "subject="
```

### 4. 编辑 Xray 配置

在 `config.json` 的 `inbounds` 数组中添加新节点。

**关键参数说明**：

| 参数 | 值 | 说明 |
|------|-----|------|
| port | 443 或 8443 | 推荐443（伪装HTTPS）或高位端口 |
| flow | xtls-rprx-vision | REALITY 推荐 flow，改善 UDP 性能 |
| shortIds | 短 hex 串（如 6ba8e4f03d） | 可设多个，客户端任选一个 |
| serverNames | www.apple.com | 必须与 dest 域名匹配 |
| fingerprint | chrome | TLS 指纹伪装成 Chrome 浏览器 |

配置模板见 `references/config_template.json`。

### 5. 重启 Xray

```bash
systemctl restart xray
sleep 2
systemctl status xray --no-pager -l | head -15
ss -tlnp | grep xray    # 确认新端口在监听
```

### 6. 伪装验证

从外部扫描该端口，应返回目标网站的 TLS 证书：

```bash
# 验证证书伪装
echo "" | openssl s_client -connect <VPS_IP>:443 -servername www.apple.com 2>&1 | grep -E "subject=|issuer="

# 验证 HTTP 请求转发
curl -sk --connect-timeout 5 https://<VPS_IP>:443/ 2>&1 | head -5
```

预期结果：
- openssl 返回 Apple Inc. 的 EV 证书
- curl 返回「Invalid URL」（来自苹果服务器）

### 7. 防火墙

确认目标端口在 ufw/firewalld 中已放行：

```bash
ufw allow 443/tcp
```

### 8. 生成客户端配置

#### Shadowrocket (iOS) 导入

vless:// URI 格式：
```
vless://<UUID>@<SERVER_IP>:<PORT>?type=tcp&security=reality&pbk=<PUBLIC_KEY>&fp=chrome&sni=<SERVER_NAME>&sid=<SHORT_ID>&flow=xtls-rprx-vision#<NAME>
```

生成二维码（需 `pip install qrcode[pil]`）：
```python
import qrcode
link = "vless://..."
img = qrcode.make(link)
img.save('/tmp/vps-reality-qr.png')
```

#### V2RayN (Windows) 手动配置

| 字段 | 值 |
|------|-----|
| 地址 | VPS IP |
| 端口 | 443 |
| 用户ID | UUID |
| 加密方式 | none |
| 传输协议 | tcp |
| 伪装类型 | none |
| 安全 | reality |
| PublicKey | 生成的 PublicKey |
| ShortId | 如 6ba8e4f03d |
| ServerName | 如 www.apple.com |
| Fingerprint | chrome |
| Flow | xtls-rprx-vision |

## 验证清单

- [ ] Xray 日志无报错 (`journalctl -u xray --no-pager -n 20`)
- [ ] 新端口在监听 (`ss -tlnp | grep xray`)
- [ ] openssl 返回目标网站的 TLS 证书
- [ ] 防火墙已放行新端口
- [ ] 客户端配置已生成（vless:// 链接 + 二维码）

## 坑与注意事项

1. **端口冲突**：如果 443 已被 nginx 占用，可用其他端口或先停 nginx
2. **Xray 配置语法**：`flow` 字段要放在 `settings.clients[].flow` 中，不要放在 `streamSettings` 层
3. **shortIds 冲突**：不同节点用不同的 shortId，避免客户端连接串线
4. **fingerprint 必须指定**：REALITY 节点若缺省 fingerprint，部分客户端（如 Shadowrocket）会连接失败
5. **sniffing 开启**：建议在 inbound 中开启 sniffing + destOverride，改善 DNS 表现
6. **V2RayN 版本**：较旧版本可能不支持 `xtls-rprx-vision`，可降级为 `xtls-rprx-direct`
