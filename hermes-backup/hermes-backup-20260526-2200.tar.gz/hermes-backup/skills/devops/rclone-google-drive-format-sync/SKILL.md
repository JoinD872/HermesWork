---
name: rclone-google-drive-format-sync
description: Bidiectional sync between local files and Google Drive with format conversion (.md ↔ Google Docs), dual-folder management, and conflict prevention
tags:
  - rclone
  - google-drive
  - sync
  - format-conversion
  - cloud-storage
risk: write-safe
---

# Rclone Google Drive Format Sync

## When to use

- Setting up Google Drive as a sync intermediary between mobile (Google Docs app) and desktop (Obsidian, local .md)
- Converting between local formats (.md, .txt, .html) and native Google Docs/Sheets/Slides
- Managing **dual-format** folders: one for Google Docs (phone-editable), one for .md snapshots (desktop-syncable)
- Preventing format corruption when multiple rclone scripts operate on the same Drive folder

## Key patterns

### Import: local file → Google Doc

Upload a `.md` file and have Drive store it as a native Google Doc:

```bash
rclone copy <local_file> "remote:<path>/" \
  --drive-import-formats md \
  --drive-root-folder-id "<folder_id>"
```

**Result**: Drive stores the file as `application/vnd.google-apps.document` (native Google Doc). Verify with `rclone lsl` — size shows `-1`.

### Export: Google Doc → local .md

Download a Google Doc and have rclone convert it to `.md`:

```bash
rclone copy "remote:<path>/" <local_dir>/ \
  --drive-export-formats md \
  --drive-root-folder-id "<folder_id>"
```

**Result**: The Google Doc is downloaded as a `.md` file with the content converted to markdown. Used for reading into LLM context or syncing to local-only tools (Obsidian, etc.).

### Dual-folder pattern

Most robust setup for mobile editing + desktop sync:

```
Drive/
├── 笔记/          ← Google Docs (size -1, phone edits)
└── 笔记/MD快照/    ← .md snapshots (size > 0, desktop reads)
```

**Conversion pipeline** (runs every 30 min via cron):
```bash
# Step 1: Pull Google Docs as .md
rclone copy "remote:笔记/" /tmp/convert/ \
  --drive-export-formats md --size-only

# Step 2: Push .md to snapshot folder
rclone copy /tmp/convert/ "remote:笔记/MD快照/" \
  --size-only
```

## Critical pitfalls

### 1. Format overwrite (most dangerous)

If you `rclone copy` a `.md` file to Drive **without** `--drive-import-formats md`, it uploads as a plain `.md` file. If a Google Doc with the same name already exists, it overwrites the Google Doc — **user loses mobile editing ability**.

**Prevention**: Exclude the Google Doc folder from any plain rclone sync scripts:

```bash
rclone copy "$LOCAL_DIR/" "remote:" \
  --exclude "笔记/*" \
  --drive-root-folder-id "..."
```

Only the dedicated format-aware scripts should write to the Google Doc folder.

### 2. Import operations can hang

`--drive-import-formats` triggers a server-side conversion, which can be slow or timeout. Always wrap with `timeout`:

```bash
# Bad: hangs forever on a slow API
rclone copy ... --drive-import-formats md

# Good: bails after 90 seconds
timeout 90 rclone copy ... --drive-import-formats md || true
```

### 3. Google Doc filename on Drive

Drive shows the uploaded filename with its original extension (e.g., `2026-05-24-日记.md`). The `.md` suffix is cosmetic — the file IS a native Google Doc internally. User can tell by:
- `rclone lsl` shows size `-1`
- `rclone cat` returns the document content
- Google Drive app opens it as a Google Doc

### 4. Empty file cleanup

When using templates (e.g., diary daily creation):
- Newly created template is smaller than a filled-in version
- Compare file sizes to detect empty docs
- Delete both the Google Doc (from `笔记/`) and the .md snapshot (from `笔记/MD快照/`) together

## Real-world example: Diary system

```
08:00 daily cron → daily_diary.sh:
  1. Generate .md from template
  2. Push to 日记/ with --drive-import-formats md → Google Doc
  3. Push .md to 日记/日记MD/ → snapshot

Every 30 min → pull_user_notes.sh:
  1. Pull entire vault from Drive (no format flag)
  2. Pull 日记/ with --drive-export-formats md → .md version
  3. Push .md version to 日记/日记MD/

Sync vault → sync_vault_to_drive.sh:
  1. Push vault EXCLUDING 日记/* (to avoid format overwrite)
```

## Commands reference

| Operation | Flag | Direction |
|-----------|------|-----------|
| `.md` → Google Doc | `--drive-import-formats md` | local → Drive |
| Google Doc → `.md` | `--drive-export-formats md` | Drive → local |
| Multiple formats | `--drive-export-formats md,txt,docx` | Drive → local |
| Skip duplicates | `--size-only` | both directions |
| Prevent overwrite | `--exclude "folder/*"` | local → Drive |
