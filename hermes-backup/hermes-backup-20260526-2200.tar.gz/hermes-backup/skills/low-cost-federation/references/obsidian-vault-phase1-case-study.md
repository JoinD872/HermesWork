# Obsidian Vault Phase 1 — 四职能模型实战案例

> 记录时间：2026-05-23
> 项目：搭建 Hermes × Obsidian Vault 最小闭环（中文目录 + 白名单 + 模板 + 备份）

## 项目概览

| 项目 | 详情 |
|------|------|
| 风险等级 | 中 → 高（涉及 file_tools.py 源码修改） |
| 耗时 | 约 2 小时（含 GPT 审计修正） |
| Phase 数 | Phase 1.0（最小闭环）+ Phase 1.1（白名单）+ Phase 1.2（审计修正） |

## 各角色实际参与

### 小H（主控官）
- 接收任务、判断风险、分派
- 协调小策出模板方案 → 老V执行系统层 → 小研发 token 数据
- 最终输出验证报告

### 小策（方案官）
- 设计 Vault 目录结构（中文命名 + 数字前缀排序）
- 出 3 个 Markdown 模板（复盘模板.md / 文献模板.md / 收件箱模板.md）
- 设计权限规则（3写6禁 + 草稿统一写入收件箱AI）
- 设计 callback payload 扩展方案（`meta.vault` 字段）
- 评估 GPT 任务单的 6 个问题并修正

### 老V（执行官）
- 创建中文目录树
- 调研 write_file 白名单可行性（发现无现成机制，给出方案 A/B）
- 实现 file_tools.py 白名单代码（~96行，含 realpath 防 symlink 绕过）
- 配置 config.yaml（security.obsidian_vault）
- 执行 tar 本地备份
- 验证 A-E 全部测试项

### 小研（调研/验证/沉淀官）
- 输出 token 成本估算报告（DeepSeek Flash vs Pro 定价、缓存命中率、cron 频率建议）
- 提供三组精确数据用于成本预算
- 验证分类方案合理性

### 黑翼（风控官）
- 本轮未触发（Phase 1 为搭建阶段，风险可控，未涉及长期系统行为变更但已备份）

## 关键决策与修正

### 受 GPT 审计修正的 4 个点

| 纠正前 | 纠正后 | 原因 |
|--------|--------|------|
| 混用中英路径名（`收件箱AI/` vs `00_收件箱-AI/`） | 全程完整中文路径 | 白名单配置需精确匹配 |
| 草稿直接写目标目录（`Ideas/`、`项目文档/`） | 统一写 `00_收件箱-AI/`，frontmatter 标注 `target_dir` | 避免权限矛盾，便于后续 vault-digest 晋升 |
| Phase 1 直接加 rclone crypt | Phase 1 只做最小闭环（目录+模板+白名单+本地备份） | 减少 Phase 1 复杂度，rclone crypt 推迟到 Phase 1.5 或 3 |
| `abspath` 防路径绕过 | `realpath` 防路径绕过 | symlink 可绕过 abspath，需 resolve 实际路径 |
| `vault:true` 放 payload 顶层 | 放 `payload.meta` 下（含 `vault_target`、`vault_template`） | 不污染主字段，可扩展 |

### 重要规则确立

- **写入权限**：白名单外的 Vault 目录全部禁写，草稿统一走 `00_收件箱-AI/` + frontmatter 标注
- **路径安全**：必须用 `realpath`（或 `Path.resolve()`）而非 `abspath`，防 symlink 绕过
- **配置默认安全**：配置缺失时白名单不启用，不改变现有 write_file 行为
- **阶段衔接**：Phase 之间必须有检查点（≥24h 稳定运行），并有完整回滚方案

## 项目结构

```
~/.hermes/ObsidianVault/
├── 00_收件箱-AI/         ← 小H自动写
├── 00_收件箱-人工/       ← 禁写（云端入口）
├── 10_文献笔记/           ← 小H/小研自动写
├── 20_项目文档/           ← 禁写（草稿走收件箱）
├── 30_永久笔记/           ← 禁写（人工晋升区）
├── 40_复盘归档/           ← 小H/小研自动写
├── 50_Hermes架构/        ← 禁写（草稿走收件箱）
├── 灵感创意/              ← 禁写（草稿走收件箱）
└── 模板/                  ← 小策/人工维护，含3个模板
```

## 白名单实现关键代码

```python
# file_tools.py 中新增（L188-270）
def _check_obsidian_vault_path(path, task_id):
    resolved = os.path.realpath(os.path.expanduser(...))  # 防 symlink
    vault_root = os.path.realpath(os.path.expanduser(cfg["root"]))
    # Vault 外路径跳过
    if not resolved.startswith(vault_root):
        return None
    # 取顶层目录名
    top_dir = rel.split(os.sep)[0]
    if top_dir in writable:
        return None  # 允许
    # 不在白名单 → 返回中文错误引导写收件箱
    return "Error: use 00_收件箱-AI/ with status=draft"
```

## 教训总结

1. **路径一致性**：配置文件和报告中的路径标注必须完全一致，缩写会引发白名单配置 bug
2. **测试文件清理**：Phase 验证完成后必须删除测试文件，不留垃圾
3. **报告标注准确**：写权限标注必须跟 config 配置对得上，否则审计时会出问题
4. **symlink 防御**：路径校验必须用 realpath/resolve，不能只用 abspath
5. **最小闭环**：搭建阶段只做核心功能，不要一次铺太大。验证稳定后再加下一层
