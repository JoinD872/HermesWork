---
name: knowledge-base
description: 知识库搭建与管理 — 目录结构规范、写入权限、模板系统、AI Agent 知识沉淀规则、Federation callback 集成
risk: write-safe
version: 1.0
created: 2026-05-23
category: productivity
tags:
  - obsidian
  - knowledge-management
  - vault
  - writing-permissions
  - templates
related_skills:
  - federation-protocol-v320
  - low-cost-federation
---

# knowledge-base — AI Agent 知识库管理

> 当需要让 AI Agent（小H）将产出（复盘、研究、灵感、架构记录）整理成结构化 Markdown 知识库时使用。
> 核心原则：正式区只有一个 writer，其他都是入口。

## 核心架构

### 三阶段落地节奏（已实施）

```
Phase 1 ✅ 搭建骨架（已完成）
   建目录 → 配写入权限 → 出模板 → 测试写入 → 本地备份

Phase 1.5 ✅ Cloud Inbox（已完成）
   Google Drive 收件箱 → rclone pull → 00_收件箱-人工/
   详见 references/phase1.5-2-implementation.md

Phase 2 ✅ 通管道（已完成）
   cron 输出 → vault_ingest.py → 10_文献笔记/ / 40_复盘归档/
   联邦回执 → 自动分类入库
   详见 references/phase1.5-2-implementation.md

Phase 3 接外部（规划中）
   多端同步已通过 Google Drive 实现 → 暂无需额外工作
```

### 最小闭环原则
- 每个 Phase 只做该阶段必要的事，不做下阶段功能
- 每 Phase 有自己的验证清单和回滚方案
- 测试产物验证后必须清理

## 目录结构规范

### 数字前缀排序

推荐按使用频率为目录加数字前缀，以便在文件管理器中自然排序：

```
00_收件箱-AI/           # 00 = 最频繁，显示在最上
00_收件箱-人工/         # 00 = 跟收件箱并列
10_文献笔记/            # 10-19 = 中等频率
20_项目文档/            # 20-29 = 项目类
30_永久笔记/            # 30 = 成熟知识
40_复盘归档/            # 40 = 归档类
50_架构记录/            # 50 = 系统架构类
灵感创意/               # 无数字 = 尾部
模板/                   # 无数字 = 固定资源
```

### 目录命名
- 中文名对国内用户更友好，Linux / Obsidian 均原生支持 UTF-8 路径
- 收件箱用 `00_` 前缀确保显示在最前
- 模板目录单独放置，不参与知识图谱

## 写入权限模型

### 三级权限

| 级别 | 说明 | 示例目录 |
|------|------|---------|
| **可写（writable）** | AI Agent 可自由写入 | 收件箱-AI、文献笔记、复盘归档 |
| **草稿区（draft-only）** | 只能向收件箱写草稿，标注 target_dir | 项目文档、永久笔记、灵感创意 |
| **只读/人工** | 仅人工编辑，AI 不出草稿 | — |

### 实现方式

在 `write_file` 或等价工具中加入路径校验：

```python
def check_vault_path(path, config):
    resolved = os.path.abspath(os.path.expanduser(path))
    vault_root = os.path.abspath(os.path.expanduser(config["root"]))

    if not resolved.startswith(vault_root):
        return None  # Vault 外跳过

    rel = resolved[len(vault_root):].lstrip(os.sep)
    top_dir = rel.split(os.sep)[0]

    if top_dir in config["writable_dirs"]:
        return None  # 允许
    if top_dir in config["draft_only_dirs"]:
        return "Error: 该目录为草稿区，请写入收件箱"
    return "Error: 目录不在白名单中"
```

**安全要求：**
- 使用 `expanduser` + `abspath` / `resolve` 防 `../` 绕过
- 配置缺失时默认不启用白名单（安全降级）
- 配置变更需先备份 config 文件

## 草稿规范

当 AI 写入内容但目标目录属于禁写区时：

1. **实际路径**：写入 `00_收件箱-AI/`
2. **frontmatter 必含**：

```yaml
---
title: "..."
date: YYYY-MM-DD
status: draft
target_dir: "目标目录名"    # 如"20_项目文档"
promotion_required: true    # 标记需要人工审核
---
```

3. **人工确认后**：将文件从收件箱移到目标目录，修改 frontmatter 中 `status: draft` → `status: promoted`

## 模板系统

### 模板目录
所有模板放在独立 `模板/` 目录下，不允许 AI 自动修改。

### 推荐模板类型

| 模板 | 用途 | frontmatter type |
|------|------|:---:|
| 复盘模板 | VPS 排障、巡检、系统复盘 | `recap` |
| 文献模板 | 研究报告、外部资料摘要 | `literature` |
| 收件箱模板 | 灵感、创意、待整理内容 | `inbox` |
| 日记模板 | 每日日记（极简，仅日期+空白） | `diary` |

### 日记系统

极简模板：只保留日期和空白区域，不给用户填写压力。

- 模板：`模板/日记模板.md`
- 每天上海 08:00 自动创建 `日记/{date}-日记.md`
- 第二天自动清理未填写的空日记
- 详见 `references/phase1.5-2-implementation.md`（日记系统章节）

### 模板格式
- 使用 `{{placeholder}}` 做占位符，AI 写入时替换
- 必须有 YAML frontmatter
- 必须包含双链候选区（`[[相关文档]]`）
- 必须包含后续动作区

## Federation callback 集成（已通过 vault_ingest.py 实现）

详见 `references/phase1.5-2-implementation.md`。不再依赖 `payload.meta` 标记——vault_ingest.py 自动扫描 callback 目录，根据 task_id 分类入库：

| task_id 前缀 | 目标目录 | 处理方式 |
|-------------|---------|---------|
| MINIMAX_DAILY / MINIMAX_SCAN | 10_文献笔记 | key_findings+action_items 结构化写入 |
| RESEARCH | 10_文献笔记 | 同上 |
| PAIN (健康) | 10_文献笔记 | 同上 |
| UE5WP / UE5 | 10_文献笔记 | 同上 |
| vps-patrol | 40_复盘归档 | 直接归档 |
| 其他 | 00_收件箱-AI | 进入等待处理的收件箱 |

## 输出标准化

每条知识库文档包含：

```markdown
---
title: "{{标题}}"
date: YYYY-MM-DD
source: Chat / Web / Github / PDF / 其他
tags: [#Hermes, #标签]
status: completed / draft / processed
type: recap / literature / inbox
---

# 标题

## 核心结论
- 点1
- 点2

## 详情
...

## 后续动作
- 是否固化进 Memory
- 是否归档项目文档

---
双链候选：
- [[相关文档]]
标签：#标签
```

## 常见陷阱

- ❌ 测试笔记留在 Vault → 验证完成后必须清理
- ❌ 收件箱堆积不整理 → 建议每周自动汇总过期收件箱成 digest
- ❌ 多层 live sync 混用 → 只保留一层 live sync，其余做备份层
- ❌ AI 把目录写乱（taxonomy drift）→ 白名单+模板约束
