# Obsidian Vault Phase 1 实施记录

> 2026-05-23 实施 | 参考：knowledge-base/SKILL.md

## 目录结构

```text
~/.hermes/ObsidianVault/
├── 00_收件箱-AI/           # 小H/小研 自动写
├── 00_收件箱-人工/         # 云端收件箱回拉入口
├── 10_文献笔记/            # 小H/小研 自动写
├── 20_项目文档/            # 草稿区（仅收件箱写草稿）
├── 30_永久笔记/            # 草稿区（仅收件箱写草稿）
├── 40_复盘归档/            # 小H/小研 自动写
├── 50_Hermes架构/         # 草稿区（仅收件箱写草稿）
├── 灵感创意/               # 草稿区（仅收件箱写草稿）
└── 模板/                   # 固定模板，AI不可自动修改
```

## 权限配置（config.yaml 示例）

```yaml
security:
  obsidian_vault:
    enabled: true
    root: "~/.hermes/ObsidianVault"
    writable_dirs:
      - "00_收件箱-AI"
      - "10_文献笔记"
      - "40_复盘归档"
    draft_only_dirs:
      - "20_项目文档"
      - "30_永久笔记"
      - "50_Hermes架构"
      - "灵感创意"
```

## 代码改动

`tools/file_tools.py` 新增两个函数（约 +96 行）：
- `_load_obsidian_vault_config()` — 线程安全的配置加载器
- `_check_obsidian_vault_path()` — 路径校验（expanduser + abspath 防 ../ 绕过）

在 `write_file_tool()` 的敏感路径检查之后插入校验调用。

## 模板列表

| 文件 | 用途 |
|------|------|
| `模板/复盘模板.md` | VPS排障/巡检/系统复盘 |
| `模板/文献模板.md` | 研究报告/外部摘要 |
| `模板/收件箱模板.md` | 灵感/创意/待整理 |

所有模板使用 `{{placeholder}}` 占位符。

## 备份

```bash
# file_tools.py 备份
cp ~/.hermes/hermes-agent/tools/file_tools.py ~/.hermes/hermes-agent/tools/file_tools.py.bak.$(date +%Y%m%d-%H%M%S)

# config.yaml 备份
cp ~/.hermes/config.yaml ~/.hermes/config.yaml.bak.$(date +%Y%m%d-%H%M%S)

# Vault 整体备份
tar -czf ~/.hermes/backups/obsidian-vault-$(date +%Y%m%d-%H%M%S).tar.gz -C ~/.hermes ObsidianVault
```

## 验证清单

1. `00_收件箱-AI/` 可写 ✅
2. `10_文献笔记/` 可写 ✅
3. `40_复盘归档/` 可写 ✅
4. `20_项目文档/` 不可写 ❌ 返回中文错误
5. `30_永久笔记/` 不可写 ❌
6. `50_Hermes架构/` 不可写 ❌
7. `灵感创意/` 不可写 ❌
8. `../` 绕过测试被拒 ❌
9. Vault 外 write_file 不受影响 ✅
10. tar 本地备份成功 ✅
