---
name: daily-diary
description: 每日日记自动化系统 — 模板设计、Google Docs 创建、自动清理、用户笔记同步
trigger: user wants to start/configure daily journaling, diary creation, or a personal note-taking system synced with Obsidian
risk: write-safe
---

# Daily Diary — 每日日记自动化系统

## Overview

Automated daily diary system with Google Docs integration. Creates a daily journal file at **Shanghai 08:00**, uploaded to a specific Google Drive folder as a native Google Doc (editable on mobile). User writes in the early morning hours (凌晨); unfilled entries auto-delete the next day. Filled entries sync back to Obsidian Vault as `.md`.

## Components

1. **Diary template** — Minimal "凌晨倾倒式" format: date header + free-write area + 灵感想法 section
2. **Creation script** (`scripts/daily_diary.sh`) — Creates `.md` locally, uploads to Drive with `--drive-import-formats md` to convert to Google Doc
3. **Cleanup logic** — Next-day run: pull back, compare size vs template, delete empty files
4. **Pull-back pipeline** — Filled diaries sync back to Vault via `pull_user_notes.sh`
5. **Cron job** — `0 0 * * *` UTC (= Shanghai 08:00), `no_agent=true`

## User Context

- Writes diary at **凌晨 (2-6am Shanghai time)**
- Uses **Google Docs app on mobile** — cannot create .txt/.md files on Drive mobile
- Template must be minimal, no form-filling pressure
- Diaries that aren't filled are auto-deleted (no guilt)
- Diary doubles as idea/inspiration capture (same file, bottom section)

## Template Format

```markdown
---
title: "{{date}} 日记"
date: {{date}}
type: diary
status: draft
---

# {{date}}
                              ← free-write area (user writes anything)

# 灵感、想法                  ← ideas section below
```

The user explicitly rejected structured templates (gratitude/CBT/mood-tracker). Keep it to just a date header + free write + ideas section.

## Google Docs Conversion

### Creation (VPS → Drive)

```bash
# Creates .md locally, uploads as Google Doc on Drive
rclone copy "$LOCAL_DIARY.md" "mydrive:日记/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-import-formats md \
  -q
```

- `--drive-import-formats md` converts the `.md` file into a native Google Doc on Drive
- Google Docs show as `-1` size in `rclone ls` (expected)
- File is immediately editable in Google Docs mobile app

### Pull-back (Drive → VPS)

```bash
# Pulls Google Doc back, exports as .md
rclone copy "mydrive:日记/$DATE-日记.md" "$STAGE/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-export-formats md \
  --size-only -q
```

- Export produces a `.md` file (~200-300 bytes for template, larger if user wrote)
- Frontmatter may be flattened to single line on re-export — this is acceptable

## Cleanup Logic

Check if diary was filled by comparing file sizes:

```bash
TEMPLATE_SIZE=$(wc -c < "$TEMPLATE")
PULLED_SIZE=$(wc -c < "$PULLED_DIARY")
if [ "$PULLED_SIZE" -gt "$TEMPLATE_SIZE" ]; then
  # User wrote something — copy to Vault
  cp "$PULLED_DIARY" "$VAULT_DIR/日记/"
else
  # Empty — delete from Drive + local
  rclone delete "mydrive:日记/$YESTERDAY-日记.md" --drive-root-folder-id "$FOLDER_ID" -q
  rm -f "$VAULT_DIR/日记/$YESTERDAY-日记.md"
fi
```

Threshold: file is "filled" if size exceeds template size. Template is ~90 bytes; even a few words of user input will exceed this.

## Cron Job Setup

```json
{
  "schedule": "0 0 * * *",
  "name": "每日日记 — 创建+清理",
  "script": "bash ~/.hermes/scripts/daily_diary.sh",
  "no_agent": true,
  "deliver": "local"
}
```

- `0 0 * * *` UTC = **08:00 Shanghai** (UTC+8)
- Must run AFTER `pull_user_notes.sh` (or combined) so yesterday's diary is pulled before cleanup
- `no_agent=true`: pure bash, no LLM cost
- `deliver: local`: silent operation, no chat spam

## Google Drive Folder Targeting

Use `--drive-root-folder-id` to target a specific folder rather than the Drive root:

```
FOLDER_ID="1XvPIqFqftMhG_4QSC9LnApxue_ayvAmg"
rclone copy ... "mydrive:" --drive-root-folder-id "$FOLDER_ID" ...
```

This is the user's existing Obsidian vault folder on Drive. All diary/note files live inside this folder.

## User Preference: No Title Limitation

The user explicitly said not to refer to them as "UE5策划" or game-related roles. Treat them as a regular internet worker. Don't frame analysis through a game-dev lens unless the topic is explicitly about game development.

## Script Location

- `~/.hermes/scripts/daily_diary.sh` — Main diary creation + cleanup
- `~/.hermes/scripts/pull_user_notes.sh` — Reverse sync (Drive → VPS), includes diary pull-back
- `~/.hermes/ObsidianVault/模板/日记模板.md` — Diary template

## Related Skills

- `obsidian-cloud-inbox`: Google Drive → Vault inbox pipeline (complementary)
- `research-workflow`: Analysis output format with data-driven style preference (Section 8)
- `cron-output-standard`: Cron job output format norms
