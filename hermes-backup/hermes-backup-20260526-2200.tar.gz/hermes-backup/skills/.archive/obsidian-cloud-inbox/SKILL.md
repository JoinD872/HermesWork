---
name: obsidian-cloud-inbox
description: Set up and maintain a Google Drive → Obsidian Vault cloud inbox pipeline with Google Docs export support
trigger: user wants to sync Google Docs or files from Google Drive into Obsidian Vault, or extend an existing cloud inbox
---

# Obsidian Cloud Inbox

## Overview
Bridge Google Drive (as a cloud inbox) into the Hermes Obsidian Vault. Users drop `.md`/`.txt` files **or create Google Docs** in a Drive folder; a scheduled cron job pulls them, adds Obsidian frontmatter, and places them in the Vault's inbox directory for processing.

## Components
1. **rclone remote** — Google Drive remote with `export_formats = md,txt,docx` to auto-export Google Docs as Markdown
2. **Pull script** — `rclone move` from Drive → local staging → Vault inbox with frontmatter
3. **Cron job** — `*/30 * * * *`, `no_agent=true`, runs the bash script

## Setup Steps

### 1. rclone Config
The remote must include `export_formats`. Google Docs (`.gdoc`) are auto-exported to the **first format** in the list (`md` in this case):

```ini
[mydrive]
type = drive
token = <OAuth token>
team_drive = 
export_formats = md,txt,docx
```

Files are cleaned from Drive after successful move.

### 2. Pull Script
Key elements of `pull_cloud_inbox.sh`:

```bash
# Include ALL source extensions, including .gdoc
rclone move "$REMOTE_INBOX" "$STAGE/" \
  --include "*.md" \
  --include "*.txt" \
  --include "*.gdoc" \
  --delete-empty-src-dirs \
  -v 2>&1

# Process each file: add Obsidian frontmatter, rename with date prefix
find "$STAGE" -type f \( -name "*.md" -o -name "*.txt" \) | while read -r f; do
  base="$(basename "$f" | sed 's/\.[^.]*$//')"
  dest="$VAULT/00_收件箱-人工/$(date +%Y%m%d)-$base.md"
  {
    printf -- "---\n"
    printf "created: %s\n" "$(date -Iseconds)"
    printf "source: cloud-inbox\n"
    printf "status: unprocessed\n"
    printf "promotion_required: true\n"
    printf -- "---\n\n"
    cat "$f"
    printf "\n"
  } > "$dest"
  rm -f "$f"
done
```

**Critical: include `*.gdoc` in the filter.** Google Docs appear as `.gdoc` files in Drive listings. Without this, they're silently skipped.

### 3. Cron Job
```json
{
  "schedule": "*/30 * * * *",
  "no_agent": true,
  "script": "pull_cloud_inbox.sh"
}
```

Use `no_agent=true` since this is a pure bash script — no LLM reasoning needed.

## Usage Flow
1. User opens Google Drive on mobile/desktop
2. Creates a **Google Doc** (→ `.gdoc`) or uploads `.md`/`.txt` to the inbox folder
3. Cron runs → pulls new files → exports `.gdoc` → `.md` → adds frontmatter → places in Vault inbox
4. Agent picks up processed notes for organization

## User Preference: Google Docs First
This user prefers creating Google Docs online rather than uploading raw files. Google Docs offers a better editing experience on mobile. The pipeline is designed to treat `.gdoc` as a first-class input format.

## Pitfalls
- **Include *.gdoc or lose Docs**: Google Docs silently skipped if filter doesn't include `*.gdoc`
- **rclone delete = one path only**: Use `rclone deletefile` for individual file cleanup, not the bulk `delete` command
- **OAuth on headless VPS**: Google's OAuth redirect won't go back to a raw IP. Workaround: run `rclone authorize` on VPS with socat port forwarding, have user manually replace `localhost` with VPS IP in the callback URL
- **Token refresh**: rclone handles refresh tokens automatically — no manual intervention needed once initial auth is captured
- **File naming**: Google Doc titles become filenames; the script strips extension and adds date prefix for uniqueness

## Related Skills
- `hermes-agent`: CLI for cron job management (`cronjob` tool)
- `hermes-internals`: Vault whitelist config in `config.yaml`
- `github-file-read-write`: Alternative sync target (GitHub workspace, not Drive)
