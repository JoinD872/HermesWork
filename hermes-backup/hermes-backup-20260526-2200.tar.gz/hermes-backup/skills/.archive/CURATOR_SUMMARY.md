## Structured summary (required)
```yaml
consolidations:
  - from: community-content-extraction
    into: community-content-scraping
    reason: Pure subset — every curl command, capability matrix entry, and limitation in extraction was already present in the stronger scraping umbrella; zero unique content to merge
  - from: community-intelligence-gathering
    into: community-content-scraping
    reason: Cron pipeline layer (dedup strategy, X/Twitter cron-only restrictions, exception notification protocol, quarterly maintenance check) merged as new "定时情报采集" section; xiaohongshu-blocked.md reference moved to umbrella
  - from: knowledge-base
    into: hermes-obsidian-vault
    reason: Same domain (Obsidian Vault) with near-identical directory/permissions/templates coverage; unique content (vault_ingest.py routing table, output standardization, common pitfalls, phase1.5-2 implementation reference) absorbed into umbrella SKILL.md and references/
  - from: obsidian-cloud-inbox
    into: hermes-obsidian-vault
    reason: Component of the Vault ecosystem (Phase 1.5 Cloud Inbox); operational details (rclone config, pull script, cron setup, pitfalls) demoted to references/cloud-inbox-pipeline.md under the umbrella
  - from: daily-diary
    into: hermes-obsidian-vault
    reason: Component of the Vault ecosystem (Phase 1.5 diary system); operational details (template, rclone conversion, cleanup logic, cron setup) demoted to references/daily-diary-system.md under the umbrella
prunings:
  - name: rclone-google-drive-headless-oauth
    reason: Fully consumed by vps-oauth-proxy's existing "实战案例：rclone Google Drive 授权" section plus references/rclone-gdrive-config.md; zero unique content (identical socat/UFW/URL-correction workflow, same pitfalls)
```
