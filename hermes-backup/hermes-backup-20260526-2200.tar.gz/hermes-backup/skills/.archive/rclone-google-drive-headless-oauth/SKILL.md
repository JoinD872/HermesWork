---
name: rclone-google-drive-headless-oauth
description: 无图形界面的 VPS/服务器上配置 rclone Google Drive OAuth 授权 — socat 端口转发 + UFW 放行 + URL 修改法
category: devops
risk: write-safe
---

# Rclone Google Drive Headless OAuth

## 场景
在纯命令行的 VPS 上（无桌面、无浏览器、无 SSH X11 forwarding）需要给 rclone 授权 Google Drive。

## 标准方法（无效时）
`rclone authorize "drive"` 会在 `127.0.0.1:53682` 启动一个 HTTP 服务器等待回调。但 VPS 无浏览器，用户无法访问 `127.0.0.1`。

## 完整步骤

### 1. 安装 rclone + socat（如未装）
```bash
apt-get update && apt-get install -y rclone socat
```

### 2. 创建 rclone config（可选，用默认 client_id）
```bash
rclone config create mydrive drive
# 或直接运行 authorize
```

### 3. 启动 rclone authorize（后台）
```bash
rclone authorize "drive" > /tmp/rclone_auth.log 2>&1 &
sleep 3
cat /tmp/rclone_auth.log
# 输出会包含 URL：http://127.0.0.1:53682/auth?state=xxx
```

### 4. 端口转发（socat）
由于 rclone 只监听 `127.0.0.1`，用 socat 转发公网端口到本地：
```bash
# 选一个未使用的端口（如 53683）
socat TCP-LISTEN:53683,reuseaddr,fork TCP:127.0.0.1:53682 &
```

### 5. 放行防火墙（UFW）
```bash
ufw allow 53683/tcp comment "rclone OAuth temp"
```

### 6. 给用户 URL
用户浏览器访问 `http://<VPS_IP>:53683/auth?state=xxx`

### 7. Google OAuth 回调修复
Google 会重定向到 `http://127.0.0.1:53682/auth?code=xxx`（用户本机）。
**用户需要将地址栏中的 `127.0.0.1:53682` 改为 `<VPS_IP>:53683`，回车后即可完成授权。**

### 8. 验证
```bash
# rclone 日志应更新，显示成功
cat /tmp/rclone_auth.log
# 测试
rclone ls mydrive:
```

### 9. 清理
```bash
ufw delete allow 53683/tcp
kill %1 %2 2>/dev/null
```

## 坑点
| 坑 | 原因 | 解决 |
|----|------|------|
| socat bind 失败 | rclone 已在 53682 监听，socat 绑定同端口冲突 | socat 用不同端口（53683） |
| iptables DNAT 无效 | 回程路由问题；UFW 默认 DROP | 改用 socat + UFW 放行 |
| 用户授权后无反应 | OAuth 回调地址是 127.0.0.1，用户本机无法访问 VPS 的 127.0.0.1 | 手动改 URL 中的 IP 和端口 |
| `rclone authorize` 后台无输出 | stdout/stderr 可能被缓冲 | 重定向到文件后读取 |
