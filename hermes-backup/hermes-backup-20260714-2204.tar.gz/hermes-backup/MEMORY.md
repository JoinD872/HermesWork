GitHub PAT 实际位置在 /root/.hermes/scripts/hermes-backup.sh（不在 .env），用户 JoinD872，仓库 JoinD872/HermesWork（私人），Token 前缀 ghp_6q...XGvJ。以后查 GitHub 认证先看 backup.sh。
§
用户云端迭代工作流 — 主力走 GitHub：文件放 JoinD872/HermesWork/workspace/，用户在网页版改，我读+改+提交推送。不走百度网盘/飞书云盘。补充：Google Drive 用于 Obsidian Cloud Inbox（HermesInbox/ 文件夹，每30min拉取到 Vault 收件箱），仅做灵感投递不用于代码迭代。
§
## 低频流程索引（详情查对应 skill）
宠物技能设计：skill `pet-skill-design-workflow` | crawl4ai：skill `community-scraping` | 日记格式：skill `obsidian`
§
图片理解：主力 OpenCode Go minimax-m3（视觉），备用 GitHub Models gpt-4o（免费）。不用 DeepSeek 直连（用户要求非订阅付费 API 不用）。
§
## Windows/黑翼
SSH: `ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37`，工作目录 E:\Hermes\。两台机器：desktop-tg4loen（在线）+ 笔记本（离线30天+）。
小红书 headless 被拦（300012），需用户桌面非 headless 浏览器配合。
§
知乎已升级为官方API：ZHIHU_ACCESS_SECRET存于.env，developer.zhihu.com，每天1000次免费搜索。
§
## 通知与日记偏好
无事不通知；cron 用 silent script + deliver=local。Vault/日记默认被动，不主动读/写，等用户问再说。日记路径：~/.hermes/ObsidianVault/日记/ | 模板在 模板/日记模板.md
§
AI 偏好：Gemini "回答简短、语言贫乏、刻意迎合"；GPT "内容衍生多、思维更广"。不要 yes-man，要能发散碰撞的对话伙伴。
§
Codex CLI 当前版本 0.133.0（2026-05-23 升级）。Codex 无持久记忆——每次 exec 独立会话，需显式附带上下文。高推理模式：`codex exec -c 'reasoning_effort="high"'`。
§
## VPS/cron 自动化
IP 192.3.241.244 | SSH user=root（非joind，joind仅Windows）端口2222 | Xray 8081 VLESS+WS → CF Tunnel | cron no_agent script 只写文件名不加 shell 前缀
§
## 协作模型 V2（2026-06-01 经 Codex 迭代确认）

### 六个参与方
小H（主控）、Codex（外脑）、小策（方案官）、小研（调研/验证/沉淀官）、黑翼（风控官）、老V（执行官）

### Codex 规则
强默认前置参与所有任务。跳过需显式记录状态+原因：called / skipped_quota(附原因) / lite_check(说明覆盖)。配额耗尽时不阻塞。

### 路由细则
中风险：小策必参与。小研按需（资料核验/事实准确性/可行性/工具对比/效果验证时触发）。老V按需（有执行时）。黑翼不参与。
高风险：小策必参与。黑翼必参与。小研按需（同中风险触发）。老V按需。
低风险：小H处理。但写入文件/改配置/部署/调API/付费/权限变更不得小H直接执行，必须走老V。

### 用户确认闸门
高风险/不可逆/付费/权限/生产/隐私操作，执行前小H必须确认：方案+影响+风险+回滚。用户必须明确确认，沉默不算授权。

### 冲突仲裁优先级
安全/权限边界 > 用户当前指令 > 用户原始目标 > SOUL.md/memory规则 > 小H判断。可验证事实校正所有层级。高风险冲突不得静默合并。
§
## 运维信条
应用层连接错误 ≠ 应用本身故障。排查顺序：① DNS(/etc/resolv.conf + resolvectl) → ② TCP → ③ 代理/出口(WARP/Tailscale) → ④ 服务 → ⑤ 配置 → ⑥ 业务逻辑。网络组件修改必须 Before→Snapshot→Modify→HealthCheck→Rollback。Tailscale 不只是 VPN，它还管理 DNS (MagicDNS)。WARP warp 模式 (全流量隧道) 会触发 Tailscale DNS 接管，只允许 proxy 模式。
§
优选 IP 测试规则：VPS 只能验证隧道连通性（curl --resolve + HTTP 400=通），VPS 端的延迟数字对中国用户无参考价值。严禁报 VPS 侧测速结果（如"这个 IP 只要 72ms"）给用户做优选依据。用户必须自己从 Windows 侧 ping 或 CloudflareSpeedTest 测速。
§
MoA 参考顾问模型：用户偏好用 mimo-v2.5（非 pro 版）。mimo-v2.5 在 OpenCode Go 上可用，mimo-v2.5-pro 是更重量的版本，用户不需要。