# AI API 月订阅市场格局（2026.07 调研）

> 调研来源：2026-07-29 session，用户需要可当 Hermes provider 的国外 API 订阅。
> 核心发现：**这个市场极小**，大多数 AI API 是 PAYG，Flat-rate 订阅极罕见。

---

## 市场格局总览

| 定价模式 | 代表服务 | 占比 |
|---------|---------|------|
| **PAYG（按 token/请求付费）** | OpenAI, Anthropic, Google Gemini, DeepSeek, Together AI, Fireworks, Groq, OpenRouter, Novita, AIMLAPI | ~90%+ |
| **月订阅 + API 配额** | OpenCode Go ($10)、GitHub Copilot Pro ($10/$39/$100, 含信用额度) | ~5% |
| **月订阅（聊天/IDE 类，非 API）** | Cursor, Windsurf, Claude Pro/Max, ChatGPT Plus, Poe, Perplexity | ~5% |

---

## 可当 Hermes provider 的月订阅列表

| 服务 | 月费 | 含什么 | Hermes 集成 | ⚠️ 限制 |
|:---|:---:|:---|:---:|:---|
| **OpenCode Go** | $10 | DeepSeek V4 Flash + MiMo 视觉 | ✅ 直接配置 | 国内服务 |
| **GitHub Copilot Pro** | $10 | $15 API 信用额度 | ⚠️ 需配 GitHub Models API | 速率限制极严（高级模型 5 req/day） |
| **GitHub Copilot Pro+** | $39 | $70 API 信用额度 | ⚠️ 同上 | 速率限制同样严格 |
| **GitHub Copilot Max** | $100 | $200 API 信用额度 | ⚠️ 同上 | 适合重度用户 |
| **Hugging Face Pro** | $9 | 推理积分 | ✅ 但限 HF 开源模型 | 没有 deepseek/claude/gpt |

---

## Cursor 用量模型（单独记录，因为是最常被问到的 IDE 产品）

虽然 Cursor 是 IDE 不是 API provider，但因其常被拿来当"coding plan"提及：

- **双用量池**：Cursor Models（Grok 4.5 + Composer 2.5）和 Other Models（Claude/GPT/Gemini 等第三方）
- Cursor Models 池：Pro 给 "generous limits"，Pro+ 的 3x，Ultra 的 20x Pro
- Other Models 池：Pro 含至少 $20/月第三方额度，更多计划更多
- 超限策略：用完可继续按 API 价付费

### Cursor 可用模型（2026.07）

| 模型 | 提供方 | 默认上下文 | 最大上下文 | 特性 |
|------|-------|:---:|:---:|------|
| Claude Sonnet 5 | Anthropic | 200k | 1M | Agent+思考+图片 |
| Claude Opus 5 | Anthropic | 300k | 1M | Agent+思考+图片 |
| Claude Fable 5 | Anthropic | 300k | 1M | Agent+思考+图片 |
| GPT-5.6 Sol | OpenAI | 272k | 1M | Agent+思考+图片 |
| GPT-5.6 Luna | OpenAI | 272k | — | Agent+思考+图片 |
| GPT-5.6 Terra | OpenAI | 272k | — | Agent+思考+图片 |
| Gemini 3.1 Pro | Google | 200k | 1M | Agent+思考+图片 |
| Gemini 3.6 Flash | Google | 200k | 1M | Agent+思考+图片 |
| Grok 4.5 | xAI via Cursor | 256k | — | Agent+思考，无图片 |
| Composer 2.5 | Cursor 自有 | 200k | — | Agent+思考+图片 |

---

## GitHub Models 速率限制（免费/Pro 层）

| 层级 | 请求/分 | 请求/天 | Token/请求 | 并发 |
|:---|:---:|:---:|:---:|:---:|
| 低限 | 15 | 150 | 8k入/4k出 | 5 |
| 高限 | 10 | 50 | 8k入/4k出 | 5 |
| 高级模型（Opus/GPT） | 5 | **5** | 1k-4k入 | **1** |

→ Pro 层每天高级模型只能用 5 次，对 Hermes 不够用。

---

## 总结

> 能找到的国外 API 月订阅选项——实际上只有 GitHub Copilot 系列（$10-100/mo，含信用额度）和 Hugging Face Pro（$9/mo，限开源模型）。**OpenCode Go 在 $10 价位是该品类的性价比之王，国外没有真正平替。**
