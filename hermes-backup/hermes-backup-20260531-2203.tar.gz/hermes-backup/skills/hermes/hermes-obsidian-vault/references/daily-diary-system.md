# 每日日记系统 — Daily Diary Automation

> Phase 1.5 component. Automated daily journaling with Google Docs integration.

## Overview

Creates a daily journal file at **Shanghai 08:00**, uploaded to Google Drive as a native Google Doc (editable on mobile). User writes in the early morning hours (凌晨); unfilled entries auto-delete the next day. Filled entries sync back to Obsidian Vault as `.md`.

## User Context

- Writes diary at **凌晨 (2-6am Shanghai time)**
- Uses **Google Docs app on mobile** — cannot create .txt/.md files on Drive mobile
- Template must be minimal, no form-filling pressure
- Diaries that aren't filled are auto-deleted (no guilt)
- Diary doubles as idea/inspiration capture (same file, bottom section)
- User explicitly rejected structured templates (gratitude/CBT/mood-tracker)

## Components

1. **Diary template** — `~/.hermes/ObsidianVault/模板/日记模板.md`
2. **Creation script** — `~/.hermes/scripts/daily_diary.sh`
3. **Cleanup + pull-back** — Same script, runs next day
4. **Cron job** — `0 0 * * *` UTC (= Shanghai 08:00), `no_agent=true`

## Template Format

```markdown
---
title: "{{date}} 日记"
date: {{date}}
type: diary
status: draft
---

# {{date}}
                              ← free-write area (user writes anything)

# 灵感、想法                  ← ideas section below
```

Keep it to just a date header + free write + ideas section. No structured prompts.

## Google Docs Conversion

### Creation (VPS → Drive)

```bash
rclone copy "$LOCAL_DIARY.md" "mydrive:日记/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-import-formats md \
  -q
```

- `--drive-import-formats md` converts `.md` → native Google Doc
- Google Docs show as `-1` size in `rclone ls` (expected)

### Pull-back (Drive → VPS, for cleanup check)

```bash
rclone copy "mydrive:日记/$DATE-日记.md" "$STAGE/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-export-formats md \
  --size-only -q
```

Frontmatter may be flattened to single line on re-export — acceptable.

## Cleanup Logic

```bash
TEMPLATE_SIZE=$(wc -c < "$TEMPLATE")
PULLED_SIZE=$(wc -c < "$PULLED_DIARY")
if [ "$PULLED_SIZE" -gt "$TEMPLATE_SIZE" ]; then
  # User wrote something — copy to Vault
  cp "$PULLED_DIARY" "$VAULT_DIR/日记/"
else
  # Empty — delete from Drive + local
  rclone delete "mydrive:日记/$YESTERDAY-日记.md" --drive-root-folder-id "$FOLDER_ID" -q
  rm -f "$VAULT_DIR/日记/$YESTERDAY-日记.md"
fi
```

Template is ~90 bytes; even a few words exceed this threshold.

## Cron Job

```json
{
  "schedule": "0 0 * * *",
  "name": "每日日记 — 创建+清理",
  "script": "daily_diary.sh",
  "no_agent": true,
  "deliver": "local"
}
```

Must run AFTER `pull_user_notes.sh` (or combined) so yesterday's diary is pulled before cleanup.

## Google Drive Folder

```
FOLDER_ID="1XvPIqFqftMhG_4QSC9LnApxue_ayvAmg"
```

Targets the user's existing Obsidian vault folder on Drive.
