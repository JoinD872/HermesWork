---
name: codex-execution-contract
description: 小H派发任务给 Codex 时的执行合约 — 定义 Codex 必须返回的格式、验收标准、重试规则和回滚要求
version: 1.0.0
risk: write-safe
---

# Codex Execution Contract

当小H派发任务给 Codex 时加载此 skill。Codex 负责执行，小H负责审查、验收、决策。

## ⚠️ 核心前提：Codex 没有持久记忆

**Codex 每次 exec 都是全新会话。** 它不知道：
- 用户的风格偏好（语言、详细度、格式要求）
- Hermes 的 skill 库和相关知识
- 项目上下文和历史教训
- 之前的协作约定

因此派发时必须**显式提供**所有关键上下文。不能假设 Codex 记得任何跨会话信息。

## 派发格式

每次派发必须包含以下字段：

```markdown
Task: 任务一句话描述
Context: 背景、环境、当前状态
Allowed scope: 允许改动的范围（文件/服务/配置）
Disallowed actions: 禁止做的事
Expected output: 期望输出
Verification required: 验证方式
Rollback required: 是否需要回滚命令
```

示例：

```markdown
Task: 更新 nginx 配置使 app.example.com 代理到 localhost:3000
Context: Ubuntu VPS, nginx 已安装, app 已在 127.0.0.1:3000 运行
Allowed scope: /etc/nginx/sites-available/ 及 sites-enabled 中的 symlink
Disallowed actions: 不改 SSH、firewall、DNS、app 代码
Expected output: 遵循 Codex Execution Contract
Verification required: sudo nginx -t && curl -I http://127.0.0.1:3000
Rollback required: 提供恢复之前 nginx 配置的命令
```

## Codex 必须返回的格式

### Summary
一两句话描述改动内容和原因。

### Files Changed
| Path | Action | Purpose |
|------|--------|---------|
| /absolute/path | Created/Modified/Deleted | 原因 |

无文件改动则写：`No files changed.`

### Commands Executed
| Command | Purpose | Result |
|---------|---------|--------|
| `command` | 目的 | Pass/Fail/Not run |

包含只读命令、写命令、测试命令、服务命令、包管理命令和验证命令。

### Verification Results
| Check | Command | Result | Evidence |
|-------|---------|--------|----------|
| 描述 | `...` | Pass/Fail/Not run | 输出摘要 |

### Assumptions Made
列出 Codex 在执行过程中做的假设（如有）。

### Residual Risks
列出改动后仍然存在的风险（如有）。

### Rollback Commands
```bash
# 回滚命令
COMMAND_1
COMMAND_2
```

## 小H验收标准

### ACCEPT 条件（全部满足）
- [ ] Files Changed 完整且准确
- [ ] 所有预期命令已执行
- [ ] 所有验证项结果为 Pass
- [ ] Rollback Commands 存在（或明确说明不需要）
- [ ] 没有意外副作用

### RETRY 条件（任一满足则要求重试）
- [ ] Verification Results 存在 Fail
- [ ] 改动了 Allowed scope 之外的内容
- [ ] 缺少 Files Changed 或 Commands Executed
- [ ] 没有 Rollback Commands 且需要
- [ ] 输出格式不符合合约

### REJECT 条件（任一满足则拒绝）
- [ ] 改动了 Disallowed actions 中的内容
- [ ] 造成了数据丢失或安全风险
- [ ] 没有提供任何可用的输出
- [ ] 验证失败且原因不明确

## 重试规则

1. 小H明确描述重试原因和需要修正的具体问题
2. Codex 只修指定问题，不重新发散
3. 同一任务最多重试 2 次
4. 2 次后仍不满足 → 升级为 deep mode 或更换方案
