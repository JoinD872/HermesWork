---
name: codex
description: Delegate coding tasks to OpenAI Codex CLI agent. Use for coding, refactoring, code review, and multi-round fix loops. GPT-5.5 via ChatGPT Plus — no extra billing.
version: 1.2.0
risk: write-dangerous
metadata:
  hermes:
    tags: [Coding-Agent, Codex, OpenAI, Code-Review, Refactoring]
    related_skills: [claude-code, hermes-agent, software-development:code-repair-loop]
---

# Codex CLI

Delegate coding tasks to [Codex](https://github.com/openai/codex) via the Hermes terminal. Codex is OpenAI's autonomous coding agent CLI.

## Prerequisites

- Codex installed: `npm install -g @openai/codex`
- **Authentication (one of two modes)**:
  - **API key mode**: set `OPENAI_API_KEY` env var
  - **ChatGPT Plus mode** (no API key needed): Codex stores session tokens in `~/.codex/auth.json` with `auth_mode: "chatgpt"`. Tokens auto-refresh via ChatGPT Plus session.
- **Must run inside a git repository** — Codex refuses to run outside one
- Use `pty=true` in terminal calls — Codex is an interactive terminal app

## One-Shot Tasks

```
terminal(command="codex exec 'Add dark mode toggle to settings'", workdir="~/project", pty=true)
```

For scratch work (Codex needs a git repo):
```
terminal(command="cd $(mktemp -d) && git init && codex exec 'Build a snake game in Python'", pty=true)
```

## Background Mode (Long Tasks)

```
# Start in background with PTY
terminal(command="codex exec --full-auto 'Refactor the auth module'", workdir="~/project", background=true, pty=true)
# Returns session_id

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send input if Codex asks a question
process(action="submit", session_id="<id>", data="yes")

# Kill if needed
process(action="kill", session_id="<id>")
```

## Key Flags

| Flag | Effect |
|------|--------|
| `exec "prompt"` | One-shot execution, exits when done |
| `--full-auto` | Sandboxed but auto-approves file changes in workspace |
| `--yolo` | No sandbox, no approvals (fastest, most dangerous) |

## PR Reviews

Clone to a temp directory for safe review:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && gh pr checkout 42 && codex review --base origin/main", pty=true)
```

## Parallel Issue Fixing with Worktrees

```
# Create worktrees
terminal(command="git worktree add -b fix/issue-78 /tmp/issue-78 main", workdir="~/project")
terminal(command="git worktree add -b fix/issue-99 /tmp/issue-99 main", workdir="~/project")

# Launch Codex in each
terminal(command="codex --yolo exec 'Fix issue #78: <description>. Commit when done.'", workdir="/tmp/issue-78", background=true, pty=true)
terminal(command="codex --yolo exec 'Fix issue #99: <description>. Commit when done.'", workdir="/tmp/issue-99", background=true, pty=true)

# Monitor
process(action="list")

# After completion, push and create PRs
terminal(command="cd /tmp/issue-78 && git push -u origin fix/issue-78")
terminal(command="gh pr create --repo user/repo --head fix/issue-78 --title 'fix: ...' --body '...'")

# Cleanup
terminal(command="git worktree remove /tmp/issue-78", workdir="~/project")
```

## Batch PR Reviews

```
# Fetch all PR refs
terminal(command="git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'", workdir="~/project")

# Review multiple PRs in parallel
terminal(command="codex exec 'Review PR #86. git diff origin/main...origin/pr/86'", workdir="~/project", background=true, pty=true)
terminal(command="codex exec 'Review PR #87. git diff origin/main...origin/pr/87'", workdir="~/project", background=true, pty=true)

# Post results
terminal(command="gh pr comment 86 --body '<review>'", workdir="~/project")
```

## Usage Rules (This User)

These rules were established through explicit user direction. Follow them strictly.

### 1. Use Codex by default — EVERY task, not just coding

Do not gatekeep Codex for "hard tasks" or "coding tasks" only. The user explicitly wants Codex involved in **every class of work**: coding, analysis, summarization, research, review, brainstorming. The expected output pattern is: 小H → Codex → 碰撞/收敛 → 最终结果.

The user's exact words (2026-05-30): *"我希望你让CODEX参与所有事情，比如分析、总结，你们碰撞后给结果"*

Scope includes:
- **Coding**: implementation, refactoring, debugging (original scope)
- **Analysis & Summary**: diary/journal analysis, data pattern recognition, report synthesis
- **Review & Audit**: code review, config audit, security check, skill/library scan
- **Brainstorming**:方案碰撞、验证假设、补充遗漏

Only skip Codex if it actively reports quota exhaustion. Do not preemptively conserve quota.

- Low-complexity tasks → call Codex (reasoning: medium)
- Medium-complexity → call Codex (reasoning: medium or high)
- High-complexity → call Codex (reasoning: high or xhigh)

**Auth mode note (2026-05-27):** ChatGPT Plus expired. Codex now runs via ChatGPT Free plan weekly quota (~GPT-5.5 usage cap). Usage is still functional until the cap is hit. No action needed — Codex errors naturally when quota runs out.

### 2. Reasoning depth

| Level | When |
|-------|------|
| `medium` | Default. Use for all routine tasks. |
| `high` | Complex logic, multi-file refactors, non-trivial debugging. |
| `xhigh` | Deep reasoning problems, architecture design, algorithmic work. |

Pass via the `--reasoning-effort` flag:
```
codex --reasoning-effort high exec "..."
```

### 3. Quota management

Codex CLI doesn't expose remaining quota via CLI. Check empirically:
- If Codex runs without error → quota is fine
- If Codex errors with quota-related message → skip it for this session, fall back to DeepSeek
- Do not track or log quota state in memory — it changes frequently

### 4. Always verify before answering

**This is a hard rule.** Before answering any integration question about Codex, load this skill AND run a terminal check:
```bash
which codex && codex --version && cat ~/.codex/auth.json | python3 -c "import json,sys; d=json.load(sys.stdin); print('auth:', d.get('auth_mode'))"
```
Do NOT reason from general knowledge or past experience. The user has explicitly corrected this behaviour.

### 5. Privacy model (2026-05-27)

Codex CLI **has no separate privacy/data-sharing setting**—it's a local CLI tool. The only privacy control is in ChatGPT Settings:
```
Settings → Data Controls → Improve the model for everyone → OFF
```
- When OFF: new conversations (including Codex requests) are not used for model training
- OpenAI still retains data for safety/abuse detection (unavoidable compliance requirement)
- Codex uses the same ChatGPT auth as the browser session, so the same toggle applies
- `runtime_metrics` feature (the only potential telemetry) is `under development` + **disabled by default**
- Session history is stored locally in `~/.codex/sessions/`, not sent externally

## Pitfalls

- **Don't assume auth mode** — check `~/.codex/auth.json` to see if it uses API key or ChatGPT tokens before claiming a setup cost. On this VPS it uses ChatGPT Plus tokens, not a separate API key.\n- **Don't assume it's not installed** — check `which codex` and `npm list -g @openai/codex` before claiming it needs setup. On this VPS it's already at `/usr/bin/codex`.\n- **Always verify before answering integration questions** — load this skill and check the actual environment (installed, auth mode, version) instead of reasoning from general knowledge. The user will notice if you skip this step.\n\n## Reference\n\n- `references/vps-optimization-case.md` — real-world example of multi-round convergence
- `references/session-memory-model.md` — Codex has NO persistent memory; every `exec` is fresh. Key difference from Hermes memory system. (小H→Codex→小H→converge) on a VPS network optimization task. Demonstrates Codex catching false assumptions, suggesting missing parameters, and preventing wasted effort.
