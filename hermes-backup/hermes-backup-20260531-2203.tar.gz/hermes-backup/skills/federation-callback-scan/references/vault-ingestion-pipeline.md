# Vault Ingestion Pipeline — 回执+Cron输出持久化到 Obsidian Vault V1.0

将联邦回执和 cron 作业输出自动写入 Obsidian Vault，形成可检索的知识沉淀。

## 解决的问题

`scan_callbacks()` 只把结果提到当前会话，出了会话就丢了。Cron 输出同样只在 `cron/output/` 目录保留，不在 Vault 中可检索。

## 架构

```
cron 输出 → ~/.hermes/cron/output/{job_id}/{timestamp}.md
联邦回执 → ~/.hermes/federation/callbacks/{task_id}.json
                            ↓
              vault_ingest.py (每2小时, no_agent)
                            ↓
  40_复盘归档/    10_文献笔记/    00_收件箱-AI/
```

## 关键文件

| 文件 | 用途 |
|------|------|
| `~/.hermes/scripts/vault_ingest.py` | 入库脚本 |
| `~/.hermes/config/vault-ingest-state.json` | 状态跟踪，防重复处理 |
| cron job `0504bc83cd83` | 调度器，每2小时, no_agent, deliver: local |

## 路由规则

**回执路由** (按 task_id 前缀判断):
- MINIMAX_DAILY / MINIMAX_SCAN / PAIN_ / UE5WP_ / UE5_ / research_ → `10_文献笔记/`
- vps-patrol-* → `40_复盘归档/`
- 其他 → `00_收件箱-AI/`

**Cron 路由** (按 job_id 映射):
- `a259819c24f4` VPS巡检 → `40_复盘归档/`
- `22c677b8acac` 每日早报 → `40_复盘归档/`
- `858137a1ff62` Hermes备份 → `40_复盘归档/`
- `4103b67f5134` global_knowledge清理 → `40_复盘归档/`

## 零成本设计

- no_agent cron，纯 Python 脚本，不走 LLM
- 无新增内容时静默退出（无输出 = 不浪费 token）
- 状态文件防重复，历史数据一次性入库后不再处理

## 回执文件名解析

回执 JSON 的 `completed_at` 字段可能是 epoch 秒数，脚本自动转 ISO 日期写入 frontmatter。
