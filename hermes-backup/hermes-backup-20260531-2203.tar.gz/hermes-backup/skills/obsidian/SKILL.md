---
name: obsidian
description: Obsidian Vault 知识库管理 — 架构设计/目录规则/写入控制/Callback管道/模板体系，含 Hermes × Obsidian Vault 单主库多入口架构
version: 2.4.0
tags: [obsidian, knowledge-base, vault, note-taking, knowledge-management]
risk: write-safe
related_skills:
  - federation-protocol-v320
  - low-cost-federation
---

# Obsidian Skill

管理 Hermes Agent 的 Obsidian Vault 知识库。以 **VPS 单主库 + 白名单写入 + Cloud Inbox 投递 + callback 沉淀** 为核心架构。

## 架构概览

```
你（飞书/手机） → 聊天 or Cloud Inbox → 小H处理
                                                       ↓
                  ┌──────────────────────────────────┐
                  │   VPS 单主库（canonical）          │
                  │   ~/.hermes/ObsidianVault/        │
                  │    + 日记/                        │
                  └──────────┬───────────────────────┘
                             │
              ┌──────────────┼──────────────┐
              ▼              ▼              ▼
     vault_ingest.py   cron 输出       federation
     (2h, no_agent)    早报/巡检      callback/研究
              │                           ▲
              ▼                           │
     Google Drive （用户仓库文件夹）──────┘
              │                   pull_user_notes.sh
              │   Google Drive 桌面版自动同步
              ▼
     Windows 本地 → 你在 Obsidian 中打开
       ├── 日记/ ← 每天自动建，未填自动删
       └── 你的笔记 ← 我每30分钟拉回VPS读
```

详细架构见 `references/hermes-vault-architecture.md`。

## 目录规则（中文名优先）

所有目录名用中文，Linux 原生支持 UTF-8 路径：

```
~/.hermes/ObsidianVault/
├── 00_收件箱-AI/          # 小H自动写入 + 草稿（frontmatter标注target_dir）
├── 00_收件箱-人工/        # Cloud Inbox 回拉
├── 10_文献笔记/           # 小研报告、外部摘要 → 自动写
├── 20_项目文档/           # → 仅出草稿
├── 30_永久笔记/           # → 仅出草稿（人工晋升）
├── 40_复盘归档/           # 排障/复盘/callback → 自动写
├── 50_Hermes架构/         # → 仅出草稿
├── 日记/                  # 每日日记（自动创建+清理）
├── 灵感创意/              # → 仅出草稿
└── 模板/                  # 固定模板（含日记模板）
```

## 写入权限规则

| 目录 | 自动写 | 出草稿 |
|------|:-----:|:------:|
| 00_收件箱-AI/ | ✅ | — |
| 00_收件箱-人工/ | ✅ 拉取 | — |
| 10_文献笔记/ | ✅ | — |
| 40_复盘归档/ | ✅ | — |
| 20_项目文档/ | ❌ | ✅ → 写收件箱-AI/ |
| 30_永久笔记/ | ❌ | ✅ → 写收件箱-AI/ |
| 50_Hermes架构/ | ❌ | ✅ → 写收件箱-AI/ |
| 灵感创意/ | ❌ | ✅ → 写收件箱-AI/ |

草稿统一写 `00_收件箱-AI/`，frontmatter 含：
```yaml
status: draft
target_dir: "灵感创意"
promotion_required: true
```

## 输出标准化

每条 Markdown 含 frontmatter（title/date/source/tags/type/status）+ 正文 + 双链候选 + 标签。

模板文件在 `模板/` 目录：
- `复盘模板.md` — 排障、巡检、复盘
- `文献模板.md` — 研究报告、资料摘要
- `收件箱模板.md` — 灵感、待整理草稿（自带 target_dir 字段）
- `日记模板.md` — 每日日记（{{date}} 占位符）

## Phase 2 — Vault Ingest Pipeline（vault_ingest.py）

**自动将 cron 输出 + 联邦回执写入 Vault**，两条管道汇总到单主库。

### 架构

```
cron 输出目录 (~/.hermes/cron/output/)            federation 回执 (~/.hermes/federation/callbacks/)
         │                                                     │
         ▼                                                     ▼
    vault_ingest.py（每 2 小时，no_agent=true，零 token 成本）
         │
         ├── 40_复盘归档/    ← 早报/VPS巡检/备份日志
         ├── 10_文献笔记/    ← 小研研究报告（research callback）
         └── 00_收件箱-AI/  ← 其他回执兜底
```

### 核心设计

- **状态跟踪**：`~/.hermes/config/vault-ingest-state.json` 记录已处理的 cron 文件名 + callback task_id，不重复写入
- **静默退出**：无新增内容时输出为空，no_agent cron 不触发任何通知
- **宽松匹配**：cron 输出仅处理有名字映射的 job（早报/巡检/备份），旧 job 输出自动忽略
- **回执分类**：根据 task_id 前缀自动路由（MINIMAX/PAIN → research, SCAN/PATROL → log）
- **frontmatter 注入**：每条笔记带 title/type/source/created/status

### 实施步骤

```bash
# 1. 写入 vault_ingest.py → ~/.hermes/scripts/vault_ingest.py
# 2. 创建 cron job（no_agent=true，每 2 小时）
cronjob action=create \
  name="Vault Ingest — Cron+回调入库" \
  script="vault_ingest.py" \
  no_agent=true \
  schedule="0 */2 * * *" \
  deliver=local
```

### 回执分类规则

| task_id 前缀 | 目标目录 | 说明 |
|:---|:---|:---|
| MINIMAX_DAILY | 10_文献笔记 | MiniMax 动态追踪 |
| MINIMAX_SCAN | 10_文献笔记 | MiniMax 扫描报告 |
| UE5WP / UE5 | 10_文献笔记 | UE5 技术研究 |
| RESEARCH | 10_文献笔记 | 综合研究报告 |
| PAIN | 10_文献笔记 | 健康研究 |
| PATROL | 40_复盘归档 | VPS 巡检回执 |
| 其他 | 00_收件箱-AI | 兜底 |

### 回执 JSON 格式要求

```json
{
  "task_id": "RESEARCH_20260505",
  "assignee": "小研",
  "status": "done",
  "payload": {
    "summary": "Markdown 正文摘要",
    "key_findings": ["发现1", "发现2"],
    "action_items": ["行动项1"]
  },
  "completed_at": 1778007779
}
```

## Phase 2b — Vault 同步到用户桌面（Google Drive 中转）

将 VPS Vault 同步到用户的本机 Obsidian。首选方法是通过 **Google Drive 中转**：VPS 用 rclone 推送到用户的 Drive 文件夹，用户在电脑上安装 Google Drive 桌面版自动同步到本地。

### 为什么不用 SSH 直推？

初期尝试通过 Tailscale SSH (SFTP) 直接同步到 Windows 桌面。但 Tailscale 使用 DERP relay 中继（延迟 ~180ms），单次 81 文件的 checksum 同步耗时 >100s，用户体验差且依赖桌面开机。Google Drive 中转方案：
- 不依赖桌面在线（离线时文件先到 Drive，开机后 Google Drive 桌面版自动同步）
- Google Drive 桌面版双向同步，用户在 Obsidian 编辑的笔记可回传
- VPS → Drive 走 Google 直连，快且稳定

### 同步链路

```
VPS ~/.hermes/ObsidianVault/
  │   rclone copy (每30min, no_agent, 零 token)
  ▼
Google Drive 目标文件夹（--drive-root-folder-id）
  │   Google Drive 桌面版自动同步
  ▼
用户本机 (如 C:\Users\用户名\Google Drive\)
  │   Obsidian "打开文件夹作为仓库"
  ▼
用户在本地 Obsidian 中看到 Hermes 的所有内容
```

### 关键设计决策

详见 `references/drive-sync-setup.md`，核心要点：

- **`--drive-root-folder-id` 定位**：永远用 folder ID 而非路径名，避免路径绑定断裂
- **`rclone copy` 而非 `sync`**：copy 只增补更新，永不删除目标文件。当 Hermes Vault 内容合并到用户已有的 Obsidian 仓库时，用户原有的笔记不会被误删
- **格式隔离（重要）**：`日记/` 在 Drive 上存储为 Google Docs 格式（手机编辑），但本地 Vault 是 `.md`。`sync_vault_to_drive.sh` **必须**用 `--exclude "日记/*"` 排除，否则 rclone 会用纯文本 `.md` 覆盖 Google Docs，导致手机编辑丢失
- **静默离线处理**：no_agent=true，sync 脚本在无新内容时输出为空，零 token
- **`--size-only`**：比 `--checksum` 快（Google Drive API 侧只需比对大小+修改时间）

### 配置步骤

```bash
# 1. 用户指定 Google Drive 上的目标文件夹，获取 folder_id（来自 URL）
# 2. 写 sync 脚本 → ~/.hermes/scripts/sync_vault_to_drive.sh
# 3. 创建 no_agent cron（⚠️ deliver=local，否则发到聊天！）
cronjob action=create \
  name="Vault 同步 → Google Drive" \
  script="sync_vault_to_drive.sh" \
  no_agent=true schedule="*/30 * * * *" deliver=local
# 4. 用户在 Windows 装 Google Drive 桌面版 → 打开 Obsidian
```

## 用户笔记反向同步（pull_user_notes.sh）

除了 VPS → Drive 推送，还需要从 Drive **拉回用户自己写的笔记**（日记、个人笔记等），供小策/小H读取作为知识上下文。

### 架构

```
用户在 Windows Obsidian 写笔记
  → Google Drive 桌面版同步到云端
    → pull_user_notes.sh（每30min，与 sync 同 cron job）
      → ~/.hermes/inbound/user-notes/
        → 代理按需读取
```

### 关键设计

- **`rclone copy`（非 sync）**：不删除本地文件，安全增量获取
- **两步法拉取**：先全量拉取（排除 `日记/*`），再从日记子目录单独导出 .md（Google Docs → Markdown）。避免一次性拉取时 `--include` 模式匹配到子目录中的文件
- **与 sync_vault_to_drive.sh 合并**：同一个 cron job 运行两个脚本，共享 deliver=local

```bash
# ~/.hermes/scripts/pull_user_notes.sh（两步法）
# Step 1: 全量拉取排除 日记/
rclone copy "mydrive:" "$STAGE/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --exclude "日记/*" \
  --size-only --timeout 120s -q

# Step 2: 单独从日记目录导出 .md
rclone copy "mydrive:日记/" "$STAGE/日记/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-export-formats md \
  --include "/*-日记.md" \
  --size-only --timeout 120s -q
```

### ⚠️ 已知坑：raw `--include` 模式匹配子目录

旧版 `pull_user_notes.sh` 用 `--include "日记/$YESTERDAY-日记.md"` 从根目录拉取。rclone 的 `--include` 默认递归匹配所有子目录，所以 `日记/日记MD/2026-05-29-日记.md` 也被拉取，导致本地出现 `日记/日记MD/日记MD/日记MD/...` 无限嵌套。

**修复（2026-05-30）：**
1. 两步法：Step 1 用 `--exclude "日记/*"` 排除，Step 2 精确到 `mydrive:日记/` 子目录
2. `--include "/*-日记.md"` 用 `/` 前缀锚定根目录，不穿透子目录
3. `daily_diary.sh` 中同样用 `--include "/$DIARY_SUB/*-日记.md"` 锚定
4. 删除整个 `日记MD/` 同步逻辑（该目录是旧版 .md 镜像，已废弃）

## 每日日记系统

自动创建当天日记文件（上海日期），次日清理未填写的空日记。模板含日期占位符，每天 08:00 HKT 由 cron 触发。用户手机在 Google Docs 中编辑后，次日 cron 自动拉回并存入 Vault。

**完整设计见** `references/daily-diary-system.md`，涵盖：
- 模板格式（YAML frontmatter + 四区块引导格式）
- 日记文件自动创建 + 清理的脚本逻辑（grep status + wc -l 行数比对）
- cron 定时配置（16:00 UTC = 00:00 HKT）
- 同步链路
- ✅ 2026-05-30 修复：日记MD/无限嵌套bug已修复，历史日记补拉逻辑已添加

### 架构（v3 — 单目录 Google Docs 模式，不再使用日记MD/）

```
本地 Vault 日记/            = .md 模板文件
Drive 日记/                 = Google Docs（点开即写，手机原生编辑）
  模板从本地 .md 通过 --drive-import-formats md 上传转换为 Google Doc
  用户手机编辑 Google Doc → 次日 cron 用 --drive-export-formats md 拉回为 .md

创建流程（daily_diary.sh，00:00 HKT）：
  本地生成 .md → rclone --drive-import-formats md 推日记/（转 Google Docs）
                → 不推日记MD/（已废弃，该目录逻辑已完全删除！）

编辑流程（用户手机编辑后）：
  用户改日记/ Google Doc → 每日 00:00 daily_diary.sh 执行
    → rclone --drive-export-formats md 拉取所有 *-日记.md
    → for 循环遍历每个拉回的文件
    → 内容检测通过则 cp 到 Vault
    → 内容为空则删除 Drive 上的 Google Doc + 清理本地

清理流程（daily_diary.sh，每日 00:00 HKT）：
  拉取所有 *-日记.md → 对每个文件判断用户是否填写
    → 有内容：cp 到 Vault 日记/
    → 空文件：rclone delete（删 Google Doc）+ rm -f 本地文件
```

### 内容检测（双重判断，废弃旧版 wc -c 大小比较）

旧版用 `wc -c` 比较文件大小（模板 112 字节 vs 用户文件），但 Google Docs 导出格式变化导致误判。新版：

```bash
# 方法1：检查 frontmatter 中 status 是否改为非 draft
grep -q "^status:" $FILE
STATUS=$(grep "^status:" $FILE | sed 's/^status:[[:space:]]*//')
[ "$STATUS" != "draft" ] && HAS_CONTENT=true

# 方法2（后备）：行数比较（模板 11 行，用户内容增加行数）
if [ "$HAS_CONTENT" = false ]; then
  [ "$(wc -l < $FILE)" -gt "$(wc -l < $TEMPLATE)" ] && HAS_CONTENT=true
fi
```

### 日记模板格式（v2 — 2026-05-30 更新）

旧版只有「# {{date}} + # 灵感、想法」两个空区块，用户反馈太自由、不知道写什么。新版改为四个有引导问题的格子：

```markdown
# {{date}}

## 📍 今天最重要的一件小事
（一句话，不用展开）

## 🧠 情绪锚
（今天最强烈的一个感受，1-2个词）

## 🔍 一个我注意到的
（任何小观察，不一定要有意义）

## 💡 灵感/想法
```

**用户偏好（2026-05-30 确立）：** 格子是启动入口，不是限制篇幅的栅栏。用户想细写时可以在某个格子下自由展开（不限长度），其他格子可留空。**不要强制全填满，不要提示「只填了2个格子」。**

### 已知坑

| 坑 | 后果 | 修复 |
|:---|:-----|:-----|
| `--include "日记/2026-05-31-日记.md"` 无 `/` 锚定 | rclone 递归匹配 `日记/日记MD/...` 中的同名文件 → `日记MD/` 无限嵌套 | ✅ 已修（2026-05-30）：改为两步法 + `--include "/*-日记.md"` 根锚定 |
| 日记MD/ 上传逻辑 | cron 把本地 .md 推送到 Drive 的 `日记/日记MD/` → 后续拉取又拉回来 → 不断嵌套 | ✅ 已修（2026-05-30）：整段删除，不再使用日记MD/ |
| 仅拉取昨天 | 历史日记（如 5/24-5/29）除非恰好某天拉取成功，否则永远不回本地 | ✅ 已修（2026-05-30）：改为 for 循环遍历所有拉回的文件 |
| `wc -c` 文件大小比较 | Google Docs 导出格式变化导致误判「用户没写」→ 删除有内容的日记 | ✅ 已修（2026-05-30）：改为 grep status + wc -l 双检测 |
| 子 Agent 误删 Drive 数据 | Codex 子代理在清理嵌套目录时，误将 Drive 上 5 篇有内容的日记 Google Docs 当做空模板删除 | ⚠️ 已恢复（2026-05-30）：小H 提前手动拉了 .md 备份到 /tmp，无损恢复。教训见 code-repair-loop skill 的生产数据保护规则 |

### 关键细节

- **模板约 112 字节**，日期替换后略增
- **Cron：`0 0 * * *` UTC = 每日 08:00 HKT**（注意：调度器使用 UTC）
- **格式隔离**：`sync_vault_to_drive.sh` 必须 `--exclude "日记/*"`，否则覆盖 Google Docs
- **零 token 成本**：全 rclone 搬运，无 LLM 参与

## Cloud Inbox（用户投递入口）

Google Drive 作为云收件箱，用户从手机/电脑投递 → rclone 定时拉取 → Vault 收件箱。

**完整实施步骤见** `references/cloud-inbox-setup.md`，涵盖：
- Headless VPS 上 rclone OAuth 授权的 socat 端口转发方案
- Google Docs → Markdown 自动导出配置（`export_formats = md,txt,docx`）
- 拉取脚本设计（frontmatter 注入 + no_agent cron + 静默退出）
- 日常使用流程

### 已知坑点

| 坑 | 后果 | 修复 |
|:---|:-----|:-----|
| `--delete-empty-src-dirs` | rclone 从 Drive 删除空的 `HermesInbox` 目录 → 后续拉取报 "directory not found" | 脚本中移除该参数；如已误删则 `rclone mkdir mydrive:HermesInbox` 重建 |
| `deliver` 默认 `origin` | cron 输出发到用户聊天 → 每30分钟刷屏 "there was nothing to transfer" | 所有 no_agent cron 显式加 `deliver=local` |
| 脚本不静默 | 即使无内容也输出 "Inbox pull complete" → cron 仍发通知 | 脚本加判断：抓取 `OUTPUT` 检查是否实际传输文件，无传输时完全静默 |

## Phase 1 最小闭环

首次搭建只做：建中文目录 → 配写权限 → 写模板 → 测试写入 → tar 打包备份。
不做 rclone crypt / Syncthing / Git，待稳定后再逐级加。

## 日记分析（人本反馈）

当用户主动问起日记分析/反馈时，见 `references/diary-analysis-guide.md`。
该文件覆盖：
- 日记访问路径优先级（本地 Vault → inbound → SSH → Drive API → 用户粘贴）
- 日记三个层次（记录/提炼/反馈）
- 「迷茫/脑袋空空」对话的分层模型（方向/动力/状态）
- 给选项不催决策的响应框架
- 日记格式建议：用「引导格子」代替空标题（📍小事/🧠情绪锚/🔍注意到/💡灵感），格子不限制篇幅长度

## 已知限制与边界

- **同步流向**：VPS → Drive 单向推送，用户笔记 → Drive → VPS 反向拉取。用户在本地 Obsidian 的编辑通过 Google Drive 桌面版回传到云端 Drive；`pull_user_notes.sh` 每 30 分钟拉回 VPS 供代理读取
- **桌面端同步依赖 Google Drive 桌面版持续运行**：关掉 Drive 桌面版则停止同步，重新打开后自动恢复
- **vault_ingest.py 只处理有名称映射的 cron job**：旧/已删除 job 的输出目录不处理
- **回执状态必须为 "done"**：未完成或失败的回执不会写入 Vault
- **子 Agent 需在 emit_result() 中保证 summary 字段**：回执无 summary 则 vault_ingest 无法写入
