---
name: camoufox-install
description: camoufox Python 抗检测浏览器 — 安装/实测/与 crawl4ai 的区别与组合方案
version: 2.0.0
tags: [devops, camoufox, browser, anti-detect, playwright, crawl4ai]
risk: write-dangerous
---

# Camoufox — 抗检测 Firefox 浏览器

## 核心定位（一句话）

camoufox 是基于 Firefox 的**抗检测浏览器**，通过 C++ 级指纹注入（不依赖 JS）让自动化请求看起来像真实用户设备，专门用于绕过 Cloudflare 等反爬系统。

## 安装

```bash
pip install camoufox
python3 -c "import camoufox; print(camoufox.__version__)"
```
浏览器二进制自动下载到 `~/.cache/camoufox/`（首次 import 触发）。

## 基本用法

```python
# Async（推荐，Hermes 环境）
from camoufox.async_api import AsyncCamoufox
async with AsyncCamoufox(headless=True) as browser:
    page = await browser.new_page()
    await page.goto("https://example.com", timeout=20000, wait_until="domcontentloaded")
    title = await page.title()
    content = await page.inner_text("body")

# Sync
from camoufox.sync_api import Camoufox
with Camoufox() as browser:
    page = browser.new_page()
    page.goto("https://example.com")
```

## camoufox vs crawl4ai 区别

| 维度 | camoufox | crawl4ai |
|------|---------|----------|
| **浏览器内核** | Firefox（debloated） | Chromium（via Playwright） |
| **抗检测机制** | C++级指纹注入（WebRTC/WebGL/字体/屏幕等全维度） | `enable_stealth` JS patch |
| **资源占用** | 轻量（Firefox fork，去广告/动画） | 较重（Chromium 完整） |
| **AI 友好** | ❌ 无 markdown 提取，返回原始 HTML | ✅ 自动提取 markdown/结构化数据 |
| **浏览器类型** | 仅 Firefox | Chromium / Firefox / WebKit |
| **适合场景** | 需要通过反爬挑战（CF JS challenge） | 日常爬取 + markdown 提取 |

## 实测结果（2026-08-04 VPS 实测，camoufox 0.5.4 + Firefox v152 内核）

| 目标站点 | camoufox 结果 | crawl4ai Chromium 结果 | 原因 |
|----------|:------------:|:---------------------:|------|
| Reddit JSON | ❌ IP封锁 | ❌ 403（0.9.2 与 0.8.6 均失败） | IP 级封锁，浏览器无关；Reddit 反爬已升级 |
| old.reddit.com | ✅ | ✅ | 旧版限制宽松 |
| **Cloudflare Forum** | **✅ 通过 CF challenge**（1.47M chars） | ❌ 未测 | camoufox 指纹绕过了 CF JS challenge |
| 小红书（Tencent EdgeOne） | ❌ 超时 | ❌ 超时 | EdgeOne 多层检测，Firefox 也绕不过 |
| B站 | ✅ | ✅ | 正常 |

**升级注意**：camoufox 0.5.x 升级后必须运行 `camoufox fetch` 重新下载浏览器二进制（约 663MB，新内核 v152），否则报 `CamoufoxNotInstalled`。

**crawl4ai 0.9.x API 变化**：`AsyncWebCrawler(browser_config=...)` 改为 `AsyncWebCrawler(config=...)`。新增 patchright undetected 模式（`use_undetected=True`），但实测对 Reddit 无效（Reddit 反爬升级，0.8.6 同样 403）。

## crawl4ai + camoufox 组合方案

crawl4ai 0.8.6 不直接支持 camoufox 作为 browser_type，有两种组合思路：

### 方案1：camoufox 单独用（推荐，简单直接）
直接用 Playwright API 写脚本，不需要 crawl4ai 框架。适合需要抗检测的场景。

### 方案2：crawl4ai cdp_url + camoufox（复杂，不推荐）
先启动 camoufox remote debugging，再用 crawl4ai 的 `BrowserConfig(cdp_url=...)` 连接。目前无实测验证。

### 决策建议
- **日常爬取**（国内站/API）→ crawl4ai Chromium 或纯 curl
- **Cloudflare 防护站** → camoufox 单独用
- **IP 级封锁**（Reddit/小红书）→ 两个工具都绕不过，需要代理

## 依赖

- Python 3.9+
- 无需额外依赖（camoufox 内置浏览器二进制）
- VPS 上需 headless 模式（`headless=True`）
