GitHub PAT 实际位置在 /root/.hermes/scripts/hermes-backup.sh（不在 .env），用户 JoinD872，仓库 JoinD872/HermesWork（私人），Token 前缀 ghp_6q...XGvJ。以后查 GitHub 认证先看 backup.sh。
§
用户云端迭代工作流 — 主力走 GitHub：文件放 JoinD872/HermesWork/workspace/，用户在网页版改，我读+改+提交推送。不走百度网盘/飞书云盘。补充：Google Drive 用于 Obsidian Cloud Inbox（HermesInbox/ 文件夹，每30min拉取到 Vault 收件箱），仅做灵感投递不用于代码迭代。
§
## 低频流程索引（详情查对应 skill）
宠物技能设计：skill `pet-skill-design-workflow` | crawl4ai：skill `community-scraping` | 日记格式：skill `obsidian`
§
图片理解：主力 OpenCode Go minimax-m3（视觉），备用 GitHub Models gpt-4o（免费）。
§
VPS 隧道架构（2026-07-17）：Docker-tunnel = systemd 服务（`cloudflared-docker-tunnel.service`），服务于 `proxy.cloudjoind.com` 翻墙代理；JoinD-tunnel = Docker 容器（`cloudflared-joined`）。两者独立不冲突。Docker 容器有 IPv6 DNS 超时问题（不影响功能）。
§
知乎已升级为官方API：ZHIHU_ACCESS_SECRET存于.env，developer.zhihu.com，每天1000次免费搜索。
§
## 通知与日记偏好
无事不通知；cron 用 silent script + deliver=local。Vault/日记默认被动，不主动读/写，等用户问再说。日记路径：~/.hermes/ObsidianVault/日记/ | 模板在 模板/日记模板.md
§
AI 偏好：Gemini "回答简短、语言贫乏、刻意迎合"；GPT "内容衍生多、思维更广"。不要 yes-man，要能发散碰撞的对话伙伴。
§
## 协作模型 V2（2026-07-15 更新）
小H（主控）、Codex（外脑）、小策（方案官）、朵朵（个人认知/知识库）、黑翼（风控官）、老V（执行官）。小研已于2026-07-15被替换为朵朵。Codex强默认前置参与所有任务。
§
## 运维信条
应用层连接错误 ≠ 应用本身故障。排查顺序：① DNS(/etc/resolv.conf + resolvectl) → ② TCP → ③ 代理/出口(WARP/Tailscale) → ④ 服务 → ⑤ 配置 → ⑥ 业务逻辑。网络组件修改必须 Before→Snapshot→Modify→HealthCheck→Rollback。Tailscale 不只是 VPN，它还管理 DNS (MagicDNS)。WARP warp 模式 (全流量隧道) 会触发 Tailscale DNS 接管，只允许 proxy 模式。
§
优选 IP 测试规则：VPS 只能验证隧道连通性（curl --resolve + HTTP 400=通），VPS 端的延迟数字对中国用户无参考价值。严禁报 VPS 侧测速结果（如"这个 IP 只要 72ms"）给用户做优选依据。用户必须自己从 Windows 侧 ping 或 CloudflareSpeedTest 测速。
§
朵朵每日笔记归档 cron: job_id=2db29a49d308, 每天 UTC 15:00 (北京时间 23:00) 运行。扫描当日朵朵对话→有价值内容→写 Draft/→通知用户。关联技能：cognitive-support, duoduo-note-workflow, personal-cognitive-management。
§
用户用 Obsidian 免费版（无 Sync），手机看 .md 文件要么装 Remotely Save 插件要么在 Google Drive App 里预览。不能指望 Obsidian 官方同步。
§
当前状态：工作日10点上班→21点回家→打游戏放空→刷手机→2点睡→8点半起。自述每天心力不足、没精神。持续已久的6.5h/晚睡眠，属于慢性睡眠剥夺。
§
核心动机：深度父职责任感——「怕接不住女儿」。不跟别人比，而是怕未来的自己达不到女儿需要的标准。对父母（全年无休带娃做饭）有强烈愧疚感，想分担但缺乏行动精力。
§
信息来源偏好：要求权威性/同行评审来源（PubMed、Nature、Sleep期刊）。强烈排斥个人博客/低赞知乎文章作为证据——用户说「我让你是去找权威性的」。引用研究时必须提供PMID/DOI、期刊名称、引用次数等可验证细节。
§
认知到位但执行卡住：不是不知道问题在哪，是工作日精力耗尽后无力改变。行动切入点选在周末（学做饭），接受渐进改变而非一步到位。
§
睡眠是当前所有问题的根因（精力/情绪/动力）。已确定渐进式恢复方案：第1周7h→第2周7.5h→第3周8h，优先固定起床时间。PubMed研究已验证6h/晚认知退化风险。
§
Hermes 大版本升级：先加载 hermes-maintenance skill 按 Phase 1-4 执行。关键：git fetch --tags + git checkout 而非 hermes update；先升级所有依赖（lark-oapi 等）再重启网关；重启前告知用户可能断连；网关内用 Python subprocess + os.setpgrp 或另开 SSH 会话重启，不能直接 restart。记录见 references/v0.19.0-upgrade-incident.md
§
Windows PC (DaLao): Tailscale 100.108.175.15, SSH user 61915, workdir E:\Hermes. Needs V2RayN proxy for Tailscale control plane. Old desktop-tg4loen decommissioned.
§
User is cost-conscious about AI service subscriptions - was checking Xianyu prices for OpenCode Go accounts, considered using multiple Google accounts to repeatedly get the $5 first-month deal.
§
OpenCode Go ($10/月) 含多模型：Grok 4.5、DeepSeek V4 Pro/Flash、Kimi K3、Qwen3.7 Max、GLM-5.2、MiniMax M3、MiMo-V2.5 等；flash+MiMo 才是耐用主力（14天用25%≈$15，月均~$32），高级模型额度低。换模型只需改 config model 名（base_url https://opencode.ai/zen/go/v1 不变）。升级路径：DeepSeek 官方 API 直连 V4 Pro（PAYG，$0.435/$0.87 per 1M），Grok 4.5 约 flash 20 倍价（$2/$6 短、$4/$12 长）。Cursor/GitHub Copilot 是 IDE 产品无通用 API，不能当 Hermes provider。
§
DaLao (100.108.175.15) user Desktop is on OneDrive: `C:\Users\61915\OneDrive\Desktop`. Use `[Environment]::GetFolderPath('Desktop')` to discover user Desktop path on Windows.
§
DeepSeek V4 Flash 已配置 reasoning_effort: max（用户要求）。通过 `hermes config set model.reasoning_effort max` 设置。OpenCode Go API 支持该参数。Artificial Analysis 评测的 40 分基于 max effort，默认级别（空）得分可能更低但更快更省。
§
国外包月 API 订阅市场很薄：平替方向=DeepSeek 国际站 PAYG（~$11/月）。详见 skill api-cost-tracking references/foreign-ai-subscription-plans.md
§
Cloudflare（2026-08-02）：账号 619151721@qq.com，域名 cloudjoind.com，账号ID bf2a313ec68a3b07bf094238f475d6b5，ZoneID a56d0c8d2e517d1251f63d67d8096dd0，凭据 /root/.hermes/.cf_credentials（cfat_ Token 有 Workers 权限无 DNS 权限，workers/domains API 可绑自定义域）。CF Worker 反代 cf-proxy 已上线：https://rss.cloudjoind.com/<完整URL>（国内可访问）或 workers.dev 备用，豆瓣被墙但反代 200 全通。用量脚本 /root/.hermes/scripts/cf_worker_usage.py 已接入老V每日巡检（a259819c24f4）。VPS IP 192.3.241.244 在 Spamhaus ZEN+CBL 双黑名单（本地 DNS 漏报，须公共 DNS 交叉验证），查 IP 用 ip_reputation.py。RSSHub 公共实例 rsshub.ktachibana.party 豆瓣 route 稳定（zhihu/weibo 热门 route 429/503），备用 rssforever/slarker/woodland。
§
跨 profile 通信：朵朵可用飞书 API 直发消息到小H Home 群（oc_8391fa2b38acbd759ff75ab3616d5d1f），凭据在 Hermes 环境变量，替代已拆联邦管道；机器人自发消息不自动触发小H，需用户 @ 唤醒。CF 反代（rss.cloudjoind.com）对 www.bsedu.org.cn 系 522 绕不过（服务器级地域封锁），需国内 IP。注意 bsedu 裸域名 bs edu.org.cn 无 DNS/超时，必须用带 www 的 www.bsedu.org.cn。
§
用户手机荣耀 Magic6 Pro（Android，非 iOS，Shadowrocket 不适用），Tailscale 100.120.41.74（magic6-pro，账号 w619151721@gmail.com），流量充足。⚠️手机代理方案已放弃：Android 上 Tailscale 与 NekoBox 因 VpnService 冲突（实测互相顶掉）；NekoBox/Termux 均不在 Google Play（GitHub 官方下载）。bsedu 类仅限国内IP站靠 SSH 电脑兑底（已验证 200）。
§
教训：域名/URL/路径必须从实际命令输出复制，禁止手写或凭印象缩写（曾把 www.bsedu.org.cn 手写成 bsedu.org.cn 导致误解）。涉及具体地址写后必须对照原始输出复核。