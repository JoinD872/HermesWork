---
name: china-domestic-site-bypass
description: VPS 访问国内被墙/被风控网站的零成本绕行方案 — RSSHub 公共实例、Cloudflare Workers 免费反代、DNSBL 协议查询、反爬破解方法论。当数据中心 IP 被国内站屏蔽（豆瓣/微博等）时使用。
tags: [china, bypass, rsshub, cloudflare, workers, dnsbl, anti-crawl, free]
risk: read-only
created: 2026-08-02
---

# 国内站零成本绕行（数据中心 IP 被墙时）

## 触发条件
- VPS 直连国内站返回 000/403（IP 在 CBL/Spamhaus 黑名单或站点风控）
- 用户问"零成本访问国内站""怎么绕过反爬""被封了怎么复活"
- 需要抓豆瓣/微博/小红书等对数据中心 IP 不友好的站点

## 核心认知

1. **数据中心 IP 被墙 ≠ 全面被墙** — 实测同一 IP 对百度/B站/知乎/网易/QQ/淘宝全通，只有豆瓣/微博 API 断。必须逐站测试，不要一票否决
2. **curl 通 ≠ 全通** — curl 和 browser 走不同路径，browser 层还有 JS 反爬
3. **零成本绕行三件套**：RSSHub 公共实例（已验证）> Cloudflare Workers 免费反代 > GitHub Actions 免费算力

## 方案一：RSSHub 公共实例（首选，零部署零成本）

RSSHub（⭐45k）公共实例让第三方服务器访问国内站，转 RSS 给你。

### 可用实例（2026-08-02 实测）
| 实例 | 状态 | 豆瓣 route |
|------|------|-----------|
| `rsshub.ktachibana.party` | ✅ 200 | ✅ 内容完整 |
| `rsshub.rssforever.com` | ✅ 200 | ❌ 503 |
| `hub.slarker.me` | ✅ 200 | ❌ 503 |
| `rsshub.woodland.cafe` | ✅ 200 | — |
| rsshub.app / pseudoyu / shab.fun / feeded / tangwudi / rss-all.top / vercel | ❌ 403/000/402 | — |

### 已验证 route（ktachibana）
```bash
curl -s "https://rsshub.ktachibana.party/douban/movie/playing"   # ✅ 在映电影（评分/片长/导演/主演）
curl -s "https://rsshub.ktachibana.party/douban/book/latest"     # ✅ 新书
```
实测：蜘蛛侠：崭新之日 7.8分 / 八仙！8.2分 — 内容完整。

### 限流注意
微博/知乎/B站 route 在公共实例上 429/503（公共实例禁用热门 route）。私有实例才全开放。

## 方案二：Cloudflare Workers 免费反代

免费额度 10万请求/天（UTC 重置，超限 Error 1027）。GitHub 已验证项目：
- `QImageLab/cf-proxy`（186★）— 零配置 HTTP/HTTPS 反代
- `Mikotwa/reverse-proxy-cf`（39★）— Worker 变网页代理/镜像

**额度关键事实**：
- 域名**不提升** Workers 额度（账户级固定），但自定义域名可绑 Worker 绕 workers.dev 被墙
- 免费限制：CPU 10ms/请求、内存 128MB、子请求 50/请求 — 纯反代够用，重 HTML 解析不够
- 实际用量余量极大：Hermes 日均 ~10 次 LLM 回复，即使放大 100 倍也远低于限额

部署流程与安全边界见 `references/cloudflare-workers-deploy.md`。

## 方案三：GitHub Actions 免费算力

公开仓库 2000 分钟/月免费。用 runner 出口爬国内站，结果 push 仓库或回调 VPS。

## 反爬破解方法论（网页被 CF 拦截时）

**第一性原理：反爬拦"人访问网页"，拦不住"协议/API"。**

1. **找 API 端点**（最高性价比）— 网页被 CF 拦，找 `api.xxx.com` 隐藏 JSON 接口。例：Scamalytics 网页 403，`api.ipapi.is/?q=<IP>` 返回更全数据（abuser_score 公司+ASN 双重评分、is_datacenter/proxy/vpn/tor、abuse 联系邮箱）；`ipwho.is/<IP>` 是轻量备选（geo/ASN）
2. **协议层查询** — DNSBL（host/dig）、DNS TXT、WHOIS，不走 HTTP
3. **缓存/搜索绕行** — Wayback Machine、Google 索引、SearXNG
4. **换网络身份** — 住宅代理（最后手段，付费）

### 已被 CF 拦截的网站（勿浪费时间）
Scamalytics、AbuseIPDB、WhatIsMyIPAddress、IPQualityScore、ipapi.co — 全 403。

## DNSBL 查询关键坑（2026-08-02 实测）

**本地 DNS 缓存会抖动，单次 host 查询结果不可信！** 同一 IP 对 CBL 连续查询出现 `127.255.255.254`（列入）和 NXDOMAIN（未列入）交替。必须用公共 DNS 交叉验证：
```bash
dig +short "244.241.3.192.cbl.abuseat.org" A @1.1.1.1   # 127.x = 列入
dig +short "244.241.3.192.cbl.abuseat.org" A @8.8.8.8
```
本地 DNS 还可能**漏报**（Spamhaus 误报未列入，公共 DNS 验证实际已列入）。完整检测用自建工具：
```bash
python3 /root/.hermes/scripts/ip_reputation.py <IP>   # DNSBL公共DNS交叉验证 + WHOIS + ipapi.is评分
```

## 国内房产网站反爬实测（2026-08-17）

安居客/链家/我爱我家/58同城/房天下 对数据中心 IP 有强反爬（验证码/CF 拦截/JS 混淆）。

### 可行方案：CF Worker 反代 + curl
```bash
curl -s -L --max-time 20 'https://rss.cloudjoind.com/https://m.anjuke.com/sh/community/1209363/' \
  -H 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)' 2>/dev/null
```
- CF Worker 出口 IP 不在反爬名单，能拿到 160K+ 完整 HTML
- 移动端 UA 比桌面端 UA 反爬更宽松
- 安居客返回的数据包含 `window.__NUXT__` 结构化 JSON，价格信息在变量参数中

### 已知限制
- **历史房价走势数据**：所有平台的价格走势图都是前端 Canvas/SVG 动态渲染，服务端返回 `priceData:[]`（空数组），无法通过 curl 或 CF Worker 获取逐月历史数据
- 安居客 NUXT 数据中 `priceInfo.price` 字段含当月挂牌均价
- 58同城/我爱我家会强制 JS 反爬验证（`C3VK` cookie 机制），即使 CF Worker 代理也会被拦
- **房天下** 移动端（m.fang.com）通过 CF Worker 可拿到参考均价（`pageConfig` 内嵌 JS 变量）

### 各平台数据获取难度
| 平台 | CF Worker 可达 | 可得数据 | 历史走势 |
|------|---------------|---------|---------|
| 安居客 | ✅ | 挂牌均价 + 在售房源列表 | ❌ 前端渲染 |
| 房天下 | ✅ | 参考均价 | ❌ 前端渲染 |
| 我爱我家 | ❌ JS 反爬 | 搜索摘要可得 | ❌ |
| 58同城 | ❌ 强 JS 反爬 | 几乎不可达 | ❌ |
| 链家 | ❌ 403/超时 | 几乎不可达 | ❌ |

### 建议
历史房价数据无法服务端抓取，建议在手机 APP 或 Windows 浏览器端查看。如果必须自动化，需要住宅 IP + headless browser（如 camoufox）。

## 参考文件
- `references/cloudflare-workers-deploy.md` — Workers 免费额度官方口径、API Token 创建流程、V2RayN 安全确认
