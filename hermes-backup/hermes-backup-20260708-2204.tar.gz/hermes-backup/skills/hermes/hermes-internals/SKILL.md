---
name: hermes-internals
description: Hermes Agent 内部机制核心知识 — 基于官方文档。Frozen Snapshot Pattern、字符限制、Skills 三级加载、OpenClaw 迁移、DeepSeek 缓存架构。
version: 1.1.0
metadata:
  hermes:
    tags: [hermes, internals, memory, skills, openclaw, migration, caching, deepseek]
risk: read-only
---

# Hermes Internals

## ❄️ Frozen Snapshot Pattern（最重要）

**Session 期间对 MEMORY.md 的修改，下个 session 才生效。**

> "The system prompt injection is captured once at session start and never changes mid-session. When the agent adds/removes memory entries during a session, the changes are persisted to disk immediately but won't appear in the system prompt until the next session starts."

**实际影响**：
- `memory` 工具的 add/replace 操作 → disk 立即写入，下次 session 生效
- 我现在 session 里更新的记忆，刷新页面/重连后才能在 prompt 里看到
- 每次 session 开始时 prompt 里显示的 `%` 利用率是**上个 session 结束时**的快照

## 📏 Memory 字符限制（bounded memory）

- `MEMORY.md` 上限：**2,200 chars**
- `USER.md` 上限：**1,375 chars**
- 满了会自动 consolidation（合并/替换旧记忆）
- 当前利用率在每次 session 启动时显示，如：`[67% — 1,478/2,200 chars]`

**记忆必须精简**，不能往里塞大量原始内容。

## 📚 Skills 三级加载（Progressive Disclosure）

```
Level 0: skills_list() → [{name, description, category}, ...] (~3k tokens)
Level 1: skill_view(name) → 完整内容 + metadata（实际使用时才加载）
Level 2: skill_view(name, path) → 具体引用文件（最细粒度）
```

agent 调用 skill 时按需加载，不是全量加载。

## 🆕 Skills 新字段（我的 skills 缺的）

SKILL.md 支持但我目前没用到的字段：

```yaml
platforms: [macos, linux]        # OS 限制
metadata:
  hermes:
    fallback_for_toolsets: [web]  # 条件激活
    requires_toolsets: [terminal]  # 依赖条件
    config:                        # 安装时用户配置
      - key: my.setting
        description: "..."
        default: "value"
        prompt: "Prompt for setup"
```

## 🗂️ OpenClaw 迁移状态

**重要发现**：OpenClaw workspace 文件夹没有自动迁移。

```
OpenClaw 旧数据:  ~/.openclaw/workspace/knowledge/
  deep-learning.md   ← 还在这里！
  network.md         ← 还在这里！

Hermes skills:      ~/.hermes/skills/knowledge/  ← 不存在，未迁移
```

如果要从 OpenClaw 迁移 knowledge 文件，需要手动复制到 `~/.hermes/skills/`。

迁移命令 `hermes claw migrate` 只迁移人格/记忆/技能/消息配置/凭据，不迁移 workspace 普通文件。

## 🖼️ 视觉识别（2026-05-09 更新 — MiniMax 迁移后）

**主流模型切换**：主力模型从 MiniMax 切换为 **DeepSeek V4**。
MiniMax MCP server（`minimax-coding-plan-mcp`）已全部移除，包括 `understand_image` 和 `web_search`（均为平台级 404）。

**当前 Vision 方案（按优先级）**：

| 方式 | 状态 | 说明 |
|------|------|------|
| `vision_analyze` tool（原生 fast path） | ✅ 首选 | 图片嵌入主模型上下文（DeepSeek V4 Flash 原生视觉），不走辅助 LLM |
| `vision_analyze` tool（辅助 fallback） | ✅ 备用 | 通过 GitHub Models `gpt-4o-mini`（免费，Azure AI Inference 端点） |
| `mmx vision describe` CLI | ⬜ 已归档 | 仅在紧急降级时考虑 |
| `mcp_minimax_plan_understand_image` | ❌ 已移除 | MiniMax MCP 网关 endpoint 404 |

**`vision_analyze` 机制**：有两层路径

1️⃣ **原生 fast path**（优先）
- 条件：`_should_use_native_vision_fast_path()` 返回 `True`
- 行为：下载图片 → base64 → 构建 `_multimodal` tool-result 信封 → 嵌入主模型上下文，主模型直接"看到"像素
- 适用：Anthropic、OpenAI、Gemini 3.x、DeepSeek V4 Flash（需配置）、任何设置 `model.supports_vision: true` 的 provider

2️⃣ **辅助 LLM 路径**（fallback，`async_call_llm(task="vision")`）
- 通过 `resolve_vision_provider_client()` 获取辅助视觉客户端
- 路由链：辅助 vision provider → fallback OpenRouter → fallback Nous Portal

🔥 **关键坑：DeepSeek V4 Flash 需要显式配置原生视觉**

DeepSeek V4 Flash 支持原生视觉（API 接受 tool_result 中的图片），但 Hermes 默认不将其识别为视觉模型。必须手动在 config.yaml 中声明：

```yaml
model:
  default: deepseek-v4-flash
  provider: deepseek
  base_url: https://api.deepseek.com
  supports_vision: true       # ← 必须
  image_input_mode: native    # ← 或 auto（native 更直接）
```

否则 `decide_image_input_mode()` 返回 `text`，`_should_use_native_vision_fast_path()` 返回 `False`，所有 vision 请求走辅助 LLM 路径，质量明显下降。

**GitHub Models 免费视觉 fallback 配置**

GitHub PAT（`ghp_*`）可免费调用 Azure AI Inference 上的 gpt-4o-mini / gpt-4o 视觉模型，无需额外费用（有 rate limit）。

⚠️ **关键坑：ghp_ prefix 触发 Copilot handler**

GitHub 经典 PAT 会被 Hermes 的 Copilot OAuth 检测机制拦截（运行 `gh auth token` 发现 `ghp_*` token 后尝试用于 Copilot API 失败）。**不能通过 `key_env` 引用 PAT**，必须在 `auxiliary.vision` 配置中直接写入 `api_key` 字段：

```yaml
auxiliary:
  vision:
    provider: custom
    model: gpt-4o-mini
    base_url: https://models.inference.ai.azure.com
    api_key: ghp_...  # ← 直接写值，不通过 key_env
    timeout: 120
    download_timeout: 30
```

若用 `key_env: GH_MODELS_KEY` 配合 `.env`，`custom:github-models` provider name 解析时会被 Copilot 模块重写为 `copilot` 并返回 `client=None`，导致全线 fallback 失败。

**自定义 provider 与辅助视觉的关系**

`custom_providers` 中定义的 provider 可用于 `auxiliary.vision`，但：
- `custom:xxx` provider name 必须在 `resolve_vision_provider_client()` 中通过 `_get_cached_client()` 解析成功
- 对于 GitHub Models 这种特殊端点（PAT 触发 Copilot），直接写 `api_key` 比 `key_env` 更可靠
- Volcengine Ark（doubao 模型）可作为 custom provider 配置，但需确保网络可直达国内端点

**VPS 视觉模型配置方案汇总（VPS US 环境）**：

| 层 | 模型 | 配置方式 | 网络要求 |
|----|------|---------|---------|
| 原生（主模型） | DeepSeek V4 Flash | `config.yaml: model.supports_vision: true` | 无（已联通）|
| 辅助 fallback | GitHub Models gpt-4o-mini | `auxiliary.vision` 直接写 api_key | 无（已联通）|
| 预备（待网络打通） | Volcengine Ark doubao × 5 | `custom_providers` + `.env` ARK_API_KEY | 需国内 IP 或 Ark 国际访问 |

**有效文件判断**：`file /root/.hermes/image_cache/img_xxx.jpg` 返回有效 JPEG（文件本身没坏）

## 💾 DeepSeek 缓存架构（关键知识）

DeepSeek 的 Context Caching on Disk 是**服务端自动触发**的 byte 级前缀匹配缓存，无需 API 标记。

### 与 Hermes 交互的关键点

| 模块 | 状态 | 代码位置 |
|------|------|---------|
| `_cached_system_prompt` 会话内 frozen | ✅ 正确 | `run_agent.py:6056-6281` |
| 工具 schema 通过 `tools` 参数传递（不在 system prompt 文本中） | ⚠️ 常被误解 | `run_agent.py:10025-10028` |
| `_format_tools_for_system_message()` 只用于 trajectory | ⚠️ 容易误认 | `run_agent.py:4803-4825` |
| `/compress` → 必然破坏缓存 | 权衡（防 OOM > 缓存） | `run_agent.py:10722-10724` |
| `_deterministic_call_id` 防 UUID 破坏缓存 | ✅ 已做 | `run_agent.py:6655-6663` |
| `extract_cache_stats()` 读缓存统计 | 取决于 DeepSeek 是否返回字段 | `chat_completions.py:615-627` |

详见 `references/deepseek-caching.md`（含完整机制说明、代码位置索引、常见误解纠正、实测数据、跨频道缓存共享分析）

## 🔬 缓存诊断工作流（2026-05-17 实测验证）

当需要验证 DeepSeek（或其他 OpenAI 兼容 provider）的缓存是否生效时：

### 1. 确认 toolsets 一致
```python
from model_tools import get_tool_definitions
tools = get_tool_definitions(enabled_toolsets=["hermes-cli", "browser"], quiet_mode=True)
names = sorted(t["function"]["name"] for t in tools)
```
- `registry.get_definitions()` 内部用 `sorted(tool_names)` — 注册顺序跨会话稳定
- 各 profile 的 toolsets 必须完全一致，否则 system prompt 中的 skills 索引不同 → 前缀不同

### 2. 运行 `--verbose` 观察缓存统计
```bash
hermes chat -q "调用一次工具任务" --verbose
```
关键日志行：
```
API Response received - Model: deepseek-v4-flash
  Usage: CompletionUsage(..., prompt_tokens=20225, ...,
    prompt_tokens_details=PromptTokensDetails(cached_tokens=640),
    prompt_cache_hit_tokens=640,
    prompt_cache_miss_tokens=19585)
```

### 3. 解读缓存数据

| 轮次 | 典型命中率 | 说明 |
|------|-----------|------|
| 第 1 轮（冷启动）| ~3% | 仅共享前缀（默认 SOUL.md 路由规则 ~2.1KB 中已被缓存的部分）|
| 第 2 轮（同会话）| **~100%** | system prompt + 历史全部命中，仅新增 tool result 未命中 |
| 跨频道同 profile | 共享 ~2.1KB 前缀 | 频道独有 SOUL.md 需各自冷却 |

实测数据（2026-05-17, deepseek-v4-flash）：
```
Call #1: cache=640/20225 (3% hit) — cold start
Call #2: cache=20352/20420 (100% hit) — prefix fully cached, only 68 miss tokens
```

### 4. 跨频道缓存共享模型

各频道（小策/黑翼/小研/老V）运行在同一 default profile 下，共享：
```
[default SOUL.md (2.1KB, 路由规则)]  ← 所有频道共享
[per-profile SOUL.md (3.5-4.3KB)]    ← 频道独有
[per-profile MEMORY.md (0.4-3KB)]    ← 频道独有
[volatile: timestamp + memory snap]  ← 每次 session 不同
```

Feishu adapter：per-profile SOUL.md + MEMORY.md 通过 `channel_prompt` 机制注入为 `ephemeral_system_prompt`，拼接到 `_cached_system_prompt` 尾部（`feishu.py:2258-2285`）。详见 `hermes-per-channel-profile-injection` skill。

### 5. 失败模式速查

| 现象 | 原因 |
|------|------|
| 全程 0% 命中 | toolsets 不一致 / provider 不支持缓存 |
| 第 2 轮仍 < 50% | system prompt 在轮次间被重建（检查是否切换模型/重载工具）|
| 跨频道 < 10% 共享 | 频道独有 SOUL.md 不同 → 前缀从该处开始分叉 |
| 压缩后 0% | 必然行为（见 `_invalidate_system_prompt`），压缩和缓存不可兼得 |

## 💰 费用追踪

Hermes TUI 层内置 `show_cost` 配置项（当前 `config.yaml: show_cost: false`），但实际计费追踪需要对接 provider 的余额 API。

另见独立 skill `api-cost-tracking`（含 DeepSeek 余额 API 实现、V4 Flash/V4 Pro 定价表、人民币计价报告格式）。