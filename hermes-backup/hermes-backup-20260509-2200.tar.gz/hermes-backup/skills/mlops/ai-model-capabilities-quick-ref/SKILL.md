---
name: ai-model-capabilities-quick-ref
description: 常见 AI 模型多模态能力快速对照 — 图片理解 vs 图片生成，明确各模型能力边界
category: mlops
risk: read-only
version: 1.0
created: 2026-05-08
source: 大佬 DM 对话
---

# AI 模型多模态能力快速对照

## 核心原则

> **图片理解 ≠ 图片生成**。买咖啡时确认"有wifi"不等于"有电源"——两个完全不同的能力，必须分别确认。

---

## 主流模型能力矩阵（2026-05-08 实测/调研）

### 图片理解（Image Understanding / Vision）

| 模型 | 状态 | 说明 |
|------|------|------|
| **MiniMax Vision** (`mmx vision describe`) | ✅ 可用 | CLI 工具，绕过 API，是当前唯一可靠方案 |
| **MiniMax MCP** `understand_image` | ❌ 平台级 404 | 所有请求返回 404，不要再试 |
| **DeepSeek V4 Vision** | ✅ 有 | 原生多模态输入（image + text），支持上传图片分析 |
| **GPT-4o / ChatGPT** | ✅ 极强 | 精确 reference image 控制，姿势迁移可用 |
| **Claude** | ✅ 极强 | 图像理解第一梯队 |
| **Gemini** | ✅ 极强 | Google 原生多模态 |

### 图片生成（Image Generation / T2I）

| 模型 | 状态 | 说明 |
|------|------|------|
| **MiniMax `image-01`** | ✅ 可用 | `response_format: base64` 绕过 OSS 不可达；`reference_image` 参数支持 img2img（但精度有限） |
| **pollinations.ai** | ✅ 免费备用 | 无需 API key，VPS 可访问，URL 方案 |
| **GPT-4o** (DALL-E) | ✅ 质量最高 | reference image 控制精准，姿势迁移可用 |
| **DeepSeek V4** | ❌ **没有** | V4 是纯语言/推理模型，**没有图片生成能力** |
| **DeepSeek Janus Pro** | ✅ 独立图片生成 | `deepseekimage.org`，与 V4 主模型完全独立 |
| **Midjourney** | ✅ 质量高 | 需要稳定梯子 |

---

## 关键坑点

### 坑1：以为"多模态"= "能生成图片"

DeepSeek V4（2026-04-24 发布）是 2026 年最受关注的模型之一，但它：

- ✅ 有 Vision（图片理解）
- ❌ **没有图片生成**（Text-to-Image）

3月份有谣言说 V4 会带图生视频能力，官方 4 月确认：**V4 仍是纯语言模型**。

**切记**：买之前先查「model name + image generation」，不要假设。

### 坑2：以为换了模型就能解决"生成质量差"

图片生成质量差通常是**模型能力上限**问题，不是"没用对模型"：

| 问题 | 根因 | 解法 |
|------|------|------|
| 姿势不精确 | `reference_image` 本质是风格参考，不是 ControlNet 级别姿势迁移 | GPT-4o / 让用户生成 / 接受模糊结果 |
| 生成模糊 | 模型本身分辨率/细节控制有限 | 换质量更高的模型（DALL-E 3 / Midjourney） |
| 角色特征丢失 | 文字 prompt 无法精确定义细节 | reference image 控制 + 文字补充 |

### 坑3：MiniMax MCP 工具一直挂着但还在试

`mcp_minimax_plan_understand_image` 平台级 404，2026-05-08 确认仍然不可用。

**统一走 `mmx vision describe`**，不要依赖 MCP。

---

## 快速查询

当用户问"XX 模型能生成图片吗？"时：

1. 查本表
2. 如果表里没有 → 搜索「model name + image generation + 2026」
3. 区分清楚是要「看懂图」还是「生成图」

---

## 更新日志

- 2026-05-08：创建。来源于大佬问 DeepSeek V4 能否改善图片质量，实际测试发现 V4 没有图片生成能力。
