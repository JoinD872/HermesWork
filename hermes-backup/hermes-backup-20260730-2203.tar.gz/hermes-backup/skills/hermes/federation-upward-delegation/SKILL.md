---
name: federation-upward-delegation
description: 子 Agent profile 通过文件联邦向 default profile 反向派活——适用于朵朵/老V/小策等非默认 profile 需要 default（小H）协助的技术任务（连用户电脑/查国内网站/技术方案等）
version: 1.0.0
category: hermes
tags: [federation, delegation, multi-agent, reverse, profile]
risk: write-safe
created: 2026-07-28
contributors: [小H]
triggers:
  - 用户在一个 profile 群聊中提出该 profile 能力范围外的任务（如朵朵群中要求查国内网站）
  - profile 自身 memory 中有联邦派活协议，识别到任务类型匹配「应转给 default」
---

# 反向联邦：子 Agent → Default 派活

## 背景

Hermes 原联邦协议（`federation-dispatch-wake`）解决的是 **DM (default profile) → 子 Agent** 的单向派活。但实际中用户也会在子 Agent 群里提出需要 default profile 能力的事（连 Windows 电脑、查国内网站、技术方案等），此时子 Agent 需要反向委托给 default。

本 skill 定义了完整的反向派活链路。

## ⚠️ 重要教训（2026-07-28）

**用户明确拒绝了此联邦管道方案。** 他说「我觉得你的方法不好，还是全部还原吧」。

### 教训：永远先试最简单的方案

用户要求「让朵朵能给你派任务」时，正确做法只有：

```
让用户自己来 default profile（小H）的会话说
```

**不需要任何联邦管道。** 朵朵的记忆里加一行「遇到技术问题告诉用户找小H」就够了。

### 什么时候才值得搭建联邦管道

仅当同时满足以下所有条件时才考虑：
1. **高频** — 子 Agent 每周需要找 default 帮忙多次（≥3-5次/周）
2. **自动化收益明确** — 每次手动转述的成本 > 搭建管道的维护成本
3. **用户明确要求** — 用户说「帮我弄个自动化的方式」，而不是「你帮我想办法」
4. **先给用户看最简单的方案**，用户觉得不够再升级

### 此 skill 的技术方案仍保留供参考

以下完整管道方案在技术上可行，但已不属于用户当前期望采用的方案。保留作技术文档。如果未来用户主动要求自动化管道，可参考此文档实施。

## 链路全景

```
用户 → 朵朵/老V/小策 群聊
         │
         ▼
  子 Agent 识别：这不是我的事
         │
         ▼
  write_file → ~/.hermes/federation/pending/default/{task_id}.json
         │
         ▼
  default profile 的 no_agent cron (如 check-duoduo-pending.sh)
  每30min 扫描 pending/default/*.json
         │
         ▼
  有任务 → 送达通知到 default profile 会话
         │
         ▼
  小H (default) 读取 pending 文件 → 处理 → 写 callback
         │
         ▼
  ~/.hermes/federation/callbacks/{task_id}.json
         │
         ▼
  子 Agent 下次会话时读 callback → 拿结果 → 清理
```

## 需要创建的组件

### 1. pending/default/ 目录

```bash
mkdir -p ~/.hermes/federation/pending/default
```

### 2. no_agent 扫描脚本

位置：`~/.hermes/scripts/check-pending-default.sh`

功能：
- 扫描 `pending/default/*.json`
- 有任务时输出通知（含 task_id、类型、描述、等待时间）
- 无任务时静默退出（no_agent 静默 = 不打扰）

### 3. no_agent cron（每30分钟）

```python
cronjob(
    action="create",
    name="default pending扫描",
    schedule="every 30m",
    script="check-pending-default.sh",
    no_agent=True,
    deliver="origin"
)
```

## 子 Agent 端配置

### 写入 MEMORY.md

在子 Agent 的 `~/.hermes/profiles/{profile}/memories/MEMORY.md` 中添加联邦协作章节，包含：

#### 派活方式

子 Agent 通过 `write_file` 创建任务文件：
```
~/.hermes/federation/pending/default/{task_id}.json
```

格式：
```json
{
  "task_id": "DUODUO_YYYYMMDD_序号",
  "agent": "default",
  "created_at": 时间戳,
  "status": "waiting",
  "user_context": {
    "source": "朵朵（替换为实际 profile 名）",
    "original_request": "用户原话"
  },
  "task": {
    "type": "国内搜索/电脑操作/技术方案/其他",
    "description": "一句话描述",
    "requirements": ["具体要求1", "具体要求2"]
  }
}
```

#### 收结果

小H处理完后写 callback 到：
```
~/.hermes/federation/callbacks/{task_id}.json
```

格式：
```json
{
  "task_id": "DUODUO_...",
  "assignee": "小H",
  "status": "done",
  "payload": {
    "summary": "处理结果摘要",
    "key_findings": [],
    "action_items": []
  },
  "completed_at": "时间"
}
```

#### 触发条件（什么情况该派活）

| 场景 | 说明 |
|------|------|
| 需要访问国内网站/资源 | VPS 被屏蔽，小H可连用户电脑通过国内网络访问 |
| 需要操作 Windows 电脑 | 文件操作、软件管理等 |
| 用户问技术方案 | UE5、VPS、网络配置等 |
| 用户问 Hermes 配置/维护 | 升级、cron、技能管理等 |
| 任何该 profile 不负责的事 | 直接转给 default |

#### 派活礼仪

- task_id 用 profile 前缀（朵朵=DUODUO_、老V=VPS_、小策=GAME_）
- created_at 用 `int(time.time())` 生成
- 派活后告知用户：「我已经让小H去处理了，稍等回音」
- 不等小H回复，派完继续和用户聊
- 用户问进度时，去读 callback 文件检查

## Default 端处理流程

当 default profile 的 cron 检测到 pending 任务时：

1. 读取 `pending/default/{task_id}.json` 了解任务内容
2. 判断类型，执行所需操作（SSH 连电脑、搜索、技术分析等）
3. 处理完成后写 callback 到 `callbacks/{task_id}.json`
4. 删除 `pending/default/{task_id}.json`
5. （可选）在该对话中向用户汇报结果

## 脚本实现参考

```bash
#!/bin/bash
# check-pending-default.sh — no_agent 扫描脚本
# 有任务时输出通知，无任务时静默

PENDING_DIR="$HOME/.hermes/federation/pending/default"
shopt -s nullglob
files=("$PENDING_DIR"/*.json)
[ ${#files[@]} -eq 0 ] && exit 0

echo "📨 收到子Agent派来的新任务！"
for f in "${files[@]}"; do
  task_id=$(basename "$f" .json)
  task_desc=$(grep -o '"description":[ ]*"[^"]*"' "$f" | head -1 | sed 's/"description":[ ]*"//;s/"//')
  task_type=$(grep -o '"type":[ ]*"[^"]*"' "$f" | head -1 | sed 's/"type":[ ]*"//;s/"//')
  created=$(grep -o '"created_at":[0-9]*' "$f" | grep -o '[0-9]*$')
  now=$(date +%s)
  age=$(( (now - created) / 60 )) 2>/dev/null
  echo "  📋 $task_id  |  类型: ${task_type:-?}  |  内容: ${task_desc:-?}  |  等 ${age:-?}分"
done
```

## 已知实例

| 子 Agent | task_id 前缀 | 首次部署 | 备注 |
|----------|-------------|---------|------|
| — | — | — | 无已部署实例。2026-07-28 曾尝试为朵朵部署（cron `4eb5e6ef62b5`），用户否决后全部还原 |

## 相关 Skill

- `federation-dispatch-wake` — 正向派活（DM → 子 Agent），protocol 层
- `federation-protocol-v320` — 联邦协议目录结构规范（受 curator 保护，不可编辑）
- `federation-callback-scan` — 回执池与 vault ingestion
- `personal-cognitive-management` — 朵朵的人设与认知工作流
