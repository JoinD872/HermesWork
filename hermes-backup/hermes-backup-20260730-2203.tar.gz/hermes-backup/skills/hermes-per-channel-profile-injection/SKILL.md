---
name: hermes-per-channel-profile-injection
description: Hermes multi-group (Feishu/Telegram/Discord) per-chat_id profile SOUL.md + MEMORY.md injection via channel_prompt mechanism. Gateway runs single default profile; per-channel identity is injected at the MessageEvent layer.
risk: write-dangerous
---

# Hermes Per-Channel Profile SOUL + Memory Injection

## Background

Hermes Gateway runs a single instance on the `default` profile — it **only loads global files**:
- `~/.hermes/SOUL.md`
- `~/.hermes/memories/MEMORY.md`

Per-profile files under `profiles/<name>/SOUL.md` and `profiles/<name>/memories/MEMORY.md` are **NOT loaded by the gateway**. Restarting doesn't fix this — they're not on the load path.

## Architecture: channel_prompt Injection

All multi-channel platform adapters (Telegram/Discord/Slack) inject per-channel system prompt via the `MessageEvent.channel_prompt` field.

**Message flow:**
```
Message arrives
  → Adapter builds MessageEvent(chat_id, channel_prompt=...)
  → Gateway run_sync()
  → combined_ephemeral = context_prompt + channel_prompt + ephemeral_system_prompt
  → AIAgent(ephemeral_system_prompt=combined_ephemeral)
  → LLM receives the correct persona prompt
```

`channel_prompt` is per-message, injected at API-call time only, **not** part of the cached system prompt. This keeps `_cached_system_prompt` stable across channels for prefix cache optimization.

## Implementation Status (2026-07-15)

**The feishu adapter is now a plugin:** `plugins/platforms/feishu/adapter.py` (no longer at `gateway/platforms/feishu.py`). The hardcoded `profile_map` / `_resolve_profile_channel_prompt()` from the old codebase no longer exists.

The primary mechanism that IS confirmed working: **`~/.hermes/SOUL.md` routing table** — the agent reads the chat_id → persona mapping from the system prompt and responds accordingly.

### Current profile assignments

| chat_id | profile dir | identity | status |
|---------|-------------|----------|--------|
| `oc_cc9c8289c9520ff326578703ff17392c` | `vps-technician/` | 老V | active |
| `oc_5a883cbe523b1a93ee269bba2f8536a0` | `game-designer/` | 小策 | active |
| `oc_8391fa2b38acbd759ff75ab3616d5d1f` | `game-designer/` | 小策 (alt) | active |
| `oc_6dbf15aa718c29adca8d085017930a71` | `health/` | 黑翼 | active |
| `oc_ec9adb3139cd38ac706cd7a54c4d059d` | `duoduo/` | 朵朵 | **2026-07-15: replaced researcher** |

Note: directory name `health/` serves the 黑翼 identity. The `duoduo/` profile fully replaced `researcher/` on 2026-07-15 (new profile dir + SOUL.md + MEMORY.md, old content archived to `archive/researcher_old/`).

### How to add/change a persona (current method)

1. Create `profiles/<name>/` with SOUL.md + MEMORY.md + config.yaml
2. Update the routing table in `~/.hermes/SOUL.md`
3. Update `channel_directory.json` group name if desired
4. Gateway restart (or wait — SOUL.md is read per-session)

This is simpler than the old patching approach — no code changes needed.

### Cross-channel cache impact

channel_prompt is appended to `_cached_system_prompt` via `ephemeral_system_prompt` (appended at `run_agent.py:11905`). All channels share the first ~2.1KB of default SOUL.md prefix (DeepSeek prefix cache shared). Only the last cache unit (per-channel SOUL.md + MEMORY.md) needs independent caching. See `hermes-internals` skill `references/deepseek-caching.md` for the full analysis.

## Identity Migration Workflow

When creating a new identity or replacing an existing one:

### Step 1: Create new profile directory
```bash
# If replacing: archive old content first
mkdir -p ~/.hermes/profiles/archive/<old_name>_old
mv ~/.hermes/profiles/<old_name>/SOUL.md ~/.hermes/profiles/archive/<old_name>_old/
mv ~/.hermes/profiles/<old_name>/memories/MEMORY.md ~/.hermes/profiles/archive/<old_name>_old/

# Create new profile (copy config from existing one)
mkdir -p ~/.hermes/profiles/<new_name>/{memories,cron,home,logs,plans,reports,sessions,skins,workspace}
cp ~/.hermes/profiles/<existing_profile>/config.yaml ~/.hermes/profiles/<new_name>/
```

### Step 2: Write SOUL.md + MEMORY.md
```bash
# SOUL.md: identity, core responsibilities, boundaries, rules
# MEMORY.md: stable user info (background, family, preferences)
# See ~/.hermes/profiles/duoduo/ as a reference example
```

### Step 3: Update routing table
Edit `~/.hermes/SOUL.md`:
- Change the routing table entry (chat_id → new identity name)
- Replace the identity description section

### Step 4: Update channel directory (optional)
Edit `~/.hermes/channel_directory.json`:
- Update the group name for the chat_id

### Step 5: Restart gateway
```bash
systemctl --user restart hermes-gateway
# or
hermes gateway restart
```

### What NOT to change
- The feishu plugin adapter code (no code changes needed)
- Config files or cron jobs referencing the old profile (archive first, clean up references)

### Verification
Send a message in the target group chat. The agent should respond with the new persona.

### Reference: real migration (小研 → 朵朵, 2026-07-15)
The `researcher/` profile was fully replaced by `duoduo/`:
- New profile dir, new SOUL.md (83 lines), new MEMORY.md (27 lines)
- Old content archived to `archive/researcher_old/`
- Knowledge base: `ObsidianVault/朵朵笔记/` with 4 subdirs + README.md
- Google Drive sync: covered automatically by existing Vault sync cron

## Implementation Steps (if adding a new platform)

### 1. Add a `_resolve_profile_channel_prompt` method

In the platform adapter class:

```python
def _resolve_profile_channel_prompt(self, chat_id: str) -> str:
    from pathlib import Path
    import os

    _profile_map = {
        "oc_cc9c8289c9520ff326578703ff17392c": "vps-technician",
        "oc_5a883cbe523b1a93ee269bba2f8536a0": "game-designer",
        "oc_6dbf15aa718c29adca8d085017930a71": "health",
        "oc_ec9adb3139cd38ac706cd7a54c4d059d": "researcher",
    }
    profile_name = _profile_map.get(chat_id)
    if not profile_name:
        return ""

    profile_dir = Path(os.path.expanduser("~/.hermes")) / "profiles" / profile_name
    if not profile_dir.is_dir():
        return ""

    parts = []
    for rel in ("SOUL.md", "memories/MEMORY.md"):
        path = profile_dir / rel
        if path.is_file():
            content = path.read_text(encoding="utf-8").strip()
            if content:
                parts.append(content)
    return "\n\n".join(parts)
```

### 2. Inject into all MessageEvent construction points

Every `MessageEvent(` call site needs `channel_prompt`:

```python
normalized = MessageEvent(
    ...
    channel_prompt=self._resolve_profile_channel_prompt(chat_id) or None,
)
```

Must handle: text messages, reaction events, card action events, any other synthetic event type.

### 3. Validate syntax

```bash
cd ~/.hermes/hermes-agent
python -m py_compile gateway/platforms/feishu.py
```

### 4. Restart gateway

```bash
hermes gateway restart
# or
systemctl --user restart hermes-gateway
```

## Casual / No-Agenda Channel Pattern

A new channel type introduced 2026-06-02: 闲聊频道 (casual chat).

### Use case

A dedicated group chat where the user wants to chat casually without:
- Task execution (no file writes, no tool calls, no config changes)
- Knowledge base updates (no memory writes, no diary entries)
- Codex delegation (not worth the cost for casual chat)
- Cron delivery / notifications

### Implementation approach

Two layers of isolation:

**Layer 1: SOUL.md routing table** — Add a routing row for the new chat_id with a "闲聊小H" identity that explicitly states: "no tasks, no work, just chat."

**Layer 2: channel_prompt (feishu.py profile_map)** — Map the new chat_id to a profile that has a minimal SOUL.md defining the casual persona. Can either:
- (a) Create a new profile dir (e.g. `profiles/casual/`) with a short SOUL.md — requires adding to feishu.py `_profile_map`
- (b) Reuse an existing profile but rely entirely on the SOUL.md routing table injection — simpler, no code change

Option (b) is preferred for minimal risk: the routing table in the system prompt is enough to tell the agent "this is a casual channel, don't execute tasks."

### Casual persona definition (SOUL.md entry)

```
### 🗣️ 闲聊小H
- 纯聊天模式，不输出方案、代码、研究结论、知识库
- 不建立知识点，不写日记，不写 memory
- 用户可以聊任何事——吐槽工作、游戏感想、对某个事情的想法
- 小H可以展开聊、跟着思路发散、分享自己的「看法」
- 不把用户的任何话当「任务」执行
- 退出这个频道时，这段对话就像没发生过一样
- Codex 不参与（不值得花那钱），回复标 Codex：0轮
```

### Behavioral difference matrix

| 事项 | 闲聊群 | 正常群（DM/工作群） |
|------|--------|-------------------|
| 任务执行 | ❌ 不执行 | ✅ 默认 |
| 知识库/memory | ❌ 不写入 | ✅ 维护 |
| Codex 参与 | ❌ 不叫 | ✅ 按需求 |
| cron 投递 | ❌ 不投递 | ✅ 默认 |
| 上下文压缩 | ✅ 正常 | ✅ 正常 |
| 费用显示 | — 随用户偏好 | — 随用户偏好 |

### Setup steps

1. User creates a new Feishu group, adds the bot
2. User sends the new chat_id to 小H
3. 小H adds a routing row in `~/.hermes/SOUL.md`
4. (Optional) 小H adds the casual persona definition to SOUL.md
5. No gateway restart needed — SOUL.md is read per-session

## Key Lessons

1. **The old feishu.py patching approach is deprecated.** The feishu adapter is now a plugin (`plugins/platforms/feishu/adapter.py`). Profile injection relies on the SOUL.md routing table + profile directories — no code changes needed.
2. **Gateway restart is not strictly required** — SOUL.md is read per-session. But restarting makes the change take effect immediately.
3. **Profile directory names are free** — you can create new ones without editing any adapter code. The SOUL.md routing table and channel_directory.json are the only files that need updates.
4. **channel_prompt** is the platform adapter layer injection point. Telegram/Discord/Slack already use this for per-channel prompts. The feishu plugin's mechanism differs from the old patched approach.
5. **Casual channels** are a new pattern: no profile injection needed, just SOUL.md routing + persona definition.

## Reference: Telegram/Discord channel_prompt usage

Telegram (`gateway/platforms/telegram.py`):
```python
_channel_prompt = resolve_channel_prompt(self.config.extra, thread_id_str or _chat_id_str, ...)
return MessageEvent(..., channel_prompt=_channel_prompt)
```

Discord (`gateway/platforms/discord.py`):
```python
_channel_prompt = self._resolve_channel_prompt(channel_id, parent_id)
return MessageEvent(..., channel_prompt=_channel_prompt)
```

`resolve_channel_prompt()` is defined in `gateway/platforms/base.py`. It reads `config.extra.get("channel_prompts")`. The per-profile approach reads files directly, same effect with less config overhead.