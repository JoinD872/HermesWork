---
name: duoduo-note-workflow
description: 朵朵（个人认知管理助手）笔记写入工作流 — 存储位置 / 确认流程 / 文件格式规则 / 更新策略 / 双向链接规范
version: 1.0.0
tags: [duoduo, personal-notes, knowledge-base, obsidian, productiviy]
risk: write-safe
---

# 朵朵笔记工作流

## 触发条件

当用户与朵朵进行了有深度的对话（个人反思、生活状态、家庭关系、情绪整理、认知变化等），且用户确认「值得记录」时，执行本工作流。

## 存储位置

### 朵朵知识库（独立于主 Vault）

知识库位于独立的 Google Drive 文件夹，**不是**主 Obsidian Vault：

- **Google Drive folder ID**: `1oLAY4-63zFm5vFSM5UiNycMuFChuYAnt`
- **同步方式**: rclone 直接读写（不经过 VPS 本地 Vault）

### 目录结构

```
朵朵笔记/
├── README.md                ← 本库说明
├── 01_人生系统/              ← 目标、价值观、决策记录
├── 02_家庭育儿/              ← 女儿成长、育儿原则、家庭关系
├── 03_聊天归档/              ← 原始对话草稿（未经确认）
└── Draft/                   ← 待用户确认的笔记草稿
```

### 与主 Vault 的关系

⚠️ 不要混用。朵朵笔记走独立的 Drive 文件夹，不写入 `~/.hermes/ObsidianVault/`。主 Vault 用于技术文档、项目复盘、Hermes 架构等，朵朵知识库用于个人/人文内容。

## 写入流程

### 第一步：确认（**必须**）

在写出任何内容前，先问用户是否需要记录。句式参考：

> 「这几轮的聊天，你觉得哪些有价值，需要做到 Obsidian 里？」

### 第二步：写 Draft（用户确认后）

1. 在本地创建 .md 文件（临时目录即可，如 `/tmp/duoduo-draft/`）
2. 用 **纯 rclone copy** 上传到 `Draft/` 子目录
3. 用户自行从 Draft 晋升到目标目录

### 第三步：通知用户

告知已写入 Draft，用户可以自行查看和晋升。

## 文件格式规则（⚠️ 关键）

### 上传参数

**正确** — 原生 .md 文件：

```bash
rclone copy /local/path/ "mydrive:Draft/" \
  --drive-root-folder-id "1oLAY4-63zFm5vFSM5UiNycMuFChuYAnt"
```

**错误** — 不要加 `--drive-import-formats md`：

```bash
# ❌ 此参数将 .md 转换为 Google Docs 格式
# 用户从 Drive 下载时拿到的将是 PDF 而非 .md
rclone copy ... --drive-import-formats md ...
```

规则：知识笔记用原生 .md（Google Docs 格式仅用于日记系统，因为手机编辑需要）。

### 文件内容格式

每条笔记需包含：

```markdown
# 笔记标题

**日期：** YYYY-MM-DD
**来源：** 朵朵飞书对话
**标签：** #标签1 #标签2

---

（正文）
```

使用 `[[笔记名]]` 双向链接关联已有笔记。第一篇笔记通常没有可链对象，后续笔记应主动链接前文。

## 笔记更新策略

| 场景 | 做法 |
|------|------|
| 同一主题有进展（同一话题线的延续） | 追加到现有笔记 |
| 全新主题（与原笔记无关） | 另开新文件 |
| 关联度高但不完全一样 | 新笔记开 `[[关联笔记]]` 双向链接 |
| 不确定 | 问用户：「这个跟上次那篇放一起，还是另开一篇？」并附上已有笔记摘要 |

## 已确立的规则（来自用户确认）

1. **优先维护已有笔记，不无限开新文件** — 用户 README 明确要求
2. **用户不需记住笔记内容** — 问到关联度时，由朵朵摘要已有笔记内容帮用户回忆
3. **拿不准就确认** — 花 2 秒问用户比猜错后返工更省事
4. **用户不负责晋升** — 笔记写 Draft 即可，用户有空再看

## 已知坑点

| 坑 | 后果 | 修复 |
|:---|:-----|:-----|
| `--drive-import-formats md` 上传知识笔记 | .md 被转换为 Google Docs，用户下载得 PDF | 只用原生 copy，不加 import-formats |
| 写入主 Vault 而非朵朵知识库 | 笔记在错的位置，用户找不到 | 确认 `--drive-root-folder-id` 为 `1oLAY4-...` |
| 上传时带空目录 | rclone 可能跳过 | 确保目标子目录（如 Draft/）已存在 |

## 参考

- `references/this-session.md` — 本工作流确立的原始对话记录
