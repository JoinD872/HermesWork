---
---
name: hermes-github-backup
description: Hermes Agent 配置备份到 GitHub 私人仓库（PAT认证 + 每日Cron + 10个归档轮换）
risk: write-dangerous
---

# Hermes GitHub 备份机制

## 核心设计

**格式**：每次备份生成单个 tar.gz 文件，文件名含精确时间戳，永远不覆盖旧文件。
**轮换**：保留最近 10 个归档包，超出自动删除最早的。
**路径**：`hermes-backup/hermes-backup-YYYYMMDD-HHMM.tar.gz`

## 备份内容（P0+P1）

| 类别 | 内容 | 大小 |
|------|------|------|
| P0 核心 | SOUL.md, MEMORY.md, USER.md, global_knowledge.md, config.yaml, auth.json, channel_directory.json, cron/jobs.json | ~200KB |
| P0 profiles | 4个Agent的 SOUL.md + config.yaml | ~50KB |
| P1 skills | ~/.hermes/skills/ 整体（全部SKILL.md） | ~3.8MB |
| P1 research | ~/.hermes/research/ | ~40KB |
| P2 federation | callbacks 历史记录 | ~4KB |

**注意：不要备份 hermes-agent/ 源码（2GB），不要备份 profiles/*/skills/（是 ~/.hermes/skills/ 的副本）**

## GitHub 仓库最终结构

```
HermesWork/
└── hermes-backup/
    ├── hermes-backup-20260427-0732.tar.gz   ← 第一个归档
    ├── hermes-backup-20260427-0737.tar.gz
    └── ...最多10个，到第11个时自动删除最早的
```

## 备份脚本

`/root/.hermes/scripts/hermes-backup.sh`

核心逻辑：
1. Clone 或 pull 仓库
2. 临时目录打包所有备份内容为 tar.gz（含精确时间戳）
3. git add + commit + push
4. 统计归档数量，超过 10 个则删除最早的

```bash
# 轮换逻辑（核心）
BACKUPS=$(ls -1 hermes-backup-*.tar.gz | sort)
TOTAL=$(echo "$BACKUPS" | wc -l)
if [ "$TOTAL" -gt "$MAX_BACKUPS" ]; then
    TO_DELETE=$(echo "$BACKUPS" | tail -n +$((MAX_BACKUPS + 1)))
    echo "$TO_DELETE" | while read -r old_backup; do
        git rm "$old_backup"
    done
fi
```

## GitHub PAT 认证（坑点）

```bash
# ❌ 不生效：credential.helper store 方式
git config --global credential.helper "store --file ~/.git-credentials"
git ls-remote https://github.com/USER/REPO.git  # 失败：No such device

# ✅ 有效方式：clone/pull 时直接把 PAT 嵌在 URL 里
git clone "https://ghp_TOKEN@github.com/USER/REPO.git" /tmp/repo
```

## 恢复步骤（新机器）

```bash
# 1. 拉取仓库
git clone https://github.com/JoinD872/HermesWork.git /tmp/restore

# 2. 解压最新归档
LATEST=$(ls -1 /tmp/restore/hermes-backup/*.tar.gz | sort | tail -1)
tar -xzf "$LATEST" -C /tmp/restore

# 3. 恢复配置（覆盖）
cp -r /tmp/restore/hermes-backup/* ~/.hermes/
```

## 已知坑点

- `git ls-remote` 不读取 `~/.git-credentials`，认证失败 → 用 embedded token URL 解决
- skills 目录复制用 `cp -r ~/.hermes/skills/ skills/` 会嵌套成 `skills/skills/` → 先 mkdir -p 再复制
- PAT 写在脚本里，Security scan 会报警但用户自己批准，属于正常操作

## 关键信息

| 项目 | 值 |
|------|-----|
| 备份脚本 | `/root/.hermes/scripts/hermes-backup.sh` |
| Cron Job ID | `858137a1ff62` |
| Cron 表达式 | `0 22 * * *` = 每天 06:00 上海时间 |
| 目标仓库 | `github.com/JoinD872/HermesWork` |
| 归档路径 | `hermes-backup/hermes-backup-YYYYMMDD-HHMM.tar.gz` |
| 保留数量 | 永远 10 个（超出自动删除最早的） |
