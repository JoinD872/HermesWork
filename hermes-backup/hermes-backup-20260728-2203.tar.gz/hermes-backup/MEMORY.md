GitHub PAT 实际位置在 /root/.hermes/scripts/hermes-backup.sh（不在 .env），用户 JoinD872，仓库 JoinD872/HermesWork（私人），Token 前缀 ghp_6q...XGvJ。以后查 GitHub 认证先看 backup.sh。
§
用户云端迭代工作流 — 主力走 GitHub：文件放 JoinD872/HermesWork/workspace/，用户在网页版改，我读+改+提交推送。不走百度网盘/飞书云盘。补充：Google Drive 用于 Obsidian Cloud Inbox（HermesInbox/ 文件夹，每30min拉取到 Vault 收件箱），仅做灵感投递不用于代码迭代。
§
## 低频流程索引（详情查对应 skill）
宠物技能设计：skill `pet-skill-design-workflow` | crawl4ai：skill `community-scraping` | 日记格式：skill `obsidian`
§
图片理解：主力 OpenCode Go minimax-m3（视觉），备用 GitHub Models gpt-4o（免费）。不用 DeepSeek 直连（用户要求非订阅付费 API 不用）。
§
VPS 隧道架构（2026-07-17）：Docker-tunnel = systemd 服务（`cloudflared-docker-tunnel.service`），服务于 `proxy.cloudjoind.com` 翻墙代理；JoinD-tunnel = Docker 容器（`cloudflared-joined`）。两者独立不冲突。Docker 容器有 IPv6 DNS 超时问题（不影响功能）。
§
知乎已升级为官方API：ZHIHU_ACCESS_SECRET存于.env，developer.zhihu.com，每天1000次免费搜索。
§
## 通知与日记偏好
无事不通知；cron 用 silent script + deliver=local。Vault/日记默认被动，不主动读/写，等用户问再说。日记路径：~/.hermes/ObsidianVault/日记/ | 模板在 模板/日记模板.md
§
AI 偏好：Gemini "回答简短、语言贫乏、刻意迎合"；GPT "内容衍生多、思维更广"。不要 yes-man，要能发散碰撞的对话伙伴。
§
## 协作模型 V2（2026-07-15 更新）
小H（主控）、Codex（外脑）、小策（方案官）、朵朵（个人认知/知识库）、黑翼（风控官）、老V（执行官）。小研已于2026-07-15被替换为朵朵。Codex强默认前置参与所有任务。
§
## 运维信条
应用层连接错误 ≠ 应用本身故障。排查顺序：① DNS(/etc/resolv.conf + resolvectl) → ② TCP → ③ 代理/出口(WARP/Tailscale) → ④ 服务 → ⑤ 配置 → ⑥ 业务逻辑。网络组件修改必须 Before→Snapshot→Modify→HealthCheck→Rollback。Tailscale 不只是 VPN，它还管理 DNS (MagicDNS)。WARP warp 模式 (全流量隧道) 会触发 Tailscale DNS 接管，只允许 proxy 模式。
§
优选 IP 测试规则：VPS 只能验证隧道连通性（curl --resolve + HTTP 400=通），VPS 端的延迟数字对中国用户无参考价值。严禁报 VPS 侧测速结果（如"这个 IP 只要 72ms"）给用户做优选依据。用户必须自己从 Windows 侧 ping 或 CloudflareSpeedTest 测速。
§
朵朵每日笔记归档 cron: job_id=2db29a49d308, 每天 UTC 15:00 (北京时间 23:00) 运行。扫描当日朵朵对话→有价值内容→写 Draft/→通知用户。关联技能：cognitive-support, duoduo-note-workflow, personal-cognitive-management。
§
小研（researcher profile）已于2026-07-15被替换为「朵朵」（duoduo profile）。朵朵定位：个人认知管理助手，核心职责思维整理/决策辅助/情绪支持/家庭育儿/知识库沉淀。不负责工作设计/游戏策划/Hermes工程。知识库写入需用户确认。旧researcher归档至archive/researcher_old/。
§
用户用 Obsidian 免费版（无 Sync），手机看 .md 文件要么装 Remotely Save 插件要么在 Google Drive App 里预览。不能指望 Obsidian 官方同步。
§
当前状态：工作日10点上班→21点回家→打游戏放空→刷手机→2点睡→8点半起。自述每天心力不足、没精神。持续已久的6.5h/晚睡眠，属于慢性睡眠剥夺。
§
核心动机：深度父职责任感——「怕接不住女儿」。不跟别人比，而是怕未来的自己达不到女儿需要的标准。对父母（全年无休带娃做饭）有强烈愧疚感，想分担但缺乏行动精力。
§
信息来源偏好：要求权威性/同行评审来源（PubMed、Nature、Sleep期刊）。强烈排斥个人博客/低赞知乎文章作为证据——用户说「我让你是去找权威性的」。引用研究时必须提供PMID/DOI、期刊名称、引用次数等可验证细节。
§
认知到位但执行卡住：不是不知道问题在哪，是工作日精力耗尽后无力改变。行动切入点选在周末（学做饭），接受渐进改变而非一步到位。
§
睡眠是当前所有问题的根因（精力/情绪/动力）。已确定渐进式恢复方案：第1周7h→第2周7.5h→第3周8h，优先固定起床时间。PubMed研究已验证6h/晚认知退化风险。
§
大版本升级 Hermes 必须按流程走：先读 release notes 检查 breaking changes → 升级依赖包 → 确认回滚手段 → 告知用户风险 → 再重启网关。不能在网关会话内直接 restart，要用 Python subprocess + os.setpgrp 或另开 SSH 会话。详见 skill hermes-maintenance。
§
Hermes 大版本升级必须先加载 hermes-maintenance skill，严格按 Phase 1-4 执行。关键：1) git fetch --tags + git checkout 而不是 hermes update  2) 先升级所有依赖（lark-oapi 等）再重启网关  3) 重启前告知用户可能断连  4) 网关内用 Python subprocess + os.setpgrp 重启。记录见 references/v0.19.0-upgrade-incident.md
§
Windows PC (DaLao): Tailscale 100.108.175.15, SSH user 61915, workdir E:\Hermes. Needs V2RayN proxy for Tailscale control plane. Old desktop-tg4loen decommissioned.
§
User is cost-conscious about AI service subscriptions - was checking Xianyu prices for OpenCode Go accounts, considered using multiple Google accounts to repeatedly get the $5 first-month deal.
§
OpenCode Go 用量参考：14天用25%（$15），月均约$32消耗。相比 DeepSeek 官方 API（上个月用了¥80），Go 套餐$10/月更划算。用户对AI订阅的价格敏感区间在$5-10/月，超过$10需要物有所值才接受。
§
DaLao (100.108.175.15) user Desktop is on OneDrive: `C:\Users\61915\OneDrive\Desktop`. Use `[Environment]::GetFolderPath('Desktop')` to discover user Desktop path on Windows.