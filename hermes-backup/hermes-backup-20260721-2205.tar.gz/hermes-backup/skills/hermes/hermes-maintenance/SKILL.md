---
name: hermes-maintenance
description: Hermes 升级/维护/回滚/网关重启全流程 — 升级前检查、依赖更新、重启模式、回滚预案、事后验证。避免「升完飞书断了」类事故。
version: 1.0.0
author: Hermes Agent (self-taught)
tags: [hermes, upgrade, gateway, maintenance, rollback, dependency]
risk: write-dangerous
---

# Hermes Maintenance

Hermes 大版本升级、网关重启、依赖管理、回滚的标准操作流程。

## Upgrade Execution

### Phase 1: Pre-flight (升级前)

1. **Read release notes** — 不要只看版本号，看 Highlights + Breaking Changes
   ```bash
   # 查看最新 release
   hermes --version                              # 当前版本
   git log --oneline origin/main..v2026.x.x      # 新版本提交量
   ```
2. **Check dependency changes** — 平台插件可能有新的依赖参数
   ```bash
   # 查看 feishu/telegram 等平台插件的最新改动
   git diff vOLD..vNEW -- plugins/platforms/ | grep -E '^[+-].*import|^[+-].*pip|^[+-].*requirement'
   ```
3. **Update dependencies FIRST** — 在重启网关之前更新所有相关包
   ```bash
   cd ~/.hermes/hermes-agent
   source venv/bin/activate
   pip install lark-oapi --upgrade --break-system-packages  # Feishu SDK
   # 其他平台同理
   pip install -r requirements.txt 2>/dev/null || true
   ```
4. **Save rollback point** — 记录当前版本 tag，准备好回滚命令
   ```bash
   CURRENT_TAG=$(git describe --tags --always)
   echo "Current: $CURRENT_TAG  →  rollback: git checkout $CURRENT_TAG"
   ```
5. **Communicate** — 告知用户可能有一小段不可用时间

### Phase 2: Upgrade (升级执行)

```bash
# 拉取新 tag
git fetch origin --tags
# 切换到目标版本
git checkout v2026.X.Y
# 验证版本
hermes --version
```

### Phase 3: Gateway Restart (重启网关)

⚠ **关键限制: 不能在网关进程内重启网关**
`hermes gateway restart`、`systemctl --user restart hermes-gateway` 等指令在 Feishu/Telegram 会话中会被网关拦截（SIGTERM 传播到子进程）。

正确做法 — 使用 Python subprocess 分离进程组：

```python
import subprocess, os
proc = subprocess.Popen(
    ['systemctl', '--user', 'restart', 'hermes-gateway'],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
    preexec_fn=os.setpgrp,  # 脱离网关进程组
)
```

或者从另一个终端/SSH 会话执行（不在网关内）。

### Phase 4: Post-flight (升级后验证)

1. **检查网关状态**
   ```bash
   systemctl --user status hermes-gateway
   # Active: active (running)  ✓
   ```
2. **检查平台连接**
   ```bash
   tail -50 ~/.hermes/logs/gateway.log | grep -E "connected|error|TypeError|traceback"
   # 应看到: ✓ feishu connected
   ```
3. **检查关键平台特有的兼容性**
   - Feishu: 确认 WebSocket 连接成功，无 `TypeError: unexpected keyword argument`
   - Telegram/Discord: 确认 bot 在线
4. **发一条测试消息** 确认能正常回复

### Phase 5: Rollback (回滚)

如果新版本有问题：

```bash
cd ~/.hermes/hermes-agent
git checkout <前一版本tag>
# 重启网关
```
注：rollback 后如果依赖有变化，可能需要降级依赖包版本。

## Known Pitfalls

| 陷阱 | 表现 | 处理 |
|------|------|------|
| **lark-oapi 版本不兼容** | `TypeError: Client.__init__() got an unexpected keyword argument 'extra_ua_tags'` | 升级 lark-oapi: `pip install lark-oapi --upgrade` |
| **在网关内重启网关** | `Blocked: cannot restart or stop the gateway from inside the gateway process` | 用 Python subprocess + os.setpgrp 或通过另一个 SSH 会话 |
| **hermes update 的 stash/restore** | `hermes update` 可能 stash 了本地提交后再 restore，导致版本混乱 | 升级用 `git fetch --tags + git checkout` 代替 |
| **PEP 668 (Debian/Ubuntu)** | pip 安装被阻止 | 加 `--break-system-packages` 或在 venv 内操作 |

## Gateway Restart Reference

| 场景 | 可行方法 |
|------|---------|
| 从 CLI 终端（非网关） | `hermes gateway restart` |
| 从 SSH 会话 | `systemctl --user restart hermes-gateway` |
| 从网关内（飞书/Telegram 对话） | Python `subprocess.Popen([...], preexec_fn=os.setpgrp)` |
| 定时/自动化 | `echo "systemctl --user restart hermes-gateway" | at now + 1 minute`（可能被拦截）|

## Related

- `hermes-doctor` — 健康自检，升级后运行 `hermes doctor` 验证
- `hermes-agent` (bundled) — 升级评估方法论（是否该升级），本 skill 为升级执行流程
