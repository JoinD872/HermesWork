---
name: hermes-github-backup
description: Hermes Agent 配置备份到 GitHub 私人仓库（PAT认证 + 每日Cron）
---

# Hermes GitHub 备份机制

## 触发条件
- 用户要求将 Hermes 配置备份到 GitHub 私人仓库
- 涉及 git push 认证 + 每日 cron 调度

## 核心流程

### 1. GitHub PAT 认证（坑点）
```bash
# ❌ 不生效：credential.helper store 方式
git config --global credential.helper "store --file ~/.git-credentials"
git ls-remote https://github.com/USER/REPO.git  # 失败：No such device

# ✅ 有效方式：clone 时直接把 PAT 嵌在 URL 里
git clone "https://ghp_TOKEN@github.com/USER/REPO.git" /tmp/repo
```
**经验：git ls-remote 不读取 ~/.git-credentials，必须用 embedded token URL 或 SSH。**

### 2. 备份脚本结构
```bash
REPO_DIR="/tmp/hermes-backup-daily"
GITHUB_PAT="ghp_xxx"

# 首次 clone 或更新
if [ -d "$REPO_DIR/.git" ]; then
    cd "$REPO_DIR" && git pull origin main --quiet
else
    git clone "https://${GITHUB_PAT}@github.com/JoinD872/HermesWork.git" "$REPO_DIR"
    cd "$REPO_DIR" && git config user.name "HermesBackup"
fi

# 清理重建备份目录 → 复制文件 → git add → commit → push
bash /root/.hermes/scripts/hermes-backup.sh
```

### 3. 备份内容（P0+P1）
| 类别 | 内容 | 大小 |
|------|------|------|
| P0 核心 | SOUL.md, MEMORY.md, USER.md, global_knowledge.md, config.yaml, auth.json, channel_directory.json, cron/jobs.json | ~200KB |
| P0 profiles | 4个Agent的 SOUL.md + config.yaml | ~50KB |
| P1 skills | ~/.hermes/skills/ 整体（全部SKILL.md） | ~3.8MB |
| P1 research | ~/.hermes/research/ | ~40KB |
| P2 federation | callbacks 历史记录 | ~4KB |

**注意：不要备份 hermes-agent/ 源码（2GB），不要备份 profiles/*/skills/（是 ~/.hermes/skills/ 的副本）**

### 4. GitHub 仓库目录结构
```
HermesWork/
└── hermes-backup/
    ├── root/           # SOUL.md, global_knowledge.md
    ├── memories/       # MEMORY.md, USER.md
    ├── config/         # config.yaml, auth.json, jobs.json, etc.
    ├── profiles/       # 4 agents × (SOUL.md + config.yaml)
    ├── skills/         # 全部 skills
    ├── research/       # 研究文档
    └── federation/     # callbacks
```

### 5. 恢复步骤（新机器）
```bash
# 恢复配置
git clone https://github.com/JoinD872/HermesWork.git /tmp/restore
cp -r /tmp/restore/hermes-backup/* ~/.hermes/
```

### 6. 已知坑点
- `git ls-remote` 不读取 `~/.git-credentials`，认证失败 → 用 embedded token URL 解决
- skills 目录复制用 `cp -r ~/.hermes/skills/ skills/` 会嵌套成 `skills/skills/` → 用 `mkdir -p` 确认目标结构后再复制
- PAT 不要写在命令行里暴露（Security scan 会报警但用户自己批准），建议写到脚本里

## 关键文件
- 备份脚本：`/root/.hermes/scripts/hermes-backup.sh`
- Cron Job ID：`858137a1ff62`（每日 10:00 UTC / 18:00 GMT+8）
- 目标仓库：`github.com/JoinD872/HermesWork`
