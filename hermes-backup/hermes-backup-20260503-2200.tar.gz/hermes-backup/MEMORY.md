## 搜索策略（2026-05-03 调整）

**两引擎互补，按场景强制切换：**

| 场景 | 优先引擎 | 原因 |
|------|---------|------|
| 中文关键词搜索 | MiniMax (mcp_minimax_plan_web_search) | 知乎/百度/微博/公众号覆盖好 |
| 国内内容/新闻 | MiniMax | 中文理解强，结果相关 |
| 英文技术文档 | SearXNG (mcp_searxng_search) | Google 聚合质量高 |
| 实时价格/商品 | MiniMax | 国内平台收录新 |
| 搜索无结果时 | 换另一个引擎重试 | 互补策略 |

**执行习惯：搜索前先判断语言和平台，再选引擎，不是默认 SearXNG。**
§
## VPS IP 封锁（重要）
VPS 192.3.241.244 被 Epic Games + Cloudflare 屏蔽，无法访问：dev.epicgames.com / docs.unrealengine.com / unrealengine.com。搜索 Epic 相关内容走 SearXNG + 第三方站（Tom Looman / GameFromScratch / Vagon）。
§
## Hermes 系统管理风格（2026-05-02）

用户使用 GPT 作为"架构评审"角色：小H 执行自我审查 → GPT 出评审报告 → 用户转发指令给小H 执行。这是一种「AI 审查、AI 改进」的迭代模式。

执行风格偏好：
- 指令分 P0/P1/P2 优先级，依次执行
- 每个改动都要有验证步骤和回滚方案
- 不接受"先改再说"，必须"先诊断→列影响→再执行"
- 完成后必须出结构化汇报（GPT 要求统一格式）

## 小研研究沉淀问题（未解决）

现状：小研 callbacks（MINIMAX_DAILY/PAIN/UE5WP）存在 callbacks/ 但小H 不主动读取。
结果：研究"存了"但没有"用了"，MEMORY.md 里没有沉淀任何研究结论。
需要：研究结论自动同步 global_knowledge.md，或 cron 输出包含"对小H有用的行动项"。
§
## VPS 安全事件（2026-05-03 已修复）
- SSH 被暴力破解后停掉 → 已恢复（服务在运行）
- 端口已改为 2222
- ✅ Fail2Ban 已安装运行（帮你挡了 47k+ 次攻击）
- ✅ SSH 公钥免密登录已配置（小H 用 ed25519 私钥）
- nginx 因 /tmp/vpsfiles.conf 被清空而挂 → 已修复并移到永久路径
- cloudflared tunnel 521 错误 → 已恢复
- proxy.cloudjoind.com → HTTP 200 正常