---
name: chinese-cloud-resource-search
description: 百度网盘/夸克/阿里云等中文网盘影视资源搜索方法论——如何找到最顶配版本并提取真实链接+提取码
triggers:
  - 用户要找中文影视/动画资源的百度网盘链接
  - 搜索结果有链接但没有提取码
  - 找到的版本标注模糊，需要找最顶配版本
risk: read-only
version: 1.0
created: 2026-05-04
---

# 中文网盘资源搜索（最顶配标准）

## 核心原则

> 搜索引擎是入口，不是答案本身。
> 真正的链接在 Telegram 频道和论坛帖子里。
> 最顶配 = 最大文件体积 + 最高码率 + 最完整音轨

**用户偏好：只找最顶配版本，不接受凑合替代版。**

---

## GitHub 网盘搜索项目（首选，绕过搜索引擎风控）

> 2026-07-29 实测：VPS IP 被 Google/Bing 风控时，网盘搜索项目完全不受影响——它们**直接爬 Telegram 资源频道**，不调搜索引擎。

| 项目 | Stars | 说明 |
|:---|:---:|:---|
| **fish2018/pansou** | ⭐14k | PanSou 网盘搜索 API，TG 频道+插件并发搜索，Docker 一键部署 |
| **wu529778790/panhub** | ⭐1.5k | PanHub 聚合搜索，80+ TG 频道 + 20+ 插件，**有在线站可直接用** |
| **Xwudao/lzpan_search** | ⭐628 | 懒盘搜索，短剧网盘搜索 |
| **towelong/panxiaozi** | ⭐248 | 盘小子一站式网盘搜索 |

**PanHub 在线 API（免部署直接用）：**
```bash
curl "https://panhub.shenzjd.com/api/search?kw=关键词"
```
返回 JSON，`data.list` 含网盘链接+提取码，支持百度/夸克/阿里/UC/迅雷多平台。2026-07-29 实测「功夫女足」返回 10 条结果，含 5 个平台链接。

> ⚠️ 2026-07-31 实测：官方在线站 `panhub.shenzjd.com` 已挂（HTTP 400/000）。**已在 VPS 上 Docker 自建，本机直接可用：**
> ```bash
> # VPS 上自建实例（已部署，开机自启）
> curl "http://localhost:4000/api/search?kw=关键词"
> # 部署命令（如需重建）：
> docker run -d --name panhub -p 4000:4000 -v /root/panhub/data:/app/data ghcr.io/wu529778790/panhub.shenzjd.com:latest
> docker update --restart unless-stopped panhub
> ```
> 实测搜「无职转生」返回 85 条（magnet 75 + 夸克/百度/迅雷/阿里网盘直链），搜「无职转生Ⅲ」返回 14 条含第三季最新更新（更至5集）。搜索参数 `kw` 需 URL 编码；无密码锁时 `/api/search` 直接可用。

**PanSou 部署（自建更稳）：** Docker 一键：`docker run -d --name pansou -p 8080:8080 fish2018/pansou`，然后 `http://localhost:8080/api/v1/search?keyword=关键词`。

> 注意：在线站可能变更/限流，失效时优先部署 PanSou 自建，或改用下面的 TG 频道直搜。

---

## 搜索链路（按优先级）

### 第一步：GitHub 网盘搜索项目（PanHub 在线 API 或自建 PanSou）

### 第二步：并行搜索，多引擎组合

```bash
# 同时跑 SearXNG +  MiniMax，覆盖国内外资源
mcp_searxng_search("小猪佩奇 国语 百度网盘 4K 完整版")
mcp_minimax_plan_web_search("小猪佩奇 国语 百度网盘 完整 4K")
```

**关键词组合策略：**
- `pan.baidu.com OR yun.baidu.com` — 过滤出含真实网盘链接的结果（**最有效**）
- `site:pan.baidu.com` — 直接搜百度盘链接（有时有用）
- `百度网盘综合频道` / `bdwpzhpd` — 找 Telegram 百度盘频道
- `4K HQ 高码率` / `60FPS` / `DTS` / `杜比全景声` — 找顶配版本标注
- `文件名 提取码` — 同时找链接和密码
- 文件大小关键词：`18.4GB` / `22.9G` / `52GB` — 大文件通常是顶配

### 第二步：定位 Telegram 资源频道（最关键）

Telegram 上的资源频道是中文网盘链接的**最活跃来源**，比搜索引擎快、比论坛新。

重点频道：
- `t.me/s/bdwpzhpd` — 百度网盘综合频道（资源最全，更新快）
- `t.me/s/YioveComplex` — 综合资源分享（阿里/夸克/百度都有）
- `t.me/s/Aliyun_4K_Movies` — 阿里云盘4K资源（百度链接也常出现）
- `t.me/s/aliyun_4k_movies` — 同上（另一个频道）
- `t.me/s/vip115hot` — 115/阿里/百度影视综合

**搜索 Telegram 频道内具体资源：**
```
# 在 Telegram 页面用页面搜索功能搜标签
URL: https://t.me/s/bdwpzhpd?q=%23关键词
```

> **补充：** Telegram 上也有夸克网盘资源频道（如 `pan.quark.cn` 链接），可同时搜索 `quark.cn` 过滤夸克资源。

### 第三步：浏览论坛帖子提取真实链接

找到疑似链接后，去论坛帖子页用 browser 工具提取**实际百度链接 + 提取码**：

```javascript
// 在论坛页面控制台执行，提取所有百度/阿里链接
Array.from(document.querySelectorAll('a'))
  .map(a => a.href)
  .filter(h => h.includes('pan.baidu') || h.includes('aliyundrive') || h.includes('115.com'))
```

常见来源论坛：
- `kuafzys.cn` / `kuakezys.com` — 夸父资源论坛
- `gomicx.net` — 粤漫社（粤语/三语资源，质量高）
- `jixutao.com` / `moeduo.com` — 继续淘/磨耳朵英语（儿童资源）
- `jianshu.com` — 简书（百度贴吧转存，内容杂需甄别）
- `sdocapp.com` — 超文档（聚合资源站，常同时提供百度+夸克双平台链接）

> **实用经验：** 聚合资源站（超文档等）常同时列出百度网盘和夸克网盘两个链接，当百度网盘无法访问或速度慢时，夸克网盘可作为备选方案。

### 第四步：验证提取码一致性

同一资源在多个页面出现时，提取码应该一致。**不同来源但提取码相同**是资源真实可靠的强信号。

---

## 「最顶配」版本识别标准

| 指标 | 顶配标志 | 凑合版本标志 |
|------|---------|------------|
| 文件大小 | ≥15GB（剧集） | 1-3GB |
| 分辨率 | 4K / 2160p | 1080p 甚至 720p |
| 帧率 | 60fps | 30fps 或未标注 |
| 音轨 | DTS + 杜比全景声 / 杜比AC3 | 单音轨 |
| 音轨数 | 国粤英三语可选 | 仅单语 |
| 压制组 | HDHive / 知名压制组 | 佚名/未知 |
| 字幕 | 内嵌中英双语 | 无字幕或外挂 |

---

## 飞书链接显示问题

飞书 Markdown 渲染会拦截百度链接，导致用户看不到超链接。

**解决方案：** 给用户纯文本格式，链接单独一行，提取码单独标注：

```
百度链接：
https://pan.baidu.com/s/xxxxxxxxxxx
提取码：xxxx
```

---

## 输出格式规范

找到资源后，按以下结构输出：

```markdown
### ⭐ [资源名称] — [画质/规格]

| 项目 | 内容 |
|------|------|
| 画质 | [具体参数] |
| 大小 | [文件体积] |
| 集数 | [集数] |
| 配音/音轨 | [配音/音轨信息] |
| 百度链接 | `https://pan.baidu.com/s/xxxx` |
| 提取码 | `xxxx` |
| 夸克链接 | `https://pan.quark.cn/s/xxxx`（备选） |
| 来源 | [来源页面/频道] |
| 更新日期 | [日期] |

---

### 说明
- [版本对比/注意事项]
- [推荐版本]
```

---

## 参考文件

- `references/telegram-search-recipe.md` — Telegram 网盘资源实战搜索完整流程（已验证可行），含分步操作、链接提取方法、版本对比示例。

## 常见坑

1. **标注4K实际是1080P放大** — 看文件大小，<10GB的"4K"通常是假的
2. **同链接多版本混发** — 进入网盘后文件名会标注 HQ/WEB-DL 等，可选
3. **链接有提取码但文件被删** — 只能换来源，无法预判
4. **付费论坛 vs 免费资源** — 粤漫社等需要注册积分，但质量高；继续淘等付费资源站6-12元可买

---

## 相关 Skills

- `search-tool-fallback` — 搜索引擎切换策略
- `research-domain-fallback` — 站点访问失败时的 fallback
