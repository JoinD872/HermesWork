# Telegram 网盘资源搜索实战指南

> 来自 2026-05-27 搜索《菜肉馄饨》(Shanghai Wonton) 的完整实战记录

## 标准搜索链路（已验证可行）

### Step 1: SearXNG 快速定位
搜索词: `"片名 电影 百度网盘 下载"`
结果示例：返回电影简介（百度百科）+ 资源聚合站链接（如 panquduo.com）

### Step 2: 资源聚合站提取基本链接
资源聚合站（如 panquduo.com）通常提供百度+夸克双平台链接。
- 点击"百度网盘"按钮 → 浏览器跳转到百度盘分享页
- URL 中带 `surl=`（分享码）和 `pwd=`（提取码）
- 示例链接：`https://pan.baidu.com/share/init?surl=xxx&pwd=xxxx`
- 用 `browser_console('document.location.href')` 直接读取重定向后的URL

### Step 3: Telegram 频道找顶配版本（最关键）
URL 格式：`https://t.me/s/bdwpzhpd?q=%23片名`

Telegram Web 页面显示结果包含：
- 简介文字（剧情概要）
- 版本规格标注（如 `4K HQ 60FPS 高码率 DTS环绕声&杜比全景声 国沪双语 内嵌简中`）
- 文件大小（如 `22.9G` / `18.4GB`）
- 压制组（如 HDHive）
- 直达链接（a 标签，href 里是百度盘 URL）

### Step 4: 提取百度盘链接（关键技巧）
Telegram 页面的"直达链接"是 `<a>` 标签，但点击不会跳转（JS 行为）。
**正确的提取方式** — 用 browser_console 执行：
```javascript
document.querySelectorAll('a[href*="pan.baidu"]').forEach(a => console.log(a.href))
```

注意：同一URL可能在页面中出现两次（"直达链接" + "查看分享链接"），去重即可。

### Step 5: 版本对比选出顶配
TG频道常同时发布多个版本，对比参数选顶配：

| 对比项 | 标准版 | 顶配版 |
|--------|-------|-------|
| 规格标注 | `4K WEB-DL HQ DTS5.1` | `4K HQ 60FPS 高码率 DTS+杜比全景声` |
| 大小 | 18.4GB | 22.9G |
| 音轨 | 单DTS | DTS + 杜比全景声双轨 |
| 语言 | 单语 | 国沪双语 |

## 注意事项

1. **VPS 无法直接访问百度盘** — 从 VPS navigate 到 pan.baidu.com 会超时。链接直接给用户，用户自行在手机/桌面打开
2. **早期7天资源存活率最高** — Telegram 频道资源多为网友分享，文件可能被百度删除
3. **提取码在 URL 中** — 注意 `?pwd=xxxx` 参数，区分大小写
4. **夸克网盘备选** — 当百度盘链接失效时，同一聚合站常同时提供夸克链接
5. **资源聚合站 + Telegram 双源交叉验证** — 两处提取码一致则资源可靠
