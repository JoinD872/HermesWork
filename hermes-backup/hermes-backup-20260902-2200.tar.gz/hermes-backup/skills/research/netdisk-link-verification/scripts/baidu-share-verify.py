#!/usr/bin/env python3
"""百度盘分享链接 API 验证脚本 — 输入 surl+提取码，遍历输出文件列表。

用法:
    python3 baidu-share-verify.py <surl> <pwd>
    例: python3 baidu-share-verify.py orCJKA03PQ64q0xwItsJvA nric

2026-08-16 实测有效。流程:
  1. GET  /s/{surl} 拿 cookie + HTML（提取 shareid / share_uk）
  2. POST share/verify 提交提取码（errno==0 + randsk = 正确）
  3. shorturl list root=1 拿根目录（dir 参数被忽略，只对根有效）
  4. shareid+uk 老接口 + 完整 path 递归钻子目录（dir=/ 返回空，必须用完整路径）

版本判断: 文件名含 TC = 影院翻录枪版（即使标 1080P 也是枪版）。
院线期(<1月)新片全网只有 TC 版，真 4K 要等流媒体上线。
"""
import sys
import json
import time
import urllib.parse
import urllib.request
import http.cookiejar
import re


def fmt_size(sz):
    try:
        sz = int(sz)
        return '%.2f GB' % (sz / 1024**3) if sz > 1024**3 else '%d MB' % (sz // (1024 * 1024))
    except Exception:
        return str(sz)


def main(surl, pwd):
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36')]
    ref = 'https://pan.baidu.com/s/1%s' % surl

    # 1. 打开分享页
    r = opener.open(ref, timeout=20)
    html = r.read().decode('utf-8', 'ignore')
    m = re.search(r'"shareid"\s*:\s*"?(\d+)"?', html)
    m2 = re.search(r'share_uk:"(\d+)"', html)
    if not m or not m2:
        print('!! 无法提取 shareid/share_uk，链接可能已失效')
        return
    shareid, share_uk = m.group(1), m2.group(1)

    # 2. 提交提取码
    data = urllib.parse.urlencode({
        'pwd': pwd, 'vcode': '', 'vcode_str': '',
        'channel': 'chunlei', 'web': '1', 'app_id': '250528'
    }).encode()
    req = urllib.request.Request('https://pan.baidu.com/share/verify?surl=%s' % surl, data=data, method='POST')
    req.add_header('Referer', ref)
    req.add_header('Content-Type', 'application/x-www-form-urlencoded')
    vj = json.loads(opener.open(req, timeout=20).read().decode())
    if vj.get('errno') != 0:
        print('!! 提取码错误或链接失效: errno=%s %s' % (vj.get('errno'), vj.get('err_msg')))
        return
    print('✓ 提取码验证通过')

    # 3. shorturl 拿根目录
    ts = int(time.time())
    u = 'https://pan.baidu.com/share/list?app_id=250528&shorturl=%s&root=1&t=%d&channel=chunlei&web=1' % (surl, ts)
    req3 = urllib.request.Request(u)
    req3.add_header('Referer', ref)
    lj = json.loads(opener.open(req3, timeout=20).read().decode())

    # 4. 老接口递归（shorturl 接口忽略 dir 参数，必须用 shareid+uk + 完整 path）
    def list_old(path):
        ts = int(time.time())
        u = ('https://pan.baidu.com/share/list?shareid=%s&uk=%s&dir=%s&order=other&desc=1&showempty=0&web=1&page=1&num=100&t=%d&channel=chunlei&web=1&app_id=250528'
             % (shareid, share_uk, urllib.parse.quote(path, safe=''), ts))
        rq = urllib.request.Request(u)
        rq.add_header('Referer', ref)
        return json.loads(opener.open(rq, timeout=20).read().decode())

    seen = set()

    def walk(path, depth=0):
        if path in seen or depth > 4:
            return
        seen.add(path)
        lj = list_old(path)
        for f in lj.get('list', []):
            name = f.get('server_filename')
            size = fmt_size(f.get('size'))
            isdir = 'DIR' if str(f.get('isdir')) == '1' else 'file'
            print('  ' + '  ' * depth + '- %s | %s | %s' % (name, size, isdir))
            if str(f.get('isdir')) == '1' and f.get('path'):
                walk(f.get('path'), depth + 1)

    for f in lj.get('list', []):
        print('- %s | %s | %s' % (f.get('server_filename'), fmt_size(f.get('size')), 'DIR' if str(f.get('isdir')) == '1' else 'file'))
        if str(f.get('isdir')) == '1' and f.get('path'):
            walk(f.get('path'), 1)


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print('用法: python3 baidu-share-verify.py <surl> <pwd>')
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
