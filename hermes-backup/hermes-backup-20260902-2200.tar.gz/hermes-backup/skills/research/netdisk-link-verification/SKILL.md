---
name: netdisk-link-verification
description: 网盘分享链接 API 级验证 — 不打开页面就确认链接是否有效、提取码是否正确、实际文件内容与画质版本（识别 TC 枪版 vs 真 4K）。涵盖百度网盘 share API 三步验证流程、贴吧页面被风控时的替代路径、院线期新片版本判断规律
triggers:
  - 需要验证百度网盘链接是否有效 / 提取码是否正确
  - 搜索结果里一堆"4K完整版"标题，需要确认链接里实际是什么版本
  - 链接有提取码但不确定资源还在不在、内容是什么
  - 贴吧/B站页面从海外 VPS 抓不到，但 snippet 里有链接
risk: read-only
created: 2026-08-16
---

# 网盘链接 API 验证（不打开页面确认链接内容）

## 核心原则

> 帖子标题不可信——"4K完整版"营销帖 90% 是假的，实际是 TC 枪版。
> 必须进链接看**实际文件名 + 文件大小**，再判断版本。
> 网盘分享页有公开 API，不需要登录/打开页面就能遍历文件列表。

## 百度盘三步验证流程（2026-08-16 实测有效）

```
1. GET  https://pan.baidu.com/s/1{surl}          → 拿 cookie + 页面 HTML
2. POST https://pan.baidu.com/share/verify?surl={surl}
      body: pwd={提取码}&vcode=&vcode_str=&channel=chunlei&web=1&app_id=250528
      → errno==0 且返回 randsk = 提取码正确；errno!=0 = 提取码错/链接失效
3. GET  https://pan.baidu.com/share/list?app_id=250528&shorturl={surl}&root=1
      → 根目录文件列表
4. 钻子目录必须用老接口 + 完整路径：
   GET  https://pan.baidu.com/share/list?shareid={shareid}&uk={share_uk}&dir={完整路径}&order=other&web=1&app_id=250528
```

## 接口关键细节（踩坑记录）

| 坑 | 正确做法 |
|----|---------|
| `shareid` 提取 | 分享页 HTML 正则 `"shareid":"(\d+)"` |
| `share_uk` 提取 | 正则 `share_uk:"(\d+)"`——**不是** `uk:'0'`（那是登录态字段，恒为 0） |
| shorturl 接口 dir 参数 | **被忽略**——只对根目录有效；递归子目录返回同一个目录（fs_id 相同） |
| 老接口 dir=/ | 返回空列表——必须先 shorturl root=1 拿根目录，取 path 字段再老接口递归 |
| 目录 path | 带虚拟前缀 `/888888888888888888888888888/...`，递归时原样传回 |
| cookie | 验证通过后 cookie 带 randsk；后续请求必须带 `Referer: https://pan.baidu.com/s/1{surl}` |
| 反爬 | 302 到 /share/init 是正常流程，不是失效；`<title>百度网盘 请输入提取码</title>` 表示分享存在只是要密码 |

## 版本判断（识别枪版）

- 文件名含 `TC` = 影院翻录枪版——即使标 1080P、8.6GB 也是枪版（画面偏暗/环境噪音）
- 院线上映 <1 月的新片：**全网只有 TC 版**，真 4K/蓝光/WEB-DL 要等流媒体上线（通常 2-6 个月）
- 多个贴吧帖子"4K完整版"验证后可能是**同一个 TC 文件**（同源营销帖，链接不同内容相同）
- <10GB 的"4K"基本是拉伸假 4K

## 贴吧等论坛页面被风控的替代路径

VPS 直连贴吧 403/超时、浏览器导航也超时时：
1. **SearXNG 搜 `"片名" 百度网盘 链接 提取码`**——结果 snippet 里直接含完整链接+提取码（如 `链接:https://pan.baidu.com/s/1xxxx?pwd=1314 提取码:1314`），不需要打开贴吧页面
2. 拿到链接后用上面的 API 流程验证
3. r.jina.ai 阅读代理需 API key（401），不免费

## 完整脚本

`scripts/baidu-share-verify.py` — 输入 surl+提取码，自动遍历输出文件列表（用法: `python3 baidu-share-verify.py <surl> <pwd>`）

## 相关技能（注意重叠）

- `chinese-cloud-resource-search` — 网盘资源**搜索**方法论（找链接），本技能负责**验证**拿到的链接
- `netdisk-aggregator-search` — PanHub/PanSou 聚合搜索 API，搜索链路的第一入口
- 三者互补：搜到链接 → 本技能验证内容 → 按版本标准交付
