---
name: github-pan-search-apis
description: 用 GitHub 网盘聚合搜索项目（PanHub/PanSou 等）找百度/阿里/夸克/UC/迅雷网盘资源——绕过 VPS 数据中心 IP 被搜索引擎 CAPTCHA 封锁的问题。当 Google/Bing/搜狗等全部被拦截时使用。
triggers:
  - 找中文网盘/影视/短剧资源时搜索引擎全部被验证码拦截
  - 需要搜索百度网盘/夸克/阿里云盘资源但 VPS IP 被搜索引擎风控
  - 想自建网盘搜索服务
risk: read-only
---

# GitHub 网盘聚合搜索 API（绕过搜索引擎风控）

## 何时用

从 VPS（数据中心 IP）发起搜索时，Google/Bing/DuckDuckGo/Yandex/百度/搜狗**几乎全触发 CAPTCHA**，SearXNG 也可能返回空；搜狗偶尔第一次能通、第二次必被限流。此时不要死磕搜索引擎，改用 GitHub 上的网盘聚合搜索项目——它们爬的是 TG 频道和插件，**不依赖搜索引擎**，VPS 可直连。

## PanHub 在线 API（最快，免部署、免 key）

```bash
curl -sL "https://panhub.shenzjd.com/api/search?kw=功夫女足" -H "User-Agent: Mozilla/5.0"
```

响应结构：
```json
{"code":0,"message":"success","data":{"total":10,"merged_by_type":{
  "quark":[{"url":"https://pan.quark.cn/s/xxx","password":"","note":"...","datetime":"..."}],
  "baidu":[{"url":"https://pan.baidu.com/s/xxx?pwd=y2wt","password":"","note":"...","datetime":"..."}],
  "aliyun":[{"url":"https://www.alipan.com/s/xxx","password":"","note":"...","datetime":"..."}],
  "uc":[...], "xunlei":[...]}}}
```

要点：
- 参数名是 **kw**，不是 keyword（用 keyword 会返回 `kw is required`）
- 结果按网盘类型分组（merged_by_type），url 常直接带 `?pwd=提取码`
- 聚合 80+ TG 频道 + 20+ 插件；单条 note 可能把多个网盘链接拼在一起，需自行切分
- code=0 即成功；total 为命中数

## PanSou（自部署 API，⭐14k）

- 仓库：`fish2018/pansou`
- 纯后端 API：`docker run -d --name pansou -p 8888:8888 ghcr.io/fish2018/pansou:latest`
- 前后端集成版：`docker run -d --name pansou -p 80:80 ghcr.io/fish2018/pansou-web`
- 支持网盘类型：baidu/aliyun/quark/guangya/tianyi/uc/mobile/115/pikpak/xunlei/123/magnet/ed2k
- 环境变量：`CHANNELS`（默认 tgsearchers3）、访问 TG 受限地区需 `PROXY=socks5://...`、可选 JWT 认证（`AUTH_ENABLED`）

## 其他同类项目

- `wu529778790/panhub.shenzjd.com` — PanHub 本体，在线站 panhub.shenzjd.com，可 Vercel/CF Workers/Docker 部署
- `Xwudao/lzpan_search`（⭐628）— 懒盘搜索，短剧网盘搜索
- `towelong/panxiaozi`（⭐248）— 盘小子
- `675061370/xinyue-search`（⭐558）— 心悦搜索

## 验证与交叉检查

1. 先跑 PanHub API 拿初步结果
2. 再用 Telegram 频道公开页（`t.me/s/频道?q=关键词`）交叉验证提取码一致性
3. 新上映影视：聚合搜索通常只有 TC/HDTC 枪版或同名短剧，高清（WEB-DL/BD）要等院线结束 + 流媒体上线（2-6 个月）——这是行业规律，不是漏搜

## 常见坑

- 搜索引擎从 VPS 访问必被 CAPTCHA，别浪费时间重试
- GitHub API 搜索中文/含 + 号的组合查询易失败：用 `urllib.parse.quote` 编码整个 query，而不是手拼 + 号
- PanHub 的 note 字段可能把多个网盘链接拼接在一条里（百度+夸克+UC+迅雷），要解析出全部
- 相同链接重复出现（多个频道源）是正常现象，去重即可

## 相关

- `chinese-cloud-resource-search`（Telegram 频道/论坛路线、顶配版本识别标准、飞书链接输出格式）——本技能是其"搜索引擎被风控"时的首选替代路径；两者应最终合并进同一伞形技能
