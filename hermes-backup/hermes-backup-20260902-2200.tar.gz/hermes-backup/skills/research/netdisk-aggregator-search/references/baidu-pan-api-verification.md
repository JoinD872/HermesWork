# 百度网盘分享链接 API 验证流程（2026-08-16 实测）

无需登录、无需浏览器，纯 Python urllib + cookie jar 即可验证分享链接有效性并遍历文件内容（拿到真实文件名/大小/目录结构）。用于：链接是否失效、提取码是否正确、实际画质标注（不信帖子标题）。

## 流程

### 1. 打开分享页拿 shareid / share_uk
```
GET https://pan.baidu.com/s/1{surl}
```
- 正常返回 302 → `/share/init?surl=...` → 200 页面标题"百度网盘 请输入提取码"（链接存在）
- 从 HTML 提取 JS 变量（正则）：
  - shareid: `"shareid"\s*:\s*"?(\d+)"?`
  - **share_uk**: `share_uk:"(\d+)"` —— 注意页面里还有个 `uk:'0'`（未登录态），不能用！必须用 share_uk
- 分享被删则页面提示"分享的文件已经被删除"之类，无 shareid

### 2. 提交提取码
```
POST https://pan.baidu.com/share/verify?surl={surl}
body (form): pwd={提取码}&vcode=&vcode_str=&channel=chunlei&web=1&app_id=250528
headers: Referer: https://pan.baidu.com/s/1{surl}, Content-Type: application/x-www-form-urlencoded
```
- 响应 `{"errno": 0, "randsk": "..."}` 表示提取码正确；errno=105 之类为错误
- 必须复用同一 cookie jar（randsk 靠 cookie 传递）

### 3. 列文件（关键：两种接口分工）
- **shorturl 接口 —— 只能看根目录**：
  ```
  GET https://pan.baidu.com/share/list?app_id=250528&shorturl={surl}&root=1&t={ts}&channel=chunlei&web=1
  ```
  `root=1` 返回根目录；**dir 参数会被忽略**（传任何路径都返回同一层），不要用它递归。

- **老接口 —— 钻子目录（必须完整路径）**：
  ```
  GET https://pan.baidu.com/share/list?shareid={shareid}&uk={share_uk}&dir={完整路径}&order=other&desc=1&showempty=0&web=1&page=1&num=100&t={ts}&channel=chunlei&web=1&app_id=250528
  ```
  - dir 必须是 share/list 返回的 `path` 字段（完整路径，含虚拟前缀如 `/888888888888888888888888888/`）
  - **dir=/ 返回空列表**（不是失效，是参数不合法），必须传完整路径
  - dir 参数 URL 编码用 `urllib.parse.quote(path, safe='')`（连 '/' 一起编码，避免解析截断）

推荐组合：shorturl root=1 拿根目录 → 对每个目录用老接口+完整 path 递归（记得去重 seen 集合防环）。

## 坑
1. `uk` 正则会匹配到 `'0'`（未登录态值），必须用 `share_uk`
2. shorturl 接口 dir 无效 —— 只看 root=1 结果
3. 老接口 dir=/ 返回空 —— 换完整路径再试，别误判为失效
4. 文件 size 字段可能是字符串，`int()` 后再换算 GB
5. 多个分享链接可复用同一脚本批量验证（贴吧营销帖场景）
