# RSSHub 公共实例 — 零成本绕行被封锁的国内站（实测 2026-08-02）

## 适用场景

VPS 直连国内站返回 000/403 时（如豆瓣、微博 API），RSSHub 公共实例是**零部署零成本**的替代通道：
公共实例部署在第三方服务器，出口 IP 不同，绕开 VPS 数据中心 IP 封锁。curl 即可用，无需装任何东西。

> ⚠️ **连通状态是动态快照，不是永久事实**：本文件所有实测数据均标注日期。数据中心 IP 随时可能被重新拉黑（2026-08-02 实测大部分国内站网络层已恢复，但豆瓣仍 5 连断 000），公共实例也会限流/关闭。**每次任务前先 curl 重测，别拿旧结论当现状**——直连 200 就不用绕行，直连 000 再走 RSSHub。

## 可用实例（2026-08-02 实测）

| 实例 | 首页 | 豆瓣 route | 微博 route | 备注 |
|------|------|-----------|-----------|------|
| rsshub.ktachibana.party | ✅ 200 | ✅ 200 | ❌ 503 | **首选，豆瓣内容完整** |
| rsshub.rssforever.com | ✅ 200 | ❌ 503 | ❌ 503 | 备用 |
| hub.slarker.me | ✅ 200 | ❌ 503 | ❌ 503 | 备用 |
| rsshub.woodland.cafe | ✅ 200 | - | - | 未深测 |
| rsshub.app | ❌ 403 | - | - | 官方实例对 VPS 403 |
| rsshub.pseudoyu.com / shab.fun / tangwudi.com / feeded.xyz | ❌ 000 | - | - | 不可达 |
| rsshub.rss-all.top | ❌ 404 | - | - | - |
| rsshub.vercel.app | ❌ 402 | - | - | - |

## 已验证可用的豆瓣 route（ktachibana）

```bash
# 正在上映电影（返回完整 RSS XML，含评分/片长/导演/主演/封面）
curl -s -A "Mozilla/5.0" "https://rsshub.ktachibana.party/douban/movie/playing"
# 最新图书
curl -s -A "Mozilla/5.0" "https://rsshub.ktachibana.party/douban/book/latest"
```

实测内容（真实返回）：
> 蜘蛛侠：崭新之日 7.8分 145分钟 汤姆·霍兰德主演 | 八仙！8.2分 144分钟 中国大陆

## 已知不可用 route

- `weibo/*` — 公共实例全部 503（微博反爬严格，公共实例被限制）
- `zhihu/hotlist`、`bilibili/hot-search`、`jianshu/trending/weekly` — 429 限流（注意：知乎/B站 VPS 直连本来就通，无需绕行）

## 坑与注意事项

1. **429 = 限流**（公共实例被滥用保护），等一会或换实例；**503 = 该 route 在实例上不可用**
2. **公共实例不稳定**：会限流/关闭/加验证，任务前先 curl 测首页 200 再用
3. 数据来自 RSSHub 抓取，时效比直连略延迟（ttl=5 分钟级）
4. 输出是标准 RSS XML，可管道给 feedparser / python xml 解析
5. 只适合**读内容**；写操作（登录/评论/点赞）不可能走公共实例

## 延伸：GitHub 上的零成本方案（调研结论）

| 方案 | 成本 | 适用 | 备注 |
|------|------|------|------|
| RSSHub 公共实例 | 免费 | 被封锁站的读内容 | 本文件主推，已验证 |
| Cloudflare Workers 反代（QImageLab/cf-proxy 186★、Mikotwa/reverse-proxy-cf 39★） | 免费（10万请求/天） | 私有稳定通道 | 需 CF 账号，部署即用 |
| GitHub Actions 跑爬虫（公开仓库 2000 分钟/月） | 免费 | 定时抓取 | Actions 出口 IP 是 GitHub 的 |
| 知乎官方 API（ZHIHU_ACCESS_SECRET 已配置） | 免费（1000次/天） | 知乎搜索 | 无需绕行 |
| PanHub 网盘聚合 | 免费 | 网盘资源 | 见 SKILL.md 主文 |
