---
name: game-build-guide
description: Research and author comprehensive build guides for games with frequent meta/balance changes (e.g. Path of Exile 2). Involves patch-note research, mechanic deep-dives, Codex collaboration for accuracy, Chinese translation handling, and structured output.
version: 1.0.0
risk: write-safe
---

# Game Build Guide Authoring Workflow

Research and produce well-structured build guides for games that undergo frequent balance patches.

## 🔬 Phase 1: Research Stack

When asked about a game with frequent patches:

1. **Search current patch notes first** — game builds are time-sensitive. Check the latest patch version, find patch notes, understand what changed.
2. **Identify key mechanics** — what the build revolves around, how it scales, what was buffed/nerfed in current patch.
3. **Gather skill/talent/gear data** — use game wikis (poe2db.tw, poe2wiki.net) for raw numbers. Do NOT guess numbers from general knowledge.
4. **Check community sources** — Reddit build subs, Mobalytics/Maxroll guides, Chinese gaming sites (游民星空, 17173, 九游) for established builds.

## 🤝 Phase 2: Codex Collaboration

When the user says your analysis isn't good enough, OR when the topic requires domain depth you're uncertain about:

1. **Stop iterating alone.** Do NOT try to fix it yourself first — the user's signal is clear: delegate immediately.
2. **Gather all context** you already have (user's build, their complaints, patch data, game mechanics) into a comprehensive prompt.
3. **Send to Codex** with all context, asking it to fact-check, fill gaps, and provide practical recommendations.
4. **Let Codex do a fresh deep dive** — it has access to GPT-5.5's game knowledge which may be more current than yours.
5. **Merge insights.** Read Codex's output carefully. It will catch errors in your assumptions (wrong skill scaling formulas, incorrect node effects, outdated patch info).
6. **Iterate once.** If Codex had major corrections, write the revised version yourself with those corrections applied, then optionally send back for a final check.

## 🌐 Phase 3: Chinese Translation

For Chinese-language game content (PoE2 international server with Chinese UI):

1. **All skill/item/passive names must use official international version Chinese translations.** Reference poe2db.tw (Traditional Chinese = international version) for accurate names.
2. **Format:** `中文名（English）` on first mention, then just `中文名` thereafter.
3. **If the user asks for pure Chinese** — strip ALL English. Remove parenthetical English annotations. Keep only: inc/more (game shorthand), roman numerals in gem names (流血 III).
4. **Common PoE2 Chinese translations:**
   - 震地 (not 地震) = Earthquake
   - 拾荒者护板 (not 掠夺板甲) = Scavenged Plating
   - 重盾冲锋 (not 盾冲) = Shield Charge
   - 野性残暴 (not 残暴) = Brutality
   - 物理专精 (not 物理掌握) = Physical Mastery
   - 雷里的训练 (not 伦利的训练) = Renly's Training
   - 守护者核心 (not 核心守卫) = Core of the Guardian
   - 掩护护罩 (not 覆盖守卫) = Covering Ward
   - 广阔屏障 (not 宽阔壁垒) = Wide Barrier
   - 高耸盾牌 (not 壁垒盾墙) = Towering Shield
   - 持续时间压缩 (not 压缩持续时间) = Compressed Duration
   - 战争铁拳 (not 战争之拳) = Fist of War
   - 势大力沉 (not 重击) = Heft
   - 护甲破坏 (not 护甲爆破) = Armour Break
   - 延长持续时间 (not 持久) = Prolonged Duration
   - 不懈 (not 气势) = Tireless
   - 裂地战吼 (not 地震战吼) = Seismic Cry

## 📝 Phase 4: Formatting & Delivery

1. **Structure:** Tables for comparisons, code blocks for setups, emoji headings for visual hierarchy, bullet lists for details.
2. **Practice table format:** skill → supports → explanation; phase → goal → gear; node → effect → priority.
3. **Include a "常见错误" (Common Mistakes) section** — user appreciates knowing what NOT to do.
4. **Delivery:** For complex multi-section guides → upload to Google Drive (rclone copy to mydrive:) as `.md` file. For quick tips → send directly in chat.

## 🎯 Key Signals That Trigger This Skill

- User asks about a build/class/spec for a game with balance patches
- User mentions specific game mechanics or patch version numbers
- User says your analysis "不好" / "不够好" / "不对" about game content
- User asks for practical, actionable gameplay advice
