# PoE2 国际服中文名速查表（vs 常见错误译名）

从2026-05-31游戏攻略制作会话中整理的翻译对照。国际服中文以poe2db.tw（台服/国际版）为准。

## 技能宝石

| English | 国际服官中 | ❌ 常见错误 |
|---------|-----------|-----------|
| Earthquake | 震地 | 地震 |
| Scavenged Plating | 拾荒者护板 | 掠夺板甲 |
| Shield Charge | 重盾冲锋 | 盾冲 |
| Brutality | 野性残暴 | 残暴 |
| Physical Mastery | 物理专精 | 物理掌握 |
| Compressed Duration | 持续时间压缩 | 压缩持续时间 |
| Fist of War | 战争铁拳 | 战争之拳 |
| Heft | 势大力沉 | 重击/分量 |
| Armour Break | 护甲破坏 | 护甲爆破 |
| Armour Explosion | 护甲爆破 | 护甲爆炸 |
| Prolonged Duration | 延长持续时间 | 持久 |
| Tireless | 不懈 | 气势 |
| Seismic Cry | 裂地战吼 | 地震战吼 |
| Bleed III | 流血 III | — |
| Thornskin | 荆棘之皮 | 荆棘皮肤 |
| Magnified Area | 范围扩大 | — |
| Astral Projection | 星界投射 | — |
| Cool Headed | 冷静 | 冷静头脑 |
| Herbalism | 药草学 | — |
| Vitality | 活力 | — |
| Heavy Swing | 沉重挥击 | — |

## 升华与天赋

| English | 国际服官中 | ❌ 常见错误 |
|---------|-----------|-----------|
| Renly's Training | 雷里的训练 | 伦利的训练 |
| Turtle Charm | 龟甲护符 | — |
| Jade Heritage | 翡翠传承 | — |
| Warcaller's Bellow | 战吼者之咆哮 | 战吼者之吼 |
| Anvil's Weight | 铁砧之重 | — |
| Imploding Impacts | 内爆冲击 | — |
| Core of the Guardian | 守护者核心 | 核心守卫 |
| Covering Ward | 掩护护罩 | 覆盖守卫 |
| Wide Barrier | 广阔屏障 | 宽阔壁垒 |
| Towering Shield | 高耸盾牌 | 壁垒盾墙 |

## 精魄技能

| English | 国际服官中 | 精魄占用 |
|---------|-----------|---------|
| Iron Ward | 钢铁守护 | 30 |
| Scavenged Plating | 拾荒者护板 | 30 |
| Magma Barrier | 熔岩屏障 | 30 |
| Encase in Jade | 翡翠护体 | 30 |

## 暗金装备

| English | 国际服官中 | 类型 |
|---------|-----------|------|
| Oaksworn | 橡木誓言 | 盾牌 |
| Doomgate | 末日之门 | 盾牌 |
| Feathered Fortress | 羽盾堡垒 | 盾牌 |
| Svalinn | 斯瓦林 | 盾牌 |
| The Surrender | 降服 | 盾牌 |
| Belly of the Beast | 兽腹 | 胸甲 |
| The Brass Dome | 青铜之顶 | 胸甲 |
| Kaom's Heart | 卡欧之心 | 胸甲 |
| The Rat Cage | 鼠笼 | 胸甲 |
