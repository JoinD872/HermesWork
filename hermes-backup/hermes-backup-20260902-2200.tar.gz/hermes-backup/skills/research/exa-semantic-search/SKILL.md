---
name: exa-semantic-search
description: Exa AI 语义搜索引擎 — 通过 mcporter 调用 Exa MCP 实现全网语义搜索和网页内容读取。免费、免 API Key、比传统关键词搜索强一档。
risk: write-safe
version: 1.0.1
created: 2026-07-13
---

# Exa 语义搜索

## 概述

Exa (exa.ai) 是一个 AI 原生的语义搜索引擎，通过 MCP 协议接入。装好即用（免费，无需 API Key），适合做深度调研、技术趋势分析等场景。

**优势**：
- 语义搜索而非关键词匹配 — 搜"最新的 LLM 微调方法对比"能直接命中高质量文章
- 返回清洗后的文本内容（+ Highlights），不是一堆 HTML 标签
- 支持网页全文读取（web_fetch），替代 Jina Reader
- 免费、无速率限制（合理使用范围内）

## 前置条件

- `mcporter` 已安装（`npm install -g mcporter`）
- Exa MCP server 配置在 `/root/config/mcporter.json`：
  ```json
  {"mcpServers": {"exa": {"baseUrl": "https://mcp.exa.ai/mcp"}}}
  ```

## 可用工具

### 1. web_search_exa — 全网语义搜索

搜索任何话题，返回清洗后的内容摘要。

```bash
# 语法：mcporter call exa.web_search_exa key=value key=value
mcporter call exa.web_search_exa query="AI agent framework comparison 2025" numResults=3
```

**参数**：
| 参数 | 必填 | 说明 |
|------|:----:|------|
| `query` | ✅ | 自然语言搜索词。描述理想页面，不是关键词。"comparing React and Vue performance" 而非 "React vs Vue" |
| `numResults` | ❌ | 返回结果数，默认 10 |

**高级查询**：
- `category:people` — 搜索 LinkedIn 人物
- `category:company` — 搜索公司

**坑点**：
- ❌ 不要用 JSON 格式传参：`'{"query":"..."}'` → mcporter 返回 validation error
- ✅ 必须用 `key=value` 格式：`query="自然语言描述" numResults=5`

### 2. web_fetch_exa — 读取指定 URL 内容

读取一个或多个 URL，返回清洗后的 Markdown 内容。

```bash
# 单 URL
mcporter call exa.web_fetch_exa urls='["https://github.com/NanmiCoder/MediaCrawler"]' maxCharacters=2000

# 多 URL
mcporter call exa.web_fetch_exa urls='["https://example.com","https://example.org"]' maxCharacters=3000
```

**参数**：
| 参数 | 必填 | 说明 |
|------|:----:|------|
| `urls` | ✅ | URL 数组，用 JSON 数组格式传入 |
| `maxCharacters` | ❌ | 每页最大字符数，默认 3000 |

**坑点**：
- `urls` 参数需要用 JSON 数组字面量：`'["url1","url2"]'`（注意外层的单引号和内层的双引号）

## 典型使用场景

### 调研/竞品分析
```bash
mcporter call exa.web_search_exa query="best open source AI agent framework 2026 production" numResults=5
```

### 跟踪最新动态
```bash
mcporter call exa.web_search_exa query="LLM fine tuning techniques 2026 comparison QLoRA vs LoRA" numResults=3
```

### 从搜索结果继续深入
先用 web_search_exa 找到相关文章 URL，再用 web_fetch_exa 读全文。

## VPS 兼容性

Exa 的 MCP 服务不依赖 VPS 出口 IP 声誉（和 Jina Reader 不同），在 VPS 上工作正常。已验证可在 192.3.241.244 稳定使用。

## 搜索结果落盘

调研结果默认只留在对话历史里。**结束调研后，有价值的结论应归档到 Vault：**

```
# 1. 用 web_search_exa / web_fetch_exa 收集信息
# 2. 整合成笔记（标题 + 背景 + 结论 + 详情 + 参考来源）
# 3. 写进 Vault:
#    - 10_文献笔记/  ← 技术调研/工具评估
#    - 40_复盘归档/  ← 系统改动/排查复盘
#    - 00_收件箱-AI/ ← 草稿/待整理的
# 4. 前端加 YAML frontmatter: title/date/source/tags/status
```

**原则：** 让下次能用上，不留在对话里腐烂。

## 与其他搜索的定位

| 工具 | 方式 | 适合场景 |
|------|------|---------|
| **Exa** | AI 语义搜索 | 深度调研、技术趋势、论文/文章发现 |
| **SearXNG** | 传统关键词搜索 | 快速查特定信息、国内站内容 |
| **知乎 API** | 中文站内搜索 | 知乎专属内容 |
| **Google/Bing** | 综合搜索 | 兜底 |
