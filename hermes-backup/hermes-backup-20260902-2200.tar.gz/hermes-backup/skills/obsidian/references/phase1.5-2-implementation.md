# Obsidian Vault Phase 1.5 + Phase 2 实施记录

> 2026-05-23 实施 | 参考：knowledge-base/SKILL.md

## 概述

Phase 1.5 和 Phase 2 在一天内实施完成。核心链路：

```
用户手机/PC写入
  ↓
HermesInbox (Drive)     ← 用户丢灵感的地方（Google Docs / 文件）
  │
  ├─→ pull_cloud_inbox.sh (每30min) → 00_收件箱-人工/  ← Phase 1.5
  │
  ├─→ vault_ingest.py (每2h)        → 10_文献笔记/ / 40_复盘归档/  ← Phase 2
  │
  ├─→ sync_vault_to_drive.sh (每30min) → Google Drive (用户Obsidian仓库)
  │
  └─→ pull_user_notes.sh (每30min)   → inbound/user-notes/  ← 反向，读用户笔记
```

## Phase 1.5 — Cloud Inbox

### 文件
- `~/.hermes/scripts/pull_cloud_inbox.sh`

### 机制
- `rclone move` 从 Google Drive 的 `HermesInbox` 文件夹拉取文件到 VPS 暂存区
- 支持 `.md` / `.txt` / `.gdoc`（Google Docs 自动导出为 Markdown）
- 暂存后添加 YAML frontmatter（created/source/status/promotion_required）→ 写入 `00_收件箱-人工/`
- 使用 `rclone move`（移动=删除 Drive 上的源文件，避免重复拉取）
- 无新文件时静默退出（不浪费 token）

### Cron
- `dbd469f40f54` — 每30分钟，no_agent=true
- Deliver: local（不打扰用户）

### 坑点修复
1. ❌ `--delete-empty-src-dirs` 导致 HermesInbox 目录被误删 → ✅ 去掉该参数
2. ❌ deliver 设为 origin 导致用户每次收到通知 → ✅ 改为 local
3. ❌ 脚本无判别逻辑，每次输出"nothing to transfer" → ✅ 加判别，新文件才输出

## Phase 2 — Vault 内容自动入库

### 文件
- `~/.hermes/scripts/vault_ingest.py`

### 功能
扫描两个来源，写入 Vault：

**来源 A：cron 输出**
- 扫描 `~/.hermes/cron/output/{job_id}/` 下的新 .md 文件
- 只处理有友好名称映射的活跃 cron job（每日早报、VPS巡检、备份、global_knowledge清理）
- 写入 `40_复盘归档/{date}-{name}.md`

**来源 B：联邦回执（小研的研究报告）**
- 扫描 `~/.hermes/federation/callbacks/` 下的新 .json 文件
- 根据 task_id 自动分类：research/health→`10_文献笔记`，log→`40_复盘归档`，其他→`00_收件箱-AI`
- 提取 summary + key_findings + action_items 写入结构化工笔记

### 状态追踪
- `~/.hermes/config/vault-ingest-state.json` — 记录已处理过的文件，避免重复入库

### Cron
- `0504bc83cd83` — 每2小时，no_agent=true
- 无新内容时零输出（零 token 消耗）

## Google Drive 双向同步

### VPS → Drive（正向）
- 文件：`~/.hermes/scripts/sync_vault_to_drive.sh`
- 每30分钟 `rclone copy` 整个 Vault 到用户指定的 Google Drive 文件夹
- 使用 `--drive-root-folder-id` 直接定位（用户 Drive 上具体的文件夹 ID）
- 使用 `copy` 而非 `sync`：**永不删除用户已有的笔记**
- 桌面端走 Google Drive Desktop → 用户 Windows Obsidian 自动同步

### Drive → VPS（反向，用于读取用户笔记）
- 文件：`~/.hermes/scripts/pull_user_notes.sh`
- 每30分钟 `rclone copy` 用户 Obsidian仓库 到 VPS 的 `inbound/user-notes/`
- 作为 `sync_vault_to_drive.sh` 的后半部分一起执行（同一 cron job）

### 关键参数
- `--size-only`：只比较文件大小和修改时间，比 `--checksum` 快得多
- `--timeout 120s`：处理 Tailscale relay 的延迟抖动
- `--drive-root-folder-id`：指定具体文件夹，不用路径名（避免中文编码问题）

### 日记系统（在 Vault 内）

模板：`模板/日记模板.md` — 极简格式，只有一个日期
```
---
title: "{{date}} 日记"
date: {{date}}
type: diary
status: draft
---

# {{date}}
```

- 文件：`~/.hermes/scripts/daily_diary.sh`
- 每天上海 08:00 创建 `日记/{date}-日记.md`（UTC 0:00）
- 同时检查前一天日记是否被填写：
  - 对比 `inbound/` 版（用户从 Windows 同步回来的）和 VPS 原版的大小
  - 如果 inbound 版更大 = 用户填了 → 保留
  - 否则 = 空模板 → 删除
- 日记 cron：`791b84ec0bde`，`0 0 * * *` UTC，no_agent=true
