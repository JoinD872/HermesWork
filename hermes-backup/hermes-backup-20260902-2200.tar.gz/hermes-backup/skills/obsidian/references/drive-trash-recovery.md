# Google Drive 回收站恢复指南

> rclone delete / rclone 删除的文件去哪里了？如何恢复？

## 核心事实

`rclone delete` 和 Google Drive API 的删除操作**默认移到回收站**，不是永久删除。Google Drive 回收站保留 30 天后自动清空。

## 检测

```bash
# 列出某个目录下所有已删除（回收站中）的文件
rclone ls "mydrive:path/" --drive-trashed-only --drive-root-folder-id "$FOLDER_ID"

# 文件大小含义
# -1   = Google Docs 原生格式（没有实际文件字节，只是占位符）
# >0   = 实际文件（图片、.md、.pdf 等），有真实内容
```

## 完全恢复

```bash
# 方法 1：untrash 后端命令（恢复目录及子内容）
rclone backend untrash "mydrive:directory" --drive-root-folder-id "$FOLDER_ID"

# 方法 2：直接从回收站 copy 到本地（不修改远程状态）
rclone copy "mydrive:path/to/file.md" /tmp/recovery/ \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-trashed-only
```

## 常见陷阱

### 1. 递归嵌套导致超时

当目录结构中有递归嵌套时（如 `日记MD/日记MD/日记MD/...`），`rclone ls --drive-trashed-only` 会因遍历整个嵌套树而超时。

**解法**：直接指定具体文件路径，不要通配整个目录。

```bash
# ❌ 超时：rclone ls "mydrive:日记/" --drive-trashed-only
# ✅ 可行：rclone copy "mydrive:日记/日记MD/文件.md" ... --drive-trashed-only
```

### 2. 回收站有多份同名文件

每次 `rclone copy --drive-import-formats md` 都会在回收站产生一条新记录（Google Doc 本体 + 导出副本）。同名文件需要逐个恢复，取字节最大的那个。

### 3. `rclone delete` vs `rclone purge`

| 命令 | 行为 | 可恢复？|
|------|------|---------|
| `rclone delete` | 移到回收站 | ✅ 30 天内可恢复 |
| `rclone purge` | 跳过回收站，永久删除 | ❌ 不可恢复 |
| `rclone deletefile` | 移到回收站 | ✅ 30 天内可恢复 |

始终优先用 `rclone delete` 而非 `purge`。
