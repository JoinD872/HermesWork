# 日记同步修复记录（2026-06-01）

## 问题现象
Google Drive 上日记文件全部消失，只剩一个空目录。VPS 本地的日记文件也没有同步到 Drive。

## 根因
`/root/.hermes/scripts/daily_diary.sh` 第83行用 `rclone copy` + `--drive-import-formats md` 尝试将 .md 上传为 Google Docs。但：
1. 转换可能超时或报错（timeout 90秒不够）
2. `|| true` 吞掉了所有错误信息
3. Google Drive 上 `日记/2026-06/` 子目录从未被成功创建

同时第67行清理空日记时，也找不到 Drive 上的文件（因为从未上传成功）。

## 修复方案
去掉 Google Docs 转换，直接上传 .md 文件到 Drive。手机上用 Google Drive App 可以直接打开和编辑 .md 文件。

```bash
# 改前（第83行）：
timeout 90 rclone copy "$TODAY_FILE" "mydrive:$DIARY_SUB/$MONTH_DIR/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-import-formats md \
  -q 2>&1 || true

# 改后：
rclone copy "$TODAY_FILE" "mydrive:$DIARY_SUB/$MONTH_DIR/" \
  --drive-root-folder-id "$FOLDER_ID" \
  -q 2>&1
```

关键改动：
- 去掉 `--drive-import-formats md`（不再转 Google Docs）
- 去掉 `timeout 90`（默认超时够了）
- 去掉 `|| true`（让错误能暴露出来）
