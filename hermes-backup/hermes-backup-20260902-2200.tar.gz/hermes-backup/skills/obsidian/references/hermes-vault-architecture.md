# Hermes × Obsidian Vault 架构（2026-05-23 定稿）

## 架构原则

- **单主库多入口**：VPS 上只有一个 canonical Vault，所有写入走 VPS
- **单一写入者**：正式知识区只允许小H通过白名单写入，其他端通过 Cloud Inbox 投递
- **草稿统一收件箱**：需要人工确认的内容统一写到 `00_收件箱-AI/`，frontmatter 标注 `target_dir` 和 `status: draft`
- **最小闭环**：先跑通 Vault 本体（目录 + 模板 + 写入 + 备份），再加同步和管道

## 最终目录结构

```
~/.hermes/ObsidianVault/
├── 00_收件箱-AI/          # 小H自动写入，也放草稿（frontmatter标注target_dir）
├── 00_收件箱-人工/        # Cloud Inbox 回拉，人工投递的原始素材
├── 10_文献笔记/           # 小研研究报告、外部资料摘要、早报提炼 → 自动写
├── 20_项目文档/           # 项目文档 → 仅出草稿，人工确认
├── 30_永久笔记/           # 长期复用知识 → 仅出草稿，人工晋升
├── 40_复盘归档/           # 排障/复盘/cron callback → 自动写
├── 50_Hermes架构/         # Agent 分工/路由规则 → 仅出草稿
├── 灵感创意/              # 玩法/技能创意 → 仅出草稿
└── 模板/                  # 固定模板，手写不动
```

## 写入权限矩阵

| 目录 | 自动写 | 出草稿 | 备注 |
|------|:-----:|:------:|------|
| `00_收件箱-AI/` | ✅ | — | 最活跃目录，草稿和自动笔记都放这里 |
| `00_收件箱-人工/` | ✅ 仅拉取整理 | — | Cloud Inbox 回拉的目标 |
| `10_文献笔记/` | ✅ | — | 小研、小H都可自动写 |
| `40_复盘归档/` | ✅ | — | callback 提取 + 手工复盘 |
| `20_项目文档/` | ❌ | ✅ | 写入收件箱-AI，promote 时手工移入 |
| `30_永久笔记/` | ❌ | ✅ | 同上 |
| `50_Hermes架构/` | ❌ | ✅ | 同上 |
| `灵感创意/` | ❌ | ✅ | 同上 |
| `模板/` | ✅ | — | 固定资源，一般不改 |

草稿统一写 `00_收件箱-AI/`，frontmatter 包含：
```yaml
status: draft
target_dir: "灵感创意"
promotion_required: true
```

## Phase 2 — Vault Ingest Pipeline（vault_ingest.py）

不再依赖 callback meta 字段。改为 `vault_ingest.py` 统一扫描：
- **cron 输出目录** `~/.hermes/cron/output/` → 定期早报/巡检自动归档到 `40_复盘归档/`
- **federation 回执** `~/.hermes/federation/callbacks/` → 根据 task_id 前缀自动路由：
  - MINIMAX/PAIN/RESEARCH/UE5 → `10_文献笔记/`
  - PATROL → `40_复盘归档/`
  - 其他 → `00_收件箱-AI/`

脚本用状态跟踪 `vault-ingest-state.json`，无新增时零输出、零 token。每 2 小时运行一次（no_agent cron）。

## Phase 2b — Windows 桌面同步

VPS → Windows 单向同步，每 30 分钟通过 rclone SFTP 推送到：
`E:\Obsidian\HermesObsidian\`

用户在该目录打开 Obsidian，内容与小H的 Vault 完全一致。

脚本：`~/.hermes/scripts/sync_vault_to_windows.sh`
- 桌面离线时（ping 不通）静默退出，不报错
- `--size-only` 加速 Tailscale relay 同步
- no_agent cron，零 token

## 输出标准化

每条 Markdown 文档包含：
```markdown
---
title: "标题"
date: YYYY-MM-DD
source: "Chat / Web / GitHub / PDF / 其他"
tags: [#Hermes, #UE5, #复盘]
type: recap | literature | inbox
status: completed | draft | processed
---

# 标题

（正文）

---
双链候选：
- [[相关文档1]]
- [[相关文档2]]
标签：#Hermes #UE5
```

## 已知限制与边界

- **同步是单向的**（VPS → Windows），Windows 编辑不会回流
- **Windows 同步依赖桌面开机**，关机时静默跳过
- **vault_ingest 只处理 status: "done" 的回执**
- **回执必须有 summary 字段**，否则无法写入
