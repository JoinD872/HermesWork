# 无头服务器 rclone Google Drive OAuth 授权方法

> 记录时间：2026-05-23
> 状态：已验证可用，但本项目的 Google Drive 集成已搁置
> 场景：在无浏览器 VPS 上让用户通过自己的浏览器完成 Google OAuth 授权

## 问题

`rclone authorize "drive"` 默认监听 `127.0.0.1:53682`，Google OAuth 回调也指向这个地址。用户从外部浏览器访问不到 VPS 的 localhost。

## 解决方案：socat + UFW 端口转发

```bash
# 1. 启动 rclone OAuth 服务器
rclone authorize "drive" > /tmp/rclone_auth.log 2>&1 &

# 2. 用 socat 将公网端口转发到 rclone（不能用同一端口，会冲突）
socat TCP-LISTEN:53683,reuseaddr,fork TCP:127.0.0.1:53682 &

# 3. 开放防火墙端口
ufw allow 53683/tcp comment "rclone OAuth temp"

# 4. 获取授权 URL
cat /tmp/rclone_auth.log
# → http://127.0.0.1:53682/auth?state=xxxxx

# 5. 给用户：将 127.0.0.1:53682 替换为 VPS_IP:53683
#    用户访问此链接 → Google 登录 → 授权

# 6. Google 授权后会重定向到 http://127.0.0.1:53682/auth?code=...
#    用户需要手动将 127.0.0.1:53682 改为 VPS_IP:53683 → 回车
#    rclone 收到回调 → 显示 "Success!"

# 7. 验证
rclone ls mydrive:
```

## 清理

```bash
pkill -f "rclone authorize"
pkill -f "socat.*53683"
rm -rf /root/.config/rclone
ufw delete allow 53683/tcp
```

## 为什么不用 iptables DNAT

iptables DNAT 理论上可以，但 VPS 的 INPUT 策略默认 DROP + 反向路径问题，不如 socat 可控。

## 为什么不用 rclone headless 模式

rclone headless 模式要求用户在另一台机器上安装 rclone 并运行 `rclone authorize "drive"` 粘贴 token——用户可能没有 rclone，此方案只需浏览器。

## ⚠️ GFW 关键限制

**不要在用户位于 GFW 内的机器上跑 `rclone authorize`！**

2026-05-23 实测：在上海的 Windows 桌面上跑 `rclone authorize`：
- ✅ 用户浏览器能打开 Google 登录
- ✅ 能收到 OAuth code
- ❌ **token exchange 失败**：`oauth2.googleapis.com/token` 被 GFW 拦截

**必须**在 VPS（如洛杉矶的 RackNerd）上跑 `rclone authorize`，用户只负责浏览器授权步骤。
