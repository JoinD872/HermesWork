# 实际操作：从 Drive 回收站恢复已删日记

> 2026-06-02 实战记录。`rclone delete` 把 7 篇日记移到了回收站，未永久删除。

## 检查回收站

```bash
# 列出已删除文件（含递归嵌套目录）
rclone ls "mydrive:日记/" --drive-trashed-only --drive-root-folder-id "$FOLDER_ID"
```

输出中的 `-1` = Google Docs 原生格式占位符，`>0` = 有真实内容的文件。

## 定位有内容的文件

因之前的上传流程会额外创建 `日记MD/` 子目录存放 .md 导出副本，有内容的文件通常在这里：

```
日记MD/2026-05-24-日记.md  (840B)  ← 有内容
日记MD/2026-05-25-日记.md  (507B)  ← 有内容
日记MD/2026-05-30-日记.md  (112B)  ← 空模板
```

112 字节 = 空模板（无内容），>112 字节 = 有内容。

## 从回收站复制到本地

**关键：指定具体文件路径，不要通配目录。** 回收站里有递归嵌套（`日记MD/日记MD/日记MD/...`），通配会超时。

```bash
mkdir -p /tmp/diary-recovery

# 逐个恢复有内容的文件
for f in 2026-05-24-日记.md 2026-05-25-日记.md; do
  rclone copy "mydrive:日记/日记MD/$f" /tmp/diary-recovery/ \
    --drive-root-folder-id "$FOLDER_ID" \
    --drive-trashed-only
done
```

每个文件耗时 ~3-50s（取决于嵌套深度）。

## 验证内容

```bash
cat /tmp/diary-recovery/2026-05-24-日记.md | head -5
```

确认是真实内容（不是模板占位符）后，复制到 Vault。

## 重新上传到 Drive

```bash
# 传到正确月份目录
rclone copy /tmp/diary-recovery/2026-05-24-日记.md "mydrive:日记/2026-05/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-import-formats md
```

加 `--drive-import-formats md` 才能转为 Google Docs（手机可编辑）。

## 清理重复

Drive 上会同时存在旧 Google Doc（回收站可见）+ 新上传的 Google Doc。建议先 delete 目录全部清空再重新上传：

```bash
# 清空目录（移到回收站，可恢复）
rclone delete "mydrive:日记/2026-05/" --drive-root-folder-id "$FOLDER_ID"

# 重新上传干净版本
for f in /root/.hermes/ObsidianVault/日记/2026-05/*.md; do
  rclone copy "$f" "mydrive:日记/2026-05/" \
    --drive-root-folder-id "$FOLDER_ID" \
    --drive-import-formats md
done
```

## 关键陷阱

| 陷阱 | 表现 | 对策 |
|------|------|------|
| 目录级 listing 超时 | `rclone ls --drive-trashed-only` 卡死 | 直接指定文件路径，不要通配 |
| `untrash` 超时 | `rclone backend untrash` 也卡死 | 改用 copy 到本地再 re-upload |
| 同名文件重复 | 回收站里有旧副本 + 新上传的副本 | 清空再重传 |
| 上传报 format 错误 | `can't update google document type` | 加 `--drive-import-formats md` |
