# Rclone Google Drive 格式同步模式

> 并入 hermes-obsidian-vault，作为 Cloud Inbox 管道的子知识。原独立技能已归档。

## 适用场景

- 设置 Google Drive 作为中间层，在手机（Google Docs app）和桌面（Obsidian、本地 .md）之间同步
- 本地格式（.md、.txt）与 Google Docs/Sheets/Slides 之间的格式转换
- 管理双格式同步目录：一个存 Google Docs（手机端可编辑），一个存 .md 快照（桌面可同步）
- 防止多个 rclone 脚本操作同一 Drive 目录时的格式覆盖

## 核心模式

### Import：本地文件 → Google Doc

上传 .md 文件并让 Drive 存储为原生 Google Doc：

```bash
rclone copy <local_file> "remote:<path>/" \
  --drive-import-formats md \
  --drive-root-folder-id "<folder_id>"
```

结果：Drive 存储为 `application/vnd.google-apps.document`（rclone lsl 显示 size = -1）。

### Export：Google Doc → 本地 .md

```bash
rclone copy "remote:<path>/" <local_dir>/ \
  --drive-export-formats md \
  --drive-root-folder-id "<folder_id>"
```

### 双目录模式

最稳健的移动端编辑 + 桌面同步方案：

```
Drive/
├── 笔记/          ← Google Docs (size -1, 手机编辑)
└── 笔记/MD快照/    ← .md 快照 (size > 0, 桌面读取)
```

转换管道（每 30 分钟 cron）：

```bash
# Step 1: 拉取 Google Docs 为 .md
rclone copy "remote:笔记/" /tmp/convert/ \
  --drive-export-formats md --size-only

# Step 2: 推送 .md 到快照目录
rclone copy /tmp/convert/ "remote:笔记/MD快照/" \
  --size-only
```

## 注意事项

### 1. 格式覆盖（最危险）

如果没有 `--drive-import-formats md` 就进行 rclone copy，会覆盖已有的 Google Docs（失去手机端编辑能力）。

预防：排除 Google Docs 目录：
```bash
rclone copy "$LOCAL_DIR/" "remote:" \
  --exclude "笔记/*" \
  --drive-root-folder-id "..."
```

### 2. Import 可能超时

`--drive-import-formats` 触发服务端转换，可能很慢。加 timeout：
```bash
timeout 90 rclone copy ... --drive-import-formats md || true
```

### 3. Google Doc 文件名

Drive 上显示原始扩展名（如 `2026-05-24-日记.md`），但内部是 Google Doc。通过 `rclone lsl` 查看 size 是否为 -1 来判断。

## 日记系统实战

完整实现参见 `references/rclone-diary-dual-format.md`。三脚本架构：

| 脚本 | 周期 | 职责 |
|------|------|------|
| `daily_diary.sh` | 每日 08:00 | 创建今日日记 → 上传 Google Docs + .md 快照 |
| `pull_user_notes.sh` | 每 30min | 拉取 Drive 变更 → 更新本地 .md 快照 |
| `sync_vault_to_drive.sh` | 每 30min | 推送 Vault 变更到 Drive（排除 Diary 目录） |

## FOLDER_ID

```
1XvPIqFqftMhG_4QSC9LnApxue_ayvAmg — 用户根 Vault 目录
```
