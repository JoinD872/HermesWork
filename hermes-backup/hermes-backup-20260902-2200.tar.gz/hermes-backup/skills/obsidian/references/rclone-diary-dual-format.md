# Diary System: Dual-Format Google Drive Sync

## Architecture

```
VPS (.md source)            Google Drive                  User Devices
┌──────────────────┐    ┌────────────────────┐     ┌─────────────────┐
│ daily_diary.sh   │───→│ 日记/               │←────│ iPhone Google    │
│ (create + upload)│    │  ├─ YYYY-MM-DD-日记 │     │  Docs app (edit) │
│ 08:00 daily cron │    │  │  (Google Doc)    │     └─────────────────┘
└──────────────────┘    │  └─ 日记MD/         │     ┌─────────────────┐
┌──────────────────┐    │     └─ YYYY-MM-DD-  │────→│ Windows rclone  │
│ pull_user_notes  │───→│      日记.md (.md)  │     │ → Obsidian      │
│ (30 min cron)    │    └────────────────────┘     └─────────────────┘
└──────────────────┘
```

## Three scripts involved

### 1. `/root/.hermes/scripts/daily_diary.sh` — Daily diary creation

Schedule: `0 0 * * *` UTC (08:00 Shanghai)
Type: `no_agent=true`

Key operations:
1. Pull yesterday's diary from Drive (with `--drive-export-formats md`)
2. Compare size with template to detect empty vs filled
3. If filled: copy to local vault (me reading)
4. If empty: delete from both `日记/` and `日记/日记MD/`
5. Create today's .md from template
6. Upload .md to `日记/` with `--drive-import-formats md` → Google Doc
7. Push .md to `日记/日记MD/` (Obsidian snapshot)

### 2. `/root/.hermes/scripts/pull_user_notes.sh` — 30-min pull cycle

Schedule: `*/30 * * * *` (part of `sync_vault_to_drive.sh && pull_user_notes.sh`)
Type: `no_agent=true`

Key operations:
1. Pull entire vault from Drive
2. Sync `日记/日记MD/` from staging → local vault (me reading)
3. Pull `日记/` with `--drive-export-formats md` → .md version
4. Push .md version back to `日记/日记MD/` (keeps snapshot current)

### 3. `/root/.hermes/scripts/sync_vault_to_drive.sh` — Vault push

Schedule: same 30-min cycle as pull
Type: `no_agent=true`

⚠️ **Must exclude `日记/`** to avoid overwriting Google Docs with plain .md:
```bash
rclone copy "$VAULT/" "mydrive:" \
  --exclude "日记/*" \
  --drive-root-folder-id "$FOLDER_ID" \
  --size-only --timeout 120s -q
```

## Verification commands

```bash
# Check format: -1 = Google Doc, positive = plain file
rclone lsl "mydrive:日记/" --drive-root-folder-id "$FOLDER_ID"

# Check nested structure
rclone tree "mydrive:日记/" --drive-root-folder-id "$FOLDER_ID"

# Force a sync cycle
bash /root/.hermes/scripts/pull_user_notes.sh
```

## Cron job reference

```bash
cronjob action=list  # find diary job
cronjob action=run job_id=791b84ec0bde  # manual trigger
```

## FOLDER_ID

```
1XvPIqFqftMhG_4QSC9LnApxue_ayvAmg — user's root vault folder on Drive
```
