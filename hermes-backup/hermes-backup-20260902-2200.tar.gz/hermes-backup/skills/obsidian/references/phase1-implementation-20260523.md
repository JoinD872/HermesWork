# Phase 1 实际执行记录（2026-05-23）

> 本记录供后续 agent 了解 Phase 1 的完整执行细节，避免重复调研。

---

## 参与的 Agent 分工

| 角色 | 任务 | 方式 |
|------|------|------|
| 小H（总控） | 协调、测试写入、汇总报告 | 主对话 |
| 老V（执行官） | 建目录、配白名单（改 file_tools.py）、安全验证 | delegate_task |
| 小策（方案官） | 出 3 个 Markdown 模板 | delegate_task |
| 小研（调研官） | token 成本估算、缓存分析、cron 审计 | delegate_task |
| GPT（架构评审） | 逐轮审核方案，指出 4 个关键修正 | 用户转发 |

---

## 关键决策

### 中文目录名
用户明确表示"英文的我看不习惯"，所有目录名使用中文。

### 草稿统一入口
禁写目录的草稿统一写入 `00_收件箱-AI/`，用 frontmatter 标注 `target_dir: 目标目录` 和 `status: draft`。

### 最小闭环原则
Phase 1 只做：建目录 → 模板 → 白名单 → 测试写入 → tar 备份。不做 rclone crypt / Cloud Inbox / 同步。

### 分阶段推进
三阶段严格按前置条件推进，每阶段结束后观察 24h+ 再进下一阶段。

---

## write_file 白名单代码实现

### 文件位置
`~/.hermes/hermes-agent/tools/file_tools.py`

### 改动概要（+96 行，3 处调用点）

1. **`_load_obsidian_vault_config()`** — 从 `config.yaml` 的 `security.obsidian_vault` 读取并缓存配置，线程安全（`threading.Lock`），缓存全局变量
2. **`_check_obsidian_vault_path(path, task_id)`** — 核心校验函数：
   - 使用 `os.path.realpath()` + `os.path.expanduser()` 防 `../` 和 symlink 绕过
   - `enabled: false` 或 Vault 外路径 → 跳过检查
   - Vault 内路径 → 检查 top-level 目录是否在 `writable_dirs` 中
   - 不在白名单 → 返回明确中文错误信息，引导写 `00_收件箱-AI/`
   - Vault 根目录本身也被拒绝（歧义路径）
3. **`write_file_tool()` 2 处调用** — 在敏感路径检查（`_SENSITIVE_PATH_PREFIXES`）之后插入白名单校验

### 安全防御验证

| 攻击向量 | 防御方式 | 验证结果 |
|---------|---------|:--------:|
| `../` 路径遍历 | `os.path.realpath()` 规范化路径 | ✅ 拦截 |
| symlink 软链接绕过 | `os.path.realpath()` 解析链接到目标 | ✅ 拦截 |
| Vault 外误伤 | 路径前缀匹配，不在 Vault 内则跳过 | ✅ 无影响 |

### config.yaml 配置

```yaml
security:
  obsidian_vault:
    enabled: true
    root: "~/.hermes/ObsidianVault"
    writable_dirs:
      - "00_收件箱-AI"
      - "10_文献笔记"
      - "40_复盘归档"
    draft_only_dirs:
      - "20_项目文档"
      - "30_永久笔记"
      - "50_Hermes架构"
      - "灵感创意"
```

---

## 备份文件

| 备份对象 | 路径 |
|---------|------|
| file_tools.py 原版 | `tools/file_tools.py.bak.20260523`（53,669 bytes） |
| config.yaml 原版 | `~/.hermes/config.yaml.bak.20250523-061830` |

---

## 模板

3 个模板文件位于 `~/.hermes/ObsidianVault/模板/`：

- `复盘模板.md` — 37 行，含 YAML frontmatter + 背景/问题/排查过程/根因/解决方案/验证结果/后续动作
- `文献模板.md` — 31 行，含来源/核心结论/详情/对 Hermes 的价值
- `收件箱模板.md` — 25 行，含 target_dir/promotion_required/to_memory

---

## GPT 指出的 4 个关键修正

| 修正 | 内容 |
|------|------|
| 1 | 路径名称必须完整一致（`00_收件箱-AI/` 不能缩写为 `收件箱AI/`） |
| 2 | 草稿统一写 `00_收件箱-AI/`，不在目标目录直接写 |
| 3 | Phase 1 暂不强制 rclone crypt，先最小闭环 |
| 4 | `vault:true` 放在 `payload.meta` 而非直接 payload 字段 |

---

## 后续待办

- [ ] Phase 2: callback → Vault 管道（改 federation-protocol-v320，加 meta.vault 字段）
- [ ] Phase 2: 建 vault-digest cron
- [ ] Phase 3: Cloud Inbox 回拉脚本
- [ ] Phase 3: 多端同步（按需加 rclone crypt / Syncthing / Git）
