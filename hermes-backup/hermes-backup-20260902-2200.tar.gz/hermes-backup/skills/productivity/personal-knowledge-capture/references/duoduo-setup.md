# 用户 Duoduo 知识库配置（2026-07-15 建立）

## Drive 位置
- 文件夹 ID：`1oLAY4-63zFm5vFSM5UiNycMuFChuYAnt`
- rclone remote：`mydrive:`
- 与主 Obsidian Vault（`1XvPIqFqftMhG`）**完全独立**，不共用同步链路

## 目录结构
```
朵朵知识库/
├── README.md
├── 01_人生系统/       # 目标、价值观、决策记录
├── 02_家庭育儿/       # 女儿成长、育儿原则、家庭关系
├── 03_聊天归档/       # 原始对话草稿（未经确认）
└── Draft/             # 待用户确认的笔记草稿 ← 写入入口
```

## 写入命令模板
```bash
# 写 Draft/
rclone copy /tmp/duoduo-draft/ "mydrive:Draft/" \
  --drive-root-folder-id "1oLAY4-63zFm5vFSM5UiNycMuFChuYAnt"

# 验证（正数大小 = 原生 .md ✅，-1 = Google Doc ❌）
rclone ls mydrive:Draft/ \
  --drive-root-folder-id "1oLAY4-63zFm5vFSM5UiNycMuFChuYAnt"
```

## 用户说明
- 免费版 Obsidian，不付费 Sync
- 手机通过 Google Drive App 预览 .md，不能编辑
- 可选方案：「Remotely Save」插件同步到手机 Obsidian
- 用户偏好：先问再写，不自动推送；拿不准关联度时问用户
