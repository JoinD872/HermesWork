#!/usr/bin/env bash
# 精准费用报告 — 余额查 API，文件差值法（V3.0，不被其他会话干扰）
# 本脚本是 api-cost-tracking skill 的核心工具，被 cron 和 DM 共用
# 安全声明：不要在 SKILL.md 中内联本脚本的 curl 命令（会触发 cron 注入扫描器）
set -euo pipefail

source /root/.hermes/.env

BALANCE_FILE="/root/.hermes/cache/last_balance.txt"
mkdir -p "$(dirname "$BALANCE_FILE")"

BALANCE=$(curl -s --max-time 10 https://api.deepseek.com/user/balance \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY" \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['balance_infos'][0]['total_balance'])" 2>/dev/null || echo "N/A")

if [ "$BALANCE" = "N/A" ]; then
    echo "余额：查询失败"
    exit 1
fi

COST="初次"
if [ -f "$BALANCE_FILE" ]; then
    LAST=$(cat "$BALANCE_FILE")
    if [ -n "$LAST" ] && [ "$LAST" != "N/A" ]; then
        COST=$(python3 -c "print(f'{max(0,float($LAST)-float($BALANCE)):.6f}')")
    fi
fi

echo "$BALANCE" > "$BALANCE_FILE"
echo "本次：¥$COST | 余额：¥$BALANCE"
