# 国外 AI 订阅套餐调研（2026-07 实测）

结论先行：**国外「包月 API 订阅」市场很薄**，绝大多数供应商是 PAYG（OpenAI / Anthropic / Google / Together / Fireworks / Groq / Mistral / xAI）。能当 Hermes provider 的包月订阅只有 OpenCode Go（已是主力）+ GitHub Copilot（速率限制太死）。**Cursor 是 IDE 不是 API，Hermes 无法接入**。

## GitHub Copilot / GitHub Models API 路径

| 项目 | 内容 |
|------|------|
| API 端点 | `https://models.github.ai/inference/chat/completions`（OpenAI 兼容） |
| 认证 | GitHub PAT，需 `models` scope（Settings → Developer settings → PAT） |
| 免费层 | 速率限制极低：普通模型 ~15 req/min、150 req/天；**高级模型 ~5 req/天** |
| Copilot Pro | $10/月 → **$15 信用额度/月**（可以当 Hermes provider 但 5 req/天 高级模型直接判死） |
| Copilot Pro+ | $39/月 → $70 信用额度/月（含 Opus） |
| Copilot Max | $100/月 → $200 信用额度/月 |
| 结论 | **速率限制不适合做 Hermes 后端**（cron 巡检几下就 throttle）；信用额度模式 = 预购，不是畅用 |

GitHub Models 官方文档：docs.github.com/en/github-models/use-github-models/prototyping-with-ai-models（含 Going to production / Rate limits 章节）。免费层速率表在页面底部。

## Cursor 完整定价（2026-07 官网实测）

| 套餐 | 月付 | 年付（折合月价，-20%） |
|------|:---:|:---:|
| Hobby | Free | Free |
| Pro | $20 | **$16** |
| Pro+ | $60 | **$48** |
| Ultra | $200 | **$160** |
| Teams Standard | $40/用户 | $32/用户 |
| Teams Premium | $120/用户 | $96/用户 |
| Enterprise | Custom | Custom |

**两个用量池机制**（Pro/Pro+/Ultra）：
- **Cursor Models 池**：Grok 4.5 + Composer 2.5，额度慷慨，正常日用到月底用不完
- **Other Models 池**：第三方模型（Claude/GPT/Gemini），按 API 价扣费，Pro 至少含 **$20/月**，更高档更多；用完按 API 价现结

**模型清单**：Composer 2.5（200k ctx）、Grok 4.5（256k）、Claude Sonnet 5（200k/1M）、Claude Opus 5（300k/1M）、Claude Fable 5（300k/1M）、Gemini 3.1 Pro（200k/1M）、Gemini 3.6 Flash（200k/1M）、GPT-5.6 Sol/Luna/Terra（272k/1M）。全部支持 agent + thinking + image（Grok 4.5 不支持 image）。

**⚠️ 关键认知**：Cursor 是 IDE 工具，**没有通用 API 端点**，无法给 Hermes 当 provider。用户反复问「Cursor 能不能平替 Go」的正确答案始终是「不能，它是 IDE」。Cursor CLI / ACP 是控制 IDE 的协议，不是 LLM 推理 API。

**活动情况**：无限时促销/优惠券；唯一常年折扣是年付 -20%。学生有 .edu 优惠入口。

## 其他调研过的选项（速查）

| 服务 | 模式 | 结论 |
|------|------|------|
| OpenRouter | PAYG + 5.5% 平台费 | 400+ 模型最灵活；免费层 25+ 模型 50 req/天 |
| DeepSeek 国际站 | PAYG（api.deepseek.com） | 同模型国外主体路径，月均 ~$11（等同 Go 用量）；V4 Pro ~$33 |
| Groq | PAYG | 只开源模型（GPT-OSS/Llama/Qwen），速度最快 |
| Together AI / Fireworks / Novita / AIMLAPI | PAYG | 开源+DeepSeek 系模型，无订阅 |
| Hugging Face Pro | $9/月 | 推理积分制，只限 HF 开源模型 |
| Mistral / Poe | PAYG / 订阅 | 无通用 LLM API 订阅 |
| xAI Grok 4.5 | PAYG | $2/$6 per 1M（见 grok-xai-pricing.md）；同用量月费 ~$176-235，比 V4 Flash 贵 16-21x |

## 用户决策背景

用户想「换掉 OpenCode Go（国内公司）→ 找国外 API 订阅平替」，要求：编码强、耐用（额度高）、月订阅、贵一点可接受（$10-40 区间）。结论：**国外包月 API 订阅市场不存在同价位平替**；最接近的路径是 DeepSeek 国际站 PAYG（同模型、国外主体、~$11/月）或保持 Go。Go 套餐内高级模型（Grok 4.5 等）额度低（Grok 4.5 月 ~600 次 vs V4 Flash 月 ~15.8 万次），详见 opencode-go-pricing.md。
