# xAI / Grok API Pricing Reference

> 来源：docs.x.ai 官网（2026-07-29 采集）
> 关联：api-cost-tracking SKILL.md 中的定价章节

## Grok 4.5 — 旗舰模型

| 维度 | 值 |
|:---|:---|
| 模型名 | `grok-4.5` |
| 上下文 | **500K tokens** |
| 长上下文阈值 | ≥ 200k tokens |
| 定位 | "Flagship model for code and everything else" |
| 思考模式 | Configurable reasoning |
| API 格式 | OpenAI 兼容 |

### 短上下文定价（< 200k tokens）

| 项目 | USD / 1M tokens | CNY ≈ (×6.77) |
|:---|:---:|:---:|
| 输入 | $2.00 | ¥13.54 |
| 缓存命中 | $0.30 | ¥2.03 |
| 输出 | **$6.00** | **¥40.62** |

### 长上下文定价（≥ 200k tokens）

| 项目 | USD / 1M tokens | CNY ≈ |
|:---|:---:|:---:|
| 输入 | $4.00 | ¥27.08 |
| 缓存命中 | $0.60 | ¥4.06 |
| 输出 | **$12.00** | **¥81.24** |

### 速率限制（Tier 0 默认）

| 指标 | 值 |
|:---|:---:|
| Requests/sec | 150 |
| Tokens/min | 50M |

> Tier 升级：累计消费 $50 → T1, $250 → T2, $1,000 → T3, $5,000 → T4。不降级。

### 其他模型

| 模型 | 上下文 | 输入/输出/缓存 | 定位 |
|:---|:---:|:---:|:---|
| grok-4.3 | 1M | $1.25 / $2.50 / $0.20 | 前代旗舰 |
| grok-4.20-reasoning | 1M | $1.25 / $2.50 / $0.20 | 推理专用 |
| grok-build-0.1 | 256k | $1.00 / $2.00 / $0.20 | 轻量代理 |

## vs DeepSeek V4 Flash 成本对比

> **核心结论：Grok 4.5 输出价格是 DeepSeek V4 Flash 的 21 倍，输入价格是 14 倍。**

### 单次典型请求成本估算

典型 Hermes agent 请求（5K 输入 + 1K 输出）：

| 服务 | 计算过程 | 单次成本 |
|:---|:---|:---:|
| **DeepSeek V4 Flash** (直连) | 0.005M×$0.14 + 0.001M×$0.28 | **$0.00098 ≈ ¥0.007** |
| **DeepSeek V4 Flash** (缓存命中) | 0.005M×$0.0028 + 0.001M×$0.28 | **$0.00029 ≈ ¥0.002** |
| **Grok 4.5** (短上下文) | 0.005M×$2.00 + 0.001M×$6.00 | **$0.016 ≈ ¥0.11** |
| **Grok 4.5** (长上下文) | 0.005M×$4.00 + 0.001M×$12.00 | **$0.032 ≈ ¥0.22** |

### 月费模拟（基于用户用量 ~$11/月 DeepSeek）

| 场景 | 月费估算 |
|:---|:---:|
| DeepSeek V4 Flash（Go 订阅） | $10/月 |
| DeepSeek V4 Flash（直连 PAYG） | ~$11/月 |
| Grok 4.5（同等 token 量） | **~$176-235/月** |

## 与 OpenCode Go 的对比

Go 订阅模型（$10/月）包 deepseek-v4-flash 的用量，而 xAI 只有 PAYG。对于 Hermes 这种输出密集的 agent 场景，Grok 4.5 的成本是 Go 的 15-20 倍。

## 优势场景

Grok 4.5 的强项在于：内置 Web Search / X Search / Code Execution / 图片/视频/语音生成能力——如果 agent 任务需要这些工具，可以省掉额外的服务集成。
