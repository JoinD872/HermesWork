# 第三方 AI API 平台评估笔记

> 记录对第三方 AI API 聚合平台的调研结果，供未来类似调研参考。

## ZenMux (zenmux.ai)

**调研日期**: 2026-05-30
**触发**: 早报提到 DeepSeek V4 Pro 国内免费 API 开放体验

### 平台概况

- 新加坡公司 (AI Force Singapore Pte. Ltd.)
- 模型聚合平台，兼容 OpenAI + Anthropic 协议
- 支持 API + Web Chat (Studio)
- 有 AI Insurance 补偿机制
- 148+ 模型覆盖（文本/图像/视频/Embedding）

### 免费 Builder Plan ($0/月)

| 指标 | 数值 |
|------|------|
| 5小时配额 | 5 Flows |
| 每周最大 | 38.64 Flows |
| 每月最大 | 165.6 Flows |
| 等值美元价值 | ~$5.44/月 |
| 速率限制 | 10-15 RPM |

Flow 系统: 1 Flow ≈ $0.03283，约 30 Flows = $1

### 免费模型（21个）

**关键结论：免费层不含 DeepSeek V4 Pro，只有 V3.2**

**文本模型:**
- `deepseek/deepseek-chat` — DeepSeek V3.2 (非推理)
- `deepseek/deepseek-reasoner` — DeepSeek V3.2 (推理)
- `minimax/minimax-m2.1` — MiniMax M2.1
- `z-ai/glm-4.7` — GLM 4.7
- `z-ai/glm-4.7-flash-free` — GLM 4.7 Flash (Free)
- `z-ai/glm-4.6v-flash` — GLM 4.6V FlashX
- `stepfun/step-3.5-flash` — Step 3.5 Flash
- `stepfun/step-3` — Step-3
- `inclusionai/ling-1t` — Ling-1T
- `inclusionai/ring-1t` — Ring-1T
- `sapiens-ai/agnes-1.5-pro` — Agnes 1.5 Pro
- `sapiens-ai/agnes-1.5-lite` — Agnes 1.5 Lite
- `kuaishou/kat-coder-pro-v1-free` — KAT Coder Pro V1 (Free)
- `xiaomi/mimo-v2-flash` — MiMo V2 Flash
- `xiaomi/mimo-v2-flash-free` — MiMo V2 Flash (Free)

**图像生成:**
- `openai/gpt-image-2` — GPT Image 2（免费层亮点）
- `sapiens-ai/agnes-image-1.2` — Agnes Image 1.2

### 付费套餐

| 套餐 | 月费 | 月最大 Flows | 等值美元 | 含模型 |
|------|------|-------------|---------|-------|
| Pro | $20 | 914 | ~$30 | 150+ 模型（含 Claude Sonnet/Opus、GPT-5.x、Grok 4、DeepSeek V3.2/Qwen 等） |
| Max | $100 | 5,487 | ~$180 | Pro + GPT-5.4 Pro + Veo 3.1 |
| Ultra | $200 | 14,631 | ~$480 | 同 Max |

**注意**: Pro 套餐不含 DeepSeek V4 Pro/V4 Flash，只到 V3.2

### 可用性评估（对我们）

- ✅ 文档页可直达（无 Cloudflare 拦截）
- ✅ 可 API 集成（OpenAI 协议兼容）
- ⚠️ 需注册账号才能拿到 API Key（可能需要国内手机号验证）
- ⚠️ 10-15 RPM 限速对 cron 任务和 Codex 不够
- ❌ 免费层无 V4 Pro
- ❌ 禁生产环境

### 评估方法论总结

当看到「XX 平台提供 YY 模型免费 API」的宣传时，需验证：

1. **免费层含什么模型？** — 经常出现"免费体验的是旧版/降级版"（如这里是 V3.2 不是 V4 Pro）
2. **免费额度有多少？** — 看配额（Flows/tokens/次数）、限速（RPM）、使用限制
3. **注册门槛？** — 是否需国内手机号实名，VPS 海外 IP 能否访问
4. **集成成本？** — 兼容什么协议，能否直接配进 Hermes
5. **与现有方案的性价比对比** — 当前 DeepSeek V4 Flash 成本极低（¥1/M 输入），免费层的旧版模型往往不如现有方案

---

## 空模板（用于下次调研）

```markdown
## [平台名称] ([URL])

**调研日期**: YYYY-MM-DD
**触发**: [早报/用户提及/社区消息]

### 平台概况
- [一句话介绍：聚合平台/单一模型/技术栈]
- [协议兼容性：OpenAI/Anthropic/自有]
- [关键特点：保险/路由/Edge 节点等]

### 免费层/试用法
- [额度：次数/Flows/时间]
- [限速：RPM/并发]
- [可用模型列表]

### 对我们可用吗？
- [✅/❌] 集成可行性
- [✅/❌] 模型质量
- [✅/❌] 性价比优于现有方案
- [⚠️] 风险/限制

### 结论
```
