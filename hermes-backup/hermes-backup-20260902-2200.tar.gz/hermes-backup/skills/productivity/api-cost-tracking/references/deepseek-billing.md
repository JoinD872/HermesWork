# DeepSeek Billing Reference

> 编写于 2026-05-20，基于官方文档和实测验证。

## 余额 API 文档

**Endpoint**: `GET https://api.deepseek.com/user/balance`
**Auth**: Bearer token (DEEPSEEK_API_KEY)
**官方文档**: https://api-docs.deepseek.com/api/get-user-balance

### 实测响应 (2026-05-20)

```json
{
  "is_available": true,
  "balance_infos": [
    {
      "currency": "CNY",
      "total_balance": "21.50",
      "granted_balance": "0.00",
      "topped_up_balance": "21.50"
    }
  ]
}
```

### 字段说明

| 字段 | 说明 |
|------|------|
| `total_balance` | 当前总余额（CNY，人民币） |
| `granted_balance` | 赠送余额，不可退款 |
| `topped_up_balance` | 自充值余额，可上「Billing」页面自助退款 |
| `is_available` | 账户是否可用 |

### 调用方式

```bash
# ✅ 正确方式：从 .env 读取 key
source /root/.hermes/.env 2>/dev/null
curl -s https://api.deepseek.com/user/balance \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY"
```

> ⚠️ `DEEPSEEK_API_KEY` 不存在于进程环境变量中，仅在 `.env` 文件内。
> `os.environ.get('DEEPSEEK_API_KEY')` 返回 `None`，必须用 `source` 加载。

## 官方定价 (2026-05-20 验证)

来源：https://api-docs.deepseek.com/quick_start/pricing

### DeepSeek V4 Flash

| 类型 | USD/百万tokens | CNY/百万tokens (×6.80) |
|------|---------------|----------------------|
| 输入（缓存命中） | $0.0028 | ¥0.019 |
| 输入（缓存未命中） | $0.14 | ¥0.95 |
| 输出 | $0.28 | ¥1.90 |

### DeepSeek V4 Pro（75%折扣至2026/05/31）

| 类型 | 折扣价 (USD) | 原价 (USD) |
|------|-------------|-----------|
| 输入（缓存命中） | $0.003625 | $0.0145 |
| 输入（缓存未命中） | $0.435 | $1.74 |
| 输出 | $0.87 | $3.48 |

> 折扣到期后恢复原价：缓存命中 $0.0145 / 缓存未命中 $1.74 / 输出 $3.48
> 注意：Pro 的缓存命中折扣（75%）和 Flash 的缓存命中降价（1/10）是两套不同的机制。

## 汇率参考

- 2026-05-20: 1 USD ≈ **6.80 CNY** (Bloomberg: 6.8041)
- 过去一周波动范围: 6.7851 ~ 6.8170 (极窄)
- 过去一年人民币对美元升值约 5.55%
- 日常使用取 **6.80** 作为近似值即可

## 充值与退款

- 充值入口：https://platform.deepseek.com/billing
- 未使用余额可退款：官网「Billing」→「Refunds」
- API Key 管理：https://platform.deepseek.com/api_keys
- 按 API Key 查看用量：FAQ 页面提及每个 key 独立统计

## 缓存命中成本对比

DeepSeek V4 Flash 的缓存命中价比缓存未命中价便宜 **50倍**（$0.0028 vs $0.14）。这是官方在 2026/4/26 实施的降价，将缓存命中价降至发布价的 1/10。

实际使用中，同一 session 内第二轮起缓存命中率约 **100%**（仅新增 tool result 的少量 token 未命中）。因此每轮的平均成本极低，约 ¥0.00x 级别。

跨频道切换（小策→黑翼→小研等）会丢失频道独有 SOUL.md 的缓存，导致 3.5-4.3KB 的 cache miss，但公共前缀（~2.1KB 路由规则）仍然命中。
