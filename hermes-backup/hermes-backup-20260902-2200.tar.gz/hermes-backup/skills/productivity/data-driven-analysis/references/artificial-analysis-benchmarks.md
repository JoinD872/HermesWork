# Artificial Analysis — AI 模型独立基准站

**URL**: https://artificialanalysis.ai

**定位**: 独立第三方 AI 模型评测，覆盖智能、速度、价格、延迟等多维度

**数据采集时间**: 2026-07-28

---

## Intelligence Index v4.1（2026年7月）

综合 9 项评测：GDPval-AA v2、τ³-Banking、Terminal-Bench v2.1、SciCode、Humanity's Last Exam、GPQA Diamond、CritPt、AA-Omniscience、AA-LCR

| 排名 | 模型 | 得分 |
|------|------|:----:|
| 1 | Claude Opus 5 (max) | 61 |
| 2 | Claude Fable 5 | 60 |
| 3 | GPT-5.6 Sol (max) | 59 |
| 4 | Kimi K3 | 57 |
| 5 | Grok 4.5 (high) | 54 |
| 6 | GLM-5.2 (max) | 51 |
| 7 | Muse Spark 1.1 (xhigh) | 51 |
| 8 | Gemini 3.6 Flash | 50 |
| 9 | MiniMax-M3 | 44 |
| 10 | DeepSeek V4 Pro (max) | 44 |
| 11 | DeepSeek V4 Flash (max) | 40 |
| 12 | Nemotron 3 Ultra | 38 |

**趋势**: 2026年7月竞争加剧——8天内6家实验室发布得分50+的模型。Claude Opus 5 以61分登顶。

---

## DeepSeek V4 Flash 详细数据

| 指标 | 数值 |
|------|------|
| 智能指数 | 40（同类中位数25，排#12/98） |
| 速度 | 114.2 tok/s（排#12/98） |
| 输入价 | $0.14/百万tokens |
| 输出价 | $0.28/百万tokens |
| 缓存命中价 | $0.003（行业#1，折扣98%）|
| 参数量 | 284B总 / 13B激活（MoE）|
| 上下文 | 1M tokens |
| 发布 | 2026年4月 |
| 许可证 | MIT |

**官方描述**: "amongst the leading models in intelligence and well priced when comparing to other open weight models of similar size. It's also notably fast, however very verbose."

---

## 使用方式

当用户问模型对比/排名/是否落后时：

1. 打开 https://artificialanalysis.ai 搜对应模型
2. 查看 Intelligence Index 得分、速度、价格
3. 与用户关心的竞品做横向对比
4. 标注数据来源和时间（分数每月可能变化）

**注意**: 不要凭训练知识回答模型排名——AI 行业变化极快，必须搜索当前数据。

---

## DeepSeek V4 Flash 推理级别配置

DeepSeek V4 Flash 支持多级推理强度（reasoning effort），不同级别影响智能表现和 token 消耗。

通过 OpenCode Go API 已验证支持 `reasoning_effort` 参数：

| 级别 | 配置方式 | 效果 |
|------|---------|------|
| 默认 | 不设（空） | 标准推理，速度快，token 省 |
| max | `hermes config set model.reasoning_effort max` | 最高推理强度，智能得分更高（AA Index 40 分），更耗时/更贵 |

**配置路径**: 修改 `~/.hermes/config.yaml` 的 model 段：
```yaml
model:
  default: deepseek-v4-flash
  provider: custom:opencode-go
  base_url: https://opencode.ai/zen/go/v1
  reasoning_effort: max   # 加这一行
```

或通过 CLI：
```bash
hermes config set model.reasoning_effort max
```

**注意**: Artificial Analysis 评测的 DeepSeek V4 Flash 40 分是基于 Max Effort 模式。默认（未设）模式得分可能低于此分数，但速度更快、token 消耗更少。
