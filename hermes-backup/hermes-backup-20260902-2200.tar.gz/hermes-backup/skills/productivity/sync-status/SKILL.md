---
name: sync-status
description: Sync status — Resume a task from the last checkpoint. Triggered when user says /resume or asks to continue from where left off. Reads the enhanced task_checkpoint.json and generates a structured recovery summary before proceeding.
category: productivity
risk: read-only
---
# Sync Status — 断点续传（增强版）

## 触发条件
用户说 `/resume`，或者要求"继续上一个任务"、"从刚才的地方继续"。

## 核心原则
> **绝对不让用户手动描述进度**。Checkpoint 是唯一真实来源。

## 执行流程

### 1. 读取 task_checkpoint.json（P0）
```bash
cat ~/.hermes/task_checkpoint.json
```

### 2. 解析增强字段
支持以下全部字段：
- `task_id`：任务唯一标识（如 `task_20260428_000000`）
- `task`：任务名称
- `status`：当前状态（active/paused/done/failed/代码修改完成待重启）
- `priority`：优先级（P0/P1/P2/P3）
- `owner_agent`：负责人（main/vps/researcher/health/game）
- `completed_steps`：已完成步骤列表（数组）
- `pending_steps`：待完成步骤列表（数组）
- `next_step`：下一步文字描述
- `changed_files`：已修改文件列表
- `changes`：改动描述列表
- `validation_commands`：验证命令列表
- `rollback_commands`：回滚命令列表
- `risks`：风险描述列表
- `updated_at`：最后更新时间（ISO 8601）
- `active_sub_agents`：活跃子 Agent 列表

### 3. 生成恢复摘要（强制汇报格式）

**必须输出以下全部字段，不全不汇报：**

```
✅ 检测到未完成任务

任务ID：{task_id}
任务目标：{task}
当前阶段：{status}
优先级：{priority}
负责人：{owner_agent}

已完成（{completed_steps.length}项）：
  ✅ 步骤1
  ✅ 步骤2

未完成（{pending_steps.length}项）：
  ⏳ 待办1
  ⏳ 待办2

建议下一步：{next_step}

风险提示：
  ⚠️ 风险1
  ⚠️ 风险2

验证命令：
  {validation_commands.join('\n  ')}

回滚方案：
  {rollback_commands.join('\n  ')}

最后更新：{updated_at}

是否继续？请回复"继续"或"停止"。
```

### 4. 用户确认后继续执行
- 收到"继续"后，才注入上下文并执行 `next_step`。
- 收到"停止"后，保持 checkpoint 状态不变。
- 若 checkpoint `status` 为 `done`，告知用户任务已完成，无需继续。

### 5. 完成后更新 checkpoint
任务真正完成后，将 checkpoint 状态改为 `done`，清空 `pending_steps`：

```json
{
  "task_id": "task_20260428_000000",
  "updated_at": "2026-04-28T00:00:00+08:00",
  "task": "任务名",
  "status": "done",
  "priority": "P1",
  "owner_agent": "main",
  "completed_steps": ["步骤1", "步骤2"],
  "pending_steps": [],
  "next_step": "none",
  "changed_files": [],
  "changes": [],
  "validation_commands": [],
  "rollback_commands": [],
  "risks": [],
  "active_sub_agents": []
}
```

## 错误处理
- 若 `~/.hermes/task_checkpoint.json` 不存在或为空，回复用户："没有找到上一次的进度记录，请告诉我你想继续什么任务。"
- 若 JSON 格式异常，同样告知用户并请其描述任务。
- 若 checkpoint `status` 为 `done`，告知用户"任务已完成，无需继续"。

## 注意事项
- Sync_Status 触发后，后续步骤仍遵循 P0 规范（每步写 task_checkpoint.json）
- 绝对不让用户手动描述进度——这是 Sync_Status 的核心价值
- `next_step` 为空且 `pending_steps` 为空时，任务视为已完成
