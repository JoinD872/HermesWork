# AI 模型对比研究规范

> 用于 `research-workflow` 下「产品选型/深度研究类」问题中的 AI 模型对比场景
> 经验来源：2026-05-20 Gemini vs ChatGPT vs DeepSeek 调研

## 一、典型触发场景

- "比较 X 和 Y 哪个更适合我的场景"
- "目前最推荐的模型是什么"
- "用户更喜欢哪个模型"
- "从 X 和 Y 中选一个作为主力"

## 二、对比维度（必扫）

| # | 维度 | 来源 | 说明 |
|---|------|------|------|
| 1 | **Benchmark 数据** | Artificial Analysis / LiveBench / SWE-bench / MMLU | 看客观数据但不盲信 |
| 2 | **真实用户反馈** | Reddit (r/LLM/r/GeminiAI/r/Bard) / Google AI Forum / Product Hunt | **最重要**——用户实际体验 > 厂商宣传 |
| 3 | **深度对比文** | Tech Insider / DataCamp / GuruSup / FutureAGI / Medium | 整合性最高，有横向对比表 |
| 4 | **定价与性价比** | 官网定价页 + API 成本 | 输入/输出/百万token 价格对比 |
| 5 | **速度与延迟** | Artificial Analysis 的 tokens/s 指标 | 日常交互体验的关键 |
| 6 | **上下文窗口** | 官方规格 | 是否有刚需（如 1M+ 上下文）|
| 7 | **工具生态** | 插件/函数调用/Agent 框架支持 | 对 Agent 系统最重要 |
| 8 | **版本/命名陷阱** | 官方博客 + 用户论坛 | 检查最新「稳定版」而非最新「发布版」|

## 三、搜索关键词模板

### 基础版
```
<model A> vs <model B> 真实体验对比 2026
<model A> vs <model B> comparison review 2026
<model A> vs <model B> benchmark
```

### 深度版
```
<model A> real user review 2026 coding reasoning
<model A> feels like a downgrade / better than <model B>
GPT-5 vs Gemini 2.5 Pro 对比评测
DeepSeek V4 vs GPT-5.5 benchmark coding agent
```

## 四、平行采集法（核心技巧）

**不要串行搜索**——同时启动多个来源能大幅提速：

```
① SearXNG 搜索（1-2 个关键词）      ← 同时
② browser_navigate 到对比文        ← 同时
③ browser_navigate 到社区反馈帖    ← 同时
④ browser_navigate 到 benchmark页  ← 同时
```

例：本调研中同时启动 TecHi.com + Google AI Forum + Reddit + FutureAGI 4个页面

## 五、信息加工流程

```
收集原始数据（benchmark + 用户反馈 + 价格）
         ↓
交叉验证（benchmark 高的模型用户真的喜欢吗？）
         ↓
分类到各维度（见第二部分表格）
         ↓
映射到用户的具体使用场景（如：编码/Agent/写作/运维）
         ↓
输出综合结论（含推荐和理由）
```

## 六、常见陷阱

| 陷阱 | 案例 | 应对 |
|------|------|------|
| 版本号混淆 | "Gemini 3.5" 实际叫 Gemini 2.5 Pro；"GPT-5" 有多个子版本 | 先查官方命名，确认讨论的是哪个具体版本 |
| 新不等于好 | Gemini 3.x 被社区认为比 2.5 Pro 差 | 查社区 1 个月以上使用反馈，而非首发评测 |
| benchmark ≠ 真实体验 | 模型在 MMLU 高分但用户说"机械感强" | 两者都看，benchmark 看能力边界，用户反馈看日常体验 |
| 厂商自报 vs 第三方 | DeepSeek 自报分数高于 CAISI 第三方评估 | 优先采信第三方独立评测 |
| "最好"脱离场景 | GPT-5.5 编码强但价格贵 50x | 结论必须绑定用户具体场景 |
