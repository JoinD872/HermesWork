# PubMed E-utilities API — Academic Research from Terminal

当网站被 Cloudflare 封锁时，通过 NCBI E-utilities API 直接获取同行评审文献的摘要和数据。

## 核心端点

### 搜索 PMID
```
https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi
?db=pubmed
&term=<搜索词>
&retmax=<数量>
&sort=relevance
```

返回 XML 格式，`<Id>` 节点包含 PMID。

### 获取摘要/详情
```
https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi
?db=pubmed
&id=<PMID1>,<PMID2>
&retmode=xml
&rettype=abstract
```

返回 XML 格式。提取方式：
- `//ArticleTitle` — 论文标题
- `//AbstractText` — 摘要内容（含 `Label` 属性如 BACKGROUND/METHODS/RESULTS/CONCLUSIONS）
- `//Journal/Title` — 期刊名称
- `//Author/LastName` + `//Author/ForeName` — 作者

## 实用示例

```bash
# 1. 搜索
curl -sL "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=sleep+extension+recovery+chronic&retmax=5"

# 2. 获取摘要
curl -sL "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=33274389,12603781&retmode=xml&rettype=abstract"
```

## 备用 API（交叉验证）

### Semantic Scholar
```
GET https://api.semanticscholar.org/graph/v1/paper/DOI:<doi>?fields=title,abstract,citationCount
GET https://api.semanticscholar.org/graph/v1/paper/PMID:<pmid>?fields=title,abstract,citationCount
```
- 返回 JSON，含 citationCount（引用量，衡量权威性的关键指标）
- 速率限制：较高，一般不会触发

### CrossRef
```
GET https://api.crossref.org/works/<doi>
```
- 返回完整元数据：作者、期刊、年份、引用量
- 无认证，速率友好

## 用户偏好（重要）

当用户要求「权威来源」时：
1. **优先使用 PubMed E-utilities** 获取同行评审文献
2. 展示 **PMID + 期刊名 + 引用量** 作为可信度证据
3. 避免引用个人博客、低赞知乎文章（<10 赞）、未经验证的帖子
4. 层级：PubMed 研究 > 机构发布（NIH/CDC） > 科普书 > 个人经验
5. 如果多个引擎返回 0 结果，诚实告知无法获取，不要用训练数据中的模糊记忆凑数

## 处理封锁

NCBI 站点偶尔返回 403。E-utilities API（eutils.ncbi.nlm.nih.gov）通常不受影响，优先使用。
