# 科学证据检索与呈现 — 健康/生活方式类

> 2026-07-18 经用户纠正确立。适用于朵朵提供基于科学证据的身心/睡眠/健康建议的场景。

## 核心原则

**用户要的是权威性，不是「知乎上有个人说」。**

当用户问「有没有权威案例/研究/数据」时：

| ❌ 错误做法 | ✅ 正确做法 |
|------------|------------|
| 搜知乎 → 找一篇个人文章 → 当案例推 | 找到原始研究 → 确认期刊/PMID/引用数 → 呈现原始数据 |
| 凭训练数据记忆说「有研究表明」 | 用工具确认研究细节：期刊名、作者、PMID、引用次数 |
| 把知乎内容当权威来源 | 知乎只用作**发现线索**，结论以原始论文为准 |

## 源层级

```
Level 1 (最高): PubMed 收录的同行评审论文
  → 提供: 期刊名 + PMID/DOI + 引用次数 + 机构
  → 验证: Crossref / Semantic Scholar API

Level 2: 权威机构官方报告
  → CDC / NIH / WHO / NHS
  → 提供: 机构名 + 报告标题 + 数据年份

Level 3: 顶级期刊新闻稿/科普
  → Nature / Science / JAMA 的科普栏目
  → 标注: 这是科普，不是原始论文

Level 4: 专业医生的科普
  → 公立医院/医学院附属 医生
  → 标注: 个人观点，非系统性研究

Level 5 (最低): 个人经验帖
  → 仅作参考案例，不算权威证据
  → 必须标注「个人经验」
```

## 验证工作流（已实测可用）

### Step 1: 发现线索

用知乎 API 搜中文关键词，找到相关研究提及：

```python
source /root/.hermes/.env 2>/dev/null
curl -s -G 'https://developer.zhihu.com/api/v1/content/zhihu_search' \
  --data-urlencode 'Query=睡眠不足6小时认知功能' -d 'Count=5' \
  -H "Authorization: Bearer $ZHIHU_ACCESS_SECRET" \
  -H "X-Request-Timestamp: $(date +%s)" \
  -H 'Content-Type: application/json'
```

⚠️ **知乎 API 搜到的是线索，不是 citation。** 需要提取论文名称/作者后去原始数据库验证。

### Step 2: 验证引用

用 Crossref API 确认论文基本信息：

```bash
curl -s "https://api.crossref.org/works/10.1046/j.1365-2869.2003.00337.x" | python3 -c "
import sys, json; d=json.load(sys.stdin)['message']
print('标题:', d.get('title',[''])[0])
print('期刊:', d.get('container-title', [''])[0])
print('引用:', d.get('is-referenced-by-count', 0), '次')
"
```

用 Semantic Scholar 查引用数 + 摘要：

```python
import urllib.request, json
url = "https://api.semanticscholar.org/graph/v1/paper/DOI:10.1046/j.1365-2869.2003.00337.x?fields=title,abstract,journal,year,citationCount"
resp = urllib.request.urlopen(urllib.request.Request(url), timeout=10)
# citationCount >= 1000 是高度引用的标志性论文
```

### Step 3: 按 PMID 查

如果已知 PMID，直接构造 URL 提供给用户：
- `https://pubmed.ncbi.nlm.nih.gov/12683469/`
- 工具可能被 Cloudflare 拦截，但用户自己可以打开

## 输出规范

呈现权威研究时使用标准结构：

```
### ① 研究标题简要 — 期刊名 Year
**PMID: XXXXXXXX** | 引用 NNNN 次 | 机构名

【这个研究做了什么】
- 一句话说明实验设计（多少人、分几组、测什么、多久）

【核心发现】
- 发现1：具体数据（数字）
- 发现2：具体数据（数字）

【对用户的直接意义】
- 你的情况 × 这个研究发现 = 你该知道的结论
```

**关键要点：**
- 不能用「研究表明/有一项研究说」这类模糊表达
- 每个发现必须有具体数字支撑（时间、百分比、人数）
- 如果无法访问原始论文全文，诚实说明「我已确认 PMID/DOI/引用数，但全文需用户自行查看」
- **严禁编造或杜撰研究数据**

## 这个对话中可用的研究资源

| 工具 | 用途 | 限制 |
|------|------|------|
| 知乎 API (developer.zhihu.com) | 中文关键词发现线索 | 搜到的是知乎内容，非原始论文 |
| Crossref API (api.crossref.org) | 验证 DOI 的论文元信息 | 不返回摘要 |
| Semantic Scholar API (api.semanticscholar.org) | 查引用数 + 摘要 | 有些论文无摘要返回 |

## 已验证可引用的睡眠研究

| 研究 | PMID | 引用数 | 核心结论 |
|------|------|--------|---------|
| Van Dongen 2003, Sleep | 12683469 | ~3000+ | 6h/晚 × 14天 → 认知损伤 ≈ 48h不睡 |
| Belenky 2003, J Sleep Res | 12603781 | ~1458 | 7h/晚也出现退化，3天恢复不够 |
| Mah 2011, Sleep | 21731144 | ~500+ | 延长睡眠 → 反应时间/情绪/运动表现提升 |
