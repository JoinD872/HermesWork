---
name: scrape-js-rendered-docs
description: 从 JS 渲染型文档站（如 Mintlify/Nextra）提取结构化数据的标准化方法——当 curl 返回空内容时，用浏览器控制台 JS 执行绕过动态渲染。
tags: [web, scraping, browser, mintlify, documentation, SPA]
category: web
risk: read-only
---

# JS 渲染型文档站抓取方法（browser_console JS 提取）

## 适用场景
- `curl` / `wget` 抓取返回裸 HTML（只有 `<div id="__next">` 或空壳）
- 文档站用 Mintlify、Nextra、Docusaurus 等 SPA 框架
- 需要提取日期标题、卡片内容、API 条目等结构化数据

## 核心方法：browser_console JS 提取

```javascript
// 方法1：按 data-component-part 属性提取卡片内容
const cards = document.querySelectorAll('.card');
let results = [];
cards.forEach(card => {
    const titleEl = card.querySelector('[data-component-part="card-title"]');
    const contentEl = card.querySelector('[data-component-part="card-content"]');
    const h4 = card.closest('div').previousElementSibling;
    const date = h4 ? h4.textContent.replace('Navigate to header', '').trim() : 'unknown';
    if(titleEl && contentEl) {
        results.push(date + ' | ' + titleEl.textContent + ' | ' + contentEl.textContent.substring(0, 200));
    }
});
results.join('\n');
```

```javascript
// 方法2：按 h2/h4 标题 + ul>li 列表提取 API 更新
const headings = document.querySelectorAll('h2');
let results = [];
headings.forEach(h => {
    if(h.textContent.includes('2025') || h.textContent.includes('2024')) {
        const date = h.textContent;
        const listItems = h.nextElementSibling ? Array.from(h.nextElementSibling.querySelectorAll('li')).map(li => li.textContent) : [];
        results.push(date + ' | ' + listItems.join('; '));
    }
});
results.join('\n');
```

## 标准抓取流程

1. **browser_navigate** → 目标 URL
2. **browser_click** → 展开需要交互的元素（如 "Learn More" 链接或 section 标题）
3. **browser_console** → 执行 JS 提取表达式（比 browser_snapshot 更精确）
4. **browser_vision** → 视觉验证（如需截图确认）
5. 对比上次记录 → 判断是否有新增

## MiniMax 文档站特定提取模式

MiniMax 文档站 (platform.minimax.io) 使用 Mintlify 框架，结构特点：

### Models 页面（h4 标题 + 后续节点内容）

```javascript
const results = [];
const headings = document.querySelectorAll('h4');
headings.forEach(h => {
  const dateText = h.textContent.trim();
  if (!dateText || dateText.includes('Navigate')) return;
  
  let content = '';
  let sibling = h.nextElementSibling;
  
  // Collect content until next h4
  while (sibling && sibling.tagName !== 'H4') {
    const items = sibling.querySelectorAll('li');
    items.forEach(li => {
      const text = li.textContent?.trim() || '';
      if (text) content += text + ' ';
    });
    if (!content && sibling.textContent?.trim()) {
      content += sibling.textContent.trim() + ' ';
    }
    sibling = sibling.nextElementSibling;
  }
  
  if (content.trim()) {
    results.push({ date: dateText.replace('Navigate to header ', ''), content: content.trim().substring(0, 500) });
  }
});
JSON.stringify(results);
```

### APIs 页面（h2 标题 + ul>li 列表）

```javascript
const results = [];
const headings = document.querySelectorAll('h2');
headings.forEach(h => {
  const dateText = h.textContent.trim().replace('Navigate to header ', '');
  if (!dateText || dateText === 'Documentation Index') return;
  
  let content = '';
  let sibling = h.nextElementSibling;
  
  while (sibling && sibling.tagName !== 'H2') {
    const items = sibling.querySelectorAll('li');
    items.forEach(li => {
      const text = li.textContent?.trim() || '';
      if (text) content += text + ' ';
    });
    if (!content && sibling.textContent?.trim()) {
      content += sibling.textContent.trim() + ' ';
    }
    sibling = sibling.nextElementSibling;
  }
  
  if (content.trim()) {
    results.push({ date: dateText, content: content.trim().substring(0, 300) });
  }
});
JSON.stringify(results);
```

### Pricing 页面

Pricing 页面主要是视觉卡片，结构化数据较少，用 browser_vision 截图验证即可。

## 备选方法：直接正则扫描原始 HTML

当 `__NEXT_DATA__` 不存在且 DOM 中也无结构化元素时，内容可能直接嵌入为 JS 字面量。此法无需浏览器工具，直接 `curl` + 正则即可提取：

```python
import re

with open('page.html', 'r', encoding='utf-8', errors='ignore') as f:
    html = f.read()

# 提取 __NEXT_DATA__ (如果存在)
next_data = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.DOTALL)
if next_data:
    data = json.loads(next_data.group(1))
    # 解析 data['props']['pageProps']['someContent']
    print(json.dumps(data, indent=2)[:3000])

# 备选：扫描 JS 字符串字面量中的发布记录
# Mintlify/Nextra 将内容以 JS 字符串嵌入，模式如 "Released X" / "Launched X"
patterns = [
    r'"Released\s+([^"]+)"',
    r'"Launched\s+([^"]+)"',
    r'"Introduced\s+([^"]+)"',
    r'"Announced\s+([^"]+)"',
]
entries = []
for pattern in patterns:
    matches = re.findall(pattern, html)
    for m in matches:
        if 10 < len(m) < 500:  # 过滤噪音
            entries.append(m.strip())

entries = list(dict.fromkeys(entries))  # 去重保序
for e in entries:
    print(f"  • {e[:200]}")
```

**适用场景**：MiniMax platform.minimax.io 的 release-notes/models 页面  
**已知局限**：只能提取 active-voice 描述性文本，无法获取精确日期（需回查页面 metadata）

## 已知坑点

| 坑 | 根因 | 解法 |
|----|------|------|
| curl 只返回 HTML 壳 | Next.js SPA 未执行 JS 渲染 | 用 browser_navigate + browser_console |
| browser_snapshot 截断 | 长页面只显示前 N 行 | 用 browser_console JS 表达式按需提取 |
| 点击 "Learn More" 跳走 | 链接实际指向详情页 | 用 h.closest('div').previousElementSibling 取日期标题 |
| SPA 内容加载时序 | 元素在 DOM 中但未填充 | 在 browser_navigate 后等 snapshot 稳定 |
| TOC 侧边栏干扰提取 | browser_snapshot 显示 StaticText 混杂 | 用 browser_console 执行 JS 直接提取正文区域 |
| dateText 含 "Navigate to header" | 标题元素包含可访问性文本 | `.replace('Navigate to header ', '')` 清除 |
| __NEXT_DATA__ 不存在 | 内容直接嵌入 JS hydration 字符串 | 改用正则扫描 "Released X" 等 JS 字面量模式 |
| page metadata 有 lastModified | 页面无单条日期但有全局更新时间 | 从 HTML 中提取 `lastModified` 字段判断新鲜度 |

## 验证步骤
1. 提取结果包含预期的日期 + 标题 + 摘要
2. 与上次扫描记录对比，确认无遗漏
3. 视觉确认关键条目（如新版模型发布）在页面可见
