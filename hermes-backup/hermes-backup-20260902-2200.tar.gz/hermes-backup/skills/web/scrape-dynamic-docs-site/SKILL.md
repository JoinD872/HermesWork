---
name: scrape-dynamic-docs-site
description: 抓取动态渲染文档站点的标准化方法 — 当 curl/wget 返回空内容或原始HTML时，使用浏览器JS提取
tags: [web, scraping, dynamic-rendering, browser-automation]
category: web
risk: read-only
---

# 抓取动态渲染文档站点（curl 失败时的备选方案）

## 问题
用 `curl -s URL | python3` 抓取文档页面时，返回空内容或只有 JS 框架代码。常见于：
- Next.js / Mintlify 文档站点
- Docusaurus（client-side rendering）
- 任何 heavy SPA

## 症状
- HTML size 很大但 `python3 -c "print(len(sys.stdin.read()))"` 提取不到文本
- `document.body.textContent` 在 python 解析后为空
- 页面在浏览器中正常显示，但 curl 拿到的是空白壳

## 解决方案：browser_console(expression) JS 提取

```python
# 1. 用 browser_navigate 加载页面
browser_navigate(url="https://platform.minimax.io/docs/release-notes/models")

# 2. 用 browser_console(expression) 执行 JS 提取结构化数据
browser_console(expression="""
const headings = document.querySelectorAll('h4');
const result = [];
headings.forEach(h => {
    if(h.textContent.includes('2026')) {
        result.push({
            text: h.textContent,
            next: h.nextElementSibling ? h.nextElementSibling.textContent.substring(0, 200) : 'none'
        });
    }
});
result;
""")
```

## 常用 JS 提取模式

### 提取所有标题 + 下一元素文本
```javascript
document.querySelectorAll('h1,h2,h3,h4').forEach(h => console.log(h.textContent.trim() + ' | ' + (h.nextElementSibling?.textContent||'').trim().substring(0,100)))
```

### 提取导航菜单项
```javascript
document.querySelectorAll('.toc-item, [class*="sidebar"] a').forEach(a => console.log(a.textContent.trim()))
```

### 提取页面所有文本（兜底）
```javascript
document.body.textContent.replace(/\s+/g, ' ').trim().substring(0, 3000)
```

## 已知动态渲染文档站点
| 站点 | 特征 | 是否动态 |
|------|------|---------|
| platform.minimax.io | Mintlify/Next.js | ✅ 是 |
| docs.anthropic.com | Docusaurus | ✅ 是 |
| platform.openai.com | SPA | ✅ 是 |
| github.com/*/README.md | 静态 HTML | ❌ 否 |

## 验证步骤
1. `curl -s URL | wc -c` 检查原始大小
2. `curl -s URL | python3 -c "import sys; print(len(sys.stdin.read()))"` 确认
3. 用 browser 加载 + browser_console 提取对比
4. 如果 browser_console 返回内容远多于 curl → 确认是动态渲染

## MiniMax docs 特殊提取技（2026-04-30 发现）

MiniMax 文档使用 Mintlify/MDX，内容以**编译后的 JS 对象形式**嵌入在 `self.__next_f.push([1,"..."])` 脚本标签中。无需启动浏览器，直接 grep 即可提取结构化文本：

```bash
curl -s --max-time 20 "https://platform.minimax.io/docs/release-notes/models" | \
  grep -o 'self\.__next_f\.push(\[1,"[^"]*"\]' | \
  sed 's/self\.__next_f\.push(\[1,"//;s/"\]//' | \
  python3 -c "import sys,json; data=sys.stdin.read(); print(data[:5000])"
```

**注意**：cron 环境下慎用 browser 工具（启动开销大、可能超时），优先用 curl + 正则提取 HTML 内嵌数据。

### 适用场景
- 文档站点使用 Mintlify/Docusaurus MDX 编译
- 页面内容在 HTML 中以 JS 字符串形式存在
- cron/script 环境避免浏览器依赖

### 已验证可用页面
| 页面 | URL pattern |
|------|------------|
| Models release notes | `/docs/release-notes/models` |
| APIs release notes | `/docs/release-notes/apis` |
| Pricing overview | `/docs/pricing/overview` |

## 注意事项
- 每次 `browser_navigate` 后等页面完全加载再执行 JS
- `browser_console` 的 expression 是同步的，适合提取 DOM 内容
- 不要在 expression 里执行耗时操作（如 fetch）
- 动态站点通常有反爬，避免频繁请求
