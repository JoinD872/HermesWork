---
name: china-domestic-site-scraping
description: 国内站点（政府/教育/新闻/微信）从海外 VPS 抓取 — 降级链、上海桌面 SSH 抓取、搜狗微信搜索、站内搜索接口发现、学校公告检索
risk: read-only
---

# 国内站点抓取（海外 VPS 视角）

> 2026-07 验证。原 `vps-domestic-site-access`（手动创建、已锁定、凭据过期）仅作背景参考，**实操以本 skill 为准**。

## 核心判断

- VPS（LA）→ 国内站：curl 部分通、browser 经常超时；百度/必应搜索页全被反爬（验证码）
- **本地 SearXNG（localhost:8888）主力引擎曾全废**（2026-08-02 实测 brave/ddg/startpage/google 全挂，根因=本 VPS 数据中心 IP 信誉差 Spamhaus ZEN+CBL），**已修复：显式启用 baidu/quark/sogou 后中文搜索恢复**（2026-08-05 实测搜 "opencode go" 返回 32 条，含 CSDN/博客园/微信公众号结果）。详见下方「SearXNG 本地实例」节；主搜索引擎被 IP 风控时的首选搜索通道
- **CF Worker 反代（rss.cloudjoind.com）→ 国内站稳定可达**，被墙站（豆瓣等）首选通道，**无需 SSH 私人电脑**
- **上海桌面（Tailscale SSH）→ 国内站可达**，是最后手段（依赖用户私人电脑在线），优先用 CF 反代
- **微信内容：搜狗微信搜索 VPS curl 直连可用**，无需桌面

## 降级链（按优先级）

```
1. SearXNG 搜索（2026-08 实测引擎基本全废，主力引擎被 IP 风控；可作为碰运气通道，别依赖）
2. CF Worker 反代 rss.cloudjoind.com（被墙站首选，VPS 直连即可，无需 SSH 跳板）
3. 搜狗微信搜索（微信内容首选，VPS curl 直连）
4. 目标站内搜索接口（抓首页 HTML 找 <form action>）
5. 上海桌面 PowerShell Invoke-WebRequest（国内 IP，最后手段——需用户私人电脑在线）
6. 用户协助手动提取（最后手段，F12 → copy(document.body.innerText)）
```

## CF Worker 反代（2026-08 新增，优先于 SSH 桌面）

**访问任何国内被墙/风控的 URL，直接在 VPS 上 curl，把完整 URL 拼在反代域名后：**

```bash
# 基础用法：https://rss.cloudjoind.com/<完整目标URL>
curl -s -m 25 -L "https://rss.cloudjoind.com/https://movie.douban.com/"
curl -s -m 25 -L "https://rss.cloudjoind.com/https://www.zhihu.com/"
curl -s -m 25 -L "https://rss.cloudjoind.com/https://rsshub.ktachibana.party/douban/movie/playing"

# 带 query string 的 URL 原样拼在后面即可
curl -s -m 25 -L "https://rss.cloudjoind.com/https://api.bilibili.com/x/web-interface/popular?ps=2"
```

**要点：**
- 免费额度 10万请求/天，用量监控脚本 `/root/.hermes/scripts/cf_worker_usage.py`（已接入老V每日巡检 cron，>80% 告警）；当前用量 <1%，随便用
- 豆瓣/知乎/17173/百度/上海政府(shbsq.gov.cn)/搜狗微信实测可用；B站返回 412（B站封 CF IP 段，但 B站 VPS 直连本来就通，不需要反代）
- ⚠️ **CSDN 双通道全堵（2026-08-05 实测）**：VPS 直连 HTTP 000（网络层封锁）、CF 反代 521（源站拒 CF 边缘 IP），CSDN 文章全文抓不到。**但本地 SearXNG（baidu/quark/sogou）能搜到 CSDN 标题+摘要（含正文关键数据）**，写评论/调研用摘要就够，别死磕全文
- ⚠️ **CF 反代不是万能通道**：源站级风控照样挡（2026-08-05 实测知乎搜索 403、Google 429，与 bsedu 522 同类：源站拒 CF 边缘 IP）。被封时回退本地 SearXNG 摘要，别反复重试反代
- ⚠️ **源站级地域封锁绕不过**：若目标站主动拒绝境外 IP（如宝山教育信息网 bsedu.org.cn 全系，含 school.bsedu.org.cn），CF 反代返回 **522 Connection timed out**（CF 边缘连源站超时，~20s）或 530。这不是反代配置问题，是源站只放行国内 IP。**诊断链：VPS 直连 000/超时 + CF 反代 522 = 源站地域封锁**，CF Workers 无法解决，只能靠国内 IP（上海桌面 SSH / 手机出口代理 / 国内云函数）
- ⚠️ **bsedu 域名必须带 www**：SSH 桌面（国内 IP）实测 `www.bsedu.org.cn` ✅ 200（唯一可用入口），裸域名 `bsedu.org.cn` ❌ 无 DNS/超时。抓取/测试一律用 `https://www.bsedu.org.cn/`，**不要省略 www**（2026-08-02 踩坑：传达消息时漏写 www 造成误解）
- ⚠️ **bsedu 的 200 仅限 SSH 桌面通道**：2026-08-02 朵朵用 CF 反代三次实测（带 www 的首页/详情页/栏目页）全部 522（19-21s 稳定超时），对照组（知乎/上海政府/搜狗微信）同批次 200 正常——**CF 反代对 bsedu 任何 URL 均无效，勿再重试，直接走 SSH 桌面**
- 超限行为：免费版 fail-open（请求绕过 Worker 直连），不致命
- **CF 额度/计费速查（官方核实 2026-08-02）**：免费版**不自动扣费、不自动升级**（超限=Error 1027 服务降级，不是账单）；付费版 $5/月保底含 1000万请求/月，超出 +$0.30/百万，无 egress 费；唯一自动扣费点=域名 auto-renew（~$10/年）；免费版限 1 个 Worker。**Analytics 面板**：Total requests=整个域名全部流量（大头是 proxy.cloudjoind.com 翻墙隧道，不是反代），Worker invocations=仅 cf-proxy 调用数（可用 `cf_worker_usage.py --days 1` 核对）。完整计费公式/Token 权限边界见 skill `cloudflare-worker-reverse-proxy`
- 详细部署/排障见 skill `cloudflare-worker-reverse-proxy`

**决策：能用 CF 反代就不 SSH 私人电脑** — 反代零依赖（不用等用户电脑开机）、不消耗 Tailscale 链路、不碰 PowerShell 编码坑。

**延迟实测对比（2026-08，movie.douban.com）**：单次请求 SSH 更快（0.44s vs CF 1.2s，国内直连物理优势），但**端到端** CF 反代快 3-5 倍——SSH 需握手 1-3s + PowerShell 启动 1-2s + 回传 1-2s ≈ 3.4-6s，CF 无连接开销 ≈1.2s；批量 5 站 CF 10.1s（可并行≈3s）vs SSH 17-25s（无法并行）。结论：朵朵多步抓取场景 CF 反代明显更优。

## 手机出口代理（源站地域封锁的零成本解法，2026-08 实测后放弃）

> ⚠️ **2026-08-02 实测结论：方案放弃。** Android 上 Tailscale 与 NekoBox（即使服务端模式）**都使用 VpnService，实测互相顶掉**（A 开 B 关），无法同时运行。备选 Termux + SSH 反向隧道（手机主动连 VPS 暴露本地 SOCKS5，不占 VpnService）理论可行但用户放弃继续配置。**bsedu 类站维持 SSH 电脑兜底，不再考虑手机方案。** 以下为方案评估期间的完整记录，留作未来参考。

当目标站只认国内 IP（bsedu 类 522）且不想依赖私人电脑开机时，曾考虑用用户手机做国内出口：

```bash
VPS ──Tailscale──> 荣耀手机 NekoBox(服务端模式) ──> 目标站
     (走中继)        (出口=手机国内4G/WiFi IP)
```

- **用户手机是荣耀（Android/MagicOS）**，用 **NekoBox**（免费开源）——不要用 Shadowrocket（那是 iOS 的）
- ⚠️ **NekoBox 不在 Google Play 上架**（代理/VPN 类 App 被 Play 政策限制，v2rayNG/sing-box 同理）。从 GitHub 官方仓库 `MatsuriDayo/NekoBoxForAndroid` 下载：最新 1.4.2，荣耀等骁龙/麒麟/天玑芯片选 `arm64-v8a` APK（14.5MB），手机浏览器打开 releases 页直接下载，安装需允许"未知来源应用"
- **Tailscale 国内手机登录无响应**（点 Log in 没反应 = Google OAuth 被墙）：用 auth key 方案绕过——电脑浏览器登录 `login.tailscale.com/admin/settings/keys` 生成一次性 key（有效期 1 day），手机 Tailscale 登录页选 "Use auth key" 粘贴；注意 VPS 侧没有 Tailscale API token，无法代生成 key
- NekoBox 开"服务端模式"生成 SOCKS5/HTTP 代理端口；手机装 Tailscale 与 VPS 同账号，VPS 经 Tailscale IP 连手机（无需手机公网 IP）
- **荣耀系统坑**：MagicOS 电池管理激进，必须在"应用启动管理"把 NekoBox 和 Tailscale 设为**手动管理 + 允许后台运行**，否则被系统杀掉代理断线
- 耗电/性能基本无感（网页/API 为 KB 级，CPU <1%，无流量时一晚 1-2%）
- 代价：手机需保持联网 + App 常驻；目标站看到的是手机 IP（公开网站无碍）

## 上海桌面抓取（DaLao，2026-07 当前机器）

- 机器：Tailscale `100.108.175.15`，SSH 用户 `61915`，工作目录 `E:\Hermes`
- **旧机器 `100.86.150.37` / `joind` 已下线，勿用**
- 方法：PowerShell `Invoke-WebRequest` + `WriteAllText` UTF-8 落盘 + scp 回 VPS 解析（详见 `references/windows-desktop-scraping-current.md`）
- 坑：PowerShell 控制台直接输出中文乱码，必须 UTF-8 落盘；Edge headless `--dump-dom` 常返回 0 字节不可靠
- ⚠️ **SSH 传内联 PowerShell 引号必炸（2026-08 朵朵踩坑）**：`ssh host 'powershell -Command "...'` 复杂命令常静默失败（exit 0 但无输出，或引号嵌套错乱）。**解法：本地写 .ps1 → scp 到 E:\Hermes\ → `powershell -NoProfile -ExecutionPolicy Bypass -File E:\Hermes\xxx.ps1`**。批量抓取一律走此模式，不要 inline
- ⚠️ **scp 回拉 Windows 路径格式**：`scp user@host:'E:\Hermes\f.html' /tmp/` 会报 No such file（反斜杠转义问题）；**用 `"61915@100.108.175.15:E:/Hermes/f.html"`（双引号 + 正斜杠）** 才能成功
- 批量抓取：一条 PowerShell 里 foreach + 写多文件，减少 SSH 往返
- ⚠️ **用后清理 + 透明告知**：用户在意私人电脑被借用（2026-08 朵朵查幼儿园公告用桌面抓取后，用户专门追问数据来源）。规则：① 抓取产生的临时 HTML 文件（E:\Hermes\*.html）用完必须删除（`Get-ChildItem ... | Remove-Item -Force`）；② 向用户如实说明用了其电脑做了什么（只读网页请求、无系统改动、已清理）；③ 能走 CF 反代就先走反代，桌面是最后手段

## 淘宝商品页抓取（2026-08 朵朵实测，产品评估场景）

**场景**：用户甩来淘宝分享短链（`e.tb.cn/h.xxx?tk=xxx`）让评估某商品（如幼儿园床垫/母婴用品）。

- **短链解析（必做第一步）**：淘宝 PC 短链经 CF 反代 curl 可拿到跳转页，JS 变量 `url` 里带真实商品页 `item.taobao.com/item.htm?id=xxx&price=xxx`（**价格就藏在短链跳转页**，不用点进商品页）。命令：`curl -s -m 25 -L "https://rss.cloudjoind.com/https://e.tb.cn/h.xxx?tk=xxx"`，然后 grep `item.taobao.com` 取 id 和 price
- ⚠️ **PC 商品详情页是登录墙**：`item.taobao.com/item.htm?id=` 直接抓只返回 login 跳转脚本（windvane/sdkLogin），无任何商品数据。**别死磕 PC 详情页**，也别用浏览器导航（CDP 超时）
- **免登录详情通道（2026-08 新发现，优先用）**：`my.world.taobao.com/item/<id>.htm` 经 CF 反代直接返回商品名/价格/店铺名/三项评分/最新买家评价（繁体页），无需登录。拿到商品 ID 先试这个，不够再抓软文页
- **替代通道（实测可用）**：用 SearXNG（duckduckgo 引擎能出中文结果）搜「品牌名+品类关键词」，找同商品的 **淘宝百科 `bk.taobao.com/k/...`** 和 **淘宝好物网 `goods.taobao.com/t/...`** 文章页——这些是软文/种草页，经 CF 反代可全文抓取，含规格描述 + **真实买家评价**（「商品点评与口碑」区，用户名半掩码如"无**豆"），足以支撑产品评估
- **京东 ⚠️ 同样风控**：`item.jd.com` 详情页经 CF 反代返回 JDR_shields 验证页，别死磕；用搜索引擎 snippet（京东 item 页 snippet 常含完整规格，如"总厚5.5cm=5cm软硬双面POE"）
- 完整流程与命令见 `references/taobao-product-scraping.md`

## 品牌背景调查 / 假洋牌识别（2026-08 朵朵实测，Tamoro 案例）

**场景**：用户看中某品牌（尤其"日本/德国/澳洲/美国"前缀的洋名品牌）要求"调查一下品牌背景"。目标：识别假洋牌（国产贴牌穿洋马甲），帮用户判断溢价是否值得。

**调查链路（全部走 SearXNG + 公开工商查询，无需登录）：**
1. **搜商标**：`<品牌名> 商标 注册` → 爱企查商标页 snippet（`aiqicha.baidu.com/mark/markDetail`）给出注册号/申请人/申请时间
2. **搜公司**：`<申请人公司名>` → 企查查/爱企查 snippet 给出注册资本/成立时间/法定代表人/行业/地址
3. **抓官网**：`curl` 官网 → 403 时走 CF 反代 → 看是否空壳（只有一行 © 版权 = 空壳）
4. **搜口碑**：`<品牌名> 评价` → 区分真实用户 vs 软文（sohu/smzdm/toutiao 批量"实测"文 = 投放）

**假洋牌判定信号（2026-08 Tamoro"他米乐"实锤）**：
- 商标申请人 = **注册资本 1 万元**、行业"软件和信息技术服务业"的信息科技公司（轻资产贴牌，无工厂）
- 商品标题普遍挂"日本/德国"前缀，但官网空壳、无生产基地信息
- 大量 sohu/smzdm 软文"实测"，真实用户口碑稀缺
- 结论模板：明确告诉用户"这不是外国品牌，是国产贴牌"，别为洋名付溢价；购买决策回到 价格+认证+尺寸 三硬条件

**⚠️ 爱企查/企查查详情页正文是动态加载，curl 只拿得到标题**；有效数据全在搜索引擎 snippet 里，多换几个 query 词榨 snippet。详见 `references/brand-background-investigation.md`
- **幼儿园/母婴用品选购**（床垫/被子等，含尺寸/材质/安全指标/已调研品牌）：`references/kindergarten-supplies-buying-guide.md`

## 搜狗微信搜索

- `weixin.sogou.com/weixin?type=2&query=` 搜文章；`type=1` 搜公众号
- 时间戳藏在 `<script>document.write(timeConvert('UNIX'))</script>`，必须转换判断新旧（结果默认按相关性排且不显示日期）
- ⚠️ **正文跳转被 antispider 拦截（2026-08 朵朵实测）**：结果页每条文章是 `/link?url=...`，点击会 302 到 `weixin.sogou.com/antispider/`，**拿不到真实 mp.weixin.qq.com 文章 URL**；VPS curl、CF 反代、SSH 桌面（国内 IP）三种通道全部被拦。解法：**用搜索结果页的标题+snippet+timeConvert 组合做交叉验证**（snippet 常含关键数据，如等级、统筹去向、口碑评价），不要死磕正文；需要正文时改搜该标题在其他平台的转载
- 详见 `references/sogou-wechat-search.md`

## 学校/幼儿园公告检索（2026-07 宝山案例验证，2026-08 朵朵二次实战补充）

- 渠道链：① 学校官网子站（常停更）→ ② 区教育局信息网（投稿活跃，最值得挖）→ ③ 微信公众号（索引延迟）→ ④ 家长群/电话（内部渠道，公开搜不到）
- JEECMS 系站内搜索 `/search.jspx?q=`；新闻 ID 单调递增可估时间线；详情页"作者/来源"字段可确认投稿单位（如"作者:菊泉实验幼儿园 来源:菊泉实验幼儿园"）
- ⚠️ **JEECMS 长关键词返回空（2026-08 朵朵实测）**：`q=` 带 2+ 个完整词（如"菊泉实验幼儿园等级"）返回 0 条；**用单关键词（园名"菊泉"、主题词"高质量幼儿园""幼儿园入园"）才出结果**。搜索要按"园名 / 主题词"拆开多搜几次，不要拼长句
- ⚠️ **JEECMS 搜索接口分页参数（page / pageNo / currentPage）实测均无效**，只返回前 10 条（页面显示"共找到 N 条"但看不到其余）；要覆盖全量需换关键词（全名 / 简称 / 园自称如"泉童"）缩小范围
- **学校子站定位法（2026-08 验证）**：宝山学校官网统一入口 `school.bsedu.org.cn/index.html` 列出全区学校拼音缩写子站（如菊泉实验幼儿园 = shjqsy）；子站首页含园所档案（成立时间/性质/面积/理念），但栏目页常停更/404——**动态要去区教育局信息网"一句话新闻(yjhxw)/区域动态(qydt)"栏目找**
- 完整「XX幼儿园/学校怎么样」调研工作流（渠道优先级/分步执行/报告结构/菊泉案例）见 `references/kindergarten-research-playbook.md`
- 幼儿园动态的公众号渠道常缺失：搜狗微信搜园名只出招聘/旧闻（时间戳 `timeConvert('UNIX')` 判断，如菊泉最新仅 2023-08 招聘），活动报道实际都发在区教育局信息网"一句话新闻"类栏目
- 详见 `references/china-school-announcement-search.md`

## 搜索页反爬速查（2026-07 实测）

| 引擎 | VPS | 上海桌面 |
|------|-----|---------|
| 百度搜索 | 302→安全验证 | 同样安全验证 |
| 必应 | "One last step" 验证码 | 乱码/无关结果 |
| 搜狗微信 | ✅ curl 直连 | — |
| 淘宝搜索 s.taobao.com | JS 空壳（~33KB 无商品数据）| — |
| 淘宝 PC 详情 item.taobao.com | 登录墙；**用 my.world.taobao.com 免登录** | — |
| 1688 s/m.1688.com | x5secdata punish 验证码，全拦 | — |
| 京东 item/mall.jd.com | JDR_shields 风控壳；**用搜索 snippet 拿规格** | — |

**结论：不要反复重试百度/必应搜索页，直接跳搜狗微信或站内搜索接口。电商类：淘宝短链+world 通道 / 京东靠 snippet / 1688 全拦，别死磕。**

## SearXNG 本地实例（2026-08-02 修复）

- **问题**：VPS 数据中心 IP（192.3.241.244，Spamhaus+CBL 黑名单）导致主要引擎全被风控——brave(限流)/ddg(验证码)/startpage(验证码)/qwant(denied)/google 全挂，默认搜索 0 结果
- **修复**：`/root/searxng/searxng/settings.yml` 显式启用 **baidu / quark / sogou**（中文精准，实测 200）+ bing/wikipedia 兜底；**禁用 17 个必挂引擎**（避免每次搜索等超时）；`default_lang: zh-CN`
- **实测**：宝山教育/上海教委/北京天气/python教程 19-29 条，baidu 中文精准（宝山教育信息网首页）
- **坑**：bing 表面可用（返回 10 条）但中文结果是垃圾（Canva/Google Maps 等无关内容），只作英文/技术兜底，中文靠 baidu/quark
- **配置方式**：docker 挂载 `/root/searxng/searxng` → `/etc/searxng`，改 settings.yml 后 `docker restart searxng`
- **若 baidu/quark 也被封**：需要给 SearXNG 配 HTTP 代理出口（如 CF 反代不可用于引擎请求，需国内 IP 代理）

## 相关技能边界

- `vps-domestic-site-access`（锁定）：含小红书等 SPA 站反爬深度分析，仍可参考；但其 SSH 凭据与百度结论已过期
- `research-workflow`（锁定）：通用搜索规范，中文搜索坑见本 skill
