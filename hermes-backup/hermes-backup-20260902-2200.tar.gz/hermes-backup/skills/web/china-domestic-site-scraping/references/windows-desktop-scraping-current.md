# 上海桌面抓取 — Invoke-WebRequest 实操（2026-07 验证）

## 当前机器凭据

- **DaLao**：Tailscale `100.108.175.15`，SSH 用户 `61915`，工作目录 `E:\Hermes`
- SSH 密钥默认（`/root/.ssh/id_ed25519`），命令：`ssh -o ConnectTimeout=8 -o StrictHostKeyChecking=no 61915@100.108.175.15 "..."`
- 旧机器 `100.86.150.37` / `joind` 已下线（desktop-tg4loen decommissioned）

## 首选方法：Invoke-WebRequest + UTF-8 落盘 + scp 回 VPS

```bash
# 1. 抓取并落盘（单 URL）
timeout 90 ssh -o ConnectTimeout=8 -o StrictHostKeyChecking=no 61915@100.108.175.15 "powershell -Command \"\$r = Invoke-WebRequest -Uri 'https://目标站/路径' -UseBasicParsing -TimeoutSec 25 -Headers @{'User-Agent'='Mozilla/5.0'}; [System.IO.File]::WriteAllText('E:\Hermes\page.html', \$r.Content, [System.Text.Encoding]::UTF8); Write-Output ('len=' + \$r.Content.Length)\""

# 2. scp 拉回 VPS 解析（Windows 路径用正斜杠）
timeout 30 scp -o StrictHostKeyChecking=no "61915@100.108.175.15:E:/Hermes/page.html" /tmp/page.html
```

## 批量抓取（减少 SSH 往返）

```powershell
# 一条 PowerShell 循环抓多页
foreach ($c in @(2,3,9)) {
  $r = Invoke-WebRequest -Uri ('https://目标站/栏目/' + $c) -UseBasicParsing -TimeoutSec 20
  [System.IO.File]::WriteAllText(('E:\Hermes\cat' + $c + '.html'), $r.Content, [System.Text.Encoding]::UTF8)
}
```

## 关键坑

1. **中文乱码**：PowerShell 控制台 Write-Output 中文必乱码（GBK），必须 `[System.IO.File]::WriteAllText(path, $r.Content, [System.Text.Encoding]::UTF8)` 落盘再 scp。不要在控制台打印中文内容。
2. **SSH 转义**：外层双引号内的 `$` 要写成 `\$`。
3. **Edge headless `--dump-dom` 不可靠**：对国内站点常返回 **0 字节**文件（2026-07 实测两次均空）。只把 Edge headless 当截图工具用，抓文本一律 IWR。
4. **JS 壳站**：部分政府站首页只有导航框架（IWR 拿到的 8-20KB 无正文），需找站内搜索接口或详情页 URL（见 china-school-announcement-search.md）。
5. **超时容错**：单 URL 失败（超时/断连）就 foreach 重试一次；批量时 catch 住单个失败不中断整批。

## 已验证可达的国内站点（上海桌面 IWR）

- www.bsedu.org.cn（宝山教育信息网）✅ 200
- school.bsedu.org.cn（学校子站）✅ 200
- www.shbsq.gov.cn（宝山区政府）✅ 200（JS 壳）
- weixin.sogou.com（搜狗微信，VPS curl 也可）✅

## 反爬搜索页（均失败，勿重试）

- baidu.com/s?wd= → 302「百度安全验证」（VPS 与上海桌面都触发）
- bing.com/search → 验证码；cn.bing → 乱码/无关结果
