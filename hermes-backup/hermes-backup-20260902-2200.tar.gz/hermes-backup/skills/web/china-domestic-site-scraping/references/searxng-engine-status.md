# SearXNG 引擎状态与修复（2026-08-02 实测 + 已修复）

## 结论

本地 SearXNG 实例（localhost:8888，Docker）服务正常在跑，但**主力引擎曾被 IP 风控打废**（朵朵评价"引擎基本废了"完全准确）。**2026-08-02 已修复**：启用 baidu/quark/sogou 后中文搜索恢复正常（19-29 条/查询）。

## 问题实测数据（修复前）

服务状态：8888 端口监听正常（docker-proxy），searxng 主进程 + worker-1 正常。

引擎可用性（修复前，多关键词实测：宝山教育/北京天气/python 教程/今日新闻，全部一致）：

| 引擎 | 状态 | 报错 |
|------|------|------|
| brave | ❌ Suspended | too many requests（被限流） |
| duckduckgo | ❌ CAPTCHA | 验证码拦截 |
| startpage | ❌ CAPTCHA | 验证码拦截 |
| karmasearch | ❌ access denied | 被拒绝访问 |
| google | ❌ | 0 条 |
| qwant / mojeek / yep | ❌ access denied | 被拒绝访问 |
| presearch | ❌ timeout | 超时 |
| wikipedia | ✅ 偶出 | 唯一能返回的引擎（英文词） |

## 根因

**VPS 出口 IP 信誉差**（192.3.241.244，Spamhaus ZEN + CBL 双黑名单，HostPapa 数据中心 IP）——搜索引擎对数据中心 IP 风控严格。与豆瓣 000、微博 403、Scamalytics 拦截是**同一个根因**。不是 SearXNG 配置问题。

## ✅ 修复方案（2026-08-02 已执行）

配置：`/root/searxng/searxng/settings.yml`（docker 挂载 `/root/searxng/searxng` → `/etc/searxng`），改后 `docker restart searxng`。

1. **显式启用**：`baidu` / `quark` / `sogou`（中文精准，实测可用）+ `bing` / `wikipedia` 兜底
2. **禁用 17 个必挂引擎**：brave / duckduckgo / startpage / qwant / mojeek / yep / google / google scholar / yahoo / presearch / marginalia / curlie / searx / karmasearch / bing images / bing news / bing videos——留着只会每次搜索等超时
3. **`default_lang: zh-CN`**

修复后实测（多关键词）：宝山教育 26 条 / 上海市教委 26 条 / 北京天气 29 条 / python教程 19 条 / 幼儿园招生 19 条——baidu + quark 中文精准（宝山教育信息网首页、上海教委官网、天气网、入园政策）。

## 坑：bing 表面可用实则中文垃圾

bing 单引擎测试返回 10 条，但中文查询结果全是无关内容（Canva 登录页、Google Maps、瑞士地图等）——Bing 对数据中心 IP 的中文搜索做了降级处理。**bing 只作英文/技术词兜底，中文搜索靠 baidu/quark。**

## 复现/验证命令

```bash
# 服务状态
ss -tlnp | grep :8888
ps aux | grep -i searxng

# 引擎可用性测试（中文必须 urllib.parse.quote 编码）
curl -s -m 20 "http://localhost:8888/search?q=宝山教育&format=json" | python3 -m json.tool
# 关注 results[]（结果数）与 unresponsive_engines[]（失效引擎+原因）

# 单引擎测试
curl -s -m 20 "http://localhost:8888/search?q=宝山教育&format=json&engines=baidu"
```

## 若再次失效（IP 信誉变化或引擎策略调整）

- baidu/quark/sogou 也被封 → 给 SearXNG 配 HTTP 代理出口（settings.yml `outgoing.proxies`），注意 CF 反代不可用于引擎请求（CF 节点也是数据中心 IP），需国内 IP 代理
- IP 黑名单移除（CBL/Spamhaus 清干净）后 → 可逐个重新启用被禁引擎，用上面的单引擎测试命令验证
