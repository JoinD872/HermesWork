# 搜狗微信搜索 — 微信文章/公众号检索（VPS curl 直连可用）

微信内容唯一的公开搜索入口。**VPS 上 curl 直连可通**（无需上海桌面），请求频率高会触发验证码。

## 搜索命令

```bash
# 搜公众号文章（type=2）— 主力
curl -s --max-time 10 "https://weixin.sogou.com/weixin?type=2&query=<URL编码关键词>" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

# 搜公众号账号（type=1）
curl -s --max-time 10 "https://weixin.sogou.com/weixin?type=1&query=<公众号全名>" -H "User-Agent: ..."
```

注意：查询串要预先 URL 编码（%E8%8F%8A...），否则搜不到。

## 结果提取

```python
import re, html
# 标题 + 跳转链接（<h3> 下第一个 <a>）
items = re.findall(r'<h3>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', c, re.S)
for url, title in items:
    title = html.unescape(re.sub(r'<[^>]+>', '', title)).strip()
```

## ⚠️ 时间戳转换（必做）

结果**不显示日期**，时间藏在 JS 里，是 Unix 时间戳：
```html
<script>document.write(timeConvert('1689761063'))</script>
```
```python
import datetime
datetime.datetime.fromtimestamp(1689761063)  # → 2023-07-19
# 提取：re.findall(r"timeConvert\('(\d+)'\)", c)
```

不转换就无法判断结果新旧——搜"XX幼儿园"可能返回一堆 2019 年的旧文，看起来像最新。

## 已知坑

- **type=1 公众号搜索**：名称不完全匹配返回 0 账号；试全名（加区名前缀）/简称多种叫法
- **索引延迟**：当天/近几天发布的文章常搜不到，未登录返回结果有限
- **频率限制**：连续请求间隔 ≥2s，否则跳验证码
- 文章详情需要 follow /link?url=... 跳转（可能被反爬拦，抓不到就退而用标题+时间戳做判断）
- 没有时间排序选项，只能靠时间戳自己排序

## 适用场景

- 查某公众号/机构最近发了什么文章
- 判断一个机构（学校/幼儿园/公司）是否有活跃公众号
- 补 SearXNG/百度搜不到的中文微信内容
