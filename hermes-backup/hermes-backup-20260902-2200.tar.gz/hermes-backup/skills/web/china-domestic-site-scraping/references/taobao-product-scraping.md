# 淘宝商品评估抓取流程（2026-08 朵朵实战验证）

场景：用户甩来淘宝分享短链让评估商品（幼儿园床垫案例：`开心朵朵 4D空气纤维床垫`）。
完整链路：短链解析 → 拿真实商品页 + 价格 → 抓软文页 → 提取规格 + 买家评价。

## Step 1 — 短链解析（拿真实 URL + 价格）

```bash
# 用户分享的链接形如：https://e.tb.cn/h.84iWpojRWQnIwwW?tk=X0GkgCbIj73
curl -s -m 25 -L "https://rss.cloudjoind.com/https://e.tb.cn/h.84iWpojRWQnIwwW?tk=X0GkgCbIj73" -o /tmp/tb_short.html
grep -o 'item.taobao.com/item.htm?id=[0-9]*&price=[0-9]*' /tmp/tb_short.html
# → item.taobao.com/item.htm?id=988357151708&price=588
```

- 跳转页 JS 变量 `url` 里有完整商品页 + `price=` 字段（价格直接拿到）
- 跳转页本身是淘宝的引导脚本页，正文无商品信息，只取变量

## Step 2 — 商品详情页：优先试 my.world 免登录通道（2026-08 新发现）

```bash
# ❌ 旧结论：PC 详情页强制登录，不抓
curl -s -m 30 -L "https://rss.cloudjoind.com/https://item.taobao.com/item.htm?id=988357151708" -o /tmp/tb_item.html
# 返回 5KB 的 login 跳转脚本（windvane/sdkLogin），无商品数据

# ✅ 新通道：my.world.taobao.com（免登录，CF 反代 200）
curl -s -m 30 -L "https://rss.cloudjoind.com/https://my.world.taobao.com/item/1027009188039.htm" -o /tmp/tb_world.html
# 直接返回：商品名 / 价格（¥223.00）/ 店铺名（居贝童旗舰店）/ 三项评分（物流/服务/描述 4.9）
#           / 最新买家评价（含评价日期、尺寸规格、评价原文）——无需登录！
```

- **my.world.taobao.com 是淘宝国际站聚合页，CF 反代可免登录抓取**，含详情+评价，比软文页更直接
- 页面为繁体（GBK/繁中），提取正文用 python 去 tag + `html.unescape`（本次提取中文正常）
- 评价正文正则：`(\d{4}\.\d{2}\.\d{2}[\s\S]{0,200}?)` 匹配日期开头的评价块
- 注意：该页只展示前 1-2 条评价（示例只抓到 1 条），完整评价仍靠软文页「商品点评与口碑」区
- **优先级修正**：拿到商品 ID 后 → 先试 my.world（快、准、含价格）→ 不够再抓软文页补评价

## Step 3 — 软文页抓取（淘宝百科 / 淘宝好物网）

用 SearXNG 搜「品牌名+品类关键词」定位软文页：

```bash
# 搜索（duckduckgo 引擎能出中文结果）：
#   query: 开心朵朵 新生婴儿床垫 POE空气纤维 4D 护脊 无甲醛

# 两类可抓页面（经 CF 反代）：
curl -s -m 30 -L "https://rss.cloudjoind.com/https://bk.taobao.com/k/yingtongchuangdian_10892/ab44b3793cf5c17d61f617530cfc6d11.html" -o /tmp/tb_art1.html    # 淘宝百科
curl -s -m 30 -L "https://rss.cloudjoind.com/https://goods.taobao.com/t/yingtongchuangdian_8423/689fa00d00f5a49dcaea89e38c461083.html" -o /tmp/tb_art2.html  # 淘宝好物网
```

- 均返回 200 + 完整 HTML（90-110KB）
- 提取正文：`python3` 正则去 `<script>/<style>/<tag>` + `html.unescape`
- **淘宝好物网（goods.taobao.com/t/）含「商品点评与口碑」区**——真实买家评价，用户名半掩码（如"无**豆""湘**迟"），评价含关键信息（材质、味道、尺寸定制、可水洗、检测报告），是评估的金矿

## Step 4 — 京东同款（可选，snippet 就够）

```bash
# 京东详情页经 CF 反代返回 JDR_shields 验证页，别抓
# 但搜索引擎 snippet 已含规格，例如：
#   "开心朵朵新生婴儿床垫4D空气纤维...总厚5.5cm=5cm软硬双面POE+几何凉感外套 110cm*65cm"
```

## 提取要点

- 规格关键词：厚度（5.5cm/6cm）、双面软硬、外套材质、认证（A类/无甲醛）、定制尺寸支持
- 价格核实：短链 `price=` 字段 + 软文页「¥xxx 起」交叉验证
- 买家评价：材质优劣（POE vs PP/PE）、味道、尺寸定制准确性、可水洗、检测报告——这些是用户最在意的决策点

## 输出给用户的格式（朵朵风格）

1. 一句话结论（值不值得买）
2. 参数表（项目/情况/评价三列）
3. 买家评价要点（引真实评价）
4. 明确的判断 + 行动建议（问客服定制尺寸、对比同店低价款）
