---
name: search-tool-fallback
description: 【已归档】MiniMax web_search 404 备用方案 — MiniMax MCP 已全部下线。搜索统一使用 SearXNG。
risk: read-only
status: archived
archived_at: 2026-05-09
reason: MiniMax web_search MCP 平台级 404，不再需要 fallback。搜索统一走 SearXNG。
---

# 【已归档】Search Tool Fallback

**此 skill 已归档。** MiniMax web_search MCP 已全部下线，搜索统一使用 SearXNG。
详见 MEMORY.md「搜索策略（2026-05-09 更新）」条目。
