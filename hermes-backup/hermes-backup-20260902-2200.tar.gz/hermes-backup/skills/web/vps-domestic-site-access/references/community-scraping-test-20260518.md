# 社区内容可抓取性测试（2026-05-18）

来源：DM 对话测试结果
环境：RackNerd VPS 洛杉矶（192.3.241.244），通过 Cloudflare Tunnel 出站
测试平台：上海电信（AS4812），14.6% 丢包高峰期

## 国内社区

| 社区 | 可抓取 | 方式 | 详情 |
|------|--------|------|------|
| **V2EX** | ✅ 完美 | curl 直取 HTML | 50 条帖子标题+完整内容，服务器端渲染无需 API |
| **B站** | ✅ 完美 | curl + 公开 API | 热门内容 API: `api.bilibili.com/x/web-interface/popular` 无需cookie，返回 JSON |
| **知乎** | ⚠️ 间接 | SearXNG site:zhihu.com | 拿不到全文，仅搜索摘要。知乎专栏可拿标题+摘要。curl 直接请求返回 403 |
| **小红书** | ⚠️ 不稳定 | browser (Playwright) | 572KB JS SPA，浏览器加载依赖网络质量。丢包>5%时崩溃。curl 只能拿 JS 壳 |
| **掘金** | ❌ | 不可抓 | SPA + 浏览器超时 |

### V2EX 抓取示例
```bash
curl -s "https://www.v2ex.com/" | python3 -c "
import sys, re
topics = re.findall(r'<a[^>]*href=\"/t/\d+[^>]*>([^<]+)</a>', sys.stdin.read())
for t in topics[:10]:
    print(t.strip())
"
```

### B站 API 示例
```bash
curl -s "https://api.bilibili.com/x/web-interface/popular?ps=5" | python3 -c "
import sys, json
d = json.load(sys.stdin)
for v in d['data']['list']:
    s = v['stat']
    print(f\"{v['title']} ★{s['like']} 播放{s['view']}\")
"
```

### 知乎 SearXNG 搜索
```bash
curl -s 'http://localhost:8888/search?q=site:zhuanlan.zhihu.com+游戏策划&format=json&pageno=1'
```

## 国外社区

| 社区 | 可抓取 | 方式 | 详情 |
|------|--------|------|------|
| **Reddit** | ✅ 完美 | JSON API | `reddit.com/r/{sub}/hot.json` 可拿分数+标题+URL |
| **GitHub** | ✅ 完美 | curl + REST API | Trending 页 HTML 可解析，亦可走 REST API |
| **X/Twitter** | ⚠️ 需认证 | 页面重定向登录 | 未登录无法获取 Trending 等内容，需 token/Cookie |
| **Discord** | ❌ 需认证 | 页面重定向登录 | 完全不可在未登录状态下访问 |

### Reddit JSON API 示例
```bash
curl -s "https://www.reddit.com/r/gamedev/hot.json" | python3 -c "
import sys, json
d = json.load(sys.stdin)
for p in d['data']['children'][:8]:
    data = p['data']
    print(f\"[{data['score']}↑] {data['title']}\")
"
```

### GitHub API 示例
```bash
curl -s -H "Accept: application/vnd.github+json" \
  "https://api.github.com/search/repositories?q=created:>2026-05-10&sort=stars&order=desc&per_page=5"
```

## 关键发现

1. **服务端渲染的站最好抓**（V2EX、GitHub、Reddit）：curl 一把梭
2. **重度 JS SPA 从 VPS 抓取不稳定**（小红书、掘金）：依赖国际链路质量，高丢包日直接挂
3. **知乎反爬最强**：curl 403 + browser 超时，只能靠 SearXNG 间接拿摘要
4. **需要登录的站**（Discord、X）：VPS 浏览器无法直接处理，需 cookie/token 注入
5. **国外站全部可达**：Reddit、GitHub、X 均 HTTP 200，X 是唯一需要登录的
6. **桌面 headless 也被拦**：即使从上海桌面（中国 IP）访问，小红书仍返回「安全限制 300012」，headless fingerprint 检测与 IP 无关
7. **用户数据目录无效**：`--user-data-dir` 加载 360ChromeX 的登录态 Cookie 也没用，headless 自身特征暴露
8. **PowerShell 远程截图不可行**：`CopyFromScreen` 在 SSH 会话中无法捕获桌面（需要交互式 session），仅截 headless 浏览器窗口
9. **用户最后手段**：F12 → Console → 输入 `allow pasting` → 粘贴 `copy(document.body.innerText)` 发给 Agent

## X/Twitter 内部 API 方式（2026-05-18 新增）

需要三个凭证组合使用：
1. **Bearer Token**（X 网页版公共值，非用户专属）：`AAAA...ANRILg...`
2. **auth_token Cookie**（需从浏览器提取）
3. **ct0 Cookie**（CSRF token，需从浏览器提取）

### ✅ 已验证可用的端点

```bash
# 首页 Timeline（实际测试通过）
curl -s "https://x.com/i/api/2/timeline/home.json?count=10" \
  -H "Authorization: Bearer AAAA...ANRILg..." \
  -H "X-CSRF-Token: {ct0}" \
  -H "X-Twitter-Auth-Type: OAuth2Session" \
  -H "Cookie: auth_token={auth_token}; ct0={ct0}" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" \
  -H "Origin: https://x.com" \
  -H "Referer: https://x.com/"
```

**返回**：JSON 格式，`globalObjects.tweets` 含推文（text, retweet_count, favorite_count, user_id_str），`globalObjects.users` 含用户信息（screen_name）。

### ❌ 不工作的端点
| 端点 | 原因 |
|------|------|
| `api.twitter.com/2/tweets` | 官方 v2 API，需注册开发者 |
| `x.com/i/api/2/guide.json` | 返回空响应 |
| `x.com/i/api/graphql/*` | Query ID 轮换 |
| `x.com/i/api/1.1/search/tweets.json` | 返回 34 "page not found" |

### Cookie 提取方法（推荐 Application 面板）
```
F12 → Application → Cookies → x.com
  → 找 auth_token 行，复制 Value
  → 找 ct0 行，复制 Value
```

⚠️ 官方 API v2（`api.twitter.com`）不可用（需注册开发者），必须用 `x.com/i/api/` 内部端点。
Bearer Token 单独使用（无 Cookie）返回空响应。`X-Twitter-Auth-Type: OAuth2Session` 头不可少。
