# Windows 桌面浏览器爬取（通过 Tailscale SSH）

当 VPS 浏览器无法访问国内站点时，通过 SSH 登录用户的 Windows 桌面（上海宝山）进行爬取。

## 前提条件

- 用户已连接 Tailscale（桌面 IP `100.86.150.37`，用户 `joind`）
- SSH 密钥已配置：`/root/.ssh/id_ed25519`
- Windows 桌面有 Edge（路径标准安装）

## 连通验证

### 1. SSH 可达性
```bash
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=10 joind@100.86.150.37 "echo SSH OK & hostname"
```

### 2. 浏览器可用性
```bash
# 查找正在运行的浏览器（用 wmic 避免中文编码问题）
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 \
  "wmic process where \"name like '%%360%%' or name like '%%chrome%%' or name like '%%msedge%%'\" get name,processid,commandline /format:list"

# 查看 Edge 是否已安装
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 \
  "dir \"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe\" /b"
# 应返回: msedge.exe

# 360ChromeX 路径（用户常用浏览器）
# C:\Users\JoinD\AppData\Local\360ChromeX\Chrome\Application\360ChromeX.exe
# 版本: 23.1.1200.64 (Chromium 系)
```

## 爬取方法

### 方法 A：Edge headless --dump-dom（最简洁）

直接获取渲染后的 DOM 文本：

```bash
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 \
  "\"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe\" \
  --headless --disable-gpu --dump-dom \
  --virtual-time-budget=30000 https://目标网址"
```

`--virtual-time-budget=30000` 控制 JS 渲染最大等待时间（毫秒）。

### 方法 B：Edge headless 截图

生成 PNG 截图并通过 SCP 拉回：

```bash
# 1. 截图
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 \
  "\"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe\" \
  --headless --disable-gpu \
  --screenshot=\"E:\Hermes\screenshot.png\" \
  --window-size=1920,1080 \
  --virtual-time-budget=30000 https://目标网址"

# 2. 拉回截图（注意 Windows 路径要用 forward slashes）
scp -i /root/.ssh/id_ed25519 \
  "joind@100.86.150.37:E:/Hermes/screenshot.png" \
  /tmp/screenshot.png
```

### 方法 C：PowerShell Invoke-WebRequest（仅获取 JS 壳）

解决中文编码问题——使用 `-EncodedCommand` + Python base64 编码：

```bash
# 1. Python 生成 base64 编码
python3 -c "
import base64
ps_code = r'''
\$r = Invoke-WebRequest -Uri 'https://目标网址' -UseBasicParsing -TimeoutSec 30
Write-Output \$r.StatusCode
Write-Output \$r.RawContentLength
'''
bytes_data = ps_code.encode('utf-16-le')
print(base64.b64encode(bytes_data).decode())
"

# 2. 复制输出到 SSH 命令
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 \
  powershell -EncodedCommand "<粘贴刚才的输出>"
```

⚠️ 路径中的反斜杠在 Python 三重引号中需要用原始字符串（`r'''...'''`）或双反斜杠。
⚠️ PowerShell 中的 `$` 变量前缀需要在 Python 字符串中转义为 `\$`。
⚠️ CLIXML 输出格式混杂在结果中，用 `| head -c 500` 只看有用部分。关注输出行中的 `Status: 200`、`Size: 565007 bytes` 等关键信息。

> ⚠️ 对于 SPA 站（小红书、掘金等），PowerShell 拿到的只是 JS 外壳 HTML 和 curl 没区别。不要误以为从桌面执行就能拿到渲染内容。

### 方法 D：PowerShell 脚本远程执行

对于复杂爬取，先将 .ps1 文件写入桌面，再远程执行：

```bash
# 1. 传输脚本
scp -i /root/.ssh/id_ed25519 /tmp/script.ps1 \
  joind@100.86.150.37:E:\Hermes\script.ps1

# 2. 远程执行（使用 base64 绕过编码问题）
python3 -c "
import base64
ps_code = '''
\$r = Invoke-WebRequest -Uri 'https://xxx.com' -UseBasicParsing -TimeoutSec 30
Write-Output \$r.StatusCode
'''
bytes_data = ps_code.encode('utf-16-le')
print(base64.b64encode(bytes_data).decode())
" | xargs -I{} ssh joind@desktop powershell -EncodedCommand {}
```

## 已知限制

### headless 浏览器检测

小红书等反爬严格的站能检测到 headless 模式，返回"安全限制"错误码 300012：
```
标题: "安全限制"
提示: "IP存在风险，请切换可靠网络环境后重试"
错误码: 300012
```

**headless 浏览器可用的站**（反爬较弱）：
- B站（curl/API 即可，不需要这层）
- 知乎（curl 403，但 SearXNG 间接可取，这层也无意义）
- 百度（curl 即可）

**headless 浏览器被拦截的站**：
- 小红书（300012）
- 掘金（未测试）

#### 已尝试但无效的方案

| 方案 | 命令 | 结果 |
|------|------|------|
| `--user-data-dir` 复用登录态 | `msedge.exe --headless --dump-dom --user-data-dir="C:\Users\JoinD\AppData\Local\360ChromeX\Chrome\User Data\Default" --no-sandbox --disable-blink-features=AutomationControlled` | ❌ 仍然「安全限制 300012」，headless fingerprint 太明显 |

### 最后手段：用户协助手动提取

当 headless 全部被拦后，见 `references/user-assisted-manual-extraction.md`。

流程：让用户 F12 → Console → `copy(document.body.innerText)` → 粘贴给 Agent。
