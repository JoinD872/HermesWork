# rclone Google Drive OAuth 从墙内认证

## 环境
- VPS: RackNerd 洛杉矶 (192.3.241.244)，能直连 Google API
- 客户端: Windows 桌面 (上海, 100.86.150.37)，有浏览器但 GFW 阻断 Google API

## 问题
标准 `rclone authorize "drive"` 流程需要三步：
1. 启动本地 web server 等待回调 (127.0.0.1:53682)
2. 用户打开 URL → Google 登录 → 授权
3. rclone 用 code 换 token → 保存

从国内执行：
- VPS 上跑：VPS 能换 token（第3步），但用户浏览器回调到 VPS 的 127.0.0.1:53682 不可达
- Windows 上跑：浏览器可用（第2步），但 Windows 直连 `oauth2.googleapis.com/token` 被 GFW 阻断（第3步）

## 解决方案

```bash
# === VPS 侧 ===
rm -rf /root/.config/rclone
rclone authorize "drive" > /tmp/rclone_auth.log 2>&1 &
socat TCP-LISTEN:53683,reuseaddr,fork TCP:127.0.0.1:53682 &
ufw allow 53683/tcp

# 获取 URL
cat /tmp/rclone_auth.log
# → http://127.0.0.1:53682/auth?state=XXXXX

# === 用户操作 ===
# 1. 浏览器打开（用 VPS IP 替换 127.0.0.1）：
#    http://192.3.241.244:53683/auth?state=XXXXX
# 2. 登录 Google → 授权
# 3. Google 回调到 http://127.0.0.1:53682/auth?code=... 页面打不开
# 4. 手动改地址栏：将 127.0.0.1:53682 改成 192.3.241.244:53683 → 回车
# 5. 看到 "Success!" 即可
```

## 失败尝试：SSH 远程跑在 Windows 上

```
ssh joind@100.86.150.37 "rclone.exe authorize drive"

现象：
- 浏览器弹出成功（Windows 桌面上）
- 用户授权成功
- 收到 "Got code"
- 报错：Post "oauth2.googleapis.com/token": dial tcp 173.194.43.95:443: connectex
- 上海 IP 连不上 Google 令牌接口，网络层阻断
```

## 原理

Google OAuth code→token 交换接口 `oauth2.googleapis.com/token` 在上海 IP 下不可达（TCP 连接超时）。OAuth 浏览器认证阶段（登录页面）正常，因为走的是普通 HTTPS 到 accounts.google.com。

## 清理

```bash
pkill -f "rclone authorize"
pkill -f "socat.*53683"
rm -rf /root/.config/rclone
ufw delete allow 53682/tcp 2>/dev/null
ufw delete allow 53683/tcp 2>/dev/null
rm -f /tmp/rclone_auth.log
```
