# X/Twitter 内部 API 抓取指南

通过用户浏览器 Cookie + 公开 Bearer Token 调用 X 网页版内部 API。

## 认证凭证

需要三个值组合使用：

| 凭证 | 来源 | 是否用户专属 | 说明 |
|------|------|-------------|------|
| **Bearer Token** | X 网页内嵌 JS | ❌ 公共固定值 | `AAAA...ANRILg...`（所有 X 网页用户共用） |
| **auth_token** | 用户 Cookie | ✅ 是 | 从 `document.cookie` 提取 |
| **ct0** | 用户 Cookie | ✅ 是 | CSRF token，也从 Cookie 提取 |

### 从用户浏览器提取 Cookie

```text
F12 → Console → 输入 allow pasting → 粘贴 copy(document.cookie) → 发给 Agent
```

### 通过 Application 面板提取（更友好）

```text
F12 → Application → Cookies → x.com
    → 找到 auth_token 行 → 复制 Value
    → 找到 ct0 行 → 复制 Value
```

## 所需 HTTP 头

```
Authorization: Bearer AAAA...ANRILg...
X-CSRF-Token: {ct0 值}
X-Twitter-Auth-Type: OAuth2Session
Cookie: auth_token={auth_token 值}; ct0={ct0 值}
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36
Origin: https://x.com
Referer: https://x.com/
Accept: application/json
```

⚠️ 缺少任一 Cookie 头都会返回空响应。Bearer Token 单独使用无效。

## 已验证的端点

### ✅ 首页 Timeline（已验证可用）

```bash
curl -s "https://x.com/i/api/2/timeline/home.json?count=10" \
  -H "Authorization: Bearer ..." \
  -H "X-CSRF-Token: ..." \
  -H "Cookie: auth_token=...; ct0=..." \
  -H "X-Twitter-Auth-Type: OAuth2Session" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -H "Origin: https://x.com" \
  -H "Referer: https://x.com/"
```

**返回格式**：`globalObjects.tweets` 含推文数据集，`globalObjects.users` 含用户信息。
**每个推文对象字段**：`id_str`, `text`/`full_text`, `created_at`, `user_id_str`, `retweet_count`, `favorite_count`, `entities`

### ❌ 不工作的端点

| 端点 | 失败原因 |
|------|---------|
| `api.twitter.com/2/tweets` | 官方 API v2，需注册开发者账号，公共 Bearer 被拒绝 |
| `x.com/i/api/graphql/*` | Query ID 频繁轮换，不易维护 |
| `x.com/i/api/1.1/search/tweets.json` | 返回 code 34 "page does not exist" |
| `x.com/i/api/2/search/typeahead.json` | 返回空响应 |

## 解析示例

```python
import sys, json

data = json.loads(sys.stdin.read())
tweets = data.get('globalObjects', {}).get('tweets', {})
users = data.get('globalObjects', {}).get('users', {})

for tid, t in tweets.items():
    uid = t.get('user_id_str', '')
    user = users.get(uid, {})
    screen_name = user.get('screen_name', '?')
    text = t.get('full_text', t.get('text', ''))
    rt = t.get('retweet_count', 0)
    fav = t.get('favorite_count', 0)
    print(f'@{screen_name}: {text[:120]}')
    print(f'  ♥{fav}  🔄{rt}')
```

## 限制

- `auth_token` 和 `ct0` 会过期，需用户定期在 X 登录后重新提取
- Cookie 用户专属，不能在会话间持久化存储（隐私安全原因）
- 爬取频率过高可能触发风控导致 Cookie 失效
- 仅支持 `home.json` Timeline 端点，搜索/用户时间线等端点需额外测试
