# 用户协助手动提取（最后手段）

当所有自动化爬取均失败时，请用户手动从浏览器中提取内容。

## 触发条件

仅当以下全部失败后才使用此方案：
1. VPS agent-browser 连续超时 / 被拦截
2. 桌面 Edge headless（--dump-dom）被反爬拦截（如小红书 300012）
3. Edge --user-data-dir 复用登录态仍被拦

## 标准操作流程（对用户说的话）

> 可以帮个小忙吗？
> 1. 在浏览器的页面上按 **F12** 打开开发者工具
> 2. 点 **Console（控制台）** 标签
> 3. **先输入 `allow pasting` 然后回车**（Chrome/Edge 的安全策略，阻止粘贴不明代码）
> 4. 再粘贴这段代码然后回车：
> ```javascript
> copy(document.body.innerText)
> ```
> 5. 把复制的内容直接粘贴给我

## 为什么需要 `allow pasting`

Chrome/Edge 浏览器在 Console 中粘贴代码时会弹出警告：
```
Warning: Don't paste code into the DevTools Console that you don't understand 
or haven't reviewed yourself. This could allow attackers to steal your identity 
or take control of your computer. Please type 'allow pasting' below and hit 
Enter to allow pasting.
```

必须先输入 `allow pasting` 回车解除限制，才能正常粘贴 `copy(document.body.innerText)`。

## 为什么需要这步

- 小红书/掘金等重度 SPA 对 headless 浏览器有 fingerprint 检测
- 即使用户数据目录加载登录态 Cookie，headless 自身特征（WebGL renderer: "llvmpipe"、Canvas fingerprint、无鼠标轨迹）仍会被拦截
- 用户本机浏览器是非 headless 的正常窗口，不会被检测

## 备选：如果用户打不开开发者工具

- 让用户直接 **复制地址栏 URL** 发过来
- 让用户 **截图** 发过来
- 让用户 **选中页面文字 → 右键复制** 发过来

## 和 Agent-browser 的关系

```yaml
尝试顺序:
  1. VPS agent-browser       # 最快，但网络差时不行
  2. 桌面 Edge headless       # 走中国 IP，但 headless 被检测
  3. 桌面 --user-data-dir     # 复用 Cookie 也没用
  4. [降级] 用户手动提取       # 最后手段，需用户配合
```
