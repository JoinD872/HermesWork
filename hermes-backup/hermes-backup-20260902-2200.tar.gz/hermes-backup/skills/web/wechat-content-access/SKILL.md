---
name: wechat-content-access
description: 微信公众号文章内容访问 — 从 VPS 读取 mp.weixin.qq.com 公众号文章的方法、已知限制与降级策略。VPS IP（AS36352）被微信全面封锁时的应对方案。
tags: [wechat, weixin, social-media, china, scraping, content-access]
version: 1.0.0
created: 2026-07-27
risk: read-only
---

# 微信公众号文章内容访问

## 核心事实：VPS 无法直接读取公众号文章

VPS IP（192.3.241.244，AS36352 ColoCrossing）被微信公众平台防爬系统拉黑。访问任何 `mp.weixin.qq.com/s/...` 链接均出现「环境异常」验证码拦截。**这不是 UA/浏览器问题，是 IP 段级别的封禁。**

## 已知失败的尝试

| 方案 | 结果 |
|------|------|
| curl 直连 | ❌ 环境异常 captcha |
| headless Chrome (browser tool) | ❌ 同样 captcha |
| Google 缓存 | ❌ Google 也弹 captcha |
| Wayback Machine | ❌ 无归档 |
| r.jina.ai / allorigins / ghproxy | ❌ 全部被拒 |
| 百度搜索 | ❌ 百度安全验证 |
| wechatscope.jshuii.com | ❌ 服务无响应 |
| GitHub code search | ❌ 文章 URL 未被归档 |

## 唯一可用间接方式：搜狗微信搜索

`weixin.sogou.com` 从 VPS 可访问，提供文章搜索 + 代理阅读。

```bash
# 搜索
curl -sL --max-time 15 "https://weixin.sogou.com/weixin?type=2&query=关键词" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -H "Accept-Language: zh-CN,zh;q=0.9"
```

```python
# 解析文章列表
import re
entries = re.findall(r'<div class="txt-box[^"]*">(.*?)</div>\s*</div>', html, re.DOTALL)
for entry in entries:
    title_m = re.search(r'<a[^>]+>(.*?)</a>', entry, re.DOTALL)
    url_m = re.search(r'href="(/link\?url=[^"]+)"', entry)
    title = re.sub(r'<[^>]+>', '', title_m.group(1)).strip() if title_m else ""
    sogou_path = url_m.group(1) if url_m else ""
```

**局限**：只能按关键词搜索，无法用文章 URL 反查。返回的是搜狗代理链接。

## 标准响应流程（当用户请求读取某篇微信文章时）

1. **尝试直接 curl 访问** — 判断是否被封
2. **若被封 → 立即告知**：直接说「VPS IP 被微信封了，我读不了这篇」
3. **请求用户协助**：
   - 「你能在微信里打开，然后把内容转述/截图发我吗？」
   - 或告知文章标题，尝试搜狗搜索
4. **不要**：反复尝试不同 UA/代理方案（全都无效）
5. **搜狗搜索**：仅在用户已知文章主题时用于发现场景

## 参考资料

- `references/wechat-article-access-20260727.md` — 本次会话详细排查记录
