# 微信公众号文章访问排查记录（2026-07-27）

## 背景

用户分享了一篇微信文章链接 `https://mp.weixin.qq.com/s/jGMa7u-ZD7E0q2z8HSpkgg`，要求读取内容。此前对话中讨论了 Hermes Agent 的 `/learn` 模式概念，因此推测文章主题与 AI Agent 学习模式相关。

## 排查过程

### 1. 直接访问
```bash
curl -sL "https://mp.weixin.qq.com/s/jGMa7u-ZD7E0q2z8HSpkgg"
```
→ 返回「环境异常」页面，要求 captcha 验证

### 2. 浏览器（headless Chrome）
```python
browser_navigate(url="https://mp.weixin.qq.com/s/jGMa7u-ZD7E0q2z8HSpkgg")
```
→ 重定向到 `mp.weixin.qq.com/mp/wappoc_appmsgcaptcha`，同样 captcha

### 3. Google 缓存
```bash
curl -sL "https://webcache.googleusercontent.com/search?q=cache:https://mp.weixin.qq.com/s/jGMa7u-ZD7E0q2z8HSpkgg"
```
→ Google 弹 JS challenge 页面，无法访问

### 4. Wayback Machine
```
https://archive.org/wayback/available?url=https://mp.weixin.qq.com/s/jGMa7u-ZD7E0q2z8HSpkgg
```
→ `"archived_snapshots": {}` — 无归档

### 5. 代理/中转服务
| 服务 | 结果 |
|------|------|
| wechatscope.jshuii.com | 空响应 |
| r.jina.ai | 401 — AS36352 信誉不足 |
| allorigins.win | timeout |
| ghproxy.net | Invalid input |

### 6. 搜狗微信搜索
```bash
curl -sL "https://weixin.sogou.com/weixin?type=2&query=jGMa7u-ZD7E0q2z8HSpkgg"
```
→ 返回搜索空白（无匹配结果），但服务本身可访问

按关键词搜索（"Hermes Agent learn mode"）可获取文章列表，但该 URL 不在结果中。

### 7. GitHub 搜索
- `gh search code "jGMa7u-ZD7E0q2z8HSpkgg"` — 无结果
- GitHub API search — 需认证

### 8. 百度搜索
```bash
curl -sL "https://www.baidu.com/s?wd=mp.weixin.qq.com/s/jGMa7u-ZD7E0q2z8HSpkgg"
```
→ 百度安全验证（同样被 VPS IP 信誉拦截）

### 9. 搜狗微信搜索（按主题搜索）
Sogou WeChat search returns article entries in `<div class="txt-box">` containers with proxy links. The service is useful for discovering articles by keyword when the user knows the topic.

## 根因分析

**WeChat 反爬机制**：
- 对数据中心 IP 段（AS36352 ColoCrossing/RackNerd）直接拦截
- 使用腾讯 Captcha 验证，自动化无法绕过
- 检测独立于 UA/浏览器/请求头，纯 IP 信誉驱动
- Google/Baidu 等搜索引擎同样拦截该 IP，说明进入了各厂商共享的 IP 黑名单

## 教训

- 遇到 WeChat 文章链接，不要花时间尝试各种 UA/代理/浏览器技巧
- 第一个 curl 返回 captcha 就已足够诊断
- 直接向用户说明无法读取，请用户转述
- 搜狗微信搜索是唯一可用的辅助手段，但也仅限于已知关键词的场景

## 各工具/服务状态速查

| 工具 | 对 WeChat 可用? | 说明 |
|------|:--------------:|------|
| curl | ❌ | captcha |
| browser tool | ❌ | captcha |
| SearXNG | ❌ | 搜索不到该 URL |
| 搜狗微信搜索 | ✅ | 仅限关键词搜索，不可反查 URL |
| 网页缓存 (CC/google) | ❌ | IP 被封 |
| web_services (r.jina) | ❌ | 401 |
| GitHub API | ❌ | 需要认证且无人归档 |
