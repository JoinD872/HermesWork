---
name: cn-social-platform-cookie-scraping
description: 中文社交平台（小红书/知乎/微博/抖音/B站）带登录态抓取 — cn-scraper-mcp 等工具调研、cookie 字段、住宅 IP 要求、APP vs 网页登录态概念
version: 1.0.0
tags: [web, scraping, xiaohongshu, cookie, cn-platforms, mcp]
risk: write-dangerous
---

# 中文社交平台带登录态抓取

## 核心结论（2026-08-05 GitHub 实测调研）

**小红书是中文平台反爬最严的**：数据中心 IP 直接 error_code=300012 "IP存在风险"（在检查 cookie 之前就被拒）；游客 curl 只返回 ~9KB shell 页（"你访问的页面不见了"）。搜索结果走**签名 XHR（x-s/x-t 头）**，非服务端渲染 —— 纯 HTTP 方案拿不到。

**唯一可靠路径** = 住宅 IP + 真实浏览器（本地 Chrome）+ 登录 cookie 注入。

## 最佳工具：cn-scraper-mcp

- 仓库：goesByhc/cn-scraper-mcp（⭐18，MCP server，专为 AI Agent 设计）
- 安装：`pip install cn-scraper-mcp`；启动 `cn-scraper-mcp`（stdio）或 `-p 8000 -e CN_SCRAPER_TRANSPORT=http`
- Docker：镜像内置 chromium + xvfb；`CHROME_BIN=/usr/bin/chromium`、`CHROMIUM_FLAGS="--no-sandbox --disable-gpu --disable-dev-shm-usage --headless=new"`
- **登录流程**：`guided_login(platform="xiaohongshu")` → 打开本地 Chrome 登录页 → 用户扫码 → CDP 自动抓完整 cookie（含 HttpOnly）→ 存 `~/.cn-scraper-cookies/xiaohongshu.json` → 之后自动带登录态
- 已有登录 Chrome 时用 `harvest_cookies(platform="xiaohongshu")`
- 支持平台：taobao/jd/xiaohongshu/zhihu/weibo/zsxq/douyin/pdd/douban/dianping

### ⚠️ 原版不支持代理，VPS 部署必须 patch（2026-08-05 实测）

源码 `launch_chrome()` **没有 --proxy-server 参数**，Chrome 会直连（数据中心 IP 必被 300012 拒）。两处 patch：

1. `src/cn_scraper_mcp/engines/cdp.py` 的 `launch_chrome(port, profile_dir, url, headless, proxy=None)`：
   加 `if proxy: args.append(f"--proxy-server={proxy}")`；默认 args 里补反检测参数
   `--disable-features=AutomationControlled --disable-infobars --lang=zh-CN`。
2. `src/cn_scraper_mcp/engines/xiaohongshu.py` 的 `ensure_browser()` 调用处加
   `proxy=os.environ.get("XHS_PROXY")`；文件头补 `import os`。

运行环境变量：`XHS_PROXY="socks5://127.0.0.1:10808"`（家宽隧道）、`CHROME_BIN=/usr/bin/chromium-browser`。
Chrome snap 版 dbus/AppArmor 报错是噪音，headless 功能正常。完整部署与调试记录见 `references/cn-scraper-mcp-deployment.md`。

### 🖥️ VPS 无显示器跑登录页：headful Chrome 需 xvfb（2026-08-05 实测）

`guided_login` 方式 B（远程扫码）在无显示器 VPS 上 `headless=False` 会启动失败（launch 返回 False）：
1. 先起虚拟显示：`Xvfb :99 -screen 0 1280x1000x24 &`（background 进程）
2. 再 `DISPLAY=:99` 运行引擎/Chrome，headful 就能起来
3. 打开 `https://www.xiaohongshu.com/login` → CDP `Page.captureScreenshot` 截图 → 发用户手机扫码（二维码约 1-2 分钟时效，过期重截）

**CDP 操作坑**（都踩过）：
- **截图取数**：`Page.captureScreenshot` 返回 base64 在 `r.get('data')` 或 `r.get('result', {}).get('data')` 两层嵌套都出现过，稳妥写法 `data = r.get('data') or (r.get('result') or {}).get('data')`
- **evaluate 里 fetch 返回 `{}`**：Promise + return_by_value 序列化不稳。验证浏览器出口 IP 改用 `cdp.navigate("https://ifconfig.me/ip")` 后读 `document.body.innerText`（实测拿到 180.164.97.180）
- **`connect(url_hint="xiaohongshu.com")` 报 "No page target found"**：`_find_page_target` 按 url_hint 过滤 page target；若 Chrome 启动后停在 about:blank（启动 URL 没加载成功）就匹配不到。确保启动 URL 能加载，或先 navigate 再 connect

### 🔑 关键实测：搜索页 `300012 "IP at risk"` 是误导性的

2026-08-05 VPS 实测（家宽隧道 + Chrome）：
- 小红书**首页 explore**：✅ 完美加载（"小红书 - 你的生活兴趣社区"）→ 证明 IP 干净
- 小红书**搜索页** search_result：❌ 报 300012 "IP at risk"
- curl 走隧道搜搜索页：✅ 拿到 723KB `__INITIAL_STATE__`（游客数据可拿但需解析）

**结论：搜索页的 300012 不是因为 IP 风险，而是因为游客无登录 cookie 被拦。** README 也印证："Results arrive via signed XHR (x-s/x-t headers), NOT server-side rendered"。排查时不要被"IP at risk"字样误导去怀疑 IP 信誉——首页能加载就说明 IP 没问题，缺的是登录态。

### 小红书所需 cookie 字段
`web_session, a1, webId, gid, abRequestId, xsecappid, webBuild`

### 页面状态检测
- 登录过期：URL 含 login/passport 或页面含"登录"
- IP 风险：页面含 `error_code=300012` / `IP存在风险`
- 验证码：页面含"验证/滑块"

### 笔记 ID 提取
`a[href*="xsec_token"]` 链接 + 正则 `/(explore|search_result|discovery\/item)\/([0-9a-f]{16,})/`；xsec_token 是搜索卡片最可靠信号。评论只抓首屏（不分页）。

## 关键概念：APP 登录态 ≠ 网页登录态

**APP 登录 token 存在手机沙盒里，只对 APP 接口生效；网页版靠浏览器 cookie（web_session 等），两套认证体系完全隔离。** APP 登录 ≠ 网页登录。要登录态 = 引导用户网页版扫码登录一次并保存 cookie，**不要**试图拿 APP token。匿名抓公开内容不需要登录态（零封号风险，推荐）。

## 其他平台参考

| 平台 | 方式 | 备注 |
|---|---|---|
| 淘宝 | curl_cffi + MTOP 签名 | 无需浏览器 |
| 知乎 | REST API v4 | 游客搜索已关闭需登录态 |
| 微博 | REST API | SUB token（热搜游客可看）|
| B站 | 公开 Web API | 建议低频 |
| 抖音 | Chrome CDP + 验证码轮询 | 实验性 |

## 适配住宅 IP 出口方案

cn-scraper-mcp 的 Chrome 需走代理指向家宽隧道（如 `socks5://127.0.0.1:10808`）以满足"住宅 IP"要求；登录时引导用户在隧道出口 IP 下扫码。装好后 AI Agent 可直接调 `xiaohongshu_search()`。

## 其他调研过的工具（不推荐）

- xiaofuqing13/redbooks（⭐25）：DrissionPage + GUI，Windows 版，不适合 VPS
- Apageoflove/xhs-cli-xiaohongshu（⭐10）：Go CLI，交互式为主
- Smart75850/smart-agent（⭐8）：纯 HTTP 零浏览器，但不含小红书
- selenium/appium 老方案：过时

## 进阶：ADB 通道模拟真人操作（2026-08-06 调研，推荐路线）

当需要**直接驱动手机 APP**（而非网页）时——真实 APP 指纹 + 真实 APP 登录态 + 住宅 IP = 最难判定机器人的组合。开启开发者选项（设置→关于平板→连点版本号 7 次）→ 无线调试后，VPS 可通过 Tailscale 内网 `adb connect <Tailscale-IP>:<调试端口>` 连接（首次 `adb pair <IP>:<配对端口>` 输 6 位码）。

### 三候选方案对比（GitHub 实测调研）

| 方案 | ⭐ | 语言 | 特点 |
|---|---|---|---|
| **scrcpy-mcp**（JuanCF） | 64 | TS/Node | **最推荐**：36 工具，AI 能"看见"屏幕（截图返回图片），点击/滑动/scrcpy 二进制协议 10-50x 提速（~33ms 截图），`ui_find_element` 返回坐标，剪贴板 Android 10+ 可用，无 scrcpy 时 ADB fallback。需 Node 22+ |
| android-mcp-server（minhalvp） | 792 | Python | 5 工具：截图/UI 布局/ADB shell/包管理。轻量但无封装点击滑动（需 shell 调 `input tap`） |
| uiautomator2（openatx）+ MCP | 8250 | Python | **元素级操作**（text/resourceId 定位，不靠坐标），小红书/抖音自动化社区最常用；tanbro/uiautomator2-mcp-server 提供 MCP 封装 |

**组合建议**：scrcpy-mcp（看屏幕+快速操作）+ uiautomator2（元素定位小红书 UI）+ 随机节奏控制（防机械操作风控：随机延迟 1-3s、模拟滑动手势、不高频重复）。

**ADB 附带好处**：`adb install` 可绕过华为纯净模式装 APK（termux-boot 等）；可改电池优化免冻结；可 `screencap`/`uiautomator dump` 读界面。**风险提醒**：风控依然看行为节奏，ADB 点击太机械照样被识别。

详细部署对比见 `references/adb-automation-options.md`（无线配对流程 + 三方案工具清单 + 组合策略）。

### 华为纯净模式拦截侧载 APK（实测坑）
报"解析包出问题" ≠ APK 损坏（aapt 验证有效、MD5 匹配时同样报）——是纯净模式拦截。设置→系统→纯净模式→关闭；Termux 前台时 `termux-open` 才能弹安装窗。ADB `adb install` 是绕过的正路。
