# ADB 通道自动化方案调研（2026-08-06 GitHub 深度调研）

## 背景
网页方案（camoufox / cn-scraper-mcp）拿不到 APP 登录态，且搜索页 300012 需登录 cookie。
ADB 通道 = 直接驱动手机 APP：真实 APP 指纹 + 真实 APP 登录态 + 住宅 IP = 最难判定机器人的组合。

## 无线 ADB 连接（华为平板 Android 12 实测路线）
```
1. 设置 → 关于平板 → 连点版本号 7 次 → 开启开发者选项
2. 设置 → 系统 → 开发者选项 → 打开 无线调试
3. VPS 侧（Tailscale 内网，全程不暴露公网）:
   adb pair <Tailscale-IP>:<配对端口>   # 输平板上显示的 6 位配对码
   adb connect <Tailscale-IP>:<调试端口>
4. 之后 scrcpy / MCP server 都能走这个连接
```

## 三个候选方案对比（GitHub 实测调研）

### 1. scrcpy-mcp（JuanCF/scrcpy-mcp，⭐64，2026-07 更新）— 最推荐
- **36 工具**：截图、输入、App、UI 自动化、shell、文件、剪贴板、视频流
- **AI 能看见屏幕**：截图返回图片（不是文件路径）——这是"模拟真人"的关键
- **scrcpy-first**：二进制控制协议，输入快 10-50 倍，截图 ~33ms
- **ADB fallback**：无 scrcpy 也能跑（慢但可用）
- **ui_find_element**：返回点击坐标，AI 按所见行动
- **剪贴板**：Android 10+ 可用（绕过 ADB-only 限制）
- 依赖：Node.js 22+、ADB platform-tools；可选 scrcpy + ffmpeg
- 安装：`npx scrcpy-mcp` 或 `npm install -g scrcpy-mcp`

### 2. android-mcp-server（minhalvp/android-mcp-server，⭐792，2025-05）
- 5 个工具：get_packages / execute_adb_shell_command / get_uilayout / get_screenshot / get_package_action_intents
- Python + uv；自动选唯一设备（多设备用 config.yaml）
- 轻量直接，但无封装点击滑动（需 shell 调 `input tap`），工具少

### 3. uiautomator2（openatx/uiautomator2，⭐8250）+ MCP 封装
- **元素级操作**（text/resourceId 定位，不靠坐标）——比坐标点击稳
- 小红书/抖音自动化社区最常用
- tanbro/uiautomator2-mcp-server 提供 MCP 封装（PyPI 可装）

## 推荐组合
```
scrcpy-mcp（看屏幕 + 快速操作）
+ uiautomator2（元素级定位小红书 UI）
+ 随机节奏控制（防机械操作风控：随机延迟 1-3s、模拟滑动手势、不高频重复）
```

## ADB 附带能力
- `adb install` 绕过华为纯净模式装 APK（termux-boot 等）——纯净模式拦截侧载 APK 的根治方案
- 改电池优化/免冻结（华为防冻结三件套可程序化）
- `screencap` / `uiautomator dump` 读界面
- `am start` 拉起任意 App

## 风险提醒
- 风控依然看行为节奏：ADB 点击太快/太机械照样被识别为机器人
- 模拟真人要点：随机延迟、滑动手势（input swipe）、避免高频重复操作
- 登录态：直接驱动 APP 用的是 APP 内登录态，无 cookie 导出问题

## 与网页方案的关系
- 网页方案（camoufox/cn-scraper-mcp）：适合匿名抓公开内容，零封号风险
- ADB 方案：适合需要 APP 登录态/真机指纹的场景，模拟真人操作
- 两者互补：匿名抓取用网页，深度操作用 ADB
