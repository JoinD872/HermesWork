---
name: rss-feed-reader
description: RSS/Atom 订阅源读取 — 使用 feedparser 解析任意 RSS/Atom 源，用于信息追踪、内容监控、早报原料。
risk: write-safe
version: 1.0.1
created: 2026-07-13
---

# RSS 订阅源读取

## 概述

使用 Python 的 feedparser 库解析 RSS/Atom 订阅源。已在 VPS 上可用（`pip install feedparser`）。

适合：追踪博客更新、监控技术资讯、作为早报的补充原料。

## 快速使用

```python
import feedparser

feed = feedparser.parse('https://hnrss.org/frontpage')
print(f'条目数: {len(feed.entries)}')
for entry in feed.entries[:5]:
    print(f'  - {entry.title}')
    print(f'    链接: {entry.link}')
    print(f'    时间: {entry.get("published", "N/A")}')
```

## 常用优质 RSS 源

| 源 | RSS URL | 内容 |
|---|---------|------|
| Hacker News | `https://hnrss.org/frontpage` | 全球技术热榜 |
| Hacker News (新帖) | `https://hnrss.org/newest` | HN 最新提交 |
| Hacker News (搜索) | `https://hnrss.org/search?q=LLM+OR+AI` | 关键词过滤 |
| GitHub Trending | `https://github.com/trending.rss` | 每日趋势仓库 |
| 阮一峰网络日志 | `https://www.ruanyifeng.com/blog/atom.xml` | 中文技术周刊 |
| Planet Python | `https://planetpython.org/rss20.xml` | Python 社区聚合 |
| ArXiv (CS) | `https://rss.arxiv.org/rss/cs.AI` | AI 论文新提交 |

## 命令行一行流

```bash
# 快速查看最新标题
python3 -c "
import feedparser
feed = feedparser.parse('https://hnrss.org/frontpage')
for e in feed.entries[:5]:
    print(f'[{e.get(\"published\",\"?\")[:16]}] {e.title}')
"

# 保存到文件
python3 -c "
import feedparser, json
feed = feedparser.parse('https://hnrss.org/frontpage')
items = [{'title': e.title, 'link': e.link, 'summary': e.get('summary','')[:200]} for e in feed.entries[:10]]
print(json.dumps(items, ensure_ascii=False, indent=2))
" > /tmp/rss_output.json
```

## 注意事项

- 某些 RSS 源可能被 VPS IP 封锁 → 考虑通过代理或更换 RSS 源
- 大部分 RSS 源不限制请求频率，但建议两次抓取间隔 >= 5 分钟
- feedparser 自动处理多种 XML 格式（RSS 0.9/2.0、Atom、RDF）
- 可通过 `entry.get('summary', '')` 提取摘要，`entry.get('content', [{}])[0].get('value', '')` 提取全文
