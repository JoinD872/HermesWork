# 家庭路由器能力评估 + 免客户端科学上网方案选型（2026-08-07 实测）

用户问「装软路由能不能不开 V2RayN 浏览外网」「交换机行不行」「方案 D（Tailscale exit node）访问国内站要不要断开」——本文件记录识别路由器品牌的方法、华为路由器的结论、以及四类方案的取舍。

## 一、从平板侧识别路由器品牌/型号（无需进管理页密码）

平板连 WiFi 后，VPS 经 Termux SSH（u0_a154@100.78.214.117:8022）探测网关 192.168.110.1：

```bash
# 1. 拿网关 IP（平板侧）
adb shell ip route                    # 或 dumpsys wifi 找 serverAddress
# 2. Termux 端口扫描（bash 的 /dev/tcp 可用；adb shell 的 sh 不支持）
for p in 80 443 8080 8443 22 23 53; do
  timeout 2 bash -c "echo > /dev/tcp/192.168.110.1/$p" 2>/dev/null && echo "$p OPEN" || echo "$p closed"
done
# 3. 抓 Web 管理页找品牌特征
curl -s -m 10 http://192.168.110.1/cgi-bin/luci | head -c 500   # 有 /cgi-bin/luci → luci 系固件
curl -s -I http://192.168.110.1/cgi-bin/luci | grep -i server
# 4. 关键：favicon 路径暴露品牌
#    在页面 HTML 里找 <link rel="shortcut icon" href="...">
#    /luci-static/eweb-ehr-ax/favicon.ico → 华为 eWeb 框架 + AX(WiFi6) 系列
#    验证：curl -s -o /dev/null -w '%{http_code}' http://192.168.110.1/luci-static/eweb-ehr-ax/favicon.ico → 200
# 5. 品牌特征路径表（实测/已知）
#    华为:   luci-static/eweb-ehr-ax, /cgi-bin/luci/api/sys（返回华为风格 JSON 鉴权错误）
#    OpenWrt 原版: /cgi-bin/luci + /luci-static/bootstrap
#    TP-Link: /web-static /webpages；小米: /cgi-bin/luci 但皮肤 miwifi；华硕: /Main_Login.asp
```

**判断结论**：80+53 开放、其余关闭 = 典型家用路由器（只有 Web 管理 + DNS）。`eweb` = 华为 eWeb 管理框架，`ax` = WiFi 6。具体型号看路由器底部标签，但品牌+系列已足够判定刷机可行性。

## 二、华为消费级路由器结论：不支持代理插件

- **不能刷 OpenWrt**：华为家用路由器（AX3/AX3 Pro/AX3000 等）无公开刷机生态（对比小米/红米/TP-Link 有成熟方案）
- **无插件系统**：管理界面只有官方功能（WiFi/家长控制/Mesh），装不了 OpenClash/PassWall
- **无 VPN/代理客户端**：不像华硕/网件有原生 VPN 客户端
- 结论：想靠现有这台华为路由器实现免客户端科学上网——**没戏**，必须加设备或装客户端

## 三、四类方案对比（用户问题逐一回答）

| 方案 | 是否可行 | 说明 |
|:-----|:---------|:-----|
| **交换机** | ❌ | 二层设备，只按 MAC 转发帧，不理解 IP/流量、无路由/NAT、装不了代理插件。代理必须作用在「网关」位置 |
| **软路由（旁路由）** | ✅ | OpenWrt + OpenClash/PassWall，接在华为路由下游，全屋设备网关指向它 → 自动分流（国内直连/国外走 VPS Xray 节点），零单机配置。成本：旧电脑免费/N100 盒子 ~300 元。是唯一能同时覆盖智能电视/游戏机等装不了客户端的设备方案 |
| **Tailscale exit node（方案 D）** | ⚠️ 半可行 | 是**全流量出口**：设备所有流量走 VPS 出网，**不会自动分流**——访问国内网站会绕美国（慢+海外 IP 风控/地域错乱），必须手动开关 exit node，跟手动开 V2RayN 没本质区别。只解决「单台设备免客户端」，不解决「国内站无感」 |
| **设备端分流客户端（Clash Verge 等）** | ✅ 最省事 | 规则分流（国内直连/国外走代理），开机自启、常驻后台、无需手动开关。缺点：还是装了客户端（但体验接近无感）。设备少（PC+手机+平板）时性价比最高 |

**给用户的建议**：
- 设备少 → Clash Verge 配置填 VPS Xray 节点（规则分流配好），免费零成本
- 设备多/要覆盖电视游戏机 → 旁路由软路由一步到位
- 华为路由器本身别指望

## 四、相关坑

- adb shell 的 sh **不支持 /dev/tcp 探测**（`can't create /dev/tcp/...`），必须走 Termux 的 bash
- `ip neigh show <gateway>` 在 Termux 里可能无输出（arp 缓存过期），品牌识别以 HTTP 特征为准
- 用户链路认知：VPS→Tailscale→平板 无线接管**不经过电脑**；DaLao 掉线不代表平板失联（判链路先看 `tailscale ping`）
