# ADB 平板 UI 控制开启链路（VPS → 电脑 → 平板）

## 目标
VPS 需要向平板注入 UI 操作（`input tap/swipe/text`，模拟真人行为画像）时，
Termux SSH 够不着 Android UI 层（不能改系统设置/点屏幕/装 APK）——只能走 ADB。
ADB 不碰网络栈，不违反「方案2 只增不改」铁律；Tailscale App 在线是 ADB 走内网前提。

## 链路
```
VPS (adb client)
   │  Tailscale 内网 adb connect 100.78.214.117:5555
   ▼
平板 adbd :5555   ← 需先经 Windows 电脑 USB 一次性开启网络调试
```

## 操作步骤（2026-08-06 实测环境：华为 MatePad Pro / MRX-W19）

### 1. VPS 装 adb
```bash
apt-get install -y android-tools-adb   # → adb 1.0.41，/usr/bin/adb
```

### 2. 平板开开发者选项
设置 → 关于平板 → 连点版本号 7 次 → 开发者选项。
用户当前 USB 连接方式 = 仅充电 → 必须打开「"仅充电"模式下允许 ADB 调试」。
（「选择待调试应用」= Android Studio 单 App 调试，无关；「HDB」= HiSuite 私有桥，无关；华为部分机型无「无线调试」选项，Android 11+ 才有。）

### 3. 电脑装 platform-tools（VPS 经 SSH 远程执行，用户无需动手）
```bash
# DaLao: curl.exe 下载官方 zip + PowerShell 解压
ssh 61915@100.108.175.15 "powershell -NoProfile -Command \"curl.exe -L --max-time 100 -o C:\platform-tools.zip https://dl.google.com/android/repository/platform-tools-latest-windows.zip 2>\$null; Expand-Archive -Path C:\platform-tools.zip -DestinationPath C:\ -Force\""
# 验证
ssh 61915@100.108.175.15 "C:\platform-tools\adb.exe version"
```

### 4. 检测设备
```bash
ssh 61915@100.108.175.15 "C:\platform-tools\adb.exe devices -l"
```

### 5. 空列表 → 查 Windows 实际枚举了什么
```bash
ssh 61915@100.108.175.15 "powershell -NoProfile -Command \"Get-PnpDevice -PresentOnly | Where-Object { \$_.InstanceId -match 'VID_12D1' -or \$_.FriendlyName -match 'Huawei|ADB|Android' } | Select-Object Status,Class,FriendlyName,InstanceId | Format-Table -AutoSize | Out-String -Width 200\""
```
- 华为 VID = `12D1`
- 仅充电模式典型枚举：**WPD(MTP) + Mass Storage + USB Composite，没有 ADB 接口** → `adb devices` 必空

### 6. 拔线重插（关键步骤）
**开关刚打开 adbd 不会立即以调试接口枚举——必须拔线重插 USB**，设备才会以新配置重新枚举。
重插后若仍无 ADB 接口 → 把 USB 模式切「传输文件」（MTP 下 ADB 接口更易被 Windows 识别）。

### 7. ⚠️ 主开关「USB 调试」才是总闸（2026-08-06 实测教训）
「仅充电模式下允许 ADB」只是配套开关；**主开关「USB 调试」没开，ADB 接口永远不会枚举**。
诊断信号：设备管理器里 VID_12D1 只有 MTP/Mass Storage，连「未知设备/带感叹号」的 ADB 条目都没有
→ 不是驱动问题，是平板侧配置没到位（先查主开关，别浪费时间查驱动）。

## 完整打通流程（2026-08-06 实测全链路 ✅）

```bash
# ① 电脑侧（VPS 经 SSH 远程执行）：设备出现后确认授权
ssh 61915@100.108.175.15 "C:\platform-tools\adb.exe devices -l"
#   → U9U6R20601000142 unauthorized  → 平板上弹 RSA 授权框，用户点「允许」+「一律允许」

# ② 电脑侧：开网络调试端口
ssh 61915@100.108.175.15 "C:\platform-tools\adb.exe tcpip 5555"
#   → restarting in TCP mode port: 5555

# ③ 拔掉 USB 线（平板转 WiFi/Tailscale 无线模式）

# ④ VPS 侧首次 connect 会 unauthorized —— 因为 VPS adb 用自己独立的 RSA 密钥！
adb connect 100.78.214.117:5555   # → failed to authenticate / unauthorized

# ⑤ 关键：把电脑上已授权的 adbkey 同步到 VPS，指纹一致免再弹窗（2026-08-06 新发现）
rm -f /root/.android/adbkey /root/.android/adbkey.pub
scp -o StrictHostKeyChecking=no "61915@100.108.175.15:C:/Users/61915/.android/adbkey" /root/.android/adbkey
scp -o StrictHostKeyChecking=no "61915@100.108.175.15:C:/Users/61915/.android/adbkey.pub" /root/.android/adbkey.pub
# 注意路径用正斜杠 C:/Users/... —— 双反斜杠会被 ssh/scp 的 shell 转义吃掉（scp: No such file）
# 校验：adbkey.pub 字节数与电脑一致（如 712B）

# ⑥ 重启 VPS adb daemon 重连 → 直接 device 状态
adb kill-server && adb connect 100.78.214.117:5555
adb devices -l   # → 100.78.214.117:5555  device product:MRX-W19 model:MRX_W19

# ⑦ 验证
adb -s 100.78.214.117:5555 shell "echo SHELL_OK && getprop ro.product.model"
adb -s 100.78.214.117:5555 shell input keyevent KEYCODE_HOME   # UI 注入实测
adb -s 100.78.214.117:5555 shell "dumpsys power | grep mWakefulness"  # Awake
```

## 🚑 ADB 复活 Termux（新隧道恢复路径，2026-08-06 实测）
华为系统后台冻结（SIGSTOP）会把 Termux 冻死 → sshd 拒连 → 隧道断。
**ADB 是远程拉起 Termux 的钥匙**（SSH 都连不上了只能靠它）：
```bash
adb -s 100.78.214.117:5555 shell "am start -n com.termux/.app.TermuxActivity"
sleep 8
adb -s 100.78.214.117:5555 shell "ps -A | grep -E 'termux|sshd'"   # 确认 sshd 回归
adb -s 100.78.214.117:5555 shell "ss -tlnp | grep 8022"           # 8022 LISTEN
# sshd 恢复后 tablet-tunnel.service 自动重连（~65s 周期），出口回到 180.164.97.180
```
排查顺序：`ping 100.78.214.117`（通=网络 OK）→ `ssh :8022`（拒连=Termux 死）→ ADB 拉起。

## 防冻结（用户手动，防复发）
```
设置 → 应用 → 应用管理 → Termux（Tailscale 同理）
├── 电池 → 耗电保护 → 不限制（关键）
└── 启动管理 → 手动管理 → 全部允许（自启动/关联启动/后台活动）
```

## 坑
| 坑 | 现象 | 解法 |
|---|---|---|
| 开关打开不生效 | `adb devices` 仍空 | **拔线重插**，adbd 重新枚举 |
| 主开关没开 | 重插后仍无 ADB 接口，设备管理器无 ADB 条目 | 开发者选项开「USB 调试」主开关（总闸） |
| 仅充电枚举不全 | 设备管理器只见 MTP/Mass Storage | 重插无效 → 切「传输文件」模式 |
| VPS connect 后 unauthorized | VPS adb 独立 RSA 密钥未被平板授权 | **同步电脑 adbkey 到 VPS**（见步骤⑤），指纹一致免弹窗 |
| scp Windows 路径 | `C:\\Users\\...` 报 No such file | 用正斜杠 `C:/Users/...`，反斜杠被 shell 转义 |
| Google USB Driver 装不上 | `pnputil /add-driver android_winusb.inf` 报 Authenticode 签名验证失败 | 该 INF 未签名，别硬装；靠 Windows Update 自动拉驱动（重插触发） |
| Windows SSH 无 GNU tail | `\| tail -1` 报 invalid context | 用 PowerShell `Select-Object -Last 1` / `Out-String` |
| adb server 起不来 | `cannot connect to daemon at tcp:5037` | PowerShell 杀残留 adb 进程再 `adb devices`（自动起 daemon） |
| 需用户操作点 | RSA 授权弹窗、APK 安装界面 | 电脑/平板侧只能引导用户点，SSH 无法代点 UI |

## 🎮 UI 自动化实测（2026-08-06 小红书全通过）
链路打通后第一轮真机测试：**真实 App 客户端 + 住宅 WiFi + ADB 注入触摸 = 零风控**。
结论：对已装官方 App 的平台（小红书/知乎/贴吧），ADB 驱动真机 App 比 camoufox 更优——无 TLS/JS 指纹、触摸事件走 Android 输入管道伪造不了、App 侧无法区分。camoufox 仍是无 App 场景（网页抓取）的正规军。

### 启动 App 的正确姿势
```bash
# ❌ 猜 MainActivity 会报 Error type 3（组件名不存在）
adb shell "am start -n com.xingin.xhs/.MainActivity"   # Error type 3
# ✅ 先查真实 launcher 组件
adb shell "cmd package resolve-activity --brief <pkg>"  # → com.xingin.xhs/.index.v2.IndexActivityV2
adb shell "am start -n <上面拿到的组件>"
# 兜底：monkey 注入 launcher 事件也能拉起
adb shell "monkey -p <pkg> -c android.intent.category.LAUNCHER 1"
```
已知组件：小红书 `com.xingin.xhs` → `.index.v2.IndexActivityV2`；知乎 `com.zhihu.android`；贴吧 `com.baidu.tieba`。

### 状态确认三查
```bash
adb shell "dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity'"  # App 真在前台
adb shell "dumpsys window | grep mCurrentFocus"       # 可为 null（锁屏/桌面），以 mResumedActivity 为准
adb shell "wm size"                                    # 1600x2560，swipe 坐标参考
```

### 刷流 + 验证（风控检测法）
```bash
# 注入真人手势（300ms 正常速度滑，别用 150ms 快速滑）
adb shell "input swipe 600 1600 600 500 300"     # 上滑刷信息流
adb shell "input tap 800 700"                    # 点击进详情
# 验证页面在动：两次截图 MD5 不同 = 滑动生效
adb exec-out screencap -p > /tmp/s1.png
md5sum /tmp/s1.png /tmp/s2.png
# 风控检测：uiautomator dump 出页面文本，grep 有无验证码/滑块/强制登录
adb shell "uiautomator dump /sdcard/ui.xml; cat /sdcard/ui.xml | grep -oE 'text=\"[^\"]{1,40}\"'"
# 干净信号：真实笔记昵称/话题/直播元素（布豆豆儿、直播中、deepseek计划上调定价）
# 风控信号：验证/安全验证/滑块/滑动拼图/登录后才能继续
```
实测结果：swipe×3 内容变化（MD5 不同）、tap 进直播预告页（立即关注/预约/发弹幕）、全程无验证码无滑块无强制登录弹窗。

## 边界
- adbd 与 sshd 一样有被华为防冻结（SIGSTOP）的风险 → 防冻结设置 + ADB 拉起兜底
- `adb shell` 权限受限时（dumpsys 无输出）属正常：无 root + 未授权应用
- ADB 无线通道依赖 Tailscale 内网；平板 Tailscale 掉线则 5555 不可达（可先 ping 判定）
