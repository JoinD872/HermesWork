# camoufox + 住宅 IP 突破小红书 EdgeOne（2026-08-05 实测）

## 背景：旧结论被推翻

camoufox-install skill 旧记录："小红书（Tencent EdgeOne）❌ 超时——EdgeOne 多层检测，Firefox 也绕不过"。
**这个结论不完整**：当时用的是 VPS 数据中心 IP（192.3.241.244，黑名单）。EdgeOne 拦截的是 IP 画像，不是浏览器指纹。

## 新结论：住宅 IP + camoufox = 通过

```
VPS 走家宽隧道 (socks5://127.0.0.1:10808) + camoufox Firefox
→ 小红书 www.xiaohongshu.com HTTP 200，标题正常加载
→ 无风控滑块（页面里的 "slider" 是 Swiper.js 轮播库代码，误报）
```

## 正确代码（camoufox 0.5.x / AsyncCamoufox）

```python
import asyncio
from camoufox.async_api import AsyncCamoufox

async def main():
    async with AsyncCamoufox(headless=True, proxy={"server": "socks5://127.0.0.1:10808"}) as browser:
        page = await browser.new_page()
        resp = await page.goto("https://www.xiaohongshu.com/", timeout=35000, wait_until="domcontentloaded")
        await page.wait_for_timeout(2000)
        print("状态码:", resp.status)
        print("标题:", await page.title())
        content = await page.content()
        # 注意: "slider" 关键词会命中 Swiper.js 轮播组件代码 → 需检查 iframe/验证码框架才能确认
asyncio.run(main())
```

## 排坑

1. **不要用 playwright 原生 launch**：`AsyncNewBrowser(p, headless=True)` 是协程工厂（coroutine），不能直接 `.launch()`。用 `AsyncCamoufox` 上下文管理器。
2. **geoip 参数需额外装**：`geoip={"timezone":...}` 报 `NotInstalledGeoIPExtra`，需 `pip install camoufox[geoip]`。不加 geoip 也能跑（有 LeakWarning，可忽略）。
3. **风控检测别只看关键词**：`"slider"` 会误命中 Swiper.js；要确认是否真被风控，看 iframe（EdgeOne 验证码会有带 src 的验证 iframe）+ 页面标题是否正常。

## 通用打法：三层组合（最难被判定）

| 层 | 工具 | 作用 |
|---|---|---|
| IP | 家宽隧道 127.0.0.1:10808 | 住宅 IP，无数据中心标记 |
| 浏览器指纹 | camoufox | 完整 TLS/JS/UA/WebGL 伪装 |
| 行为 | 随机延迟 + 人性化节奏 | 不机械高频 |

curl 走隧道只能偶尔用（200 但行为特征像机器人）；正经抓取用 camoufox 走隧道。

## 实测对比（2026-08-05）

| 方式 | 小红书结果 |
|---|---|
| VPS 直连 curl | 302（旧方案 CF 反代时代曾 403/超时） |
| 隧道 curl | 200（快，但行为特征机器人） |
| 隧道 camoufox | **200 + 完整页面加载 + 无验证码** ✅ |
