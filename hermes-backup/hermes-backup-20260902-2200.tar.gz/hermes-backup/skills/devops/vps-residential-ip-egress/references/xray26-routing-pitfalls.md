# Xray 26.x 域名分流排坑（2026-08-05 实测）

场景：Xray 服务端 routing 按 geosite:cn 分流国内域名到家宽 SOCKS5 出口。

## 坑 1：MphDomainMatcher 对 geosite:cn 匹配失效

**症状**：`geosite:cn` 规则不生效——访问 baidu.com 走 direct 而不是 home-broadband；显式写 `"domain": ["baidu.com"]` 却生效。

**根因**：Xray 26.x 默认启用 MphDomainMatcher（最小完美哈希匹配器），对 geosite:cn 这类大类规则匹配异常（日志可见 `MphDomainMatcher is enabled for 118515 domain rule(s)` 但仍不匹配）。

**解法**：routing 里显式指定旧匹配器：
```json
"routing": {
  "domainStrategy": "IPIfNonMatch",
  "domainMatcher": "linear",
  ...
}
```

## 坑 2：rule 内 domain+ip 组合是 AND 语义

**症状**：`{"outboundTag": "home-broadband", "domain": ["geosite:cn"], "ip": ["geoip:cn"]}` 不生效——baidu.com 域名在 geosite:cn 里、解析 IP 也在中国，却走了 direct。

**根因**：Xray 26 中同一 rule 内 domain 和 ip 是 AND（必须同时匹配才算命中）。而 DNS 解析可能返回 CDN 海外 IP（如 myip.ipip.net 实际是 Cloudflare 托管，IP 104.20.25.138 在美国），geoip:cn 不匹配 → 整条规则失效。

**解法**：拆成两条独立规则（OR 语义）：
```json
{"type": "field", "outboundTag": "home-broadband", "domain": ["geosite:cn"]},
{"type": "field", "outboundTag": "home-broadband", "ip": ["geoip:cn"]}
```

## 坑 3：xray run -test 按扩展名判断格式

**症状**：`xray run -test -config /usr/local/etc/xray/config.json.direct` 报 `Failed to get format`。

**根因**：Xray 根据文件扩展名推断配置格式，`.direct`/`.split` 等非标准后缀不识别。

**解法**：显式指定 `-format json`：
```bash
xray run -test -format json -config /usr/local/etc/xray/config.json.direct
```

## 坑 4：geosite 数据版本

旧 geosite.dat（v2fly 官方，2026-04）对 geosite:cn 匹配也可能异常。下载 Loyalsoldier 增强版可更新，但**坑 1 的 linear 匹配器是主因**，先改 domainMatcher 再考虑数据文件。

```bash
curl -sL -o /usr/local/share/xray/geosite.dat "https://raw.githubusercontent.com/Loyalsoldier/v2ray-rules-dat/release/geosite.dat"
curl -sL -o /usr/local/share/xray/geoip.dat "https://raw.githubusercontent.com/Loyalsoldier/v2ray-rules-dat/release/geoip.dat"
```

## 调试方法

临时把 loglevel 改 debug，重启 Xray，看路由决策：
```bash
sed -i 's/"loglevel": "warning"/"loglevel": "debug"/' /usr/local/etc/xray/config.json
systemctl restart xray
journalctl -u xray --since "1 min ago" | grep -E "detour|received"
# 期望输出: taking detour [home-broadband] for [tcp:www.baidu.com:443]
# 改回: sed -i 's/"loglevel": "debug"/"loglevel": "warning"/' ...
```

## 验证分流是否生效（端到端）

用 Xray 客户端模式自测（服务端侧验证，不依赖手机 v2rayN）：
```json
// /tmp/xray-client-test.json
{"log":{"loglevel":"warning"},
 "inbounds":[{"listen":"127.0.0.1","port":10999,"protocol":"socks","settings":{"udp":true}}],
 "outbounds":[{"protocol":"vless","tag":"vless-out","settings":{"vnext":[{"address":"127.0.0.1","port":8081,"users":[{"id":"<UUID>","encryption":"none"}]}]},
   "streamSettings":{"network":"ws","wsSettings":{"path":"/vless-tunnel"}}}]}
```
```bash
xray run -config /tmp/xray-client-test.json &   # 后台
curl -s --socks5-hostname 127.0.0.1:10999 https://myip.ipip.net   # 国内站应显示家宽 IP
curl -s --socks5-hostname 127.0.0.1:10999 https://www.google.com   # 海外站应 200 直连
```
注意：`--socks5-hostname` 把域名交给代理解析；若客户端先把域名解析成 IP 再传，服务端只能靠 geoip:cn 匹配。
