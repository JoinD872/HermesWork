# tablet-tunnel 运维手册（2026-08-05 实测）

## systemd 服务文件（/etc/systemd/system/tablet-tunnel.service）

```ini
[Unit]
Description=Tablet home-broadband exit tunnel (ssh -D via Tailscale)
After=network-online.target tailscaled.service
Wants=network-online.target

[Service]
Type=simple
ExecStart=/root/.hermes/scripts/tablet-tunnel.sh
Restart=always
RestartSec=15
MemoryMax=128M

[Install]
WantedBy=multi-user.target
```

启用：`systemctl daemon-reload && systemctl enable --now tablet-tunnel.service`

## 脚本关键逻辑（tablet-tunnel.sh）

循环四步：
1. `tailscale ping` 平板（失败 → miss_count+1）
2. TCP 测平板 8022（失败 → miss_count+1）
3. 隧道有效？`ss -tln | grep 10808` && `verify_tunnel`（curl 出口非 VPS IP）
4. 无效 → kill 旧 PID + 后台重启 ssh -D

**失联降级**：miss_count ≥ 3（约 90s）→ `bash xray_fallback.sh direct`
**恢复切回**：隧道健康且 `xray_mode()` 返回 direct → `bash xray_fallback.sh split`

**陷阱**：`start_tunnel` 必须后台运行（`ssh ... &` + 记录 TUNNEL_PID），否则 ssh -N 前台阻塞，主循环永远走不到恢复逻辑。

## xray_fallback.sh 关键点

- 维护两份配置：`config.json.split` / `config.json.direct`
- 切换 = 生成 → `xray run -test -format json` 校验 → 备份当前 → 应用 → `systemctl restart xray`
- **必须 `-format json`**：Xray 按文件扩展名判断格式，`.direct`/`.split` 后缀会报 `Failed to get format`
- direct 模式 = 移除 home-broadband outbound + 路由只剩全直连
- split 模式 = 恢复 home-broadband outbound + geosite:cn/geoip:cn 走家宽

## 恢复判定陷阱（重要）

服务重启后 `degraded` 内存变量清零。恢复逻辑**必须读 Xray 实际配置**：
```bash
xray_mode() {
    if grep -q "home-broadband" /usr/local/etc/xray/config.json 2>/dev/null; then
        echo "split"; else echo "direct"
    fi
}
```
不要用 `if [ "$degraded" = "1" ]` 判断——重启后永远为 false。

## 测试流程（模拟失联）

```bash
# 1. 停服务 + 杀隧道
systemctl stop tablet-tunnel.service
PID=$(ss -tlnp | grep 10808 | grep -oE 'pid=[0-9]+' | head -1 | cut -d= -f2); kill $PID

# 2. 改 TABLET_IP 为不可达（100.255.255.1）测降级
sed -i 's/TABLET_IP="100.78.214.117"/TABLET_IP="100.255.255.1"/' /root/.hermes/scripts/tablet-tunnel.sh
systemctl start tablet-tunnel.service   # 等 ~90s 应见 "Xray 降级为全直连"
grep -c home-broadband /usr/local/etc/xray/config.json  # 应输出 0

# 3. 恢复 IP + 重启服务，应自动切回 split
cp tablet-tunnel.sh.bak tablet-tunnel.sh && systemctl restart tablet-tunnel.service
grep -c home-broadband /usr/local/etc/xray/config.json  # 应输出 3
curl -s --socks5-hostname 127.0.0.1:10808 https://myip.ipip.net  # 应显示上海电信
```

## 日志

`/var/log/tablet-tunnel.log` — 追加式，含每次检查/重连/切换记录。

## 实测数据（2026-08-05）

| 项 | 值 |
|---|---|
| 家宽出口 IP | 180.164.97.180（上海电信 CHINANET-SH） |
| abuser_score | 0.0008 (Low) |
| is_datacenter | False |
| 隧道延迟 | 平板 Tailscale relay sfo，~300ms RTT |
| 息屏状态 | wake-lock + 白名单后 5 连测全通 |
| 一键杀进程 | 杀 App 前台不影响后台 sshd，隧道不断 |

## 已知边界

- 家宽出口访问海外站（Google/Reddit）超时 → 是 GFW 拦，不是隧道问题
- 小红书/知乎用 curl 访问 200 但行为像机器人 → 高频抓取用 camoufox（见 camoufox-residential-ip.md）
- 平板重启后 Termux 不自动启动 → 需 Termux:Boot 插件（见下节）

---

# 平板大文件传输（DERP 中继断流问题，2026-08-05 实测）

## 症状

VPS → 平板（Tailscale DERP relay sfo 链路）传大文件，scp / curl / base64 管道全部**中途截断**：
- scp：743KB APK 传成 261KB（连续两次同值，不是随机）
- base64 管道：991KB 传成 98KB
- curl 从 VPS HTTP 服务下载：743KB 传成 405KB / 359KB（`curl -C -` 断点续传也停在同值）

小文件（几十 KB 内）正常。根因：Tailscale DERP 中继对大流量长传输不稳定（非固定大小，约 100KB-400KB 随机断）。

## 解法：分块 base64 传输（可靠）

每块 30KB base64（约 22KB 原始数据），**每块独立 SSH 会话**传输，平板端 `>>` 追加，最后解码 + md5 校验：

```bash
# VPS 侧：切块
cd /tmp && split -b 30000 -d -a 2 termux-boot.b64 chunk_
# 逐块传（每块 3 次 SSH 往返：写 + 查大小；约 34 块需 ~5 分钟）
for f in /tmp/chunk_*; do
    cat "$f" | ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=6 -o BatchMode=yes \
        u0_a154@100.78.214.117 -p 8022 "cat >> ~/termux-boot.b64"
done
# 平板端解码 + 校验
ssh ... 'base64 -d ~/termux-boot.b64 > ~/termux-boot.apk && md5sum ~/termux-boot.apk'
```

**关键**：小块 + 独立连接 = 单次传输量小，不会触发断流。验证 md5 与源一致才算成功。

## 传文件到平板的备选通道

- SSH 管道（小文件 OK，>100KB 风险）
- VPS 起 `python3 -m http.server` 让平板 curl（同样受 DERP 断流限制，但可配合 `curl -C -` 多轮续传）
- 分块 base64（最可靠，已实测 991752 字节完整到达）

---

# Termux:Boot 开机自启配置（2026-08-05）

## 目标

平板断电/重启后自动拉起 Termux sshd，无需手动打开 Termux。

## 前提：必须手动安装 termux-boot APK

**Termux 沙盒无 root，无法 `pm install` 静默装 APK**（`pm install` 报 Permission denied / 无法读 file context）。termux-boot 也不在 pkg 仓库（`pkg install termux-boot` → Unable to locate package）。

流程：
1. **下载 F-Droid release 签名版**（GitHub 只有 debug 版，曾误判华为会拒 debug 签名）：
   ```bash
   # F-Droid 直链格式：https://f-droid.org/repo/<包名>_<versionCode>.apk
   curl -sL -o termux-boot-fd.apk "https://f-droid.org/repo/com.termux.boot_1000.apk"
   # 26KB 属正常（termux-boot 只是开机广播接收器，R8 压缩后 classes.dex 5.8KB）
   # 验证：file 应显示 "Android package (APK), with APK Signing Block"
   ```
2. 通过 SSH 传到平板（分块 base64 法，见上节）
3. **触发安装界面**：`termux-open ~/termux-boot-fd.apk`
   - ⚠️ **必须在 Termux 前台执行才弹窗**——SSH 后台执行零弹窗；需用户先在平板上打开 Termux App 到前台，再在 VPS 侧执行
   - ❌ 不要用 `am start -a android.intent.action.VIEW -d "file://..."`：Android 7+ 禁 file:// URI 分享，不弹界面
   - ❌ 不要用 `pm install`：Termux 无 root，报 Permission denied
   - 提示"不允许安装未知应用"时，引导用户去设置允许一次
4. 装好后打开一次 termux-boot App（注册开机广播）

## ⚠️ 实测终局：GitHub 版和 F-Droid 版都失败（2026-08-05）

aapt 验证两版 APK 都合法（com.termux.boot versionCode 1000, sdkVersion 21, targetSdk 28，兼容 Android 12）——**但两版安装都报"解析包出问题"**。真正根因：**华为鸿蒙"纯净模式"拦截一切侧载 APK**（Tailscale APK 当时报同样错是同一原因，与签名/文件无关）。关闭路径：设置→搜索"纯净模式"→关闭。若关闭后仍失败，或用户不愿折腾 → **放弃 APK 路线**（termux-boot 不是刚需，见下节）。

## 无 APK 替代（termux-services / runit + 务实默认）

termux-boot 的唯一价值是"平板重启后自动拉起 sshd"。装不上 APK 时：
- **务实默认（推荐）**：平板一直插电几乎不重启；真重启了用户手动打开一次 Termux 跑 `sshd`（30 秒），VPS 侧自动重连。**不值得为这点便利折腾 APK**——向用户说清利弊后即可收工
- 增强（可选）：`pkg install termux-services` 装 runit，`$PREFIX/var/service/sshd/run` 写 `termux-wake-lock; exec sshd -D -e`，删 `down` 标记后 `SVDIR=$PREFIX/var/service sv up sshd`；但 runsvdir 守护仍需 Termux 前台启动过一次才接管，收益有限，**别过度工程化**

## 开机自启脚本（VPS 通过 SSH 已配好）

平板 `~/.termux/boot/start-sshd.sh`：
```bash
#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock
sshd
```
`chmod +x` 即可，无需其他配置。

## 防杀后台三件套（华为平板必需）

1. 设置 → 应用 → Termux → 电池 → 电池优化 → **不允许**
2. 设置 → 应用 → Termux → 应用启动管理 → 手动管理 → 允许自启动 + 后台活动
3. Termux 内 `termux-wake-lock`（开机脚本里已含）

## 验证

- `pm list packages | grep termux` 确认 termux-boot 已装
- 平板重启后 VPS 侧 `tailscale ping` 平板 + `ss -tln | grep 10808` 应自动恢复
- 日志 `/var/log/tablet-tunnel.log` 应出现新的"服务启动"行
