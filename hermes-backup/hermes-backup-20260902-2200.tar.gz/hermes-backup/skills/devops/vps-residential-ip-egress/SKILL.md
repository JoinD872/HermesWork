---
name: vps-residential-ip-egress
description: VPS 获得住宅 IP 出口 — 用闲置安卓平板(Tailscale + Termux sshd)搭家宽出口 + systemd 自动重连/失联兜底 + Xray 分流。解决数据中心 IP 黑名单（Spamhaus/CBL）、国内地域封锁站 522、对 IDC IP 严打的 AI 服务
version: 3.0.0
tags: [vps, network, android, ssh, residential-ip, tailscale, xray, termux]
risk: write-safe
---

# VPS 住宅 IP 出口 — 平板家宽隧道（ssh -D 最终版）

## 触发条件
- VPS 出口 IP 信誉差（Spamhaus ZEN/CBL 段级连坐），被国外 AI 服务/风控系统拒
- 国内地域封锁站（bsedu.org.cn 等）直连 522/超时，CF 反代绕不过
- 需要"住宅 IP 画像"访问小红书/知乎/B站（防滑块验证码）
- 用户有闲置 Android 设备（平板/旧手机）可 7×24 插电放家里

## 核心架构（2026-08-05 实测成功，上海电信家宽 180.164.97.180）

```
VPS(192.3.241.244)
   │  systemd: tablet-tunnel.service（开机自启）
   │    └─ 循环脚本：平板在线检查 → 隧道健康检查 → 断线重建 → 失联降级
   │  SOCKS5: 127.0.0.1:10808
   ▼
平板 mrx-w19 (100.78.214.117, Tailscale 内网)
   │  Tailscale（WiFi 常驻）+ Termux sshd :8022（wake-lock 保活）
   ▼
出口 = 家宽住宅 IP（is_datacenter: False, abuser_score ~0.0008）
```

**最终方案 = ssh -D 动态转发（VPS 主动连平板），不是反向隧道**。踩坑史：
- v1/v2 用的 Termux + microsocks + SSH 反向隧道 **最终失败**：microsocks 在 Termux 反复 `Address already in use` 起不来；且平板开着 v2rayN 时流量被全局劫持，出口永远是 VPS IP
- **ssh -D 方案只需要平板 sshd 一个服务**，VPS 侧一个端口，无需 microsocks，稳得多

## 三件套文件

| 文件 | 作用 |
|---|---|
| `/root/.hermes/scripts/tablet-tunnel.sh` | systemd 服务脚本：重连 + 失联降级（见 references/tablet-tunnel-ops.md） |
| `/root/.hermes/scripts/xray_fallback.sh` | Xray 模式切换（split 分流 / direct 全直连） |
| `/etc/systemd/system/tablet-tunnel.service` | 开机自启 |

## 关键配置

### 1. VPS → 平板隧道（systemd 托管）
```bash
ssh -i /root/.ssh/id_ed25519 -N -D 10808 \
    -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=30 \
    -o ServerAliveCountMax=3 -o ExitOnForwardFailure=yes \
    u0_a154@100.78.214.117 -p 8022
```
**陷阱**：脚本里 `start_tunnel` 必须后台运行（`&` + 记录 TUNNEL_PID），否则 ssh -N 前台阻塞，主循环永远走不到恢复逻辑。

### 2. Xray 分流（/usr/local/etc/xray/config.json）
```json
"outbounds": [
  {"protocol": "freedom", "tag": "direct"},
  {"protocol": "socks", "tag": "home-broadband",
   "settings": {"servers": [{"address": "127.0.0.1", "port": 10808}]}}
],
"routing": {
  "domainStrategy": "IPIfNonMatch",
  "domainMatcher": "linear",
  "rules": [
    {"type": "field", "outboundTag": "direct", "ip": ["geoip:private"]},
    {"type": "field", "outboundTag": "home-broadband", "domain": ["geosite:cn"]},
    {"type": "field", "outboundTag": "home-broadband", "ip": ["geoip:cn"]},
    {"type": "field", "outboundTag": "direct", "network": "tcp,udp"}
  ]
}
```
效果：v2rayN 客户端零改动，服务端按域名自动分流——国内域名走家宽，海外直连。

### 3. 失联兜底逻辑
- 连续 3 次（约 90s）平板检测失败 → `xray_fallback.sh direct`（全直连，服务不中断）
- 平板恢复且隧道健康 → 自动切回 split
- **恢复判定必须基于 Xray 实际配置**（grep home-broadband），不能依赖脚本内存变量（服务重启后清零）

## 使用方式
```bash
# VPS 上任何命令走家宽出口
curl --socks5-hostname 127.0.0.1:10808 https://xxx
python3 脚本 proxies={"http":"socks5h://127.0.0.1:10808","https":"socks5h://127.0.0.1:10808"}
```

## 验证命令
```bash
curl -s --socks5-hostname 127.0.0.1:10808 https://ifconfig.me   # 应显示家宽 IP
curl -s --socks5-hostname 127.0.0.1:10808 https://myip.ipip.net  # 应显示"中国 上海 电信"
python3 /root/.hermes/scripts/ip_reputation.py <家宽IP>          # is_datacenter: False
# VPS 可 SSH 直接操控平板 Termux（诊断/配置/测试）：
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=6 -o BatchMode=yes u0_a154@100.78.214.117 -p 8022 '<cmd>'
```

## 用户实操认知（2026-08-05 实测）
- **交付走 SSH，不走飞书**：用户明确说过"你飞书发我没用，你直接通过SSH装吧"。所有命令/配置/文件优先直接经 SSH 在平板 Termux 执行或分块传输；飞书只用于用户无法自助完成的操作（如必须用户点的 APK 安装界面）
- **Tailscale App 界面显示 Not connected 不可信**：App UI 会短暂掉线显示"Not connected"，但 VPS 侧 `tailscale status` 显示 active + 有实时流量——**以 VPS 侧为准**，先查再决定是否重连，避免误判拆掉本来健康的链路
- **一键杀进程不影响隧道**：杀 App 前台只关界面，后台 sshd 由白名单+wake-lock 托管，隧道不断
- **息屏不影响**：wake-lock 生效后息屏 5 连测全通
- **VPS 能 SSH 操控平板**：走 100.78.214.117:8022，可远程执行 Termux 命令（装包/传文件/测试），但不能改 Android 系统设置、不能装 APK（需用户点安装界面）
- **VPS 能 ADB 无线操控平板 UI（2026-08-06 打通+实测）**：`adb -s 100.78.214.117:5555 shell input tap/swipe/text/keyevent` 可注入真人操作（模拟刷小红书等）、`am start` 拉起被冻结的 Termux。开启链路 + UI 自动化实测（真机 App 零风控）见 references/adb-tablet-control.md
- 用户可亲自验证：杀进程/息屏/失联三连测，结果全通过后才会信任方案

## 边界（必须告知用户）
- 家宽出口访问被 GFW 墙的海外站（Google/Reddit/OpenAI）会超时 → 海外站走 VPS 直连
- 平板关机/断网：隧道断 → 90s 后 Xray 自动降级直连；海外站不受影响，国内站退化（IP 差但能通）
- CBL 有记录是家宽动态 IP 段通病，**不影响 AI 服务**（它们看 is_datacenter 不看 CBL）
- 高频抓取小红书/知乎要用 camoufox（见 references/camoufox-residential-ip.md），curl 行为特征像机器人

## 排坑清单（详细版见 references/tablet-tunnel-ops.md）
1. 家宽直连 VPS 公网 IP 被阻断（ping 100% 丢包 + ssh timeout）→ 必须走 Tailscale 内网
2. Tailscale 官方二进制在 Termux 跑 SIGSYS（Android seccomp 拦 faccessat2）→ 用官方 APK，别用 CLI
3. 华为无 GMS：Tailscale 用 "Email me a code" 登录；APK 走 GitHub 侧载
4. 平板开 v2rayN 时连 SSH 都走代理（来源 IP 显示 VPS 自己），出口永远是 VPS IP → 隧道方案要关 v2rayN
5. **Xray 26.x 默认 MphDomainMatcher 对 geosite:cn 匹配失效** → 必须显式 `domainMatcher: linear`
6. **Xray rule 内 domain+ip 组合是 AND 语义**（geoip 不匹配连累 domain 不生效）→ 拆成独立规则
7. `xray run -test -config file.direct` 报 Failed to get format → 加 `-format json`（Xray 按扩展名判断格式）
8. pkill -f "ssh -i ..." 会误杀自己（命令行含相同串）→ 用 PID kill 或分步执行
9. 公钥从截图提取会被视觉模型误读（0/O、1/l）→ 以用户粘贴文本为权威，ssh-keygen -lf 验证指纹
10. JoinD 仪表盘配置的 hostname ≠ DNS 已配置（ssh.cloudjoind.com 无 A 记录实际不可用）→ 用前 dig 验证
11. **华为装 APK：GitHub debug 版报"解析包出问题"**。曾误判为 debug 签名问题、改用 F-Droid release 签名版（`https://f-droid.org/repo/<pkg>_<versionCode>.apk`，如 com.termux.boot_1000.apk，R8 压缩后 26KB 属正常）——**F-Droid 版同样报"解析包出问题"**。真正根因：**华为鸿蒙"纯净模式"拦截一切侧载 APK**（Tailscale APK 当时也报同样错）。关闭路径：设置→搜索"纯净模式"→关闭。若用户关闭后仍失败（或用户不愿折腾），**果断放弃 APK 路线**——见 references/tablet-tunnel-ops.md 的"无 APK 替代"节
12. **Android 7+ `am start` + file:// URI 不弹安装界面**（FileProvider 限制）→ 用 `termux-open <file>`；且 `termux-open`/`termux-setup-storage` 都必须在 **Termux 前台**执行才弹 UI，SSH 后台执行零弹窗（需用户先打开 Termux App 到前台再触发）
13. **Tailscale DERP 中继传大文件中途断流**（~100-400KB 随机截断，scp/curl/管道均受影响）→ 分块 base64（30KB/块独立 SSH 会话）+ md5 校验（详见 references/tablet-tunnel-ops.md）
14. **开了「仅充电模式下允许 ADB 调试」但 `adb devices` 仍空** → 先确认**主开关「USB 调试」开了**（配套开关不是总闸，主开关没开 ADB 接口永不枚举，设备管理器连未知设备条目都没有），再**拔线重插** USB（详见 references/adb-tablet-control.md）
15. **仅充电模式设备管理器只见 MTP/Mass Storage、无 ADB 接口** → 仅充电枚举不全；重插无效就切「传输文件」模式（MTP 下 ADB 接口更易被 Windows 识别）
16. **Google USB Driver 装不上**：`pnputil /add-driver android_winusb.inf` 报 Authenticode 签名验证失败（该驱动 INF 未签名）→ 别硬装，靠 Windows Update 自动拉 ADB 驱动（重插后触发）
17. **VPS `adb connect` 后 unauthorized** → VPS adb 用自己的独立 RSA 密钥，平板没授权它。解法：把电脑上已授权的 `.android/adbkey`+`.pub` scp 到 VPS（路径用正斜杠 `C:/Users/...`，反斜杠被 shell 转义），重启 adb daemon 重连即 device 状态，免二次弹窗
18. **Termux 被华为冻结（SIGSTOP）→ sshd 拒连 → 隧道断** → ADB 是远程复活钥匙：`adb shell am start -n com.termux/.app.TermuxActivity`，sshd 回归后 tablet-tunnel 自动重连（~65s）。排查顺序：ping 平板通=网络 OK → ssh :8022 拒连=Termux 死 → ADB 拉起。预防：平板设置里 Termux/Tailscale 电池→耗电保护→不限制 + 启动管理→手动管理全部允许

## 平板跑 CloudflareSpeedTest 测优选 IP（2026-08-09 实测）

**场景**：用户 V2RayN 延迟高，需要从**家宽住宅网络**（用户真实体验）测 CF 优选 IP 的延迟+下载速度。VPS 侧只能验证连通性（HTTP 400=通），延迟无参考价值。平板在家宽 WiFi 下，是理想测速端。

**工具准备（VPS 侧，二进制名是 `cfst` 不是 CloudflareST）**：
```bash
# 查真实 release 文件名（asset 名含 cfst_ 前缀，不是 CloudflareST_）
curl -s -m 15 "https://api.github.com/repos/XIU2/CloudflareSpeedTest/releases/latest" | grep '"name"'

# 下载对应架构
curl -sL -m 60 -o /tmp/cfst_linux_arm64.tar.gz \
  "https://github.com/XIU2/CloudflareSpeedTest/releases/latest/download/cfst_linux_arm64.tar.gz"
tar -xzf /tmp/cfst_linux_arm64.tar.gz -C /tmp/cfst-arm/   # 解出 cfst + ip.txt
chmod +x /tmp/cfst-arm/cfst_linux_arm64/cfst
# Windows 备选：cfst_windows_amd64.zip（DaLao 上用）
```

**跑测（SSH 进平板 Termux）**：
```bash
# 1. 确认平板 SSH 活着
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=6 -o BatchMode=yes u0_a154@100.78.214.117 -p 8022 "uname -m"
# 2. 传工具（小文件 ~2.8MB，DERP 中继若断流用分块 base64，见 tablet-tunnel-ops.md）
# 3. 定制 ip.txt：只测 Tunnel 可用段（108.162.192-198/104.16/141.101 等），避免全量 26 段浪费时间
# 4. 执行（-tp 测速端口 443，-n 测速次数）
/tmp/cfst -tp 443 -n 200 -p 20 -dd -o result.csv
# 5. 解析 result.csv 取 延迟/下载速度 前 5
```

**⚠️ 前置检查：平板 Termux 冻结时无法远程复活**：
- 症状：`ping 100.78.214.117` 通（Tailscale DERP relay 可达）但 SSH :8022 / ADB :5555 / 其他端口全 closed
- 这是华为冻结 Termux 的系统级行为，**只能用户本机点开 Termux App 复活**，VPS 侧无解（ADB 无线调试也没开时）
- DaLao（Windows）也可能 offline（Tailscale "last seen 1h ago"）——先 `tailscale status` 确认设备在线再计划
- 备选：DaLao 开机后从 Windows 跑测速更佳（就是 V2RayN 所在机器，体验最真实）

**⚠️ cfst HTTPing 模式测 Xray 隧道全灭（2026-08-09 踩坑）**：
```bash
# ❌ 错误：-httping -httping-code 400 直测隧道域名 → 家宽侧 4624/4624 全 0 可用
#    （VPS 数据中心侧反而能出列表，迷惑性极强）
#    根因：cfst 直连候选 IP 时不带正确 SNI，TLS 握手失败（exit 35）
# ❌ 结论：不要用 cfst 测隧道延迟，cfst 只适合测 CF 官方测速点下载
```

**✅ 正确方法：手动 curl --resolve 循环（隧道延迟）**：
```bash
# 每个 IP 测 3 次取平均；HTTP 400 = 通（Xray 对非 WS 请求的预期响应），000/35 = 不通
for ip in 108.162.193.1 108.162.195.1 104.16.5.1 141.101.114.1; do
  ssh -i /root/.ssh/id_ed25519 u0_a154@100.78.214.117 -p 8022 \
    "curl -s --max-time 4 --resolve proxy.cloudjoind.com:443:$ip -o /dev/null -w '$ip %{http_code} %{time_total}\n' https://proxy.cloudjoind.com/vless-tunnel"
done
# 下载速度（CF 官方测速点 speed.cloudflare.com，与优选 IP 同边缘节点）：
curl -s --max-time 15 --resolve speed.cloudflare.com:443:<IP> -o /dev/null \
  -w "%{speed_download}" "https://speed.cloudflare.com/__down?bytes=5000000"
# 全量循环脚本存 ~/ 路径（Termux 无 /tmp），nohup 后台跑避免 SSH 超时；脚本用 awk 计算（Termux 无 bc）
```

**2026-08-09 实测结果（上海电信家宽 180.164.97.180，含 Tailscale DERP 中继损耗）**：
- `108.162.192.1~198.1` 段通（**197.1 除外**）；`199.1~215.1` 全灭；`172.64.x` / `190.93.x` 全灭；`104.16.0-15.1` 全通但下载慢（~3 MB/s vs Tunnel 段 5-7 MB/s）；`141.101.113/114/115/120-123.1` 通
- 最佳：`108.162.193.1` 448ms / 6.92 MB/s；`108.162.195.1` 456ms / 6.24 MB/s；`108.162.198.1` 498ms / 5.01 MB/s
- 历史 IP `162.159.39.141`（742ms）、`108.162.198.81`（858ms）仍通但不如新段
- **筛选结论**：优选优先扫 `108.162.192.0/22~198.0/24`，其次 `104.16.x.1` 和 `141.101.x.1`
- 测完删除平板临时文件（~/cfst ~/ip.txt ~/*.sh ~/*.csv）不留残余

## 相关技能
- `vps-ip-blocking-solutions`（手动创建，后台 curator 不可编辑）：本领域的方案总览
- `camoufox-install`（手动创建，不可编辑）：抗检测浏览器，配住宅 IP 做正经抓取

## References
- `references/tablet-tunnel-ops.md` — systemd 服务/脚本/测试流程/实测数据 + **平板大文件分块传输**（DERP 断流解法）+ **Termux:Boot 开机自启**配置
- `references/adb-tablet-control.md` — ADB 平板 UI 控制开启链路（VPS+电脑装 adb、设备枚举诊断、仅充电模式坑、pnputil 签名失败）
- `references/camoufox-residential-ip.md` — 住宅 IP + camoufox 突破小红书 EdgeOne（推翻旧结论）
- `references/xray26-routing-pitfalls.md` — Xray 26 分流三大坑（MphDomainMatcher/AND语义/-format json）
- `references/home-router-proxy-assessment.md` — 家庭路由器品牌识别（eWeb/luci-static 特征探测）+ 软路由/交换机/exit node/客户端四方案取舍（华为路由器不支持代理插件）
