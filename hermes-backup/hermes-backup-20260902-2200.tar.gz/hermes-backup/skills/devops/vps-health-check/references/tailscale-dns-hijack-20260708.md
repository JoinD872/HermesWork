# Tailscale DNS Hijack — 2026-07-08 事故复盘

## 触发链

```
WARP mode warp (全流量隧道)
  ↓
Tailscale MagicDNS 检测到上游 DNS 变化
  ↓
/etc/resolv.conf 被覆写 → nameserver 100.100.100.100
  ↓
systemd-resolved 内部仍正常 (1.1.1.1)
  ↓
DNS 分裂状态：resolvectl ✅ 但文件级 DNS ❌
  ↓
应用程序读 /etc/resolv.conf → 解析失败
  ↓
Hermes 飞书断连 + V2RayN 损坏
```

## 根因

Tailscale 不只是 VPN。它还管理 DNS (MagicDNS)。`--accept-dns=true`（默认）使 Tailscale 有权修改系统 DNS。

当网络环境变化（如 WARP 启用全流量模式）时，Tailscale 的 DNS 管理器会主动重写 `/etc/resolv.conf`，将 DNS 指向 `100.100.100.100`（Tailscale 内部 DNS）。该 IP 在 VPS 上不可达，导致系统 DNS 完全失效。

## DNS 分裂状态（关键发现）

同时检查两个层面才能发现：
- `resolvectl status` → DNS Servers 可能显示 1.1.1.1（正常）
- `cat /etc/resolv.conf` → 实际 nameserver 已变成 100.100.100.100（被劫持）

## 修复命令

```bash
systemctl stop tailscaled
rm -f /etc/resolv.conf
ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf
# 编辑 /etc/systemd/resolved.conf 确保 DNS=1.1.1.1 8.8.8.8
systemctl restart systemd-resolved
```

## 防止复发

如需保留 Tailscale，必须：
```bash
tailscale up --accept-dns=false --ssh
```

## 排查顺序（通用规则）

应用层连接错误时：
1. DNS (`/etc/resolv.conf` + `resolvectl status`)
2. TCP 连接 (`curl -v`)
3. 代理出口 (WARP/Tailscale/HTTP_PROXY)
4. 服务状态 (`systemctl status`)
5. 应用配置 (config/.env)
6. 业务逻辑

## 标签

`dns` `tailscale` `warp` `network` `hermes-gateway` `v2rayn` `incident`
