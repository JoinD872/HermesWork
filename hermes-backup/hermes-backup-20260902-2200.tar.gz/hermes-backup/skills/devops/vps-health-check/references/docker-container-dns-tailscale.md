# Docker 容器 DNS 超时 — Tailscale 干扰排查与修复

> 2026-07-18 修复记录

## 症状

Docker 容器内的应用（如 SearXNG）能正常接收请求（HTTP 200），但所有上游连接全部超时：
- 容器日志显示所有搜索引擎 `Suspended: timeout`
- `docker exec <container> nslookup google.com` ❌ 超时
- `docker exec <container> nslookup google.com 8.8.8.8` ✅ 正常

## 排查路径

```
SearXNG MCP tool 返回 0 结果
  ↓
检查 SearXNG HTTP API (localhost:8888) → HTTP 200, 0 results
  ↓
检查 Docker 日志 → 所有引擎 "Suspended: timeout"
  ↓
检查 port 8888 监听 → docker-proxy 正常 (Up 9 days)
  ↓
检查容器内 DNS:
  docker exec searxng nslookup google.com      → ❌ timeout
  docker exec searxng nslookup google.com 8.8.8.8 → ✅ 142.251.32.174
  ↓
检查容器 /etc/resolv.conf:
  nameserver 127.0.0.11 (Docker DNS proxy)
  ExtServers: [host(100.100.100.100) host(fd7a:115c:a1e0::53)]
  ↓
根因：Docker DNS 代理从宿主机继承上游 DNS 服务器，
     包含 Tailscale 的 MagicDNS（100.100.100.100 / fd7a::53），
     容器内无法解析这些 DNS 服务器 → 全部超时
```

## 修复

### 永久修复（docker-compose.yml）

在 `docker-compose.yml` 中为服务显式指定 DNS：

```yaml
services:
  searxng:
    dns:
      - 8.8.8.8
      - 1.1.1.1
```

然后重建容器：

```bash
cd /root/searxng && docker compose up -d --force-recreate searxng
```

### 验证

```bash
# 检查容器内 DNS 配置（应显示 8.8.8.8/1.1.1.1）
docker exec searxng cat /etc/resolv.conf

# 测试 DNS 解析
docker exec searxng nslookup google.com

# 测试 SearXNG 搜索引擎
curl -s "http://localhost:8888/search?q=test&format=json&engines=startpage&limit=3"
```

## 补充：VPS 搜索引擎可用性

在同一 VPS（192.3.241.244）上，不同搜索引擎的可用性：

| 引擎 | 状态 | 原因 |
|------|------|------|
| Google | ❌ 403 | VPS 数据中心 IP 被 Google 拦截 |
| DuckDuckGo | ❌ CAPTCHA | 触发验证码 |
| Startpage | ✅ 可用 | 隐私搜索引擎，基于 Yahoo/Bing，未被封锁 |
| Brave | ❌ 超时 | 不可达 |
| Wikipedia | ❌ 超时 | 不可达 |

**结论**：在 VPS 上的 SearXNG，默认引擎应设为 `startpage`。
