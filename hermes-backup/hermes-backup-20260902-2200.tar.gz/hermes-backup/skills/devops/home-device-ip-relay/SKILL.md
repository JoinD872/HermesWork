---
name: home-device-ip-relay
description: 用家庭闲置设备（平板/手机/电脑）做住宅 IP 中继出口 — 借家宽住宅 IP 绕开 VPS 数据中心 IP 黑名单、访问仅限国内 IP 的站。含 Tailscale + ssh -D 推荐架构与全部踩坑。
tags: [vps, network, tailscale, ip-reputation, residential-ip, android]
version: 2026-08-05
risk: write-safe
---

# 住宅 IP 中继出口（家庭设备做出口节点）

## 触发条件
- VPS 出口 IP 在黑名单（Spamhaus/CBL 段级连坐），需要干净住宅 IP
- 访问仅限国内 IP 的站（bsedu 等）需要国内家宽出口
- 用户提到"闲置平板/手机/电脑可以用"——这是可用的中继资源
- IP 信誉提升的替代方案（时间+干净使用是唯一正路，但中继可立即用）

## 一句话本质
借家庭设备的「家宽住宅 IP」当出口：VPS 流量经隧道跑到家里设备，再从家宽出去——对方看到的是住宅 IP（不在黑名单、不限国内），绕开数据中心 IP 原罪。

## 推荐架构：Tailscale + ssh -D 动态转发（2026-08 实锤成功）

```
VPS(192.3.241.244) --ssh -D 10808--> 平板(Tailscale 100.78.x.x, Termux sshd:8022)
     └─ curl --socks5-hostname 127.0.0.1:10808 = 平板家宽出口
```

**为什么选它**：VPS 主动连平板（Tailscale 内网，绕开公网直连被阻断），不需要 microsocks、不占 VpnService、无反向隧道。比「平板主动连 VPS 的反向隧道 + SOCKS5」少一个不稳定环节。

### 平板端（Termux）
```bash
pkg install -y openssh
mkdir -p ~/.ssh && echo "<VPS公钥>" >> ~/.ssh/authorized_keys
chmod 700 ~/.ssh && chmod 600 ~/.ssh/authorized_keys
sshd          # 监听 8022
termux-wake-lock   # 防锁屏冻结（需 pkg install termux-api）
```

### VPS 端
```bash
ssh -i ~/.ssh/id_ed25519 -N -D 10808 \
    -o StrictHostKeyChecking=accept-new \
    -o ServerAliveInterval=30 -o ServerAliveCountMax=3 \
    u0_a154@<平板tailscale-ip> -p 8022
# 验证：
curl --socks5-hostname 127.0.0.1:10808 https://ifconfig.me
```

## 备选架构：microsocks + SSH 反向隧道（平板主动连 VPS）

当平板无法被 VPS 主动连接时用（无 Tailscale 场景）：

```
VPS(127.0.0.1:10808 = 平板出口) <--ssh -R 10808:127.0.0.1:10808-- 平板
```

- 平板窗口1：`microsocks -i 127.0.0.1 -p 10808`（**前台静默 = 成功**，别等输出；ps 查不到进程=没起来）
- 平板窗口2：`ssh -N -R 10808:127.0.0.1:10808 -o StrictHostKeyChecking=accept-new -i ~/.ssh/id_ed25519 root@<VPS-tailscale-ip> -p 2222`
- VPS 验证：`curl --socks5-hostname 127.0.0.1:10808 https://ifconfig.me`

注意：microsocks 在 Termux 里启动失败会静默退出且常报 Address already in use（残留进程），用 `killall -9 microsocks` 清干净再启。

## 关键坑（全部实测踩过，2026-08-05）1. **Android VPN App 劫持一切流量（最阴的坑）**
   - 平板开着 v2rayN/NekoBox 时，SSH 隧道 + SOCKS 出网全被劫持到 VPN 出口
   - 现象：隧道"通了"（端口有监听、认证成功）但出口 IP 永远是 VPS 自己
   - 判据：SSH 日志里平板连接来源 IP = VPS 自己的公网 IP（走代理回环了）
   - 解法：中继设备必须关 VPN。v2rayN 一关，之前走代理的 SSH 隧道也会断（Broken pipe）——正常，重建即可

2. **家宽直连 VPS IP 可能被阻断**
   - 现象：ping 100% 丢包 + ssh Connection timed out，但 VPS 公网侧 2222 可达（暴力破解流量能进来）
   - 这是「你家 → 该美国 IP」的路径被阻断，不是 VPS 侧问题
   - 解法：别死磕直连，走 Tailscale 内网（DERP 中继 ~200-300ms，稳定可用）

3. **华为/鸿蒙系统冻结后台 Termux（方案成功后仍可能断）**
   - 现象：SSH 连接 ESTAB 但 Send-Q 积压增长、数据不流动（curl 不通）
   - 原因：切走/锁屏后系统 SIGSTOP Termux 进程
   - 解法三件套：① 设置→应用→Termux→电池→电池优化→不允许 ② 应用启动管理→手动→允许自启动+后台活动 ③ termux-wake-lock；平板插电放置

4. **SSH 指纹确认卡死**
   - 连 Tailscale 内网 IP 是"新主机"，必须 `-o StrictHostKeyChecking=accept-new`，否则卡在 yes/no 等待（Termux 无人应答）

5. **authorized_keys permitlisten 匹配坑**
   - 给中继密钥加限制时 `permitlisten="127.0.0.1:10808"` 与客户端 `-R 10808:...` 的默认绑定方式不匹配，报 "remote port forwarding failed"（端口其实空闲）
   - 解法：改成 `permitlisten="10808"`（允许任意回环地址绑该端口）

6. **Tailscale 无 GMS 可用**
   - 华为平板没谷歌服务也能装：官方 universal APK 侧载（GitHub releases 95MB）+ "Email me a code" 登录，不需要 Google 账号
   - 荣耀(有 GMS)与华为(无 GMS)不同，但 Tailscale 两者都支持
   - 设备名 mrx-w19 = 华为 MatePad 系列（MRX 开头）

7. **别信 Tailscale App UI 的 "Not connected"（2026-08-05 实测）**
   - 华为平板 App 可能显示断开、点 Connect 无响应，但 **VPS 侧 `tailscale status` 显示设备 active 且有实时流量**——App 界面状态不可靠，以 VPS 侧为准
   - 真正的断连主因是 Android 后台冻结（坑3），不是 Tailscale 故障，别据此换方案
   - **Termux CLI 版 Tailscale 走不通**：`pkg install -y tailscale` 不在仓库；官方 arm64 tgz 二进制启动即 `SIGSYS: bad system call`（Android seccomp 拦 faccessat2）。直接用官方 App，别试 CLI

8. **验证出口别只靠一个端点**
   - api.ipify.org 经家宽中继可能持续超时（运营商 QoS/限速），但 ifconfig.me / ipinfo.io 正常
   - 多端点交叉验证（ifconfig.me + ipinfo.io/json + 实测 baidu/zhihu HTTP 码），别因单端点超时误判隧道断
   - 住宅 IP 的 CBL 列入是常态（家宽动态段整段挂），但 is_datacenter=False、abuser_score 低——AI 服务看 is_datacenter 不看 CBL，CBL 记录不构成换 IP 理由

9. **Xray 26 分流 geosite 匹配失效（2026-08-05 实测）**
   - 默认 `MphDomainMatcher` 对 `geosite:cn` 匹配不到任何域名（日志 `taking detour [direct]`）→ 必须显式 `domainMatcher: "linear"`
   - **rule 内多字段是 AND 语义**：`"domain":["geosite:cn"],"ip":["geoip:cn"]` 合并写 = 域名和 IP 必须同时匹配（geoip 对 CDN 解析出的海外 IP 匹配失败导致整体不命中）→ 拆成独立两条规则
   - 配置校验坑：文件名非 `.json` 扩展名（如 .direct/.split）会报 `Failed to get format` → `xray run -test -format json -config <file>`

10. **Xray 分流架构（v2rayN 客户端零改动）**
    - outbounds 加 `{"protocol":"socks","tag":"home-broadband","settings":{"servers":[{"address":"127.0.0.1","port":10808}]}}`
    - routing：private→direct；`geosite:cn`→home-broadband；`geoip:cn`→home-broadband；其余→direct
    - 效果：国内站/地域封锁站走家宽住宅 IP，海外站走 VPS 直连——用户手机 v2rayN 配置一行不动
    - **边界铁律：家宽出口在国内，被 GFW 墙的海外站（Google/OpenAI）走隧道必超时**，这是特性不是 bug

11. **失联兜底三层机制（systemd 托管）**
    - 第1层：tablet-tunnel.service 断线自动重连（后台 ssh -N，主循环持续检测）
    - 第2层：连续 N 次检测失败（默认 2 次 × ~10s ≈ 30s）→ xray_fallback.sh direct 切全直连，v2rayN 不中断
    - 第3层：平板恢复 → 隧道重建+验证 → 自动切回 split
    - 恢复判定必须基于 **Xray 实际配置状态**（grep home-broadband），不能依赖脚本内存变量——服务重启后变量清零会漏恢复
    - 检测间隔最低 ~20s（阈值1次+5s间隔），太激进会被 Tailscale DERP 瞬时抖动误触发降级→恢复循环

12. **DERP 中继大文件传输断流（2026-08-05 实测）**
    - scp/curl 经 Tailscale DERP 传 >300KB 必截断（scp 卡 261KB、curl 卡 359KB），但小文件/命令正常
    - 解法：分块传输——base64 后按 30KB 切块（split -b 30000），每块独立 SSH 管道追加（`cat chunk | ssh ... "cat >> file"`），平板端 base64 -d 还原，MD5 校验
    - 断点续传（curl -C -）不可靠，DERP 链路本身不稳定

13. **华为纯净模式拦截侧载 APK（2026-08-05 实测）**
    - 现象：装 APK 报"解析包出问题"——即使 APK 有效（aapt dump badging 通过）、MD5 匹配、F-Droid release 签名
    - 这是华为系统级拦截，不是文件问题：设置→系统→纯净模式→关闭
    - termux-open/termux-setup-storage 必须 **Termux 前台运行** 才弹 UI；SSH 后台执行不弹窗
    - termux-boot 插件在华为装不上 → 开机自启降级为：手动开 Termux 跑 sshd（平板插电几乎不重启，可接受）
    - 备选：termux-services + runit（`$PREFIX/var/service/sshd/`，SVDIR 需设置），但 runsvdir 守护需 Termux 前台启动一次才接管

14. **清理清单（哪些无用）**
    - 平板 `~/tailscale-bin/`（CLI 二进制，SIGSYS 崩）68MB → 删
    - 平板 `microsocks`（方案已弃用）→ `pkg uninstall`
    - 平板 termux-boot APK 残留、旧版坏脚本 → 删
    - VPS `/tmp` 分块传输残留 → 删；**临时 HTTP 服务（python3 -m http.server）用完必关**（暴露公网是安全风险）

## 验证清单
```bash
# VPS 侧
tailscale status | grep <设备名>        # 设备在线
ss -tlnp | grep 10808                    # SOCKS 监听
curl --socks5-hostname 127.0.0.1:10808 https://ifconfig.me  # 出口=家宽IP
curl --socks5-hostname 127.0.0.1:10808 https://ipinfo.io/json | head  # 归属地
```
连续测 3-5 次验证稳定性；锁屏 30 分钟后应仍通。

## 边界如实说
- 解决「VPS IP 黑名单被拒」+「仅限国内 IP 的站」——出口是住宅 IP，全放行
- 国外站对 IP 信誉的要求它也能救（住宅 IP 画像比数据中心好）
- 中继设备是单点：断电/杀进程/无网即断 → 补充通道，不替代 CF 反代 + SSH 电脑兜底
