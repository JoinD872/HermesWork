---
name: vps-gemini-ip-reputation-assessment
title: VPS IP 信誉检测与 Gemini 订阅评估
description: VPS 出口 IP 黑名单/类型检测 + Google 直连 + Gemini 订阅可行性与 WARP 优化方案
tags: [vps, gemini, google, ip-reputation, subscription]
---

# VPS IP 信誉检测与 Gemini 订阅评估

## 场景
用户想订阅 Gemini Pro，担心国内用户说的"降智"问题。需要检测 VPS 出口 IP 信誉，评估是否适合订阅。

## 检测命令集

### 1. DNSBL 黑名单检测
```bash
host -t a 192.3.241.244.zen.spamhaus.org
host -t a 192.3.241.244.bl.spamcop.net
host -t a 192.3.241.244.b.barracudacentral.org
host -t a 192.3.241.244.dnsbl.sorbs.net
host -t a 192.3.241.244.cbl.abuseat.org
# NXDOMAIN = 未列入
```

### 2. IP 类型检测
```bash
curl -s https://ipinfo.io/192.3.241.244/json
curl -s "https://api.ip2location.io/?key=DEMO&ip=192.3.241.244&format=json"
```

### 3. Google 直连检测
```bash
curl -sI https://www.google.com -o /dev/null -w "%{http_code}"
curl -sI https://gemini.google.com -o /dev/null -w "%{http_code}"
curl -sI "https://one.google.com/plans?tab=ai" -o /dev/null -w "%{http_code}"
```

## 已知事实（VPS 192.3.241.244, 2026-05-16 实测）
- 黑名单：全部清空
- 代理检测：false
- 数据中心：true（ColoCrossing AS36352）
- Google 直连：正常，无 CAPTCHA
- 区域识别：美国洛杉矶
- 网络架构：客户端→Xray(VLESS+WS)→Cloudflare Tunnel→VPS nginx→Xray→直连

## 订阅方案
- AI Plus: $7.99/月（200GB）
- AI Pro: $19.99/月（5TB）
- AI Ultra: $249.99/月（30TB）

## WARP 优化
- 免费版 $0 够用，延迟 +1-5ms
- 可配 Gemini/Google 域名专用 WARP 分流
- 策略：先直连试用，遇降智再加 WARP

## 降智三因
1. IP/区域检测降级（主因）
2. 家庭组跨区连坐
3. 免费版高峰期限流
