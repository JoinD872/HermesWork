# Chinese Cloud API Accessibility from US VPS

## Key Finding (July 2026)

The VPS (RackNerd, Los Angeles) has **selective** access to Chinese cloud services:

| Service | Reachable? | Notes |
|---------|-----------|-------|
| **Baidu** (www.baidu.com) | ✅ Yes (~1.1s) | Has global CDN |
| **DeepSeek** (api.deepseek.com) | ✅ Yes | Has global endpoint |
| **Volcengine Ark** (ark.cn-beijing.volces.com) | ❌ No | China mainland only, IP 101.126.13.31 (Alibaba Cloud Beijing), connection times out |
| **BytePlus global** (ark.byteapis.com) | ✅ Yes (HTTP 404) | Serves a different API root; `/api/v3/chat/completions` returns 404 |
| **BytePlus** (api.byteplus.com) | ✅ Yes (HTTP 302) | Redirects to API Explorer; requires different API key |

## Volcengine Ark (Doubao Vision Models)

- **API Endpoint**: `https://ark.cn-beijing.volces.com/api/v3/chat/completions`
- **API Key format**: `ark-*` (Volcengine domestic platform key)
- **Access**: China mainland only — requires routing through a Chinese network
- **API format**: OpenAI-compatible chat completions for vision (image_url content type)
- **Global alternative**: None functional — `ark.byteapis.com` returns 404, `api.byteplus.com` redirects to API Explorer

### Current Findings (July 2026)

**Connectivity evolution (2026-07-08 session):**

| Attempt | Method | Result |
|---------|--------|--------|
| Direct HTTPS | curl to IP 101.126.13.31 | ❌ TCP timeout, connection 000 |
| Cloudflare WARP (WarpProxy mode) | SOCKS5 :40000 | ❌ "Host unreachable" — SOCKS5 resolved from VPS directly |
| Cloudflare WARP (warp/full-tunnel mode) | All traffic tunneled | ✅ TCP connected! Got HTTP 401 response |
| Container network | Docker containers | ❌ Same timeout (host network) |

**After WARP (full tunnel) — response was HTTP 401:**
```json
{
  "error": {
    "code": "AuthenticationError",
    "message": "The API key format is incorrect."
  }
}
```

This confirms WARP can **reach** the Chinese Ark endpoint (it responds), but the **API key is region-locked**: the `ark-*` format key only works from China mainland IPs. WARP egress is Cloudflare's US IP (104.28.165.132, Los Angeles).

**Tested international endpoints (all failed):**

| Endpoint | Result |
|----------|--------|
| `ark.byteapis.com/api/v3/chat/completions` | ❌ 404 |
| `ark.byteapis.com/v1/chat/completions` | ❌ 404 |
| `api.byteplus.com/api/v3/chat/completions` | ❌ 302 → API Explorer HTML |
| `open.byteplusapi.com/api/v3/chat/completions` | ❌ 400 MissingParameter / InvalidAuthorization |
| `ark-intl.byteplus.com` | ❌ DNS not found |
| `ark.ap-southeast-1.volces.com` | ❌ Timeout |
| `ark.us-east-1.volces.com` | ❌ DNS not found |

**Different auth header formats tested (all rejected):**
- `Authorization: Bearer <key>` → "format is incorrect" (closest, but region-locked)
- `Authorization: <key>` → "missing or invalid"
- `x-api-key: <key>` → "missing or invalid"
- `X-Volcengine-AccessKey: <key>` → "missing or invalid"

### For Other Chinese Cloud APIs
- **Baidu CDN services**: Reachable (had global CDN)
- **Alibaba Cloud (Beijing region)**: Blocked (same DC as Volcengine — TCP unreachable)
- **Tencent Cloud**: Untested but likely similar
- General rule: Chinese cloud services with global CDN are reachable; services served from mainland-only IP ranges are not

## Two-Layer Diagnosis: Network vs Auth

Chinese cloud APIs accessed from a US VPS have TWO potential failure layers:

```
Layer 1: Network (TCP reachability)
  → Timeout / 000     → 网络层不通（DNS可解析但TCP握手失败）
  → HTTP 200/4xx/5xx  → 网络层通，继续检查认证层

Layer 2: Authentication (API key/region lock)
  → 401 "API key format is incorrect"   → Key is recognized but region-locked（国内Key从国际IP调用被拒）
  → 401 "missing or invalid"            → Key format not recognized at all
  → 403                                 → IP blocked / not authorized
```

### WARP Diagnosis

```bash
# 1. Enable WARP full tunnel
warp-cli --accept-tos mode warp
warp-cli --accept-tos connect

# 2. Check egress IP
curl -s https://api.ipify.org?format=json
# WARP free tier always egresses from US (Cloudflare AS13335)

# 3. Test the API through WARP
curl -s --connect-timeout 10 --max-time 20 -w "\\nHTTP:%{http_code}" \
  https://ark.cn-beijing.volces.com/api/v3/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $API_KEY" \
  -d '{"model":"doubao-seed-2-0-mini-260428","max_tokens":50,"messages":[{"role":"user","content":"hi"}]}'

# Timeout → 网络层不通（WARP也无法穿透）
# 200/401/other → 网络层通了
# 401 "format is incorrect" → 认证层：region-locked API key
```

## Diagnosis Pattern

```bash
# Step 1: DNS resolution
dig ark.cn-beijing.volces.com +short

# Step 2: Direct connectivity test
curl -s --connect-timeout 10 --max-time 20 -w "\\nHTTP:%{http_code}\\nTIME:%{time_total}s" \
  https://ark.cn-beijing.volces.com/api/v3/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $API_KEY" \
  -d '{"model":"doubao-seed-2-0-mini-260428","max_tokens":50,"messages":[{"role":"user","content":"hi"}]}'

# Step 3: If timeout, try through WARP (warp mode)
# Step 4: If 401 after WARP, test different auth methods
python3 -c "
import httpx, json
for header in [{'Authorization': f'Bearer \$key'}, {'Authorization': key}, {'x-api-key': key}]:
    r = httpx.post('https://ark.cn-beijing.volces.com/api/v3/chat/completions', 
        headers={'Content-Type': 'application/json', **header},
        json={'model':'doubao-seed-2-0-mini-260428','max_tokens':50,'messages':[{'role':'user','content':'hi'}]},
        timeout=20)
    print(f'{list(header.keys())[0]}: HTTP {r.status_code} - {r.json().get(\"error\",{}).get(\"message\",\"\")[:80]}')
"
```
