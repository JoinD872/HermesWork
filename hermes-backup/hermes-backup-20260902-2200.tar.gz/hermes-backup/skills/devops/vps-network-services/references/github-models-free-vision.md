# GitHub Models — 免费视觉模型（VPS 替代方案）

当 VPS 无法访问国内云 API（如火山引擎 Ark）时，GitHub Models 提供免费的 GPT-4o-mini 视觉能力替代方案。

## 快速开始

### API 端点
- **Base URL**: `https://models.inference.ai.azure.com`
- **Endpoint**: `/chat/completions` (OpenAI 兼容)
- **Auth**: Bearer token = GitHub PAT (ghp_* / github_pat_* / gho_*)

### 可用的免费视觉模型
| 模型 | 说明 |
|------|------|
| `gpt-4o-mini` | 最快、日常首选，支持视觉 |
| `gpt-4o` | 质量更好但更慢 |
| `Llama-3.2-11B-Vision-Instruct` | 开源视觉模型 |
| `Llama-3.2-90B-Vision-Instruct` | 更大更强的开源视觉模型 |

### 限制
- 受 GitHub 免费额度限制（具体用量见 GitHub 账户）
- 图片必须用 base64 data URL 格式发送（不支持外部 URL 或 file://）

### 测试命令

```bash
export GH_PAT="ghp_你的token"

# 文本测试
curl -s https://models.inference.ai.azure.com/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $GH_PAT" \
  -d '{"model":"gpt-4o-mini","max_tokens":50,"messages":[{"role":"user","content":"hi"}]}'

# 视觉测试（需要 base64 图片）
python3 << 'EOF'
import httpx, base64

pat = "ghp_你的token"
with open("/path/to/image.jpg", "rb") as f:
    b64 = base64.b64encode(f.read()).decode()

resp = httpx.post(
    "https://models.inference.ai.azure.com/chat/completions",
    headers={"Content-Type": "application/json", "Authorization": f"Bearer {pat}"},
    json={
        "model": "gpt-4o-mini",
        "max_tokens": 500,
        "messages": [{"role": "user", "content": [
            {"type": "text", "text": "Describe this image"},
            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}}
        ]}]
    },
    timeout=60
)
print(resp.json()["choices"][0]["message"]["content"])
EOF
```

## 在 Hermes 中配置

### 方式 A：直接配置 auxiliary.vision（推荐）

```yaml
# config.yaml
auxiliary:
  vision:
    provider: custom
    model: gpt-4o-mini
    base_url: https://models.inference.ai.azure.com
    api_key: ghp_你的PAT  # 必须直接写，不能用 key_env
    timeout: 120
    download_timeout: 30
```

### ⚠️ ghp_ 经典 PAT 的关键限制

**经典 GitHub PAT（`ghp_` 前缀）不能被 `key_env` 引用！**

当 Hermes 的 `resolve_vision_provider_client()` 处理 `custom:xxx` 名称的 provider 时，如果环境变量是 `ghp_` 开头的值，Hermes 内部会触发 Copilot handler 拦截，导致 provider 解析为 `copilot` 而非 `custom`，最终认证失败。

**症状**：
```
Vision provider custom:github-models unavailable, falling back to auto vision backends
Copilot token validation failed: Token from `gh auth token` is a classic PAT (ghp_*).
...
RuntimeError: No LLM provider configured for task=vision provider=custom:github-models
```

**修复**：**直接在 `auxiliary.vision.api_key` 字段写入 PAT 值**，不经过 `key_env` / `.env`：
```yaml
# ✅ 正确：直接写 key
api_key: ghp_6qSKC9...XGvJ

# ❌ 错误：走 key_env 会触发 Copilot handler
key_env: GH_MODELS_KEY  # 即使 .env 里有也会被拦截
```

**细粒度 PAT（`github_pat_` 前缀）或 OAuth token（`gho_` 前缀）不受此限制**，可以使用 `key_env`。

### 方式 B：注册为 custom_provider（不推荐，受方式 A 限制影响）

```yaml
custom_providers:
  - name: github-models
    base_url: https://models.inference.ai.azure.com
    key_env: GH_MODELS_KEY
    default_model: gpt-4o-mini
    models:
      - gpt-4o-mini
      - gpt-4o
      - Llama-3.2-11B-Vision-Instruct

auxiliary:
  vision:
    provider: custom:github-models
    model: gpt-4o-mini
    base_url: ''  # 留空，由 custom_provider 提供
    api_key: ''   # 留空，由 key_env 提供
```

## 优先级链（完整架构）

```
用户发图片
  ↓
① DeepSeek V4 Flash 原生视觉（主模型自带）
  ↓ fallback
② GitHub Models gpt-4o-mini（免费辅助）
  ↓ fallback
③ doubao / 国内云视觉（需国内网络）
```

## 故障排查

| 问题 | 原因 | 修复 |
|------|------|------|
| `HTTP 401` | PAT 无效或过期 | 在 GitHub 重新生成 PAT |
| `HTTP 400 - Invalid/Unsupported image URL` | 使用了外部 URL 而非 base64 | 用 base64 data URL: `data:image/jpeg;base64,...` |
| `HTTP 400 - Failed to download image` | GitHub Models 不支持从外部 URL 抓图 | 用 base64 编码后内联发送 |
| `Copilot token validation failed` | ghp_ PAT 触发了 Hermes Copilot handler | 改用直接 api_key 方式（见上方） |
| `No LLM provider configured` | 自定义 provider 解析失败 | 改为 `provider: custom` + 直接 api_key |
