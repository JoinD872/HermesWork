# OpenCode Go Provider 配置记录

配置日期：2026-07-08
订阅：$5/首月 → $10/月
端点：`https://opencode.ai/zen/go/v1`

## 可用模型（20个）

| 模型 ID | 类型 | 支持视觉 |
|---------|------|---------|
| deepseek-v4-flash | 聊天/推理 | ✅（通过 Go API 不可用，直连可用） |
| deepseek-v4-pro | 聊天/推理 | ❌ |
| minimax-m3 | 通用 | **✅ 通过 Go 可用**（OpenAI 格式 + Anthropic 格式均可） |
| minimax-m2.7 | 通用 | ❌ |
| minimax-m2.5 | 通用 | ❌ |
| glm-5.2 | 通用 | ❌ |
| glm-5.1 | 通用 | ❌ |
| kimi-k2.7-code | 编程 | ❌ |
| kimi-k2.6 | 通用 | ❌ |
| qwen3.7-max | 通用 | ❌（Anthropic 格式 400） |
| qwen3.7-plus | 通用 | ❌ |
| qwen3.6-plus | 通用 | ❌ |
| mimo-v2.5-pro | 多模态 | ❌ |
| mimo-v2.5 | 多模态 | ❌ |
| mimo-v2-pro | 多模态 | ❌（500 错误） |
| mimo-v2-omni | 多模态 | ❌（500 错误，可能未上线） |
| hy3-preview | 预览 | ❌ |

## 视觉模型的特殊处理

Go 订阅中唯一可用的视觉模型是 **minimax-m3**，使用 OpenAI 格式即可。

但 Hermes 的辅助视觉系统无法通过 `provider: custom:opencode-go` + `key_env` 的方式解析——`key_env` 在视觉分支不起作用。

### 配置方式

```yaml
# config.yaml
auxiliary:
  vision:
    provider: custom            # 重要：写 custom 而不是 custom:opencode-go
    model: minimax-m3
    base_url: https://opencode.ai/zen/go/v1
    api_key: 你的完整密钥       # 直接填写，不能留空或通过 key_env 引用
```

### 为什么不能用 key_env

Hermes 的 `resolve_vision_provider_client` 在处理 `auxiliary.vision` 时：
1. 如果 `provider` 是带冒号的格式（如 `custom:opencode-go`），会尝试通过命名 provider 查找 → 但对 vision 任务会触发 Copilot/OAuth 拦截
2. 如果 `base_url` 和 `api_key` 为空，fallback 逻辑不可用
3. **必须**显式填写 `base_url` 和 `api_key` 字段

### 验证命令

```bash
export OPENCODE_GO_KEY="你的key"
python3 -c "
import httpx, base64
with open('test.jpg', 'rb') as f:
    img = base64.b64encode(f.read()).decode()
r = httpx.post('https://opencode.ai/zen/go/v1/chat/completions',
    headers={'Content-Type': 'application/json', 'Authorization': f'Bearer \$OPENCODE_GO_KEY'},
    json={'model': 'minimax-m3', 'messages': [{'role': 'user', 'content': [
        {'type': 'text', 'text': 'Describe in 5 words'},
        {'type': 'image_url', 'image_url': {'url': f'data:image/jpeg;base64,{img}'}}
    ]}], 'max_tokens': 100}, timeout=30)
print(r.status_code, r.json()['choices'][0]['message']['content'])
"
```

## Provider 切换安全规则

参考 `security-preflight` 技能的「Provider 更换陷阱：先验证 key，再切换 config」章节。

1. **先写 key，再改 config，最后重启 gateway**
2. 401 AuthenticationError 是非重试错误，Hermes 不会自动恢复
3. 如果 Gateway 在 key 空的时候启动，即使后面补了 key 也必须重启 gateway

```bash
# 正确顺序
# 步骤 1: 写入 key 到 .env
echo 'OPENCODE_GO_KEY=sk-xxx' >> ~/.hermes/.env

# 步骤 2: 验证 key 有效
curl -s -H "Authorization: Bearer $OPENCODE_GO_KEY" \
  https://opencode.ai/zen/go/v1/models | head

# 步骤 3: 修改 config.yaml
# 步骤 4: 重启 gateway（外部 shell，不可在 gateway 会话内执行）
systemctl --user restart hermes-gateway
```

## 注意事项

1. **视觉模型不能走 vision fallback**：Hermes 的 native fast path（主模型视觉）依赖 `supports_vision: true`，但 Go 的 deepseek-v4-flash 不支持视觉 → 必须走 auxiliary.vision
2. **订阅成本**：$10/月包含所有模型，无额外按量计费。但在 Go 的免费额度用完前 cost 显示 $0
3. **Go 不适用于 doubao**：如需要火山引擎 Ark 的 doubao 模型，必须单独走 Ark 直连或 Cloudflare Workers 中转
4. **模型 ID 格式**：在 OpenCode CLI 中需要加 `opencode-go/` 前缀（如 `opencode-go/deepseek-v4-flash`），但通过 REST API 直接用裸 ID
