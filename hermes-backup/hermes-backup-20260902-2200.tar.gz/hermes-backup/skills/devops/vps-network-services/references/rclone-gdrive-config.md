# rclone Google Drive 配置记录

> 记录时间：2026-05-23
> VPS：192.3.241.244（RackNerd 洛杉矶）

## rclone 版本

```
rclone v1.60.1-DEV
- os/version: ubuntu 24.04 (64 bit)
```

## 配置方式

### 交互式创建（headless 模式）

```bash
# 1. 创建 remote（config_is_local=false 表示 headless）
rclone config create <名称> drive config_is_local=false

# 2. 触发 OAuth（会反问是否使用自动浏览器，回答 n）
rclone config reconnect <名称>:

# 当回答 n 时，输出提示："Execute the following on the machine with the web browser: rclone authorize 'drive'"
# 此时启动 OAuth 代理流程（详见 SKILL.md）
```

### OAuth 代理流程

在 VPS 上按以下顺序执行：

```bash
# 1. 启动 rclone authorize
rclone authorize "drive" > /tmp/rclone_auth.log 2>&1 &
sleep 2

# 2. 放行端口
ufw allow 53683/tcp

# 3. socat 转发
socat TCP-LISTEN:53683,reuseaddr,fork TCP:127.0.0.1:53682 &

# 4. 取出 URL
cat /tmp/rclone_auth.log | grep "go to the following link"
# → http://127.0.0.1:53682/auth?state=...
# 用户替换 127.0.0.1:53682 → 192.3.241.244:53683
```

### 用户操作

1. 访问 `http://192.3.241.244:53683/auth?state=...`
2. Google 登录 + 授权
3. 回调到 `http://127.0.0.1:53682/auth?code=...`（打不开）
4. 地址栏改 `127.0.0.1:53682` → `192.3.241.244:53683`
5. 回车 → Success!

### 验证

```bash
# 检查 token
cat ~/.config/rclone/rclone.conf
# 应该包含 token 字段

# 测试连接
rclone ls <名称>: 2>&1 | head -5
```

## 已知问题

- rclone v1.60.1 的 **piped stdin 交互不可靠**（`Failed to read line: EOF`），必须用交互式或文件日志方式获取 URL
- `rclone config create X drive config_is_local=false` 创建配置但不触发 OAuth，需额外 `rclone config reconnect X:` 触发
- config_is_local=false 配置在 apt 安装的默认 rclone（v1.60）中行为与文档不完全一致，OOB 重定向 URI 未生效，需走 socat 代理方式

## ⚠️ GFW 关键坑：OAuth 不在用户本地机器上跑

### 问题现象
2026-05-23 实测：在用户 Windows 桌面（上海，GFW 内）通过 SSH 运行 `rclone authorize "drive"`：
1. 用户浏览器成功打开 Google 登录页
2. 用户成功授权
3. rclone 收到 code（日志显示 `Got code`）
4. **但 token exchange 失败**：`Post "https://oauth2.googleapis.com/token": dial tcp 173.194.43.95:443: connectex: A connection attempt failed`

### 根因
OAuth 流程分两步：
1. **用户授权**（浏览器 → accounts.google.com）— GFW 内可访问
2. **Token exchange**（CLI → oauth2.googleapis.com/token）— **GFW 拦截**

Windows 桌面在上海无法直连 Google 的 token 交换 API，但 VPS（洛杉矶）可以。

### 正解
**OAuth 授权进程（`rclone authorize "drive"`）必须在 VPS 上运行**，不能在用户的 GFW 内机器上跑。

正确架构：

```
VPS（洛杉矶，无 GFW）               用户（上海，GFW 内）
┌─────────────────────┐           ┌─────────────────┐
│ rclone authorize     │   socat   │ 浏览器访问       │
│ 127.0.0.1:53682     │◄─────────│ VPS_IP:53683    │
│                     │  转发     │                 │
│ → 接收 OAuth code   │           │ → Google 登录   │
│ → 交换 token ✅     │           │ → 授权          │
│ → 写 rclone.conf ✅ │           │ → 改 URL 回调   │
└─────────────────────┘           └─────────────────┘
```

### 检查清单
- [ ] `rclone authorize` 是否在 VPS 上运行？（不是在用户本地 Windows 上）
- [ ] socat 公网端口是否已放行 UFW？
- [ ] 用户授权后是否手动修正了回调 URL 中的 127.0.0.1？
