---
name: kanban
description: Complete Kanban multi-agent workflow — orchestration playbook for routing work across profiles, and worker pitfalls/examples for profile agents executing tasks. Covers task decomposition, dependency linking, goal-mode cards, stuck-worker recovery, handoff shapes, retry diagnostics, and workspace types.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [kanban, multi-agent, orchestration, routing, workflow, task-management]
    related_skills: []
risk: write-safe
---

# Kanban Multi-Agent Workflow

Hermes Kanban is a multi-agent task board. An **orchestrator** profile decomposes a goal into cards and assigns them to specialist profiles. The **dispatcher** picks up ready cards, spawns worker sessions for the assigned profile, and manages the lifecycle (heartbeat, timeout, retry, block, complete). Workers use `kanban_*` tools to report progress and hand off results.

**Two roles in this skill:**
1. **Orchestrator playbook** — you are routing work across profiles. You decompose, create cards, and link dependencies. Do not execute the work yourself.
2. **Worker playbook** — you are an agent dispatched to execute a card. You orient, work, heartbeat, and complete or block.

The core lifecycle (`kanban_create`/`kanban_complete`/`kanban_block`/`kanban_comment` and the "don't execute" rule) is auto-injected into every kanban session's system prompt as `KANBAN_GUIDANCE`. This skill is the deeper detail.

---

## Orchestrator Playbook

### Step 0: Discover Available Profiles

Before fanning out, you MUST know what profiles exist. The dispatcher silently fails to spawn unknown assignee names.

```bash
hermes profile list
```

If no match exists for a lane, ask the user which profile to create or assign it to.

### When to Use the Board vs delegate_task

Create Kanban cards when any of these are true:
1. **Multiple specialists needed** — research + analysis + writing is 3 profiles
2. **Work should survive crash/restart** — long-running, recurring, or important
3. **User might interject** — human-in-the-loop at any step
4. **Multiple subtasks can run in parallel** — fan-out for speed
5. **Review/iteration expected** — reviewer loops on drafter output
6. **Audit trail matters** — board rows persist in SQLite forever

If NONE apply — use `delegate_task` or answer the user directly.

### The Anti-Temptation Rules

- **Do not execute the work yourself.** Your restricted toolset usually doesn't even include terminal/file/code/web.
- **For any concrete task, create a Kanban task and assign it.** Every single time.
- **Split multi-lane requests before creating cards.** Extract independent workstreams into separate cards.
- **Run independent lanes in parallel.** Leave them unlinked so dispatcher fans them out.
- **Never create dependent work as independent ready cards.** Use `parents=[...]` to gate child start.
- **If no specialist fits the available profiles, ask the user.** Do not invent profile names.
- **Decompose, route, and summarize — that's the whole job.**

### Decomposition Playbook

#### Step 1: Understand the goal

Ask clarifying questions if ambiguous. Cheaper to ask upfront than spawn the wrong fleet.

#### Step 2: Sketch the task graph

Before creating anything, draft the graph:
1. Extract lanes from the request
2. Map each lane to a profile from Step 0 discovery
3. Decide if each lane is independent or gated
4. Independent lanes → parallel cards with no parent links
5. Synthesis/review cards → parent links to their dependencies

Show the graph to the user before creating cards. Let them correct it.

#### Step 3: Create tasks and link

```python
t1 = kanban_create(
    title="research: Postgres cost vs current",
    assignee="<profile-A>",
    body="Compare costs...",
    tenant=os.environ.get("HERMES_TENANT"),
)["task_id"]

t2 = kanban_create(
    title="research: Postgres performance vs current",
    assignee="<profile-A>",
    body="Compare performance...",
)["task_id"]

t3 = kanban_create(
    title="synthesize migration recommendation",
    assignee="<profile-B>",
    parents=[t1, t2],
)["task_id"]
```

Create parent cards FIRST, capture their ids, then pass them in child `parents`.

#### Step 4: Complete your own task

```python
kanban_complete(
    summary="decomposed into T1-T4: 2 research lanes in parallel, 1 synthesis, 1 prose draft",
    metadata={"task_graph": {"T1": {"assignee": "<profile-A>"}, ...}},
)
```

#### Step 5: Report back

Tell the user what you created in plain prose, naming the actual profiles used.

### Goal-Mode Cards (Persistent Workers)

By default a worker gets one shot at its card. For open-ended work, pass `goal_mode=True`:

```python
kanban_create(
    title="Translate full docs to French",
    body="Acceptance: every page translated, no English left.",
    assignee="<translator-profile>",
    goal_mode=True,
    goal_max_turns=15,
)
```

Behavior:
- After each turn, an auxiliary judge evaluates against the card title+body
- Not done + budget remains → worker continues in same session (full context)
- Worker calls `kanban_complete`/`kanban_block` → loop stops
- Budget exhausted → card blocked for human review

### Recovering Stuck Workers

When a worker keeps crashing/hallucinating:
1. **Reclaim** (`hermes kanban reclaim <task_id>`) — abort and reset to ready
2. **Reassign** (`hermes kanban reassign <task_id> <profile>`) — switch profile
3. **Change profile model** — edit the profile's config, then Reclaim

### Common Patterns

| Pattern | Shape |
|---------|-------|
| Fan-out + fan-in | N research cards, no parents; 1 synthesis with all as parents |
| Parallel implementation + validation | Implementer + explorer in parallel; reviewer gates on both |
| Pipeline with gates | planner → implementer → reviewer, each with `parents=[prev]` |
| Same-profile queue | N cards, same profile, no deps — serial priority processing |
| Human-in-the-loop | `kanban_block()` with a specific decision question |

---

## Worker Playbook

### Workspace Handling

| Kind | What it is | How to work |
|------|-----------|-------------|
| `scratch` | Fresh tmp dir, yours alone | Read/write freely; GC'd when archived |
| `dir:<path>` | Shared persistent dir | Other runs read what you write. Path is absolute. |
| `worktree` | Git worktree | If `.git` missing, run `git worktree add <path> <branch>` first |

### Tenant Isolation

If `$HERMES_TENANT` is set, prefix memory entries with the tenant so context doesn't leak:
- Good: `business-a: Acme is our biggest customer`
- Bad (leaks): `Acme is our biggest customer`

### Good Handoff Shapes

**Coding task:**
```python
kanban_complete(
    summary="shipped rate limiter — token bucket, 14 tests pass",
    metadata={
        "changed_files": ["rate_limiter.py", "tests/test_rate_limiter.py"],
        "tests_run": 14, "tests_passed": 14,
        "decisions": ["user_id primary, IP fallback for unauthenticated"],
    },
)
```

**Coding task needing review:** Block instead of complete:
```python
kanban_comment(body="review-required handoff:\n" + json.dumps({...}))
kanban_block(reason="review-required: rate limiter shipped, 14/14 pass — needs eyes")
```

**Research task:**
```python
kanban_complete(
    summary="3 libraries reviewed; vLLM wins on throughput",
    metadata={"sources_read": 12, "recommendation": "vLLM",
              "benchmarks": {"vllm": 1.0, "sglang": 0.87}},
)
```

**Review task:**
```python
kanban_complete(
    summary="PR #123 reviewed; 2 blocking issues found",
    metadata={"pr_number": 123, "approved": False,
              "findings": [{"severity": "critical", "file": "api/search.py", "issue": "raw SQL"}]},
)
```

Shape `metadata` so downstream parsers can use it without re-reading prose.

### Heartbeats

Good: `"epoch 12/50, loss 0.31"`, `"scanned 1.2M/2.4M rows"`.
Bad: `"still working"`, sub-second intervals. Every few minutes max.

### Blocking Effectively

Bad: `"stuck"` — no context.
Good: `"Rate limit key choice: IP (simple, NAT-unsafe) or user_id (requires auth, skips anonymous)?"`

Put longer context in a `kanban_comment()`. The block reason is what appears in the dashboard.

### Retry Scenarios

If `kanban_show` shows prior runs, read their outcome:
- `timed_out` — previous hit max_runtime_seconds. Chunk the work or shorten it.
- `crashed` — OOM or segfault. Reduce memory footprint.
- `spawn_failed` + `error` — profile config issue. Block for human.
- `reclaimed` — operator archived it. You shouldn't be running.
- `blocked` — unblock comment should be in the thread.

### Do NOT

- Call `delegate_task` as substitute for `kanban_create` (delegate is for short subtasks INSIDE your run; kanban_create is for cross-agent handoffs)
- Call `clarify` (you're headless). Use `kanban_comment` + `kanban_block` instead.
- Modify files outside `$HERMES_KANBAN_WORKSPACE` unless task body says to
- Create follow-up tasks assigned to yourself — assign to the right specialist
- Complete a task you didn't finish — block it instead

### Pitfalls

- **Task state can change between dispatch and startup.** Always `kanban_show` first.
- **Workspace may have stale artifacts** from previous runs. Read the comment thread.
- **Don't rely on the CLI when tools are available.** `hermes kanban <verb>` from terminal may fail in containerized backends. Use the tools.
- **`scripts/run_tests.sh` strips credentials** — if bug depends on user config, debug with raw `pytest` first, then re-confirm.
- **Notification routing:** Configure cross-profile notifications via `notification_sources: ['*']` in config.yaml.
