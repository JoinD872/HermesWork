// cf-proxy: 零配置 HTTP/HTTPS 反代 Worker (Service Worker 格式)
// 用法: https://<域名>/<完整目标URL>
// 示例: https://rss.cloudjoind.com/https://movie.douban.com/
// ⚠️ 必须用 Service Worker 格式（addEventListener），不能用 export default（ESM）

addEventListener("fetch", (event) => {
  event.respondWith(handleRequest(event.request));
});

async function handleRequest(request) {
  const url = new URL(request.url);

  // 健康检查 / 首页提示
  if (url.pathname === "/" || url.pathname === "/health") {
    return new Response(
      "cf-proxy is running.\n\nUsage: /<full-target-url>\nExample: /https://movie.douban.com/",
      { status: 200, headers: { "Content-Type": "text/plain; charset=utf-8" } }
    );
  }

  // 提取目标 URL
  let target = "";
  const rawPath = url.pathname;
  if (rawPath.startsWith("/https:/") || rawPath.startsWith("/http:/")) {
    target = rawPath.slice(1) + url.search;
  } else {
    target = rawPath.slice(1) + url.search;
  }

  // 修复 pathname 折叠双斜杠的问题：https:/  ->  https://
  if (target.startsWith("https:/") && !target.startsWith("https://")) {
    target = "https://" + target.slice("https:/".length);
  } else if (target.startsWith("http:/") && !target.startsWith("http://")) {
    target = "http://" + target.slice("http:/".length);
  }

  if (!target.startsWith("http://") && !target.startsWith("https://")) {
    return new Response("Invalid target URL. Use /<full-url>", { status: 400 });
  }

  // 构建目标请求
  const headers = new Headers(request.headers);
  headers.set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36");
  headers.delete("Host");
  headers.delete("cf-connecting-ip");
  headers.delete("cf-ray");
  headers.delete("cf-visitor");
  headers.delete("x-forwarded-proto");
  headers.delete("x-forwarded-for");
  headers.delete("x-real-ip");

  const init = {
    method: request.method,
    headers: headers,
    redirect: "follow",
  };
  if (request.method !== "GET" && request.method !== "HEAD") {
    init.body = request.body;
  }

  try {
    const resp = await fetch(target, init);
    const respHeaders = new Headers(resp.headers);
    respHeaders.set("Access-Control-Allow-Origin", "*");
    respHeaders.set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    respHeaders.set("Access-Control-Allow-Headers", "*");
    return new Response(resp.body, {
      status: resp.status,
      headers: respHeaders,
    });
  } catch (e) {
    return new Response("Proxy error: " + e.message, { status: 502 });
  }
}
