---
name: cloudflare-worker-reverse-proxy
description: 零成本 Cloudflare Workers 反代部署 — 让被墙的国内网站（豆瓣/微博等）通过 CF 免费额度可访问。含 API 上传、自定义域名绑定、踩坑记录
tags: [cloudflare, worker, proxy, reverse-proxy, free, cf]
version: 2026-08-02
risk: write-safe
---

# Cloudflare Workers 反代部署（零成本访问国内被墙站）

## 适用场景

- VPS 直连国内站被墙/风控（豆瓣 000、微博 403 等）
- 想零成本（CF 免费额度 10万请求/天）绕行访问
- 已有 Cloudflare 账号 + 域名

## 核心架构

```
用户/VPS → https://<自定义域名或workers.dev>/<完整目标URL> → CF Worker → 目标站
```

## 前置条件

1. Cloudflare 账号（有 API Token 权限：Workers Scripts Edit + 可选 Zone DNS）
2. 凭据存在 `/root/.hermes/.cf_credentials`：
   ```
   CF_ACCOUNT_ID=<hex id>
   CF_ZONE_ID=<hex id>
   CF_API_TOKEN=<token>
   CF_WORKER_NAME=cf-proxy
   CF_WORKER_URL=https://cf-proxy.<account>.workers.dev
   CF_CUSTOM_DOMAIN=https://rss.cloudjoind.com
   ```
   用 `source /root/.hermes/.cf_credentials` 加载

## 部署步骤

### 1. 上传 Worker（关键：必须用 Service Worker 格式，不能 ESM）

**⚠️ 最大坑：API 直接传 JS 只能用 Service Worker 格式**（`addEventListener("fetch")`），不能用 `export default`（ESM）。ESM 需要 multipart metadata 上传且容易报 `Unexpected token 'export'` 10021 错误。

Worker 脚本模板见 `templates/worker-simple.js`（Service Worker 格式，含 `//` 折叠修复）。

```bash
source /root/.hermes/.cf_credentials
curl -s -m 30 -X PUT \
  "https://api.cloudflare.com/client/v4/accounts/$CF_ACCOUNT_ID/workers/scripts/$CF_WORKER_NAME" \
  -H "Authorization: Bearer $CF_API_TOKEN" \
  -H "Content-Type: application/javascript" \
  --data-binary @worker-simple.js
# success=true 即上传成功
```

### 2. 启用 workers.dev 子域

```bash
curl -s -m 15 -X POST \
  "https://api.cloudflare.com/client/v4/accounts/$CF_ACCOUNT_ID/workers/scripts/$CF_WORKER_NAME/subdomain" \
  -H "Authorization: Bearer $CF_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"enabled": true}'
```

### 3. 绑定自定义域名（如 rss.cloudjoind.com）

```bash
curl -s -m 15 -X PUT \
  "https://api.cloudflare.com/client/v4/accounts/$CF_ACCOUNT_ID/workers/domains" \
  -H "Authorization: Bearer $CF_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"hostname\":\"rss.cloudjoind.com\",\"service\":\"$CF_WORKER_NAME\",\"environment\":\"production\",\"zone_id\":\"$CF_ZONE_ID\"}"
```

⚠️ 需要 Workers Custom Domains 权限（实测 hermes-VPS-CN token 有）。DNS 记录 + SSL 证书自动创建。

### 4. 验证

```bash
# 健康检查
curl -s https://rss.cloudjoind.com/health

# 反代豆瓣（核心测试）
curl -s -m 25 -L "https://rss.cloudjoind.com/https://movie.douban.com/" | head -c 500

# 反代 RSSHub 豆瓣 route
curl -s -m 25 "https://rss.cloudjoind.com/https://rsshub.ktachibana.party/douban/movie/playing" | head -c 300
```

## 已知坑与对策

| 坑 | 现象 | 对策 |
|----|------|------|
| ESM 格式 10021 | `Unexpected token 'export'` | 改用 Service Worker 格式（addEventListener）|
| URL `//` 折叠 | `https://` 变 `https:/` 导致 Invalid target URL | Worker 内修复：`target = "https://" + target.slice("https:/".length)` |
| 豆瓣跳转 400 | curl -L 跟随相对重定向拼错 | 用 `-L` 或直接访问；页面本身 200 |
| B站 412 | 反代返回 412 | B站反爬，需额外 header 或直接直连（未登录场景直连本来就能用）|
| workers.dev 国内被墙 | 国内用户打不开 | 绑自定义域名（rss.cloudjoind.com）|
| DNSBL 本地缓存抖动 | CBL 时列入时不列入 | 用公共 DNS 交叉验证（见 vps-ip-reputation-check skill）|

## 反代可用性实测（2026-08-02）

| 目标 | 直连 | 反代 | 说明 |
|------|------|------|------|
| movie.douban.com | ❌ 000 | ✅ 200 115KB | 核心突破 |
| rsshub 豆瓣 route | ✅ | ✅ 200 RSS | 结构化通道 |
| www.baidu.com | ✅ | ✅ 200 | |
| www.zhihu.com | ✅ | ✅ 200 | |
| news.17173.com | ✅ | ✅ 200 83KB | |
| www.bilibili.com | ✅ | ⚠️ 412 | 反爬 |

## 相关

- 清理：`curl -X DELETE .../workers/scripts/<name>`（删 Worker 不影响 DNS/隧道）
- 回滚：删自定义域名 `curl -X DELETE .../workers/domains/<id>`；删 DNS 记录在面板
- 凭据管理：token 泄露 → CF 面板 Roll；权限不够 → 面板重建 token
- 关联 skill：`vps-domestic-site-access`（国内站访问全貌）、`vps-ip-reputation-check`（黑名单检测）
