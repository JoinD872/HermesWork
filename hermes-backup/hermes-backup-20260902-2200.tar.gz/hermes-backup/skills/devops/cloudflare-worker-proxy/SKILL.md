---
name: cloudflare-worker-proxy
description: 用 Cloudflare Workers 免费额度搭建零成本反代/代理 — 访问被 VPS IP 屏蔽的国内站（豆瓣/微博等）、转发 AI API、任何 HTTP(S) 目标。含完整部署流程、multipart 上传格式坑、URL 双斜杠折叠坑、token 权限配置。
tags: [cloudflare, workers, proxy, reverse-proxy, free, china, 反代]
risk: write-safe
created: 2026-08-02
---

# Cloudflare Workers 免费反代

## 触发场景
- VPS 直连某国内站被墙（如豆瓣 000、微博 403），要零成本绕过
- 需要可复用、稳定的访问通道，不想每次用公共 RSSHub 实例（实例经常 503/429）
- 想用 CF 免费额度（10万请求/天）转发任意 HTTP(S) 目标

## 核心事实
- **免费额度 10万请求/天**（UTC 重置），CPU 10ms/请求，内存 128MB —— 纯反代转发场景完全够用
- **自定义域名不提高额度**（账户级固定），但 workers.dev 子域在国内被墙——VPS（海外）访问无此问题
- **Account API Token（cfat_ 前缀）**：创建后 `/user/tokens/verify` 返回 Invalid（不支持 user 端点），但账号/资源 API 正常 —— 用账号信息 API 验证有效性

## 已部署实例（本环境）
- Worker 名：`cf-proxy`，地址 `https://cf-proxy.619151721.workers.dev/<完整目标URL>`
- 凭据：`/root/.hermes/.cf_credentials`（source 后 `$CF_API_TOKEN` / `$CF_ACCOUNT_ID` / `$CF_ZONE_ID` 可用）
- 实测：豆瓣 200+114KB 完整内容、百度/知乎/17173/RSSHub 全通

## 部署流程

### 1. 获取 API Token（用户配合，新版面板）
- 直达链接：`https://dash.cloudflare.com/profile/api-tokens`
- **不要找 "Edit Cloudflare Workers" 模板名**（新版面板没有），点底部灰色 **Create Custom Token**
- 权限：Account → **Workers Scripts → Edit**（必需）；Zone → DNS → Edit（可选，绑自定义域名才要）
- 生成后立刻复制 secret（只显示一次）；页面关了只能重建
- ⚠️ 面板可能让用户填成 `Account API Tokens Write`（那是管理 token 的权限，不对）—— 必须 Workers Scripts Edit

### 2. 验证 token
```bash
export CF_ACCOUNT_ID=<account_id> CF_API_TOKEN=<token>
# cfat_ 前缀 token 不能用 user/tokens/verify，用账号 API 验证：
curl -s "https://api.cloudflare.com/client/v4/accounts" -H "Authorization: Bearer $CF_API_TOKEN"
```

### 3. 上传 Worker（关键坑：格式）
**❌ 直接 PUT application/javascript 带 `export default`（ESM）→ 报错 `Uncaught SyntaxError: Unexpected token 'export'`**
**✅ 用 Service Worker 格式（addEventListener）直接 PUT 即可：**
```bash
curl -s -X PUT "https://api.cloudflare.com/client/v4/accounts/$CF_ACCOUNT_ID/workers/scripts/<name>" \
  -H "Authorization: Bearer $CF_API_TOKEN" \
  -H "Content-Type: application/javascript" \
  --data-binary @worker.js
```
（若要 ESM 格式需 multipart/form-data 带 metadata part，见 references）

### 4. 启用 workers.dev 子域
```bash
curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/$CF_ACCOUNT_ID/workers/scripts/<name>/subdomain" \
  -H "Authorization: Bearer $CF_API_TOKEN" -H "Content-Type: application/json" \
  -d '{"enabled": true}'
```
等 5-15 秒 DNS 传播（dig cf-proxy.xxx.workers.dev 验证）。

### 5. 验证
```bash
curl -s "https://<name>.<subdomain>.workers.dev/health"                      # 健康检查
curl -s -L "https://<name>.<subdomain>.workers.dev/https://movie.douban.com/" # 反代测试
```

## 关键坑（实测踩过）

1. **URL 双斜杠折叠**：`new URL(request.url).pathname` 会把 `/https://x.com/` 的 `//` 折叠成 `/https:/x.com/`。必须在 worker 里修复：`target.startsWith("https:/") && !startsWith("https://")` 时补回 `//`。
2. **反代测试不要用 curl -L 判断结果**：重定向到相对路径时 curl 会拼错 URL 返回 400 假阴性；用 `-D -` 看响应头 + 直接抓 body 判断真实结果。
3. **B站 412**：反代 B站页面返回 412（需要特定 header/cookie），直连本身也通，不必强求反代。
4. **豆瓣 frodo API**：反代可达但报 `apikey is required`（需授权），页面版（movie.douban.com）完整可用。
5. **token 权限边界**：无 Zone DNS 权限时 DNS 记录 API 返回 Authentication error —— 绑自定义域名需用户面板手动加 CNAME，或 token 加 Zone:DNS:Edit。

## 反代代码模板
`templates/reverse-proxy-worker.js` — Service Worker 格式，含 URL 折叠修复、header 清理、CORS。

## 相关
- RSSHub 公共实例（零部署备选）：rsshub.ktachibana.party 豆瓣 route 200 可用
- 详细部署记录/错误复盘：`references/deploy-20260802.md`
