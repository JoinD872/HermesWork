---
name: windows-tailscale-ssh-access
description: SSH from Hermes VPS into a Windows desktop over Tailscale — identity discovery, connection troubleshooting, and working commands for file operations on Windows drives.
tags: [windows, tailscale, ssh, devops]
category: devops
risk: write-safe
---

# Windows Tailscale SSH Access

## Background

Hermes runs on a Linux VPS. The user's Windows desktop is connected via Tailscale (same account). Windows has OpenSSH Server running. The goal is to read/write files on the Windows machine (typically `E:\Hermes\` directory).

## Working Connection Command

```bash
ssh -i /root/.ssh/id_ed25519 61915@100.108.175.15 "<command>"
```

**Key Parameters:**
| Parameter | Value | Why |
|-----------|-------|-----|
| **User** | `61915` | Windows local user on the new system |
| **SSH Key** | `/root/.ssh/id_ed25519` | VPS's existing SSH key, added to Windows admin authorized_keys |
| **Host** | `100.108.175.15` | Tailscale IP of `dalao` |
| **Fallback hostname** | `dalao.tail3a58b3.ts.net` | Works but first connect needs `StrictHostKeyChecking=accept-new` |

## Windows Machine Info

| Property | Value |
|----------|-------|
| Hostname | DaLao |
| Tailscale IP | 100.108.175.15 |
| Status | Online, DERP relay only (~153ms via SFO) |
| Home directory | `C:\\Users\\61915` |
| Hermes work dir | `E:\\\\Hermes\\\\` |

## 硬件配置

| 部件 | 型号 | 规格 |
|------|------|------|
| **主板** | ASUS | BIOS AMI 4505 (2025/11/29) |
| **CPU** | Intel Core i7-12700KF | 12代, 6P+4E, 3.6GHz base |
| **内存** | 32GB DDR4 | 2×16GB Crucial, 3200MHz |
| **显卡** | NVIDIA GeForce RTX 3080 | 10GB GDDR6X |
| **系统盘** | KINGSTON SNVS1000GB | 1TB NVMe SSD |
| **数据盘** | GALAX HA1K1000F | 1TB SSD (影驰) |
| **仓库盘** | ST2000DM006-2DM164 | 2TB HDD (希捷酷鱼) |
| **有线网** | Intel I225-V | 2.5GbE |
| **无线网** | Intel AX201 | Wi-Fi 6 160MHz |
| **系统** | Windows 10 Pro | 64-bit, Build 19045 |

## Common Operations

### Verify connection
```bash
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=10 61915@100.108.175.15 "echo WINDOWS_OK && hostname && whoami"
```

### List E drive
```bash
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=10 61915@100.108.175.15 "dir E:"
```

### Write a file (Windows cmd syntax — use `>>` and escape `^` for special chars)
```bash
# Single line
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=15 61915@100.108.175.15 "echo Hello >> E:\\Hermes\\test.txt"

# With special chars — escape `^` before `(` `)` `&` `|` `>` `^`
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=15 61915@100.108.175.15 'echo Hello from Agent ^(VPS^) >> E:\\Hermes\\test.txt'
```

### Read a file
```bash
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=10 61915@100.108.175.15 "type E:\\Hermes\\test.txt"
```

### Create directory
```bash
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=10 61915@100.108.175.15 "if not exist E:\\Hermes mkdir E:\\Hermes"
```

## Connection Troubleshooting

### Symptom: `Permission denied (publickey,password,keyboard-interactive)`
**Cause:** Wrong username, wrong SSH key, or authorized_keys in wrong location.

**Fix:**
1. Use Windows local username (`61915`), NOT the Tailscale account name (`w619151721@`)
2. If user is in **Administrators** group, key must go in `C:\\ProgramData\\ssh\\administrators_authorized_keys` (NOT personal `.ssh\\authorized_keys`), with permissions: `icacls ... /inheritance:r /grant "Administrators:F" /grant "SYSTEM:F"`
3. If user is NOT admin, put key in `C:\\Users\\<user>\\.ssh\\authorized_keys`
4. The sshd_config `Match Group administrators` block overrides the personal authorized_keys path for admin users

### Symptom: `Connection timed out during banner exchange`
**Cause:** Tailscale relay instability, or the Windows machine briefly unreachable.

**Fix:** Retry after a few seconds. Use `-o ConnectTimeout=15` for more tolerance.

### Symptom: `No direct connection` (DERP relay only)
**Normal.** The VPS and Windows desktop are on different NATs (VPS in US, Windows in China behind CGNAT). DERP relay adds latency (~180ms) but works fine for file operations.

### Symptom: PowerShell commands time out
**Fix:** Prefer cmd.exe commands (`dir`, `echo`, `type`) over PowerShell. PowerShell on Windows SSH sometimes hangs on first invocation.

## Pitfalls

1. **Public key ≠ private key.** If the user sends a `.pub` file, they still need to provide the corresponding private key. The VPS's own `id_ed25519` was the correct key all along.
2. **Tailscale username doesn't map to SSH username.** Windows SSH uses the local Windows username, not the Tailscale identity.
3. **Admin users: key goes in administrators_authorized_keys, NOT personal .ssh.** Windows OpenSSH's `sshd_config` has a `Match Group administrators` block that overrides `AuthorizedKeysFile` to `__PROGRAMDATA__/ssh/administrators_authorized_keys`. User-level `.ssh\authorized_keys` is silently ignored for admin users.
4. **Tailscale SSH toggle alone isn't enough.** Enabling "Allow Tailscale SSH" in Tailscale preferences only works if OpenSSH Server is installed and running underneath. Without it, connection is refused on port 22.
5. **cmd.exe is more reliable than PowerShell** for SSH-triggered commands on Windows.
6. **Connection is intermittent** due to DERP relay. Always expect occasional timeouts and retry.
7. **🚩 Chinese characters get garbled through SSH pipe.** `Set-Content -Value '中文' -Encoding UTF8` via SSH produces corrupted bytes on disk (replacement chars U+FFFD). **Fix:** Use .NET byte-level API: `[System.Text.UTF8Encoding]::new($true)` + `[System.IO.File]::WriteAllBytes()`. Verify by reading raw bytes. See `references/chinese-encoding-through-ssh.md` for full details including byte-verification table and reusable script.
