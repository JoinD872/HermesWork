# Chinese Characters Through SSH to Windows

## The Problem

When SSH'ing from Linux (VPS) to Windows, Chinese characters (`黑翼连接测试成功！`) transmitted through the SSH pipe arrive garbled at both ends:

- **Writing**: `Set-Content -Path file.txt -Value '中文' -Encoding UTF8` creates a file on Windows, but the actual bytes are corrupted — you get replacement characters (`EF-BF-BD` = U+FFFD `�`)
- **Reading**: `Get-Content file.txt -Encoding UTF8` returns garbled CJK text in the terminal output, even though the file on disk is fine

**Root cause**: The SSH pipe between Linux and Windows OpenSSH server doesn't preserve UTF-8 encoding for CJK characters reliably when using PowerShell cmdlets like `Set-Content`/`Get-Content`.

## Reliable: Write Chinese Content — Byte-Level Approach

```powershell
$utf8 = [System.Text.UTF8Encoding]::new($true)  # $true = emit BOM
$bytes = $utf8.GetBytes('黑翼连接测试成功！^_^')
[System.IO.File]::WriteAllBytes((Join-Path $env:USERPROFILE 'Desktop\黑翼测试.txt'), $bytes)
```

**Why it works**: `[System.IO.File]::WriteAllBytes()` is a .NET API that writes raw bytes directly — no encoding conversion through the SSH pipe.

## Reliable: Verify Chinese Content — Byte Inspection

Since you can't read Chinese text from terminal output, verify by inspecting raw bytes:

```powershell
# Read raw bytes
$bytes = [System.IO.File]::ReadAllBytes((Join-Path $env:USERPROFILE 'Desktop\黑翼测试.txt'))
Write-Output ($bytes -join ' ')

# Output: 233 187 145 231 191 188 232 191 158 230 142 165 ...
# Manually decode: 黑=E9 BB 91  翼=E7 BF BC  连=E8 BF 9E ...
```

Then manually decode the UTF-8 bytes to verify:
| Byte Triplet | Unicode | Char |
|-------------|---------|------|
| E9 BB 91 | U+9ED1 | 黑 |
| E7 BF BC | U+7FFC | 翼 |
| E8 BF 9E | U+8FDE | 连 |
| E6 8E A5 | U+63A5 | 接 |
| E6 B5 8B | U+6D4B | 测 |
| E8 AF 95 | U+8BD5 | 试 |
| E6 88 90 | U+6210 | 成 |
| E5 8A 9F | U+529F | 功 |
| EF BC 81 | U+FF01 | ！ |
| 5E 5F 5E | | ^_^ |

## Fallback: Use English Content

When Chinese isn't strictly required, use English/ASCII content — it passes through SSH pipes without any encoding issues:

```bash
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 "powershell -NoProfile -Command \"Set-Content -Path \$env:USERPROFILE\\Desktop\\test.txt -Value 'Connection OK' -Encoding UTF8\""
```

## Encoding Verification Script

Save this as a reusable probe script in the skill's `scripts/` directory:

```powershell
# verify-encoding.ps1
param($Path)
$bytes = [System.IO.File]::ReadAllBytes($Path)
$hex = ($bytes | ForEach-Object { '{0:X2}' -f $_ }) -join ' '
$utf8 = [System.Text.UTF8Encoding]::new($true)
$text = $utf8.GetString($bytes)
Write-Output "Hex: $hex"
Write-Output "Text: $text"
```

## What NOT to Do

- ❌ `Set-Content -Value '中文' -Encoding UTF8` — corrupts Chinese through SSH pipe
- ❌ `echo 中文 >> file.txt` — cmd.exe encoding issues with Chinese
- ❌ `Get-Content file.txt` — garbled output, unreliable for verification
- ❌ `Out-File -Encoding UTF8` — same pipe encoding issue as Set-Content
