---
name: windows-game-pixel-automation
description: Windows 游戏像素级自动化工具开发指南 — 自动喝药/打怪类辅助：技术选型(像素vs内存vs注入vs封包)、反作弊风险阶梯、mss+numpy 血条检测架构、校准流程、DaLao 部署路径。适用于冒险岛怀旧服等 2D 横版游戏挂机工具。
tags: [windows, gaming, automation, pixel, maplestory]
category: devops
risk: write-safe
---

# Windows 游戏像素级自动化

## 触发场景

用户要"做个工具帮我自动 X"（自动喝药 / 自动打怪 / 寻怪 / 寻路等游戏辅助）。
**先讨论方案再写码**（用户明确偏好：复杂新工具先出方案，不直接闷头做）。

## 技术选型：像素 vs 内存 vs 注入 vs 封包

| 方案 | 原理 | 打怪 | 寻怪 | 寻路 | 反作弊风险 |
|------|------|:---:|:---:|:---:|:---:|
| 纯像素(截图+模拟按键) | 看屏幕 | ✅ | 🟡屏幕内 | ❌ | 最低(不碰游戏进程) |
| 内存读取(RPM) | 读坐标/怪列表 | ✅ | ✅ | ✅ | 中(NP 可能盯) |
| 注入 DLL | 进游戏进程 | ✅ | ✅ | ✅ | 高 |
| 封包伪造 | 改网络数据 | ✅ | ✅ | ✅ | 最高 |

**核心判断**：
- 像素级 = 观察者，只看到屏幕。能做：UI 状态检测(血条)、屏幕内找怪、定点打怪。
- 做不了寻路，缺三样数据：自身坐标、屏幕外地图结构、怪物精确坐标。
- 冒险岛是横版 2D 范围攻击，"打怪" = 走到怪旁 + 按攻击键，不需要精确点怪 → 像素可做定点挂机。
- "像素寻路"实际是死记硬背路径宏（录音机），被怪卡住/击退就乱套，不是真寻路。

## 国服怀旧冒险岛背景（2026-08 确认）

- 官方怀旧服 = NEXON 开发 + 盛趣(盛大)代理（mxd.web.sdo.com），2026-07 官宣。
- 反作弊：NProtect GameGuard（盛大系二十年标配），检测注入/调试器/内存操作。
- 纯像素方案完全在 NP 检测面之外 → 首选。内存读取有真实封号风险。
- 方案通用，适用于任何 2D 横版游戏。

## 工具架构（auto-potion 已实现，待部署）

代码在 VPS `/root/auto-potion/`（auto_potion.py / config.json / run.bat / requirements.txt / README.md），
部署目标 `E:\Hermes\auto-potion\` on DaLao。

依赖：`pip install mss pillow numpy pydirectinput pywin32`（pydirectinput 需要 pywin32）。

核心逻辑：
1. **截图**：mss 区域截图（比 PIL.ImageGrab 快，支持 region）。
2. **颜色比例**：numpy 掩码——HP 红条 `(R>80)&(R-G>40)&(R-B>40)`；MP 蓝条 `(B>80)&(B-R>40)&(B-G>25)`；`mask.mean()` = 0~1 填充比例。
3. **决策**：比例 < 阈值(默认 HP 40% / MP 30%) + 冷却(cooldown 1.2s)防连按 → `pydirectinput.press('f1')`（SendInput，游戏兼容）。
4. **报警**：max_attempts(6 次连按没回升) → Beep 蜂鸣 = 药水用完。
5. **前台保护**：EnumWindows + QueryFullProcessImageNameW 按进程名找游戏窗口，GetForegroundWindow 对比，切出游戏不按键。
6. **热键**：GetAsyncKeyState 轮询（F9 暂停/继续，F11 退出），零依赖。
7. **校准**：`--scan` 自动找下半屏最宽红/蓝条（行投影+列投影+长条形状约束 `宽>80px 且 宽>2.5*高`）；`--manual` 鼠标点条两端；结果写入 config.json。

## 关键坑

- **游戏必须窗口化**：全屏独占 mss 截不到（黑屏）。提示用户用窗口/无边框。
- **校准前血条要回满**：低血量时红色填充不足 80px 宽，自动扫描找不到条。
- **控制台中文乱码**：`sys.stdout.reconfigure(encoding='utf-8', errors='replace')`。
- **Windows OpenSSH 跑在 session 0**：SSH 只能部署文件/装依赖，看不到用户桌面、不能代替前台运行；工具必须用户在前台跑（校准和运行都是交互式的）。
- **战斗伤害数字干扰**：红色伤害数字会闪 → 自动扫描限制在下半屏 + 长条形状约束过滤。
- 任何辅助都有被反作弊盯上的可能，交付时提醒用户先小号验证。

## 部署流程（DaLao）

1. 先确认 DaLao 在线：`tailscale status | grep dalao`（节点 `offline, last seen 1d ago` 时别重试 SSH，让用户检查机器；详见 windows-tailscale-ssh-access skill）。
2. SSH：`ssh -i /root/.ssh/id_ed25519 61915@100.108.175.15`（DERP relay 间歇性，超时重试）。
3. 拷贝 auto-potion 到 `E:\Hermes\auto-potion\`，装依赖。
4. 用户在游戏里跑 `python auto_potion.py --scan` 校准 → `run.bat` 开跑。
5. 验证：控制台实时显示 HP/MP%，手动打怪掉血看是否自动按键、切出游戏是否停手。

## 分阶段路线（与用户讨论结论，2026-08-11）

| 阶段 | 功能 | 技术 | 风险 | 状态 |
|------|------|------|------|------|
| 1 | 自动喝药 | 像素 | 无 | ✅ 已实现 |
| 2 | 定点自动打怪 | 像素 | 无 | 下一步候选（站刷怪点自动攻击+喝药+走回点位） |
| 3 | 小范围巡逻 | 像素+路径宏 | 低 | 可选 |
| 4 | 真·寻路/自动任务 | 内存读取+逆向 | 高 | 用户明确要才做 |
