---
name: security-preflight
description: 任何系统改动前的安全检查清单 — 端口/密钥/权限/持久化/回滚/连通性。输出结构化风险矩阵，拦截高风险操作
version: 1.0.0
risk: write-dangerous
---

# Security Preflight

在**任何系统改动前**加载此 skill。逐项检查，全部通过后才能执行改动。

## 核心原则

### 故障归因模型

```
应用层故障 ≠ 应用本身故障
```

当出现连接错误时，**不应优先修改应用配置**。排查顺序：

```
1. DNS                   (cat /etc/resolv.conf / resolvectl status)
2. TCP 连接              (curl -v / nc -zv)
3. 代理出口              (检查 HTTP_PROXY / WARP / Tailscale)
4. 服务状态              (systemctl status)
5. 应用配置              (config.yaml / .env)
6. 业务逻辑              (代码/权限/认证)
```

### 真实故障链（2026-07-08 事故）

```
网络组件变化 (WARP mode warp)
  ↓
DNS 控制权变化 (Tailscale 接管 resolv.conf)
  ↓
系统解析路径异常 (100.100.100.100 不可达)
  ↓
依赖外部域名的服务失败 (飞书/V2RayN/GitHub)
  ↓
应用层表现为连接超时 ("feishu connect timed out after 30s")
```

**不是：**
```
Hermes 修改配置 → Hermes 损坏
```

### 基础设施变更协议

Agent 运行在动态变化的基础设施环境中（Xray/Tailscale/WARP/CF Tunnel/飞书/模型API），任何一个改变都可能影响其他组件。

修改以下内容必须遵守 Before→Snapshot→Modify→Check→Rollback 协议：

```
Before Change
  ↓
Snapshot (当前状态快照)
  ↓
Modify (执行修改)
  ↓
Health Check (自动验证)
  ↓
Rollback if Failed (自动回滚)
```

## 风险矩阵

```
## 风险矩阵

| 检查项 | 状态 | 风险等级 | 缓解措施 |
|--------|------|---------|---------|
| 端口变动 | ⬜ | 高/中/低 | ... |
| 密钥暴露 | ⬜ | 高/中/低 | ... |
| 权限提升 | ⬜ | 高/中/低 | ... |
| 持久化 | ⬜ | 高/中/低 | ... |
| 回滚路径 | ⬜ | 高/中/低 | ... |
| 连通性变化 | ⬜ | 高/中/低 | ... |
| 验证命令 | ⬜ | 高/中/低 | ... |

决策: PROCEED / BLOCKED / USER_APPROVAL_REQUIRED
```

## 检查清单

### 1. 端口变动

改前记录：`ss -tlnp`
改后对比：`ss -tlnp`

- [ ] 是否有端口被打开？如果是，是否需要认证/firewall/TLS？
- [ ] 是否有端口被关闭？如果是，是否影响依赖服务？
- [ ] 新端口是否仅限内网或需要公网？

### 2. 密钥/凭据暴露

- [ ] API Key / Token / 密码 是否会出现在 Git、日志、shell history、进程参数、世界可读文件中？
- [ ] 配置文件中是否硬编码了凭据？
- [ ] `.env` 文件权限是否正确（600）？

#### ⚠️ Provider 更换陷阱：先验证 key，再切换 config

当更换主模型 provider 时（如从直连 DeepSeek 切到 OpenCode Go/任何第三方）：

```
# ❌ 错误做法：
# 1. 先改 config.yaml: provider → custom:xxx
# 2. 然后才去 .env 填 key
# 结果: Gateway 在 key 空的时候就开始用新 provider → 401 Unauthorized
#       Hermes 标记为非重试错误（AuthenticationError），
#       后续即使填了 key 也不会自动恢复——需要重启 Gateway 进程

# ✅ 正确做法：
# 1. 先在 .env 写入 key 并测试 key 有效
# 2. 再改 config.yaml 切换 provider
# 3. 最后重启 Gateway: systemctl --user restart hermes-gateway
```

**关键规则：** 401 AuthenticationError 是非重试错误，Hermes 不会自动恢复。
Gateway 必须在 key 已就绪且测试通过后重启。

### 3. 权限提升

- [ ] 是否需要 sudo？具体哪个命令？
- [ ] 服务是否以 root 运行？能否降权？
- [ ] 文件权限是否被放宽？

### 4. 持久化

- [ ] 改动在重启后是否保留？
- [ ] 如果是 systemd 服务：`systemctl enable`？
- [ ] 如果是 CRON：`crontab -l` 确认持久？
- [ ] 如果是 Docker：`--restart always` / docker-compose 配置？

### 5. 回滚路径

- [ ] 回滚命令是否已知且可执行？
- [ ] 备份是否已完成？（`cp file file.bak.$(date +%s)`）
- [ ] 如果回滚不可行，标记为 BLOCKED 直到用户确认风险

回滚命令示例：
```bash
# Rollback
cp /path/to/file.bak.XXXXXXX /path/to/file
systemctl restart SERVICE
```

### 6. 外部连通性变化

- [ ] 是否改变了 DNS、TLS、反向代理、webhook、API 调用目标？
- [ ] 是否改变了出站规则？
- [ ] 是否涉及 WARP/Tailscale/Xray/任意网络代理？**如果有，必须检查 DNS**
- [ ] 验证：`curl -I https://TARGET`、`dig DOMAIN`、`sudo nginx -t`

#### ⚠️ 特别警告：WARP 全流量模式 = 高危操作

**Cloudflare WARP 的 `warp` 模式（全流量隧道）会触发 Tailscale DNS 接管！**

故障链：
```
WARP mode warp → Tailscale 修改 /etc/resolv.conf → DNS 指向 100.100.100.100 → VPS 所有域名解析失败 → Hermes 飞书断连 + V2RayN 损坏
```

**规则：**
1. **绝对不要**在 VPS 上开启 `warp-cli mode warp`（全流量隧道模式）
2. 如需 WARP，只能用 `warp-cli mode proxy`（SOCKS5 本地代理模式），只有显式通过代理的请求才走 WARP
3. 修改任何网络组件前后，**必须**检查 `/etc/resolv.conf` 和 `nslookup open.feishu.cn`

#### DNS 检查完整流程

```bash
# 改前快照
cat /etc/resolv.conf
nslookup open.feishu.cn
resolvectl status

# 改后验证
cat /etc/resolv.conf  # 确认不是 Tailscale 的 100.100.100.100
nslookup open.feishu.cn  # 确认解析正常
resolvectl status       # 确认 DNS Servers 和 resolv.conf mode

# 如果 DNS 被 Tailscale 劫持，修复：
systemctl stop tailscaled
rm -f /etc/resolv.conf
ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf
systemctl restart systemd-resolved
# 为防止复发：tailscale up --accept-dns=false
```

#### ⚠️ Tailscale 注意事项

Tailscale 不只是 VPN。它包含：
- 网络接口
- 路由
- DNS 管理（MagicDNS）
- `--accept-dns=true` 意味着 Tailscale 有权限影响系统 DNS 行为

以后任何涉及 Tailscale/WARP/VPN/Zero Trust/WireGuard 的操作，都应触发：
```
检查 DNS ownership
  → cat /etc/resolv.conf
  → resolvectl status
```

### 7. 验证命令

- [ ] 存在一个可执行的、具体的验证命令
- [ ] 验证命令有明确的 Pass/Fail 判断标准
- [ ] 验证命令不依赖人工检查（自动判断）

## 拦截规则

出现以下任一情况，**BLOCK 执行**直到问题解决：

1. 公网端口被打开但没有认证/firewall/TLS 计划
2. 密钥可能暴露在 Git/log/shell history/world-readable 文件中
3. 需要提权但不清楚具体提权操作
4. 需要持久化但未配置/验证
5. 破坏性改动或生产改动没有回滚路径
6. 外部连通性改变未知或未验证
7. 没有可执行的验证命令

## 执行后

改动执行完成后，重新运行验证命令，更新状态为 Pass/Fail。

最终输出：
```
## 改动后验证
| 检查项 | 命令 | 结果 | 证据 |
|--------|------|------|------|
| ... | ... | Pass/Fail | 输出摘要 |

最终状态: PASS / FAIL / ROLLED BACK
```

## 参考

- `references/tailscale-dns-hijack-20260708.md` — 完整事故复盘：故障链、根因分析、修复步骤、防止复发规则
