# Tailscale DNS 劫持事故复盘 (2026-07-08)

## 故障现象

- Hermes Gateway 正常运行但飞书无响应
- V2RayN 网络异常
- `hermes gateway run` 报错: `feishu connect timed out after 30s`
- 所有系统服务（Xray/nginx/Docker）正常

## 根因链

```text
WARP mode warp (全流量隧道模式)
  ↓
Tailscale MagicDNS 接管系统 DNS
  ↓
/etc/resolv.conf 被覆写 → nameserver 100.100.100.100
  ↓
100.100.100.100 不可达 (Tailscale 内部 DNS 无法响应)
  ↓
VPS 所有域名解析失败 (open.feishu.cn / github.com / api.deepseek.com)
  ↓
Hermes Gateway 无法连接飞书服务器 → 连接超时
  ↓
应用层表现为 "Hermes 挂了"
```

**关键诊断工具（修复后发现的根本原因）:**

```bash
# 发现 DNS 分裂状态
ls -la /etc/resolv.conf          # 确认是 symlink 还是 Tailscale 生成的普通文件
cat /etc/resolv.conf              # 检查 nameserver (1.1.1.1=正常, 100.100.100.100=Tailscale)
resolvectl status | grep DNS     # systemd-resolved 内部可能正常，但 /etc/resolv.conf 已被覆写
nslookup open.feishu.cn          # 实际解析测试
```

## 为什么会发生

### 直接触发条件

```bash
warp-cli mode warp     # ← 这一条命令触发了整个灾难
```

Cloudflare WARP 全流量模式 (`mode warp`) 改变了系统的网络拓扑，触发了 Tailscale 的 MagicDNS 保护机制——Tailscale 发现系统网络状态变化后自动重写 `/etc/resolv.conf`。

### 事故前的 DNS 状态（危险但侥幸运行）

事故前实际上已经存在 **DNS 分裂状态**：

```text
resolvectl status 显示 DNS Servers: 1.1.1.1 8.8.8.8  ✅
    但 /etc/resolv.conf 已经是 Tailscale 生成的静态文件 ❌
```

因为 systemd-resolved 顶着正确 DNS 在跑，所以一直没出问题。WARP 模式切换打破了这种脆弱的平衡。

## 修复步骤

### 1. 停止 Tailscale

```bash
systemctl stop tailscaled
```

### 2. 恢复 systemd-resolved DNS

```bash
# 编辑 /etc/systemd/resolved.conf
# 设置:
#   DNS=1.1.1.1 8.8.8.8
#   FallbackDNS=1.0.0.1 8.8.4.4
```

### 3. 重建 resolv.conf symlink

```bash
rm -f /etc/resolv.conf
ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf
systemctl restart systemd-resolved
```

### 4. 验证

```bash
resolvectl status               # 确认 DNS Servers: 1.1.1.1 8.8.8.8
nslookup open.feishu.cn         # 确认解析正常
```

### 5. 重启 Hermes Gateway

```bash
hermes gateway restart
```

## 防止复发

### 规则一：永远不要使用 WARP warp 模式

VPS 上只允许 `warp-cli mode proxy`（SOCKS5 本地代理模式）。代理模式的流量只有显式通过代理的请求才走 WARP，不会影响系统 DNS。

```bash
# 允许的用法
warp-cli mode proxy
warp-cli proxy port 40000

# 绝对不要
warp-cli mode warp    # ← 高危！
```

### 规则二：Tailscale 以 --accept-dns=false 启动

```bash
tailscale up --accept-dns=false --ssh
```

### 规则三：修改网络组件必须执行安全预检

涉及 WARP/Tailscale/Xray/CF Tunnel/DNS 的任何修改，必须：
1. **改前快照**: `cat /etc/resolv.conf` + `resolvectl status` + `nslookup open.feishu.cn`
2. **改后验证**: 同样三条命令
3. **自动修复命令就绪**: 如果 DNS 被劫持，能立即恢复

## 排查顺序（应用的）

遇到应用层连接错误（Hermes 无响应/飞书断连/API 超时/GitHub 拉取失败），按此顺序：

```text
1. DNS                   (cat /etc/resolv.conf + resolvectl status)
2. TCP 连接              (curl -v / nc -zv)
3. 代理出口              (检查 HTTP_PROXY / WARP / Tailscale)
4. 服务状态              (systemctl status)
5. 应用配置              (config.yaml / .env)
6. 业务逻辑              (代码/权限/认证)
```

**不要第一时间修改 Hermes 核心配置。**

## 教训总结

> Hermes 没有把自己改死，是底层网络环境变化导致 Hermes 失去飞书连接能力。
> 应用层故障 ≠ 应用本身故障。
> 网络服务正常 ≠ DNS 正常。
> 进程正常 ≠ 外部连接正常。
