#!/bin/bash
# tablet-tunnel.sh - 平板家宽出口隧道自动重连服务
# 用途: VPS 通过 ssh -D 连平板（Tailscale 内网），SOCKS5 出口 = 上海电信家宽
# 部署: systemd 服务 /etc/systemd/system/tablet-tunnel.service
# 参考: vps-residential-exit-node skill

TABLET_IP="100.78.214.117"      # 平板 Tailscale IP
TABLET_PORT="8022"              # Termux sshd 端口
TABLET_USER="u0_a154"
LOCAL_PORT="10808"              # VPS 本地 SOCKS5 端口
SSH_KEY="/root/.ssh/id_ed25519"
LOG="/var/log/tablet-tunnel.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG"; }

check_tablet_online() {
    timeout 8 tailscale ping --timeout=5s "$TABLET_IP" 2>&1 | grep -q "pong"
}

check_port() {
    timeout 5 bash -c "exec 3<>/dev/tcp/$TABLET_IP/$TABLET_PORT" 2>/dev/null
}

start_tunnel() {
    log "启动隧道: ssh -D $LOCAL_PORT → $TABLET_IP:$TABLET_PORT"
    ssh -i "$SSH_KEY" -N -D "$LOCAL_PORT" \
        -o StrictHostKeyChecking=accept-new \
        -o ServerAliveInterval=30 \
        -o ServerAliveCountMax=3 \
        -o ExitOnForwardFailure=yes \
        -o ConnectTimeout=10 \
        "$TABLET_USER@$TABLET_IP" -p "$TABLET_PORT"
}

verify_tunnel() {
    local out
    out=$(curl -s --socks5-hostname 127.0.0.1:"$LOCAL_PORT" --max-time 10 https://ifconfig.me 2>/dev/null)
    if [ -n "$out" ] && [ "$out" != "192.3.241.244" ]; then
        log "隧道验证 OK, 出口=$out"
        return 0
    fi
    log "隧道验证失败 (出口=$out)"
    return 1
}

log "===== tablet-tunnel 服务启动 ====="
while true; do
    # 1. 平板是否在线
    if ! check_tablet_online; then
        log "平板 Tailscale 不在线，等待 30s"
        sleep 30
        continue
    fi
    # 2. 平板 sshd 是否可达
    if ! check_port; then
        log "平板 sshd 不可达，等待 15s"
        sleep 15
        continue
    fi
    # 3. 现有隧道是否有效
    if ss -tln | grep -q ":$LOCAL_PORT " && verify_tunnel; then
        sleep 60
        continue
    fi
    # 4. 清理旧进程，重启隧道
    log "隧道失效或无进程，重建中..."
    pkill -f "ssh -i $SSH_KEY.*-D $LOCAL_PORT" 2>/dev/null
    sleep 2
    start_tunnel
    log "隧道进程退出(exit=$?)，10s 后重试"
    sleep 10
done
