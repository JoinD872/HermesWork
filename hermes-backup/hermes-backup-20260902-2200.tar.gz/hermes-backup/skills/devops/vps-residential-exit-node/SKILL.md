---
name: vps-residential-exit-node
description: VPS 借家用宽带住宅 IP 做出口的完整方案 — 闲置 Android 平板 + Tailscale + ssh -D 动态转发，解决数据中心 IP 信誉差被拒的问题（AI 服务风控/国内地域封锁站）。含 Xray 自动分流配置与全部排坑记录。
tags: [vps, residential-ip, tailscale, ssh, xray, ip-reputation, socks5]
version: 2026-08-05
risk: write-safe
---

# VPS 家宽出口节点（住宅 IP 隧道）

## 触发条件
- VPS 数据中心 IP 被 Spamhaus/风控/AI 服务拒绝（"IP 信誉差"）
- 需要访问仅限国内 IP 的站（bsedu.org.cn / 政务网）
- 用户有闲置 Android 平板/手机可以常驻家宽

## 一句话本质
**借家里的宽带 IP 当 VPS 出口**：VPS 通过 `ssh -D` 动态转发把 SOCKS5 流量送到平板（经 Tailscale 内网），平板 Termux sshd 收到后从家宽直连出去——目标站看到的 IP 是上海电信住宅 IP，不是 VPS 机房 IP。

## 架构

```
VPS (192.3.241.244)
  └─ systemd: tablet-tunnel.service（自动重连）
       └─ ssh -N -D 10808 u0_a154@100.78.214.117 -p 8022
            └─ Tailscale 内网（绕开公网 IP 阻断）
                 └─ 华为平板 mrx-w19 (Termux sshd :8022, wake-lock)
                      └─ 出口 = 上海电信家宽 180.164.97.180（住宅 IP）
```

## 关键步骤

### 1. VPS 侧（本机，Hermes 所在机）
- 脚本 `/root/.hermes/scripts/tablet-tunnel.sh`：循环检查平板在线 → sshd 可达 → 隧道健康（curl 出口 IP ≠ VPS IP）→ 失效自动重建
- systemd `/etc/systemd/system/tablet-tunnel.service`：`ExecStart` 指向脚本，`Restart=always`，开机自启
- 用法：`curl --socks5-hostname 127.0.0.1:10808 https://...`
- Python：`proxies={"http":"socks5h://127.0.0.1:10808","https":"socks5h://127.0.0.1:10808"}`

### 2. 平板侧（Termux）
- `pkg install openssh`；VPS 公钥加入 `~/.ssh/authorized_keys`；`sshd` 启动（默认 8022）
- Tailscale App 侧载 APK（华为无 GMS：pkgs.tailscale.com 下载 universal APK + 邮箱验证码登录）
- `termux-wake-lock` + 电池白名单 + 插电，防息屏冻结

### 3. Xray 自动分流（可选升级，v2rayN 零改动）
服务端 routing：国内域名/IP → home-broadband（socks5://127.0.0.1:10808），其余 → 直连。手机 v2rayN 访问国内站自动走家宽，海外站照常直连。

### 4. 失联兜底（平板关机/断网的自动降级）
平板不在线时走家宽的流量会失败——必须配兜底，否则用户无感知地断网：
- 脚本 `/root/.hermes/scripts/xray_fallback.sh`：`split`/`direct` 双模式原子切换（生成→`xray run -test -format json` 校验→备份→应用→重启 Xray）
- `tablet-tunnel.sh` 内：连续 3 次检测失败（约 90s，Tailscale ping / sshd 8022 / 隧道出口三连查）→ 自动降级全直连；平板恢复 + 隧道健康 → 自动切回 split
- **恢复判定必须基于 Xray 实际配置**（grep home-broadband）而非脚本内存变量——systemd 重启后内存状态清零，否则降级后永远切不回来
- 坑：`start_tunnel` 必须后台运行（`&`），前台 `ssh -N` 会占住主循环导致永远走不到恢复逻辑
- 手动切换：`bash /root/.hermes/scripts/xray_fallback.sh split|direct`

## 使用边界（必须如实告知用户）
| 流量类型 | 走哪 | 结果 |
|---|---|---|
| 国内站 / 地域封锁站 / 要干净IP的 AI 服务 | 隧道 | ✅ 住宅 IP 畅通 |
| 海外站（Google/Reddit/GitHub） | VPS 直连 | ✅ 更快 |
| 被 GFW 墙的海外 AI（OpenAI/Gemini） | 都过不去 | ❌ 家宽在国内出不去，需海外住宅 IP 或换 VPS IP |

## 排坑记录（全部实测）
1. **Android VpnService 冲突**：Tailscale 与 v2rayN/NekoBox 互顶，平板只跑 Tailscale
2. **平板开 v2rayN 全局代理会劫持 sshd 出网** → 出口显示 VPS IP，必须关掉
3. **家宽直连 VPS 公网 IP 常被阻断**（ping 100% loss）→ 必须走 Tailscale 内网
4. **华为无 GMS**：Tailscale App 连不上时重启平板；CLI 二进制在 Termux 里 SIGSYS 崩溃（seccomp），不可用
5. **息屏冻结**：termux-wake-lock + 电池白名单 + 插电；症状是 SSH 连接 ESTAB 但 Send-Q 积压、数据不流动
6. **SSH 指纹确认卡住**：连新 IP 用 `-o StrictHostKeyChecking=accept-new`（否则 Termux 里无人应答）
7. **microsocks 在 Termux 不可靠**（Address already in use 静默退出）→ 用 `ssh -D` 方案，平板不需要 SOCKS5 服务
8. **Xray 26 的 MphDomainMatcher 对 geosite:cn 匹配失效** → 必须 `"domainMatcher": "linear"`
9. **Xray 26 rule 内 domain+ip 是 AND 语义** → 拆分独立规则，否则 CDN 域名匹配失败
10. **SSH 公钥不能靠视觉 OCR 提取**（0/O 混淆：D0F vs DOF 差一字符）→ 以用户文本为准，OCR 只做辅助
11. **xray run -test 非 .json 扩展名报 "Failed to get format"** → 校验时必须加 `-format json`
12. **pkill -f 匹配串会误杀自己**（命令行含相同字符串，exit -15）→ 用 PID kill 或精确模式
13. **一键杀进程只杀前台界面不杀后台 sshd**（白名单+wake-lock 生效时）→ 隧道不断，属正常
14. **Xray 自动分流后国内流量走家宽，家宽在国内出不去 GFW** → OpenAI/Gemini 等被墙海外 AI 仍走 VPS 直连，无法借家宽解决（需海外住宅 IP 或换 VPS IP）

## 参考文件
- `references/xray-split-routing.md`：Xray 分流完整配置 + 验证方法
- `scripts/tablet-tunnel.sh`：VPS 侧自动重连 + 失联降级循环脚本（systemd 用）
- `scripts/xray_fallback.sh`：Xray split/direct 双模式切换脚本（失联兜底核心）
