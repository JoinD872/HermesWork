# Xray 服务端自动分流配置（v2rayN 零改动）

## 目标
Xray 服务端根据目标域名/IP 自动分流：
- 国内域名（geosite:cn）或国内 IP（geoip:cn）→ home-broadband（socks5://127.0.0.1:10808 家宽隧道）
- 其余 → freedom 直连

手机/平板 v2rayN 客户端**不用改任何配置**，服务端自动路由。

## 最终配置（/usr/local/etc/xray/config.json）

```json
{
  "log": {"loglevel": "warning"},
  "inbounds": [
    {
      "listen": "0.0.0.0",
      "port": 8081,
      "protocol": "vless",
      "settings": {
        "clients": [{"id": "<uuid>", "level": 0}],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "ws",
        "wsSettings": {"path": "/vless-tunnel"}
      }
    }
  ],
  "outbounds": [
    {"protocol": "freedom", "tag": "direct"},
    {
      "protocol": "socks",
      "tag": "home-broadband",
      "settings": {
        "servers": [{"address": "127.0.0.1", "port": 10808}]
      }
    }
  ],
  "routing": {
    "domainStrategy": "IPIfNonMatch",
    "domainMatcher": "linear",
    "rules": [
      {"type": "field", "outboundTag": "direct", "ip": ["geoip:private"]},
      {"type": "field", "outboundTag": "home-broadband", "domain": ["geosite:cn"]},
      {"type": "field", "outboundTag": "home-broadband", "ip": ["geoip:cn"]},
      {"type": "field", "outboundTag": "direct", "network": "tcp,udp"}
    ]
  }
}
```

## 两个致命坑（Xray 26.3.27 实测）

### 坑 1：MphDomainMatcher 对 geosite:cn 失效
症状：日志显示 `taking detour [direct]` 即使域名明确在 geosite:cn 数据里（baidu.com 匹配失败）。
根因：Xray 26 默认启用 MphDomainMatcher（最小完美哈希匹配器），对该数据文件匹配异常。
修复：routing 里显式加 `"domainMatcher": "linear"`。

### 坑 2：rule 内 domain + ip 是 AND 语义
症状：`{"domain": ["geosite:cn"], "ip": ["geoip:cn"]}` 组合时 baidu 走 direct；
拆成两条独立规则后走 home-broadband。
根因：Xray 26 中同一 rule 内多字段必须同时匹配（AND），CDN 域名的解析 IP 不在 geoip:cn 时整个规则失效。
修复：domain 规则和 ip 规则拆开写（见上面配置）。

## 验证方法

### 1. 模拟客户端端到端测试
临时起一个本地 Xray 客户端（socks 10999 → vless 8081），curl 走它验证：

```bash
# /tmp/xray-client-test.json: socks 127.0.0.1:10999 + vless outbound (127.0.0.1:8081, ws /vless-tunnel, 同 uuid)
xray run -config /tmp/xray-client-test.json &
curl --socks5-hostname 127.0.0.1:10999 -o /dev/null -w "%{http_code}" https://www.baidu.com
```

### 2. 看路由决策日志
```bash
# 临时把 loglevel 改 debug，restart xray
journalctl -u xray --since "1 min ago" | grep -E "detour"
# 期望: baidu/zhihu/bilibili → [home-broadband]; google/reddit/github → [direct]
```

### 3. 用国内 IP 查询服务看出口
注意：myip.ipip.net 是 Cloudflare CDN 托管的（解析到美国 IP），不匹配 geoip:cn，走 direct 是**正常**的。验证家宽出口要用 baidu/zhihu 这类纯国内域名 + 日志 detour 判断，或者直接看日志。

## 验证过的分流结果（2026-08-05）
| 目标 | 路由 | 结果 |
|---|---|---|
| www.baidu.com | home-broadband | 200 |
| www.zhihu.com | home-broadband | 302 |
| www.bilibili.com | home-broadband | 200 |
| www.xiaohongshu.com | home-broadband | 302 |
| www.douyin.com | home-broadband | 200 |
| www.google.com | direct | 200 |
| www.reddit.com | direct | 200 |
| github.com | direct | 200 |
| api.openai.com | direct | 421（VPS IP 信誉问题，未被本方案解决） |

## 已知小瑕疵
- `beacons.gcp.gvt2.com`（Google 统计）被 geosite:cn 误归入家宽 → 无害但可后续用精确域名规则排除
- OpenAI/Gemini 类被墙海外 AI：家宽出口在国内过不去 GFW，仍走 direct（VPS IP），需另想办法
