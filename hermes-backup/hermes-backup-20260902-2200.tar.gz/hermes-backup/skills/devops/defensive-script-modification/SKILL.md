---
name: defensive-script-modification
description: 安全修改既有脚本的防御性工作流 — 防止修A坏B、关联性异常、通跑失效
category: devops
risk: write-safe
---

# 安全修改既有脚本的防御性工作流

## 定位

本 skill 定义修改既有 bash/Python 脚本时的规范流程，防止：
- **附带修改（Collateral Damage）** — 修A顺手改了B，B出bug
- **隐含依赖断裂** — 改了表层逻辑，没发现底层依赖变了
- **通跑（End-to-End）未验证** — 改完只测了修改点，没测整体流程

## 常见踩坑模式

| # | 模式 | 案例（本次日记事故） |
|---|------|---------------------|
| 1 | **附带修改** — 同一次patch中改了超出修改范围的代码 | 修 rclone 目录时顺手改了内容检测逻辑（`wc -l`→新检测），新检测有bug |
| 2 | **隐含依赖断裂** — 改了A，没察觉B依赖A的输出格式 | 无（但典型：改了一个函数的返回值类型，调用方没适配） |
| 3 | **条件分支盲区** — 只测了正常分支，遗漏错误/边界分支 | 只测了"有内容"的分支，没测"判定为空"的分支在新逻辑下是否误判 |
| 4 | **环境状态假设** — 假设某个文件/目录/变量存在 | `MONTH_DIR` 被循环覆写，导致后续创建新日记用了旧的月份值 |
| 5 | **时间窗口依赖** — 脚本执行时依赖特定时间/时区/顺序 | UTC 00:00 vs 北京时间 08:00 的日期差异 |
| 6 | **AI幻觉引入** — LLM 在改代码时"主动优化"了无关部分 | 我「顺便优化」了内容检测逻辑 |
| 7 | **累积复杂度陷阱** — 同一脚本被patch多次后复杂度超标，每次修A产生B | daily_diary.sh 第4次修（目录解析），第5次又炸（不同原因）|

## 修改前/中/后防御流程

### 修改前

- [ ] **改写还是打补丁？** — 先走「改写决策树」（见下方）
- [ ] 阅读完整脚本，圈定本次改动涉及的**精确行号范围**
- [ ] 写下**改动范围声明**（一句话，不得超过20字）
- [ ] 识别脚本中的**冻结区**（`>>> FROZEN ZONE` 标记的关键逻辑，不得修改）
- [ ] 检查脚本顶部变量和函数定义，确认没有隐含依赖
- [ ] 备份脚本：`cp script.sh script.sh.bak-$(date +%F-%H%M%S)`

### 修改中

- [ ] **单次 patch 只改一个功能域**（不要修A时顺手改B）
- [ ] 使用**渐进式三步法**：先加不删 → 切换入口 → 清理旧代码
- [ ] 每步独立验证后再走下一步
- [ ] 每步提交后先 `bash -n script.sh` 检查语法
- [ ] 注释中标记冻结区：`# >>> FROZEN ZONE — 不可改动 <<<`

### 修改后

- [ ] `bash -n script.sh` 语法检查通过
- [ ] 对修改的函数/逻辑做单元测试
- [ ] **通跑测试**：在隔离环境跑一次完整流程（包括所有分支）
- [ ] 确认旧行为不变（回归测试）
- [ ] 回滚方案：`cp script.sh.bak-* script.sh`

## 改写决策树：patch vs rewrite

遇到需要修改的 bash 脚本时，先走这个决策树：

```mermaid
flowchart TD
    A[收到修脚本需求] --> B{这是第几次改这个脚本?}
    B -->|0-1次| C[打补丁]
    B -->|2次+| D{set -euo pipefail?}
    D -->|否| C
    D -->|是| E{包含 inline Python?}
    E -->|否| F{行数 > 100?}
    E -->|是| G[推荐 Python 重写]
    F -->|否| C
    F -->|是| G
    G --> H{用户愿意接受新脚本?}
    H -->|是| I[全量 Python 重写]
    H -->|否| C[最小补丁，加 Python 独立测试]
```

### 触发 Python 重写的信号

| 信号 | 说明 |
|------|------|
| **同一脚本被patch ≥ 3次** | 每次修A，下次B又炸，系统性地不可靠 |
| **bash + inline Python 混写** | 引号转义地狱，bash的`set -e`炸掉Python的输出 |
| **`set -euo pipefail` + 多阶段逻辑** | 前段出错直接炸，后段创建/上传逻辑永远没机会跑 |
| **逻辑≥3层嵌套（循环/分支/调用）** | bash 的条件和循环表达能力有限，边界情况极易遗漏 |
| **涉及 rclone/curl 等外部IO** | 网络超时/目录不存在的错误处理在bash中很脆弱 |

### Python 重写规范

当决策树推荐重写时，按以下框架：

```python
#!/usr/bin/env python3
"""脚本说明 — 做了什么、cron驱动还是手动执行"""
import os, sys, subprocess, re
from pathlib import Path
from datetime import datetime, timezone

# === 配置区 ===
VAULT_DIR = Path.home() / ".hermes" / "ObsidianVault"
TEMPLATE = VAULT_DIR / "模板" / "日记模板.md"
FOLDER_ID = "..."  # Google Drive 根目录ID

# === 工具函数 ===
def run(cmd, timeout=120):
    """安全的子进程调用，统一错误处理"""
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout
        )
        return result.returncode == 0, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return False, "", "TIMEOUT"
    except Exception as e:
        return False, "", str(e)

def today_cn():
    beijing = timezone(timedelta(hours=8))
    return datetime.now(beijing).strftime("%Y-%m-%d")

# === 主逻辑 ===
def main():
    errors = []
    # 每个步骤独立 try/except，不互相影响
    try:
        pull_from_drive()
    except Exception as e:
        errors.append(f"拉取失败: {e}")

    try:
        create_today_diary()
    except Exception as e:
        errors.append(f"创建失败: {e}")

    try:
        clean_empty_diaries()
    except Exception as e:
        errors.append(f"清理失败: {e}")

    if errors:
        print("⚠️ 以下步骤出错:")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
```

### 关键优势

| 方面 | bash | Python |
|------|------|--------|
| 错误隔离 | `set -e` 全局炸 | 逐 try/except，单步失败不影响后续 |
| 目录操作 | 字符串拼接易出错 | `pathlib.Path` 类型安全 |
| 正则匹配 | `sed`/`grep` 跨行困难 | `re.DOTALL` 原生跨行 |
| 日期计算 | `date -d` 复杂 | `datetime` 精确 |
| 测试 | bash内嵌麻烦 | `unittest`/`pytest` 原生 |
| 子进程管理 | 管道/退出码手动 | `subprocess.run` 结构化 |

## no_agent bash 脚本测试策略

对于 Hermes cron 中 no_agent 的 bash 脚本：

### 三层测试

```
第1层：语法检查
  bash -n script.sh

第2层：函数级测试
  脚本内置 --test 模式：
  if [ "${1:-}" = "--test" ]; then
      test_content_detection
      test_month_dir
      exit 0
  fi

第3层：通跑验证
  复制测试目录，修改变量指向测试路径，全流程跑一次
```

### 嵌入式测试示例

```bash
# 在脚本顶部添加
if [ "${1:-}" = "--test" ]; then
    echo "=== Test: 内容检测 ==="
    # 用测试文件验证
    python3 -c "
    import re
    # 测试有内容的日记
    content = '---\\n\\n# 2026-06-01\\n\\n今天我写了内容'
    m = re.search(r'# \d{4}-\d{2}-\d{2}\n\n(.+)', content, re.DOTALL)
    assert m, 'Failed: should find content'
    body = re.sub(r'# [^\n]+', '', m.group(1))
    real = re.sub(r'\s+', '', body)
    assert len(real) > 10, 'Should detect real content'
    print('✅ 有内容检测通过')
    "
    exit 0
fi
```

## 最小改动原则

### 量化标准

| 指标 | 标准 |
|------|------|
| 改动行数 | ≤ 脚本总行数的 20% |
| 改动文件 | = 1（单次只改一个文件）|
| 功能域 | = 1（单次只改一个功能） |
| 冻结区 | 0（不得触及标记区域） |

### 逐行审查清单

修改前的每行代码问自己：
- 这行属于我声明的改动范围吗？
- 不改这行会怎样？（如果不会怎样，就别改）
- 这行有没有被脚本的其他部分依赖？

## 通跑检查清单

### 执行前
- [ ] 改动范围声明已写
- [ ] 备份已做
- [ ] 通跑测试脚本已准备

### 执行中
- [ ] 语法检查通过
- [ ] 单元测试通过
- [ ] 每步独立验证

### 执行后
- [ ] 通跑完成
- [ ] 回归测试通过（旧行为不变）
- [ ] 回滚方案已知

### 回滚触发条件
- 通跑发现任何回归
- 脚本耗时超过修改前 2x
- 产生意外文件/删除

## 实战案例

`references/diary-case-study.md` — daily_diary.sh 误删事故的全流程复盘。展示了附带修改、三步法、内容检测修复等模式的真实应用场景。

## Hermes+Codex 协作

| 角色 | 职责 |
|------|------|
| 小H（我） | 拆任务、写改动范围声明、执行验证 |
| Codex | 审查改动方案、提供测试策略、检查隐含依赖 |

### 协作流程

1. **小H 发起**：「我要改 X，改动范围是 Y」
2. **Codex 审查**：检查隐含依赖、冻结区、通跑风险
3. **小H 执行**：按三步法修改，每步验证
4. **Codex 复查**：确认没产生附带修改
5. **小H 通跑**：全流程验证 + 回滚方案确认

## 事故复盘模板

```
## 事实层
- 改了哪里：
- 改了啥：
- 出了什么问题：

## 根因分析
- 直接原因：
- 模式分类（见上表）：

## 修复与改进
- 回滚方式：
- 修复内容：
- 新增防御措施：
```
