# 平板断电/重启后远程接管恢复流程（2026-08-07 实测）

华为 MatePad MRX-W19 断电重启后，各通道恢复**不同步**，恢复顺序和判据如下。

## 通道状态表（重启后）

| 通道 | 重启后 | 恢复方式 |
|:-----|:-------|:---------|
| Tailscale | ✅ 自愈 | 自动重连。VPS 侧 `tailscale ping 100.78.214.117` 立即 pong（relay sfo ~160-200ms） |
| Termux sshd 8022 | ❌ **不自启** | **用户手动打开 Termux App** → sshd 自动恢复（几秒内） |
| adb 5555 | ❌ **`adb tcpip` 是运行时设置，重启即失效** | 需重新开启（见下） |

## adb 5555 为何无法远程恢复（全部实测堵死）

- Termux 的 `su` 是**占位程序**（设备未 root）：`su -c 'setprop service.adb.tcp.port 5555 && stop adbd && start adbd'` → `No su program found on this device. Termux does not supply tools for rooting`
- Termux 无 `setprop` 命令（command not found）；`cmd clipboard` 等也 255
- `pkg install -y android-tools` 能装上（adb 35.0.2-7），但 Termux 里 `adb tcpip 5555` 报 `error: no devices/emulators found`——Termux 进程没有 USB 通道访问 adbd，**必须由有 USB 权限的 adb 客户端执行**（即电脑）
- 可查状态：`getprop init.svc.adbd` = running（adbd 在跑）；`getprop ro.debuggable` = 0；`persist.sys.usb.config` = hisuite,mtp,mass_storage,adb（USB 调试配置仍在）；但 `ss -tln | grep 5555` 无监听 → connect 报 Connection refused

## 恢复必须用户操作（二选一）

**方式 A（无线，推荐）**：
```
设置 → 系统和更新 → 开发人员选项 → 关闭再打开「USB 调试」
```
重开后 VPS 侧 `adb connect 100.78.214.117:5555` 立即恢复（无需重插 USB，授权 key 还在）。

**方式 B（有线）**：
电脑跑一次 `adb tcpip 5555`，拔线后无线恢复。

## 恢复后的验证清单

```bash
tailscale ping 100.78.214.117        # ✅ 链路
ssh -i ~/.ssh/id_ed25519 u0_a154@100.78.214.117 -p 8022 "echo SSH_OK"   # ✅ Termux
adb connect 100.78.214.117:5555 && adb devices   # ✅ adb（期望 device 非 offline）
```

## 其他坑

- `adb devices` 残留 offline 条目时：先 `adb disconnect 100.78.214.117:5555` 再 connect
- 用户误以为「电脑在链路里」——其实无线接管 VPS→Tailscale→平板，**不经过电脑**；电脑掉线不影响（判断链路时别把 DaLao ping 不通当平板失联）
- 断电恢复后小红书等 App 的编辑页可能仍在（Activity 被系统恢复），但 UI 状态（滚动/焦点）不可靠，先 uiautomator dump 再操作
