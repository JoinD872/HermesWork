---
name: vps-residential-exit-tunnel
description: 用家庭设备（安卓平板/手机/电脑）作为 VPS 的住宅 IP 出口 —— 借家宽 IP 解决数据中心 IP 信誉差问题（国内地域封锁站/高频爬取/AI 服务风控）。含 Termux sshd + Tailscale + ssh -D 架构、Xray 分流、失联自动兜底。
tags: [vps, tailscale, termux, residential-ip, xray, ip-reputation]
version: 2026-08-05
risk: write-safe
---

# VPS 住宅出口隧道（家庭设备当出口节点）

## 触发条件

- 用户 VPS 是数据中心 IP（Spamhaus/CBL 黑名单），想获得干净住宅 IP 出口
- 需要访问国内地域封锁站（bsedu/政务网，服务器级 geo-block）
- 高频爬取国内站触发风控（数据中心 IP 易滑块/限流）
- 用户手头有闲置安卓设备（平板最理想，可 7×24 插电）或家宽电脑

## 一句话原理

**借用户家宽 IP 当 VPS 的出口**：VPS 通过 Tailscale 内网 SSH 连到家里的设备，用 `ssh -D` 动态转发把 SOCKS5 监听在 VPS 本地，流量从家宽出去——对方看到的 IP 就是住宅 IP（`is_datacenter: False`，abuser_score 极低）。

```
VPS(数据中心IP, 黑名单)
   │  ssh -D 10808（经 Tailscale 内网）
   ▼
家庭设备(Termux sshd:8022, 家宽WiFi)
   │
   ▼
出口 = 家宽住宅 IP（CHINANET-SH 等）
```

## 方案选型：ssh -D 动态转发（✅ 首选）vs 反向隧道+microsocks（❌ 放弃）

| 维度 | ssh -D（VPS 主动连设备） | 反向隧道 -R + microsocks（设备主动连 VPS） |
|---|---|---|
| 设备端依赖 | 只需 Termux sshd | 需 microsocks 常驻 |
| microsocks 在 Termux 的稳定性 | 不需要 | ❌ 实测反复失败（Address already in use / 静默退出） |
| 前置条件 | VPS→设备 经 Tailscale 可达 | 设备→VPS 公网直连被墙（国内家宽连不上境外 VPS） |
| 结论 | ✅ 用这个 | 不要用 |

**关键教训**：先确认设备→VPS 的**直连**是否通（`ping` + `nc -zv <vps-ip> 2222`）。家宽到境外 VPS 往往被 GFW/运营商阻断，直连 SSH 永远连不上——所以必须走 Tailscale 内网或 Cloudflare Tunnel 域名。

## 设备端配置（安卓平板，Termux）

### 前置检查
1. 平板需能装 APK（鸿蒙 NEXT 纯血版不行）
2. Termux 从 F-Droid/GitHub 装（华为应用市场没有）
3. 装 openssh：`pkg install openssh`
4. **Termux 仓库没有 tailscale 包**；官方二进制在 Termux 跑会 SIGSYS 崩溃（Android seccomp 拦截），**不要试**。Tailscale 用 Android App（侧载 APK + 邮箱验证码登录，华为无 GMS 也能用）

### 步骤
1. 平板装 Tailscale App，登录加入与 VPS 相同的 tailnet（Email me a code 登录，不依赖 Google）
2. 生成 SSH 密钥：`ssh-keygen -t ed25519 -N "" -f ~/.ssh/id_ed25519`，把公钥发 VPS 侧加入 `authorized_keys`
3. 把 VPS 公钥（`/root/.ssh/id_ed25519.pub`）写进平板 `~/.ssh/authorized_keys`，启动 `sshd`（默认 8022）
4. **保活三件套**（华为杀后台狠）：
   - 设置 → 应用 → Termux → 电池优化 → **不允许优化**
   - 设置 → 应用 → Termux → 应用启动管理 → 手动 → 允许自启动+后台活动
   - Termux 里 `termux-wake-lock`（需 `pkg install termux-api`）
5. 平板插电放家里 WiFi，息屏不影响（wake-lock + 白名单后实测稳定）

### 已知环境陷阱（详见 references/）
- Tailscale App 界面显示 "Not connected" 不一定真断：以 VPS 侧 `tailscale status` 的 tx/rx 为准
- Android 冻结 Termux 的特征：SSH 连接 ESTAB 但数据不流动（Send-Q 积压增长）→ 用 wake-lock + 白名单解决

## VPS 侧配置

### 1. systemd 隧道服务（断线自动重连）
- 脚本：`/root/.hermes/scripts/tablet-tunnel.sh`（见 scripts/，支持失联自动降级）
- 服务：`/etc/systemd/system/tablet-tunnel.service`（Restart=always, MemoryMax=128M）
- 核心逻辑：循环检查 设备在线(tailscale ping) → sshd 可达(8022) → 隧道健康(出口非 VPS IP) → 失联连续 3 次触发降级

### 2. Xray 分流（国内走家宽，海外直连）——可选升级
在现有 Xray config.json 增加：
- outbound `home-broadband`：socks → 127.0.0.1:10808
- routing：geosite:cn / geoip:cn → home-broadband；其余 → direct
- **必须 `"domainMatcher": "linear"`**（Xray 26 默认 MphDomainMatcher 对 geosite:cn 匹配失效）
- **rule 内 domain+ip 必须拆成独立规则**（Xray rule 多字段是 AND 语义，组合会匹配失败）

### 3. 失联兜底（关键可靠性设计）
- 平板失联连续 3 次检测失败（~90s）→ `xray_fallback.sh direct` 切全直连（服务不中断）
- 平板恢复 + 隧道健康 → 检测到 Xray 是 direct 模式 → 自动切回 split
- **恢复判定必须基于 Xray 实际配置（grep home-broadband），不能依赖脚本内存变量**（服务重启后变量清零会漏恢复）
- 切换脚本：`/root/.hermes/scripts/xray_fallback.sh`（见 scripts/，生成→校验→备份→应用→重启原子操作）

## 使用边界（重要，避免误用）

| 流量类型 | 走哪 | 原因 |
|---|---|---|
| 国内站 / 地域封锁站（bsedu/政务网） | 隧道 10808 | 家宽 IP 畅通，实测 bsedu 从超时→200 |
| 高频爬取国内站（知乎/小红书等） | 隧道 10808 | 住宅 IP 风控阈值高，不易滑块 |
| 对数据中心 IP 严打的 AI 服务（若国内可达） | 隧道 10808 | is_datacenter=False |
| 海外站（Google/Reddit/GitHub） | VPS 直连 | 家宽在国内，GFW 会墙海外站；VPS 直连更快 |
| **被 GFW 墙的海外 AI（OpenAI/Gemini）** | VPS 直连 | 家宽出口到不了这些服务，此方案救不了 |

## 排坑记录

完整排坑见 `references/troubleshooting-log.md`，核心：
1. 家宽直连境外 VPS 被墙 → 必须 Tailscale/CF Tunnel 绕行
2. microsocks 在 Termux 反复失败 → 弃用，改 ssh -D
3. Termux 跑官方 tailscale 二进制 SIGSYS → 用 App 不用 CLI
4. Xray 26 三坑：MphDomainMatcher / rule AND 语义 / -format json（见 references/xray-split-routing-pitfalls.md）
5. Spamhaus 手动 dig 返回 127.255.255.254 是**查询格式错误**不是列入（对照 1.1.1.1 同值验证）→ 用 ip_reputation.py
