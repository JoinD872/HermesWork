# Xray 26.x 分流路由排坑（2026-08-05 实测）

场景：Xray v26.3.27 做 geosite:cn / geoip:cn 分流（国内走 socks 隧道出口，海外直连）。

## 坑 1：MphDomainMatcher 对 geosite:cn 匹配失效（必须 linear）

**现象**：routing 里写 `"domain": ["geosite:cn"]`，但访问 baidu.com 时日志显示 `taking detour [direct]`——geosite:cn 明明包含 baidu，就是不匹配。

**根因**：Xray 26 默认启用 `MphDomainMatcher`（最小完美哈希匹配器），对 geosite:cn 这类分类规则匹配失效（疑似兼容 bug）。日志启动时会打印 `MphDomainMatcher is enabled for N domain rule(s)`。

**修复**：routing 里显式声明：
```json
"routing": {
  "domainStrategy": "IPIfNonMatch",
  "domainMatcher": "linear",
  ...
}
```
改成 linear 后 geosite:cn 立即生效。

## 坑 2：rule 内 domain + ip 多字段是 AND 语义（必须拆规则）

**现象**：
```json
{"type": "field", "outboundTag": "home-broadband", "domain": ["geosite:cn"], "ip": ["geoip:cn"]}
```
这条规则里 baidu.com 不走家宽——即便 geosite:cn 已含 baidu。

**根因**：Xray 26 中 rule 内多个字段是 **AND** 关系（域名匹配 AND IP 匹配都满足才命中）。baidu.com 的域名在 geosite:cn ✅，但解析出的 CDN IP（如 103.235.46.x）不在 geoip:cn 的匹配范围内（或 DNS 解析结果与 geoip 库不匹配）→ 整条规则不命中。

**修复**：拆成两条独立规则（任一命中即走家宽）：
```json
{"type": "field", "outboundTag": "home-broadband", "domain": ["geosite:cn"]},
{"type": "field", "outboundTag": "home-broadband", "ip": ["geoip:cn"]}
```
验证日志应显示 `taking detour [home-broadband]`。

## 坑 3：xray run -test 需要 -format json（扩展名非 .json 时）

**现象**：配置切换脚本生成 `.direct` / `.split` 后缀的临时配置后 `xray run -test -config xxx.direct` 报：
```
Failed to load config files: [xxx.direct] > Failed to get format of xxx.direct
```

**根因**：Xray 按文件扩展名猜格式，不认识 `.direct`。

**修复**：显式指定格式：
```bash
xray run -test -format json -config /path/to/config.direct
```

## 坑 4：geosite:cn 包含少量 Google 域名（无害）

`beacons.gcp.gvt2.com` 等 Google 统计域名在 geosite:cn 分类里，会走家宽（国内出口访问这些域名慢/不通）。无害，可忽略，或加更精确的例外规则。

## 验证套路（模拟 v2rayN 客户端端到端）

写一个本地 socks inbound 的客户端配置连服务端 VLESS：
```json
{
  "inbounds": [{"listen": "127.0.0.1", "port": 10999, "protocol": "socks"}],
  "outbounds": [{
    "protocol": "vless",
    "settings": {"vnext": [{"address": "127.0.0.1", "port": 8081, "users": [{"id": "<UUID>", "encryption": "none"}]}]},
    "streamSettings": {"network": "ws", "wsSettings": {"path": "/vless-tunnel"}}
  }]
}
```
然后：
```bash
curl -s --socks5-hostname 127.0.0.1:10999 "https://myip.ipip.net"   # 国内站应显示家宽 IP
```
**注意**：`myip.ipip.net` 是 Cloudflare CDN 托管的（美国 IP），若客户端把域名解析成 IP 传给服务端，geosite:cn 域名匹配失效——用 `--socks5-hostname` 保持域名透传。判断分流是否生效看服务端日志 `taking detour [home-broadband|direct]`，比看出口 IP 更可靠。

## 完整可用配置骨架

```json
{
  "log": {"loglevel": "warning"},
  "inbounds": [{"listen": "0.0.0.0", "port": 8081, "protocol": "vless",
    "settings": {"clients": [{"id": "<UUID>", "level": 0}], "decryption": "none"},
    "streamSettings": {"network": "ws", "wsSettings": {"path": "/vless-tunnel"}}}],
  "outbounds": [
    {"protocol": "freedom", "tag": "direct"},
    {"protocol": "socks", "tag": "home-broadband",
     "settings": {"servers": [{"address": "127.0.0.1", "port": 10808}]}}
  ],
  "routing": {
    "domainStrategy": "IPIfNonMatch",
    "domainMatcher": "linear",
    "rules": [
      {"type": "field", "outboundTag": "direct", "ip": ["geoip:private"]},
      {"type": "field", "outboundTag": "home-broadband", "domain": ["geosite:cn"]},
      {"type": "field", "outboundTag": "home-broadband", "ip": ["geoip:cn"]},
      {"type": "field", "outboundTag": "direct", "network": "tcp,udp"}
    ]
  }
}
```
