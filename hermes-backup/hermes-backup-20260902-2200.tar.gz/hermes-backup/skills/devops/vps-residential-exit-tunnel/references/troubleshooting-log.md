# 家庭设备住宅出口隧道 — 完整排坑记录（2026-08-05 实测）

目标场景：VPS(192.3.241.244, HostPapa 数据中心, Spamhaus ZEN+CBL 黑名单) 需要住宅 IP 出口。用户有闲置华为安卓平板，家宽上海电信。

## 方案演进（为什么最终是 ssh -D + Tailscale）

### 尝试路线①：NekoBox 服务端模式（❌ 已放弃）
手机装 NekoBox 当 SOCKS5 服务端，VPS 走 Tailscale 连手机。
- 死因：Android 上 Tailscale 与 NekoBox 都要 VpnService（同一"VPN 席位"），互相顶掉
- 结论：不可行

### 尝试路线②：Termux + microsocks + SSH 反向隧道（❌ 已放弃）
平板主动连 VPS 建 -R 反向隧道，VPS 10808 = 平板 microsocks。
- 死因 A：**平板家宽直连境外 VPS 被墙**（ping 100% 丢包、nc 2222 超时），反向隧道连不上
- 死因 B：microsocks 在 Termux 反复启动失败——`server_setup: Address already in use`、`ps` 查不到进程、静默退出，原因不明且不稳定
- 结论：方向反了，依赖也多，弃

### 尝试路线③：ssh.cloudjoind.com 走 Cloudflare Tunnel（❌ 不可用）
JoinD 隧道 ingress 里有 `ssh.cloudjoind.com → https://localhost:22`，但 **DNS 无 A/CNAME 记录**（dig 查不到），实际不可用。教训：JoinD 仪表盘配置的 hostname 不等于 DNS 已生效，要先 dig 验证。

### 尝试路线④：Tailscale App 直连（✅ 最终方案）
平板装 Tailscale App（APK 侧载），加入既有 tailnet，VPS 经 Tailscale 内网 ssh -D 连平板 sshd。
- 优点：绕开公网直连被墙；Tailscale 不劫持其他 App 流量（不像 v2rayN 全局代理）；无需 microsocks
- 出口验证：`curl --socks5-hostname 127.0.0.1:10808 https://ifconfig.me` → 180.164.97.180（CHINANET-SH）

## 关键坑逐条

### 坑 1：家宽 → 境外 VPS 公网直连被墙
平板关掉 v2rayN 后，`ping 192.3.241.244` 100% 丢包，`ssh 2222` timeout。
- 判断：VPS 的 2222 公网可达（暴力破解流量都进来了），说明是家宽到该 IP 的路径被阻断
- 解法：必须走 Tailscale 内网（或 CF Tunnel 域名），不能指望直连

### 坑 2：v2rayN 全局代理劫持一切（含 SSH 和 microsocks）
平板开着 v2rayN 时，SSH 隧道和 microsocks 出网全部被劫持到 VPS 出口 → 出口 IP 永远是 VPS 自己（192.3.241.244），隧道"通"但无意义。
- 证据：VPS 日志 `Accepted publickey for root from 192.3.241.244`（来源是 VPS 自己 = 走了 v2rayN 代理回环）
- 解法：做出口节点时**必须关掉设备上的全局代理**（v2rayN/NekoBox 等）

### 坑 3：Tailscale App 显示 Not connected ≠ 真断
平板 Tailscale App 界面显示 "Not connected"，但 VPS 侧 `tailscale status` 显示 `mrx-w19 active; relay "sfo", tx 79404 rx 86532`（有实时流量）——App 界面不可靠。
- 判断依据：VPS 侧 `tailscale ping <ip>` 和 `tailscale status` 的 tx/rx 才是真相
- 另外注意：App 连不上时尝试"强制停止后重开"，多数华为机型重启 App 即可恢复

### 坑 4：Android/Termux 后台冻结（息屏/切后台断流）
特征：SSH 连接 ESTAB 但数据不流动，`ss` 看 Send-Q 积压增长（568→804），curl 超时。
- 原因：华为/Android 省电管理冻结后台 Termux 进程（SIGSTOP），sshd 进程在但不再处理数据
- 解法（三件套）：
  1. 设置 → 应用 → Termux → 电池优化 → 不允许
  2. 设置 → 应用 → Termux → 应用启动管理 → 手动 → 允许自启动+后台活动
  3. Termux 里 `termux-wake-lock`（pkg install termux-api）
- 验证：设置后息屏连续 5 次 curl 全通

### 坑 5：Termux 装 Tailscale 的两种死路
- `pkg install tailscale` → **仓库无此包**（E: Unable to locate package）
- 官方静态二进制 → **SIGSYS: bad system call**（Android seccomp 拦截 faccessat2 等 syscall），goroutine 崩溃
- 结论：Termux 里不要尝试跑 tailscaled，用 Android App

### 坑 6：华为平板无 GMS
- Google Play 用不了，但 Tailscale APK 侧载没问题（universal 版 95MB）
- 登录选 "Email me a code"（邮箱验证码），不依赖 Google 账号
- 鸿蒙 NEXT（纯血版）不能装 APK，这种设备此方案不可行

### 坑 7：SSH 连新主机指纹确认卡死
第一次 `ssh root@100.105.223.69`（Tailscale IP 是新主机）会卡在 "Are you sure you want to continue connecting (yes/no)"——Termux 无人应答一直卡着。
- 解法：加 `-o StrictHostKeyChecking=accept-new`（或先用 ssh-keyscan 预存）

### 坑 8：pkill 自伤
脚本里 `pkill -f "ssh -i /root/.ssh/id_ed25519.*-D 10808"` 会在包含同样字符串的 shell 命令行执行时误杀自己（exit -15）。
- 解法：改用精确 PID kill（从 ss 解析 pid），或确保 pkill 模式不匹配当前命令行

## 失联兜底设计（重要可靠性模式）

### 问题
平板失联（关机/断网/被冻）时，走家宽的国内流量全挂；海外直连不受影响。

### 设计
- **降级**：连续 3 次检测失败（约 90s，防瞬时抖动误判）→ Xray 切全直连（服务不中断）
- **恢复**：平板恢复 + 隧道健康 → 检测到 Xray 是 direct → 自动切回 split
- **关键**：恢复判定基于 Xray 实际配置（`grep home-broadband config.json`），**不依赖脚本内存变量**——因为 systemd Restart 后进程变量清零，内存状态不可靠

### 切换脚本原子操作顺序
生成 → xray -test 校验 → 备份当前 → 应用 → restart xray
（校验失败保留现有配置，不破坏运行中服务）

## 实测效果数据

| 目标 | VPS 直连 | 隧道(家宽) |
|---|---|---|
| www.bsedu.org.cn（地域封锁） | 超时/522 | ✅ 200 (1.99s) |
| www.shanghai.gov.cn（封海外） | 超时 | ✅ 200 |
| 知乎/百度/B站/小红书/抖音 | 302/200（首页可通） | 302/200（高频爬取更稳） |
| Google/Reddit/GitHub | 200/301 | ❌ 超时（家宽在国内，GFW 墙外站，正常） |

出口 IP 信誉对比：
- 192.3.241.244: is_datacenter=True, abuser_score 0.0244 (Elevated), ASN High
- 180.164.97.180: is_datacenter=False, is_proxy/vpn/tor=False, abuser_score 0.0008 (Low), ASN Very Low

## 关键文件清单

- `/root/.hermes/scripts/tablet-tunnel.sh` — systemd 服务脚本（循环检测+重连+降级）
- `/root/.hermes/scripts/xray_fallback.sh` — Xray split/direct 切换
- `/etc/systemd/system/tablet-tunnel.service` — 开机自启
- `/usr/local/etc/xray/config.json` — 分流配置（备份 .split/.direct 双份）
- VPS 公钥 `/root/.ssh/id_ed25519.pub` 需加入平板 authorized_keys
