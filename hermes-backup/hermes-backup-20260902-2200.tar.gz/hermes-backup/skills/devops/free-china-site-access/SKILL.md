---
name: free-china-site-access
description: VPS 访问被屏蔽/风控国内网站的零成本方案矩阵 — RSSHub 公共实例、Cloudflare Workers 免费反代、GitHub Actions 免费算力、搜索引擎/网盘聚合替代通道。当 VPS 直连某国内站 000/403/被墙时，按优先级选择绕行通道。
tags: [china, blocked, proxy, free, rsshub, workaround, 国内站, 零成本]
risk: read-only
created: 2026-08-02
---

# 零成本访问被墙/风控国内网站

## 触发场景
- VPS 直连某国内站失败：curl 000（网络层封禁）、403（风控/JS检测）、browser 超时
- 不想付费住宅代理（$0.4-2/GB），要零成本方案
- 用户问"被封了如何零成本复活"

## 第一步：诊断分层（先判断是什么断）

```bash
curl -s -m 5 -o /dev/null -w "%{http_code}" https://目标站
```
| curl 结果 | 含义 | 对策 |
|-----------|------|------|
| 000/timeout | 网络层封禁 | 必须换出口（Worker 反代/RSSHub/GH Actions）|
| 200/302 | 网络通，可能是 JS 层或内容问题 | 检查 browser 层，多半是反爬 |
| 403 | 风控 | RSSHub/反代/带 cookie |

⚠️ **先测再下结论**：数据中心 IP 状态是动态的，某站今天通明天可能断，反之亦然。不要凭旧记忆判断"这站肯定连不上"。

## 零成本方案矩阵（优先级从高到低）

### 方案 1：RSSHub 公共实例（零部署，秒级可用）
```bash
curl -s "https://rsshub.ktachibana.party/douban/movie/playing"  # 豆瓣 ✅ 实测 200
```
- 实测可用实例：`rsshub.ktachibana.party`（豆瓣 200 全内容）、`rsshub.rssforever.com`、`hub.slarker.me`、`rsshub.woodland.cafe`
- 同一实例不同 route 可用性不同（ktachibana 豆瓣 200 但微博 503）→ **换实例或换 route 重试**
- rsshub.app 官方实例常 403（反爬），不要首选

### 方案 2：Cloudflare Workers 免费反代（自建，稳定）
- 免费额度 10万请求/天，纯反代场景用不完
- 已部署 `cf-proxy`（详见 skill `cloudflare-worker-proxy`）：
  ```
  https://cf-proxy.619151721.workers.dev/https://movie.douban.com/  → 200+114KB ✅
  ```
- 实测能力：豆瓣 ✅、百度/知乎/17173 ✅、B站 412（需 header）、frodo API 需 apikey、微博跳验证页
- **自定义域名不提高额度**；workers.dev 子域国内被墙但 VPS 访问无碍

### 方案 3：GitHub Actions 免费算力（定时爬取）
- 公开仓库 2000 分钟/月免费，runner 出口是 GitHub IP
- 适合定时爬国内站 → push 回仓库 / 回调 VPS

### 方案 4：替代 API/搜索引擎（绕风控）
- 知乎官方 API（已配置，每天 1000 次免费搜索）
- B站公开 API（直连通）
- PanHub 网盘聚合（绕搜索引擎风控找资源，见 netdisk-aggregator-search skill）
- 微博：m.weibo.cn 302 / s.weibo.com 302 需带 cookie

## 反爬拦截破解方法论（第三方检测站被 CF 拦时）

**第一性原理：反爬拦"人访问网页"，拦不住协议/API。**
1. 找 API 端点（网页被拦但 `api.xxx.com` 通）— 例：Scamalytics 被拦但 `api.ipapi.is` 数据更全
2. 协议层查询（DNSBL host 命令、WHOIS）— 不走 HTTP，CF 管不着
3. 缓存/搜索绕行（Wayback、Google 索引、SearXNG）
4. 住宅代理（最后手段，花钱）

实测：Scamalytics/whatismyipaddress/AbuseIPDB/IPQS 全被 CF 拦截（换 UA 无效）；`api.ipapi.is`、`ipwho.is`、`ip-api.com` 免费 API 全通。

## 常见陷阱
1. **不要拿 curl -L 的结果当反代测试结论**：-L 跟随相对路径重定向会拼错 URL 产生假 400；用 `-D -` 看响应头
2. **RSSHub 公共实例不稳定**：503/429 是常态，多实例重试；豆瓣在 ktachibana 稳定
3. **"解封"是动态状态**：某天测全通 ≠ 永久解封，被墙站要逐站测试
4. **黑名单记录不会自动消失**：CBL/Spamhaus 列入需联系 ISP 申请移除（治本）；绕行方案是治标
