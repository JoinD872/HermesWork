---
name: vps-home-broadband-exit
description: 用闲置安卓平板(华为)家宽 IP 作为 VPS 出口 — 隧道建立/Xray 分流/失联兜底/华为平板排坑 全套方案
version: 1.0.0
tags: [devops, vps, tailscale, xray, proxy, residential-ip, huawei-tablet, termux]
risk: write-dangerous
---

# VPS 家宽出口方案（闲置平板做住宅 IP 出口）

## 核心定位（一句话）

VPS（数据中心 IP，信誉差/被 403）通过 Tailscale 内网 SSH 直连闲置安卓平板，把平板的**住宅家宽 IP** 作为出口，解决 IP 信誉问题（地域封锁站、AI 服务风控、国内社交平台抓取）。

## 架构总览

```
VPS 192.3.241.244（数据中心IP，信誉差）
  └─ systemd: tablet-tunnel.service（开机自启，断线30s自动重连）
       └─ ssh -i /root/.ssh/id_ed25519 -N -D 10808（Tailscale 内网）
            └─ 平板 Termux sshd:8022
                 └─ 出口 = 家宽住宅IP（上海电信 180.164.97.180）

Xray 分流（v2rayN 客户端零改动）:
  国内域名(geosite:cn)/国内IP(geoip:cn) → home-broadband outbound → 10808隧道 → 家宽
  海外域名 → freedom 直连 → VPS 洛杉矶
```

## 使用场景（关键边界）

| 场景 | 走哪条 | 说明 |
|---|---|---|
| 国内站/地域封锁站(bsedu/政务网) | 隧道 10808 | 家宽 IP 畅通，直连必死 |
| AI 服务(数据中心IP被风控的) | 隧道 10808 | 住宅 IP 正常用户画像 |
| 海外站(Google/Reddit/GitHub) | 直连 | VPS 在海外更快；走隧道反而被 GFW 卡 |
| 国内社交平台(小红书/知乎/B站/抖音) | 隧道(抓取时) | 首页访问两条路都通；高频抓取必须走隧道 |

**铁律：家宽出口在国内 → 被 GFW 墙的海外站走隧道必超时，这是特性不是 bug。**

## 实施步骤

### 1. 平板端（一次性配置）
- 装 Termux + Tailscale App（Termux 官方 GitHub 版，含 APK 可用飞书传）
- Termux 内：`pkg install openssh`，生成密钥对 `ssh-keygen -t ed25519`
- 授权 VPS 公钥到 `~/.ssh/authorized_keys`（chmod 700/600）
- 启动 sshd（默认 8022）：`sshd`
- **华为防冻结三件套**（关键！否则息屏即断）：
  1. 设置→应用→Termux→电池→电池优化→不允许
  2. 应用启动管理→手动管理（允许自启动+后台活动）
  3. Termux 内 `termux-wake-lock`

### 2. VPS 端
- Tailscale 已装（VPS 和 App 同一账号）
- 测试连通：`tailscale ping <平板IP>`；`ssh -i key -p 8022 user@平板IP 'echo OK'`
- 建立隧道：`ssh -i /root/.ssh/id_ed25519 -N -D 10808 -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -o ExitOnForwardFailure=yes u0_a154@<平板IP> -p 8022`
- 写 `/root/.hermes/scripts/tablet-tunnel.sh`（见下方模板）+ systemd 服务（After=network-online.target tailscaled.service, Restart=always, RestartSec=15, MemoryMax=128M）

### 3. Xray 分流配置
config.json 关键部分（**注意 Xray 26 的坑**）：
```json
"routing": {
  "domainStrategy": "IPIfNonMatch",
  "domainMatcher": "linear",          // ← 必须! Xray26 默认 MphDomainMatcher 对 geosite:cn 匹配失效
  "rules": [
    {"type":"field","outboundTag":"direct","ip":["geoip:private"]},
    {"type":"field","outboundTag":"home-broadband","domain":["geosite:cn"]},  // ← 拆开写!
    {"type":"field","outboundTag":"home-broadband","ip":["geoip:cn"]},        // ← 不能和 domain 合并!
    {"type":"field","outboundTag":"direct","network":"tcp,udp"}
  ]
}
```
outbounds 加：
```json
{"protocol":"socks","tag":"home-broadband","settings":{"servers":[{"address":"127.0.0.1","port":10808}]}}
```

### 4. 失联兜底（三层）
1. systemd 自动重连（断线重建）
2. 连续 2 次检测失败(~30s) → xray_fallback.sh direct 切全直连（v2rayN 不中断）
3. 平板恢复 → 隧道重建+验证 → xray_fallback.sh split 切回

## 排坑记录（每个都是血泪）

1. **Xray 26 MphDomainMatcher bug**：`geosite:cn` 匹配不到任何域名（日志显示 detour direct）→ 必须 `domainMatcher: "linear"`
2. **Xray 26 rule 内多字段是 AND 语义**：`"domain":["geosite:cn"],"ip":["geoip:cn"]` 合并写 = 域名和IP都要匹配才命中（geoip 对 CDN 解析失败导致整体不命中）→ 拆成独立两条规则
3. **xray run -test 校验失败陷阱**：配置文件名非 `.json` 扩展名（如 .direct/.split）会报 `Failed to get format` → 加 `-format json` 参数
4. **pkill 自匹配自杀**：命令串含 `ssh -i key.*-D 10808` 时 `pkill -f` 会杀自己所在命令行（exit -15）→ 用 PID kill 或分两个工具调用
5. **华为系统冻结 Termux**：现象=进程/监听/ESTAB 全正常但数据不流动（Send-Q 积压）→ 防冻结三件套 + wake-lock
6. **Tailscale App 显示 "Not connected" ≠ 网络离线**：VPS 侧 `tailscale status` 显示 active 即可，别重装 App
7. **Termux 装 Tailscale CLI 两条路都死**：`pkg install tailscale` 无包；官方静态二进制 SIGSYS（Android seccomp 拦 faccessat2）→ 只用 App 版
8. **华为纯净模式拦截侧载 APK**：报"解析包出问题"（即使 APK 有效、aapt 验证通过）→ 设置→系统→纯净模式→关闭；Termux 前台时 termux-open 才能弹窗
9. **DERP 中继大文件传输断流**：scp/curl 传 >300KB 必截断 → 分块传输（30KB base64 逐块 SSH 管道）+ MD5 校验
10. **F-Droid termux-boot 就是 26KB**（R8 压缩，classes.dex 5.8KB 正常）——别以为下载坏了
11. **CBL 对家宽动态段整段记录是通病**：不影响 AI 服务（它们看 is_datacenter 而非 CBL）
12. **Spamhaus 手查格式陷阱**：返回 `127.255.255.254` = 格式无效响应码（非列入），用 ip_reputation.py 查询

## 关键文件

- VPS `/root/.hermes/scripts/tablet-tunnel.sh` — 隧道重连+失联兜底主循环
- VPS `/root/.hermes/scripts/xray_fallback.sh` — Xray split/direct 模式切换（原子操作：生成→校验→备份→应用→重启）
- VPS `/etc/systemd/system/tablet-tunnel.service` — 开机自启
- VPS `/usr/local/etc/xray/config.json(.split/.direct)` — Xray 配置模板
- 平板 `~/.termux/boot/start-sshd.sh` — 手动重启参考（termux-boot 插件在华为装不上）
- 日志 `/var/log/tablet-tunnel.log`

## 验证命令

```bash
# 隧道健康
curl -s --socks5-hostname 127.0.0.1:10808 https://ifconfig.me  # 应显示家宽IP
# 分流验证（走测试客户端 10999 或直接看 journalctl）
journalctl -u xray | grep detour  # 国内→home-broadband, 海外→direct
# IP 信誉
python3 /root/.hermes/scripts/ip_reputation.py <出口IP>
# 降级兜底测试：临时改 TABLET_IP 为不可达 → 2次失败后 Xray 自动切 direct
```

## 边界与限制

- **平板必须在线**（插电+WiFi+白名单+wake-lock）；失联自动降级全直连保证服务不中断
- **海外住宅 IP 方案无法用这套实现**（家宽在国内被 GFW 墙海外）；OpenAI/Gemini 等被墙 AI 仍走 VPS 直连，IP 信誉问题需换 IP/海外住宅
- 抓取正经姿势：camoufox（真实浏览器指纹）+ 隧道（住宅 IP）= 最难判定机器人组合；curl 高频必被风控
