#!/bin/bash
# xray_fallback.sh - Xray 分流/直连模式切换
# 用法: xray_fallback.sh split|direct
#   split  → 分流模式(国内走家宽隧道)
#   direct → 全直连模式(平板失联兜底)
# 原理: 维护两份配置, 切换时原子替换 + 重启 Xray

CONFIG="/usr/local/etc/xray/config.json"
SPLIT_CONFIG="/usr/local/etc/xray/config.json.split"
DIRECT_CONFIG="/usr/local/etc/xray/config.json.direct"
LOG="/var/log/tablet-tunnel.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [fallback] $1" >> "$LOG"; }

gen_direct() {
python3 - "$CONFIG" << 'EOF'
import json, sys
cfg = json.load(open(sys.argv[1]))
cfg['outbounds'] = [o for o in cfg['outbounds'] if o.get('tag') != 'home-broadband']
if 'routing' in cfg:
    cfg['routing'] = {
        "domainStrategy": "IPIfNonMatch",
        "domainMatcher": "linear",
        "rules": [
            {"type": "field", "outboundTag": "direct", "network": "tcp,udp"}
        ]
    }
print(json.dumps(cfg, indent=2))
EOF
}

gen_split() {
python3 - "$CONFIG" << 'EOF'
import json, sys
cfg = json.load(open(sys.argv[1]))
has_hb = any(o.get('tag') == 'home-broadband' for o in cfg.get('outbounds', []))
if not has_hb:
    cfg['outbounds'].append({
        "protocol": "socks",
        "tag": "home-broadband",
        "settings": {
            "servers": [{"address": "127.0.0.1", "port": 10808}]
        }
    })
cfg['routing'] = {
    "domainStrategy": "IPIfNonMatch",
    "domainMatcher": "linear",   # 必须! Xray26 MphDomainMatcher bug
    "rules": [
        {"type": "field", "outboundTag": "direct", "ip": ["geoip:private"]},
        {"type": "field", "outboundTag": "home-broadband", "domain": ["geosite:cn"]},   # 拆开!
        {"type": "field", "outboundTag": "home-broadband", "ip": ["geoip:cn"]},
        {"type": "field", "outboundTag": "direct", "network": "tcp,udp"}
    ]
}
print(json.dumps(cfg, indent=2))
EOF
}

mode="$1"
case "$mode" in
    split)
        gen_split > "$SPLIT_CONFIG"
        # 注意: 非 .json 扩展名必须加 -format json
        if ! xray run -test -format json -config "$SPLIT_CONFIG" >/dev/null 2>&1; then
            log "❌ split 配置校验失败，保留当前配置"
            exit 1
        fi
        cp "$CONFIG" "$DIRECT_CONFIG" 2>/dev/null
        cp "$SPLIT_CONFIG" "$CONFIG"
        systemctl restart xray
        log "✅ 已切换为分流模式"
        ;;
    direct)
        gen_direct > "$DIRECT_CONFIG"
        if ! xray run -test -format json -config "$DIRECT_CONFIG" >/dev/null 2>&1; then
            log "❌ direct 配置校验失败，保留当前配置"
            exit 1
        fi
        cp "$CONFIG" "$SPLIT_CONFIG" 2>/dev/null
        cp "$DIRECT_CONFIG" "$CONFIG"
        systemctl restart xray
        log "✅ 已切换为全直连模式"
        ;;
    *)
        echo "用法: $0 split|direct"
        exit 1
        ;;
esac
exit 0
