#!/bin/bash
# tablet-tunnel.sh - 平板家宽出口隧道自动重连 + 失联兜底
# 功能:
#   1. 隧道断线自动重连
#   2. 平板失联(连续N次失败) → Xray 自动降级为全直连(服务不中断)
#   3. 平板恢复 → Xray 自动切回分流(国内走家宽)
# 依赖: xray_fallback.sh (切换 Xray 模式)

TABLET_IP="100.78.214.117"   # 平板 Tailscale IP（换设备必改）
TABLET_PORT="8022"
TABLET_USER="u0_a154"
LOCAL_PORT="10808"
SSH_KEY="/root/.ssh/id_ed25519"
LOG="/var/log/tablet-tunnel.log"
XRAY_FALLBACK="/root/.hermes/scripts/xray_fallback.sh"

# 失联判定: 连续失败次数达到阈值才降级(防误判)
# 压缩后: 2次 × (ping 5s + 等待10s) ≈ 30s 完成降级
MISS_THRESHOLD=2
miss_count=0
degraded=0

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG"; }

check_tablet_online() {
    timeout 5 tailscale ping --timeout=4s "$TABLET_IP" 2>&1 | grep -q "pong"
}

check_port() {
    timeout 5 bash -c "exec 3<>/dev/tcp/$TABLET_IP/$TABLET_PORT" 2>/dev/null
}

start_tunnel() {
    log "启动隧道: ssh -D $LOCAL_PORT → $TABLET_IP:$TABLET_PORT (后台)"
    ssh -i "$SSH_KEY" -N -D "$LOCAL_PORT" \
        -o StrictHostKeyChecking=accept-new \
        -o ServerAliveInterval=30 \
        -o ServerAliveCountMax=3 \
        -o ExitOnForwardFailure=yes \
        -o ConnectTimeout=10 \
        "$TABLET_USER@$TABLET_IP" -p "$TABLET_PORT" &
    TUNNEL_PID=$!
    log "隧道后台 PID=$TUNNEL_PID"
    sleep 3
}

verify_tunnel() {
    local out
    out=$(curl -s --socks5-hostname 127.0.0.1:"$LOCAL_PORT" --max-time 10 https://ifconfig.me 2>/dev/null)
    if [ -n "$out" ] && [ "$out" != "192.3.241.244" ]; then   # 换成 VPS 自身 IP
        log "隧道验证 OK, 出口=$out"
        return 0
    fi
    log "隧道验证失败 (出口=$out)"
    return 1
}

xray_mode() {
    if grep -q "home-broadband" /usr/local/etc/xray/config.json 2>/dev/null; then
        echo "split"
    else
        echo "direct"
    fi
}

degrade_to_direct() {
    if [ "$(xray_mode)" = "split" ]; then
        log "⚠️ 平板失联确认，Xray 降级为全直连"
        bash "$XRAY_FALLBACK" direct
        degraded=1
    fi
}

restore_split() {
    if [ "$(xray_mode)" = "direct" ]; then
        log "✅ 平板恢复且隧道健康，Xray 切回分流模式"
        bash "$XRAY_FALLBACK" split
        degraded=0
    else
        degraded=0
    fi
}

log "===== tablet-tunnel 服务启动(带失联兜底) ====="
while true; do
    if ! check_tablet_online; then
        log "平板 Tailscale 不在线 (miss=$((miss_count+1))/$MISS_THRESHOLD)"
        miss_count=$((miss_count + 1))
        if [ "$miss_count" -ge "$MISS_THRESHOLD" ] && [ "$degraded" = "0" ]; then
            degrade_to_direct
        fi
        sleep 10
        continue
    fi
    if ! check_port; then
        log "平板 sshd 不可达 (miss=$((miss_count+1))/$MISS_THRESHOLD)"
        miss_count=$((miss_count + 1))
        if [ "$miss_count" -ge "$MISS_THRESHOLD" ] && [ "$degraded" = "0" ]; then
            degrade_to_direct
        fi
        sleep 8
        continue
    fi
    if ss -tln | grep -q ":$LOCAL_PORT " && verify_tunnel; then
        if [ "$(xray_mode)" = "direct" ]; then
            restore_split
        fi
        miss_count=0
        sleep 60
        continue
    fi
    log "隧道失效或无进程，重建中..."
    if [ -n "$TUNNEL_PID" ]; then kill "$TUNNEL_PID" 2>/dev/null; fi
    pkill -f "ssh -i $SSH_KEY.*-D $LOCAL_PORT" 2>/dev/null
    sleep 2
    start_tunnel
    sleep 8
    continue
done
