# Cloudflare Workers 部署记录（2026-08-02）

## 免费额度官方口径（抓自 developers.cloudflare.com）

| 限制项 | Free 计划 | Paid |
|--------|----------|------|
| 每日请求 | 100,000 次/天（UTC 重置，超限 Error 1027）| 无限制 |
| CPU 时间/请求 | 10ms | 5 min |
| 内存 | 128 MB | 128 MB |
| 子请求 | 50/请求 | 10,000/请求 |

**域名不提升额度**（账户级固定值），但自定义域名可绑 Worker 绕 workers.dev 被墙（GFW 对 workers.dev 有针对性处理）。

## 近30天实际用量 vs 免费额度

网关日志统计（7天完整 + 外推）：
```
7天 LLM 回复（response ready）:  72 次
日均:                            10 次
估算30天:                        ~300 次
入站消息总数（7天）:              662 次
```
余量：即使放大 100 倍，距 10万/天 仍差一个数量级。**免费版完全够用。**

## 新版面板 API Token 创建流程（2026-08-02 实测）

Cloudflare 面板已改版，旧指引（My Profile → API Tokens）入口对不上，实际路径：

### 入口
1. dash.cloudflare.com 首页 → **左侧边栏最底部「Manage account」** → 展开找 **API Tokens**
2. 或右上角头像 → My Profile → API Tokens

### 创建
1. Create Token → **不要找模板**（新版模板列表没有 "Edit Cloudflare Workers" 这个叫法），滚到底部点 **Create Custom Token**
2. 权限必须手动添加，否则报 `At least one permission is required`：
   - 点 **+ Add policy**
   - 第一行：Account → Workers Scripts → Edit（部署 Worker 必需）
   - 第二行（可选，绑自定义域名）：Zone → DNS → Edit
3. 红色报错消失后，点 **Review token** → **Create Token**

### 关键坑
- **创建后 secret 只显示一次**，页面关了 token 就丢了，只能删除重建
- 页面上显示的 `{name, policies, resources}` JSON 是配置摘要**不是密钥**，密钥是一长串纯字符串（新版可能以 `cfut_` 开头）
- 权限组 ID：Workers Scripts Edit = `e086da7e2179491d91ee5f35b3ca210a`
- 部署只要 Workers Scripts Edit 就够；绑域名可后续在面板手动加 DNS 记录，不需要 token 带 DNS 权限

## V2RayN 安全确认（部署前必读）

V2RayN 走 **Xray VLESS+REALITY 直连 VPS IP:443**，与 Cloudflare Workers 完全无关。部署 Worker 只影响 CF 侧配置，不影响 VPS 上 Xray/tunnel。

**安全设计：只新增、不修改**
- 新 Worker + 新子域名（如 rss.cloudjoind.com）
- 不动现有 DNS 记录、cloudflared-joined 容器、cloudflared-docker-tunnel.service、Xray
- 回滚 = 删掉新记录，零影响

现有架构快照（2026-08-02）：
- `cloudflared-joined` Docker 容器（JoinD 托管，Up 11 days，ingress 由 JoinD 仪表盘推送）
- `cloudflared-docker-tunnel.service`（systemd，--token 运行，服务 proxy.cloudjoind.com）
- Xray active（VPS IP:443，REALITY，V2RayN 依赖）
- 域名 cloudjoind.com（NS = cloudflare），现有子域：proxy / open / api
