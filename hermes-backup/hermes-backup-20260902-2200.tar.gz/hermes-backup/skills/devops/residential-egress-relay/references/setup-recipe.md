# 住宅设备出口中转 — 完整配方（2026-08-05 华为平板实测）

## 设备端步骤（Termux）

### 1. 装包
```bash
pkg install -y microsocks openssh termux-api
```

### 2. 生成密钥（私钥留在设备，只发公钥）
```bash
ssh-keygen -t ed25519 -N "" -f ~/.ssh/id_ed25519 && cat ~/.ssh/id_ed25519.pub
```

### 3. VPS 侧授权（authorized_keys 加限制行）
```
no-agent-forwarding,no-X11-forwarding,no-pty,permitlisten="10808" ssh-ed25519 AAAA... u0_a154@localhost
```
**permitlisten 必须写 "10808" 不带 127.0.0.1: 前缀**——`permitlisten="127.0.0.1:10808"` 与 `-R 10808:...` 的默认绑定方式不匹配，OpenSSH 直接拒绝转发，报 `Error: remote port forwarding failed for listen port 10808`（表面像端口占用，实际是限制不匹配）。改完 `sshd -t` 验证语法。

### 4. 拉起隧道（一条命令）
```bash
killall -9 microsocks ssh 2>/dev/null; sleep 1; microsocks -i 127.0.0.1 -p 10808 & sleep 1; ssh -N -R 10808:127.0.0.1:10808 -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -o ExitOnForwardFailure=yes -i ~/.ssh/id_ed25519 root@<VPS_TARGET> -p 2222
```
跑起来卡住不动 = 成功。

### 5. 锁屏保护（华为/鸿蒙杀后台狠）
- 设置 → 应用 → Termux → 电池优化 → 不允许优化
- 设置 → 应用 → Termux → 应用启动管理 → 手动，允许自启动 + 后台活动
- 设置 → WLAN → 已连接 WiFi → 始终连接
- Termux 里 `termux-wake-lock`（需 termux-api 包）
- 验证：锁屏 30 分钟后 VPS 侧 curl 仍通

## VPS 侧验证（三层）
```bash
ss -tlnp | grep 10808                    # 1. sshd 在监听 = 隧道就位
journalctl -u ssh | grep Accepted        # 2. 设备公钥认证成功
curl -s --socks5-hostname 127.0.0.1:10808 https://ifconfig.me   # 3. 出口 IP 必须 ≠ VPS 公网 IP
```

## 坑位全记录（按踩坑顺序）

### 坑1【最大坑】设备上开着全局 VPN/代理 → 出口永远是 VPS IP
设备开 v2rayN/NekoBox/Tailscale exit node 时，**所有流量被劫持**，包括 SSH 隧道连接本身和 microsocks 出网。
- 表现：隧道"建立成功"（10808 有监听、公钥认证成功），但 curl 出口 IP = VPS 自己
- 证据：SSH 日志来源 IP 显示 192.3.241.244（VPS 自己）——因为连 SSH 连接都从代理进 VPS
- 解法：设备必须关闭所有全局 VPN/代理，只留 microsocks

### 坑2 家宽直连 VPS 公网 IP 被阻断
- 现象：`ping 192.3.241.244` 100% 丢包、`ssh` 超时，但 VPS 侧 2222 明明公网可达（暴力破解都能进来）
- 判断：是**家宽→该 IP 的路径被阻断**，不是 VPS 问题
- 解法：改用 Tailscale 内网 IP（设备入 tailnet，SSH 连 100.x.x.x），或 Cloudflare Tunnel 域名

### 坑3 新目标 IP 首次 SSH 卡指纹确认
- 现象：终端卡住不动（其实在等 yes/no 输入）
- 解法：加 `-o StrictHostKeyChecking=accept-new`

### 坑4 microsocks 后台 `&` 可能静默退出
- 现象：隧道在、端口在，但 curl 握手被 reset（Recv failure: Connection reset by peer）
- 解法：设备端验证 `ps -ef | grep microsocks` + `ss -tln | grep 10808`；稳妥做法是一个窗口前台跑 microsocks，另一个窗口跑 ssh

### 坑5 JoinD 隧道 hostname 配置里有 ≠ DNS 存在
- `ssh.cloudjoind.com` 在 cloudflared ingress 配置里，但 `dig` 查无 A 记录 → 实际不可用
- 依赖隧道域名前必须先 dig 验证

### 坑6 华为设备无 GMS/Google Play
- Tailscale APK 从 GitHub releases 侧载（universal 版兼容麒麟/骁龙），登录用 "Email me a code" 邮箱验证码
- 荣耀新款有 GMS 不受影响；鸿蒙 NEXT 纯血版装不了安卓 APK，只能换方案

### 坑7 视觉 OCR 会把公钥 0/O 认错
- 截图里 `D0F` vs `DOF` 差一个字符，入库前必须用用户文本复制的公钥，且 `ssh-keygen -lf` 验证指纹

### 坑8 设备没有 nc 工具
- `pkg install netcat-openbsd`；判断连通先 ping 再 `nc -zv -w 8 IP 2222`

## Tailscale 绕家宽阻断（坑2 的标准解法）
1. VPS 已在 tailnet（例：racknerd-81cc61a-1 = 100.105.223.69）
2. 设备侧载 Tailscale APK → Email code 登录 → 加入同一 tailnet（例：华为平板 mrx-w19 = 100.78.214.117）
3. VPS 侧 `tailscale ping 设备IP` 通（DERP 中继也 OK）
4. 隧道命令目标换成 VPS 的 Tailscale IP：`root@100.105.223.69 -p 2222`
5. Tailscale 默认不劫持其他 App 流量（只有 exit node 模式才接管），microsocks 出网走家宽直连 ✅
