---
name: residential-egress-relay
description: 住宅设备（手机/平板）作为干净住宅 IP 出口中转 — SSH 反向隧道 + microsocks，解决 VPS 数据中心 IP 信誉差/被黑名单/被国内站封的问题。含 Tailscale 绕家宽阻断、华为无 GMS 侧载等完整坑位。
tags: [vps, network, residential-ip, reverse-tunnel, tailscale, socks5]
version: 2026-08-05
risk: write-safe
---

# 住宅设备出口中转（Residential Egress Relay）

## 触发条件
- VPS 出口 IP 被黑名单（Spamhaus ZEN/CBL）、被国内站封、被搜索引擎风控（数据中心段连坐）
- 用户手头有闲置安卓设备（手机/平板）可常驻家宽 WiFi
- 需要"干净住宅 IP"出口访问目标站（bsedu/知乎/百度/Google 直连等）

## 一句话本质
**借家里闲置设备的家宽住宅 IP 当出口**。VPS 通过 SSH 反向隧道把流量转发到设备，设备用 microsocks 以家宽 IP 出网——住宅 IP 不在任何黑名单，不受 IDC 段连坐。

## 架构
```
VPS(192.3.241.244, 黑名单IP)
   │  ssh -R 反向隧道（设备主动连 VPS，不需要 VPS 连得进设备）
   ▼
设备 Termux（家宽 WiFi，住宅IP）
   │  microsocks 监听 127.0.0.1:10808
   ▼
目标站（看到的 IP = 家宽住宅 IP，干净）
```
- VPS 侧只有指定命令走设备出口（`curl --socks5-hostname 127.0.0.1:10808 ...`），不影响其他服务
- 反向隧道是普通 TCP，不占 Android VpnService，与 Tailscale 可共存

## 完整配方与坑位
详细步骤 + 8 个实测坑位见 `references/setup-recipe.md`。要点：

1. **设备端**：Termux 装 microsocks + openssh，生成 ed25519 密钥（私钥留设备），公钥授权 VPS
2. **拉起隧道**：microsocks 监听 127.0.0.1:10808 + `ssh -N -R 10808:127.0.0.1:10808 root@VPS -p 2222`
3. **VPS 授权安全限制**：`no-agent-forwarding,no-X11-forwarding,no-pty,permitlisten="10808"`（permitlisten 必须不带 127.0.0.1: 前缀，否则 OpenSSH 拒绝转发）
4. **验证三层**：端口监听 → 公钥认证日志 → curl 出口 IP ≠ VPS 公网 IP

## 核心坑位速查
| 坑 | 现象 | 解法 |
|---|---|---|
| 设备开全局 VPN/代理（v2rayN/NekoBox） | 隧道"通了"但出口永远是 VPS IP | **必须关掉**，代理劫持一切流量含 SSH 本身 |
| 家宽直连 VPS 公网 IP 被阻断 | ping 100% 丢包、ssh timeout | 改用 Tailscale 内网 IP 或 CF 隧道域名 |
| 新目标 IP 首次 SSH 卡指纹确认 | 终端卡在 yes/no | 加 `-o StrictHostKeyChecking=accept-new` |
| microsocks 后台 `&` 静默退出 | 隧道在但握手 reset | 前台跑 microsocks 或验证 `ps`/`ss` |
| JoinD 隧道 hostname 配置里有但无 DNS | ssh.xxx.com 连不上 | 依赖前先 `dig` 验证 A 记录 |
| 华为设备无 GMS | Google Play 用不了 | GitHub releases 侧载 APK + Email code 登录 |

## 验证命令（VPS 侧）
```bash
ss -tlnp | grep 10808                              # 1. 隧道监听
journalctl -u ssh | grep Accepted | tail -5        # 2. 设备公钥认证
curl -s --socks5-hostname 127.0.0.1:10808 https://ifconfig.me   # 3. 必须 ≠ VPS 公网 IP
```

## 关联
- `vps-ip-blocking-solutions`（方案矩阵，含此方案的入口）
- `windows-tailscale-ssh-access`（Tailscale SSH 访问的另一方向）
- `cloudflare-joined-tunnel-architecture`（CF 隧道域名方案）
