# crawl4ai Reddit 绕过实测结果 — 2026-05-26

## 测试环境
VPS 192.3.241.244 (RackNerd LA, 2.4GB RAM)
crawl4ai v0.8.6, Playwright chromium_headless_shell

## 结果

### ✅ 成功（4/4 子版全部通过）
| 子版 | 数据量 | 耗时 |
|------|--------|------|
| r/unrealengine hot 5条 | 10,656 chars (纯JSON) | 1.06s |
| r/VPS hot 5条 | JSON 数据完整 | 1.13s |
| r/LocalLLaMA hot 5条 | JSON 数据完整 | 1.02s |
| r/MachineLearning hot 3条 | JSON 数据完整 | 1.09s |

所有 JSON API 请求使用基础模式（无 magic/stealth）即可绕过封锁。

### 原因分析
curl 被 Reddit 在 IP 层封锁（HTTP 403）。Playwright 使用完整的 TLS 握手 + HTTP/2 + 浏览器指纹，Reddit 的封禁策略无法将该流量特征关联到封锁的 VPS IP 段。

### 坑
- 新版 Reddit HTML 有 Cloudflare challenge，返回 ~230 chars
- old.reddit.com HTML 正常（17,865 chars）
- JSON API 最稳定、最轻量
- crawl4ai 将 JSON 包裹在 markdown 代码块中，提取时需要 strip 反引号

### 推荐使用方式
参见 `community-scraping` skill 中的 Reddit 章节，含示例代码。
推荐直接调用助手脚本（免写 Python）：
```bash
/root/.crawl4ai-venv/bin/python /root/.hermes/scripts/crawl4ai_reddit.py <subreddit> [limit]
```
