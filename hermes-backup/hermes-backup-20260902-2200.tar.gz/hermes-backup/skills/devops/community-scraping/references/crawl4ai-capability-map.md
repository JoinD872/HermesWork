# Crawl4AI 能力边界与实测记录（2026-05-26 验证）

安装路径：`/root/.crawl4ai-venv/`，助手脚本：`/root/.hermes/scripts/crawl4ai_reddit.py`

## 实测结果

| 目标 | 接口 | 结果 | 响应时间 | 说明 |
|------|------|------|---------|------|
| **Reddit JSON API** | `r/{sub}/hot/.json` | ✅ **成功** | ~1.1s | 绕过 VPS IP 403，4个子版全部稳定 |
| **Reddit old.reddit.com** | HTML直连 | ✅ 成功 | ~2.1s | 17K+ chars，内容完整 |
| **Reddit 新版HTML** | `reddit.com/r/...` | ⚠️ Cloudflare拦截 | ~1s | 仅返回230 chars |
| **知乎 Developer API** | `developer.zhihu.com` | ❌ 需鉴权 | ~1s | 缺Authorization头，非crawl4ai问题 |
| **nitter.net (X)** | 前端页面 | ❌ Anti-bot拦截 | ~1s | 结构检测阻止 |
| **小红书** | `xiaohongshu.com` | ❌ Tencent EdgeOne | 60s超时 | 传输层TLS指纹封锁 |

## Reddit 使用方法

```python
import asyncio, json, re
from crawl4ai import AsyncWebCrawler

async def fetch_reddit(subreddit, limit=5):
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(
            url=f"https://www.reddit.com/r/{subreddit}/hot/.json?limit={limit}",
        )
    # markdown 输出包裹在 ```json 代码块中
    m = re.search(r"```(?:json)?\s*(.*?)```", result.markdown, re.DOTALL)
    raw = m.group(1).strip() if m else result.markdown.strip()
    return json.loads(raw)["data"]["children"]
```

## 限制

- 不接入早报 cron（Chromium 进程开销大，仅作 curl 403 时的 fallback）
- 小红书被 Tencent EdgeOne 在传输层拦截，无法绕过
- v0.8.6 曾遭遇 litellm PyPI 供应链投毒（已替换为 unclecode-litellm）
