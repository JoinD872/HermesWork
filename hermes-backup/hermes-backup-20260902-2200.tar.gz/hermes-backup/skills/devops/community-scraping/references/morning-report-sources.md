# 每日早报源配置手册（2026-05-27 更新）

## 当前7个源

| 源 | 采集方式 | 频率 | 日均调用 | 认证方式 |
|---|---------|------|---------|---------|
| X/Twitter | Timeline API | 每2小时 | ~30次 | social_scraper.json |
| V2EX | HTML爬取 | 每4小时 | ~6次 | 无 |
| GitHub Trending | Search API | 每天3次 | ~6次 | 无（公开API有速率限制）|
| 知乎 | Developer API | 每天8轮 | ~160次 | .env ZHIHU_ACCESS_SECRET |
| Hacker News | Firebase + Algolia | 每2小时 | ~200次 | 无 |
| HuggingFace Papers | REST API | 每天2次 | ~2次 | 无 |
| 掘金 | 推荐流API | 每天2次 | ~2次 | 无 |

## 知乎搜索词矩阵（17个搜索词，~160次/天）

分类: AI/ML (DeepSeek, MiniMax, ChatGPT, Claude, Gemini, 大模型 应用)
分类: AI Agent (AI Agent, MCP, Agent框架, RAG, 多模态, AI编程, 开源模型, 模型评测)
分类: 行业动态 (AI 创业, 科技热搜, AI 新闻, 模型 部署)
热点替代: AI, 大模型, 科技, 人工智能

## 掘金API踩坑记录

- 返回结构：`data[].item_info.article_info.title`
- 点赞字段：`digg_count`（不是 `like_count`）
- 标签字段：`article_info.tags[].tag_name`

## Hacker News API

- Firebase主API：无认证，无限流，~0.1s
- Algolia搜索：支持查询过滤，`hitsPerPage` 控制数量
- 安全扫描器拦截 `curl | python3` 管道，必须用分步法

## 排除规则（不可违反）

- UE5 / 虚幻引擎5所有内容
- 游戏开发（Unity/Godot/蓝图/C++游戏）
- 本地模型（ollama/llama.cpp/本地部署）
