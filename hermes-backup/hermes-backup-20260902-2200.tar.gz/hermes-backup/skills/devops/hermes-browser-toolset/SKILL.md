---
---
name: hermes-browser-toolset
description: Hermes Agent browser toolset configuration — why browser automation may silently fail and how to diagnose it
category: devops
tags: [browser, camoufox, playwright, config, troubleshooting]
version: 2026-04-09
risk: write-dangerous
---

# Hermes Browser Toolset 配置指南

## ⚠️ 修改操作前置要求

| 操作类型 | 要求 |
|---------|------|
| 修改 `~/.hermes/config.yaml` | **必须先** `cp ~/.hermes/config.yaml ~/.hermes/config.yaml.bak-$(date +%F-%H%M%S)` |
| 修改 browser 相关配置 | **必须先**备份当前 toolsets 和 browser section 配置 |
| 重启 Hermes Gateway | 确认备份存在后再执行 |

**回滚命令**：`cp ~/.hermes/config.yaml.bak-* ~/.hermes/config.yaml && systemctl restart hermes-gateway`（或对应 service 名）

---

## 症状
browser_navigate / browser_snapshot / browser_click 等 browser 工具调用后返回内容很少、或工具似乎不可用，但没有任何报错。

## 根本原因
`config.yaml` 的 `toolsets` 数组必须显式包含 `browser`。默认安装时可能只有 `hermes-cli`，导致 browser toolset 不可用。

```yaml
# ✅ 正确 — 必须有 browser
toolsets:
  - hermes-cli
  - browser

# ❌ 错误 — 缺少 browser（browser 工具全部静默失效）
toolsets:
  - hermes-cli
```

## 验证方法

在 `config.yaml` 中找到 `toolsets` 部分，确认包含 `browser`。

正常情况：browser_navigate 访问 my.racknerd.com 应返回 5,000+ 字符的完整页面内容。
异常情况：返回很少内容（几百字符或更少）。

## 浏览器引擎优先级

Hermes Agent 的 browser toolset 按以下顺序选择引擎：

1. **Camoufox**（首选）— 反检测 Firefox 浏览器，爬取动态内容最佳
2. **Playwright**（降级备选）— 当 Camoufox 不可用时自动降级，API 完全兼容

## Camoufox 与 Playwright 对比

| 特性 | Camoufox | Playwright |
|------|----------|------------|
| 内核 | Firefox（反检测） | Chromium/Firefox/WebKit |
| 动态内容 | ✅ 强 | ✅ 强 |
| 反爬对抗 | ✅ 专为爬虫设计 | 一般 |
| 内核下载 | 需要 GitHub（国内可能超时） | 预装 |
| 安装难度 | 较高 | 简单 |
| 自动降级 | — | 是 |

## 常见问题

### Q: browser 工具有时候返回内容很少
**A**: 检查 toolsets 是否包含 `browser`，然后检查 config 中 `browser` section 的 `web_extract` auxiliary 是否配置了模型。

### Q: Camoufox 内核下载失败
**A**: WSL2 环境下 GitHub 被墙，导致浏览器内核下载超时。解决方案：
1. 挂梯子手动下载内核
2. 使用 Playwright 作为替代（自动降级，API 相同）
3. Cron job 定时提醒：设置 21:00 推飞书提醒手动处理

### Q: Playwright 和 Camoufox 能否共存
**A**: 可以。安装 Camoufox 不会破坏 Playwright。Hermes 自动检测可用引擎。

## 配置检查清单

```yaml
# config.yaml 应包含以下内容：

toolsets:
  - hermes-cli
  - browser        # ← 必须有

browser:           # ← 可选，增强配置
  auxiliary:
    model: gemini-2.0-flash
    provider: google
```

## 故障排除流程

```
browser 工具异常
    │
    ├─→ 检查 config.yaml toolsets
    │       │
    │       ├─→ 没有 browser → 添加后重启 gateway
    │       └─→ 有 browser → 继续
    │
    ├─→ 检查 Camoufox 可用性
    │       │
    │       ├─→ import 失败 → 安装内核或确认 Playwright 可用
    │       └─→ import 成功 → 继续
    │
    └─→ 检查 web_extract auxiliary
            │
            └─→ 没有配置 → 添加 gemini-2.0-flash auxiliary
```

## agent-browser CLI（VPS 上独立安装的浏览器工具）

当 browser tool 在 VPS 上运行（通过 SSH 远程调用 `agent-browser`）时，注意以下关键差异：

### 命令行语法（不是 browser_navigate，是 `agent-browser open`）

```bash
# 正确
agent-browser open https://www.google.com --timeout=15

# 错误（会报 net::ERR_NAME_NOT_RESOLVED）
agent-browser navigate https://www.google.com --timeout=15
```

### VPS agent-browser 实测 bot 检测结果（2026-05-03，洛杉矶机房 IP）

| 站点 | 结果 | 备注 |
|------|------|------|
| Google | ✅ | 正常 |
| GitHub | ✅ | 正常 |
| YouTube | ✅ | 正常 |
| 知乎 | ❌ | 超时，被拦截 |
| Reddit | ⚠️ | JS 挑战页，bot 检测触发 |
| 百度 | ✅ | 正常 |
| MiniMax 文档 | ✅ | 正常 |

**结论**：知乎/Reddit 对数据中心 IP（洛杉矶 RackNerd）有严格 bot 检测，需要 residential IP 代理才能稳定访问。大多数主流网站无问题。

### VPS DNS 正常但 browser 报 ERR_NAME_NOT_RESOLVED

这是因为 agent-browser 内部不走系统 DNS，而是在容器内解析。若 VPS 上 curl/nslookup 正常但 agent-browser 报 DNS 错误，说明 agent-browser 进程本身的 DNS 解析有问题，可以直接用 `agent-browser open` 测试（它内部有重试逻辑）。

## 相关 Skill

- `devops/camoufox-install` — Camoufox 安装完整指南，包含 Playwright 降级备选
- `web/web-page-detail-extract` — 完整页面信息提取工作流
