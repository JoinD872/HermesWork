# RSS/Blog Monitoring (blogwatcher)

For RSS/Atom blog subscription monitoring, use `blogwatcher-cli`:

```bash
# Install (Go)
go install github.com/JulienTant/blogwatcher-cli/cmd/blogwatcher-cli@latest

# Add a blog
blogwatcher-cli add "My Blog" https://example.com

# Scan all feeds
blogwatcher-cli scan

# List unread articles
blogwatcher-cli articles

# Mark as read
blogwatcher-cli read 1

# Import OPML
blogwatcher-cli import subscriptions.opml
```

Environment variables:
- `BLOGWATCHER_DB` -- SQLite database path
- `BLOGWATCHER_WORKERS` -- Concurrent scan workers (default 8)
