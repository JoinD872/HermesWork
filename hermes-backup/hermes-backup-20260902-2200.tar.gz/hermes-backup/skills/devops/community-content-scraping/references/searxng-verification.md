# SearXNG 端点验证与故障排除

## 环境

VPS 上运行 SearXNG Docker 容器：
```
IMAGE: searxng/searxng:latest
PORT: 0.0.0.0:8888->8080/tcp
```

## 验证命令

```bash
# 1. 确认容器运行状态
docker ps --filter name=searxng --format '{{.Names}} {{.Status}} {{.Ports}}'

# 2. 测试搜索（关键）
curl -sS --max-time 15 \
  "http://127.0.0.1:8888/search?q=site:zhihu.com+DeepSeek&format=json" \
  | python3 -c "import json,sys;d=json.load(sys.stdin);print(f'{len(d.get(\"results\",[]))} results')"

# 3. 使用不同关键词做 fallback（首次可能无结果）
curl -sS --max-time 15 \
  "http://127.0.0.1:8888/search?q=site:zhihu.com+UE5+性能&format=json"
```

## 已知参数

| 参数 | 值说明 |
|------|--------|
| 实际端口 | 8888 (Docker 映射) |
| 内部容器端口 | 8080 |
| 协议 | HTTP（非 HTTPS） |
| 格式参数 | `&format=json` |
| 默认引擎 | google (多引擎聚合) |

## 故障排查

| 现象 | 可能原因 | 解决 |
|------|---------|------|
| connection refused | Docker 未运行 | `docker start searxng` |
| 空结果 | 关键词过于特定 | 换通用关键词重试，不要单次标失败 |
| timeout 15s+ | 引擎响应慢 | 可接受，设置 15s 超时即可 |
| 返回无 results 字段 | 非 JSON 格式 | 检查端口是否正确，可能打了 nginx/xray |
