# 国内房产平台抓取参考

## 安居客社区页 NUXT 数据完整字段

安居客移动版社区页 `https://m.anjuke.com/sh/community/<ID>/` 通过 Nuxt.js SSR 返回完整数据。

### 核心价格字段
- `priceInfo.price` → 当前挂牌均价（元/㎡），如 `25086`
- `priceInfo.title` → 价格标题，如 `8月挂牌均价`
- `priceInfo.monthChange` → 月环比涨跌（经常为 null 或 `0.0%`）
- `priceInfo.saleNum` → 在售套数
- `priceInfo.rentNum` → 在租套数
- `priceInfo.priceData` → **始终为空数组** `[]`，走势数据由前端 JS 异步加载

### 房源列表字段（嵌套在 NUXT data 中）
每条房源包含：
- `attribute.price` → 总价（万元），如 `"172"`
- `attribute.avg_price` → 单价（元/㎡），如 `"23128"`
- `attribute.area_num` → 面积（㎡），如 `"74.37"`
- `attribute.room_num` → 室数
- `attribute.hall_num` → 厅数
- `attribute.fitment_name` → 装修（毛坯/简装/精装）
- `attribute.floor_level` → 楼层（如 `高层(共18层)`）
- `attribute.orient` → 朝向（如 `南`）
- `title` → 房源标题

### 小区信息字段
- `community.extend.completionTime` → 竣工时间，如 `2019`
- `community.extend.totalHouseHoldNum` → 总户数
- `community.extend.developer` → 开发商（如 `单位自建`）
- `community.extend.propertyCompany` → 物业公司
- `community.extend.landscapingRatio` → 绿化率
- `community.extend.plotRatio` → 容积率
- `community.extend.propertyMoney` → 物业费（元/㎡/月）

### 提取脚本模板

```python
import re, json, sys

def extract_anjuke_nuxt(html):
    """从安居客移动版 HTML 中提取 NUXT 数据"""
    # 方法1：正则提取函数参数
    m = re.search(
        r'window\.__NUXT__=\(function\([^)]+\)\{return[^}]+\}\((.+)\)\)',
        html, re.DOTALL
    )
    if not m:
        return None
    
    args_str = m.group(1)
    # 解析 JS 参数（字符串和数字）
    args = []
    i = 0
    in_string = False
    string_char = None
    current = ''
    
    while i < len(args_str):
        c = args_str[i]
        if in_string:
            current += c
            if c == '\\':
                i += 1
                current += args_str[i]
            elif c == string_char:
                in_string = False
                # 处理 unicode 转义
                val = current[1:-1].replace('\\u002F', '/')
                args.append(val)
                current = ''
        else:
            if c in "'\"":
                in_string = True
                string_char = c
                current = c
            elif c in '0123456789.':
                j = i
                while j < len(args_str) and args_str[j] in '0123456789.':
                    j += 1
                args.append(args_str[i:j])
                i = j - 1
        i += 1
    
    # 方法2：直接从 HTML 文本中提取关键数字
    prices = re.findall(r'(\d{4,5})\s*(?:元/㎡|元/m²)', html)
    return {
        'raw_args_count': len(args),
        'prices_in_html': prices,
        'all_args': args
    }
```

### NUXT 参数解析的坑

1. **压缩混淆**：参数名是 `a,b,c,...,bm` 等短变量名，无法直接按名取值
2. **嵌套函数**：`return {...}` 部分引用参数名赋值给对象属性，需要执行或解析才能映射
3. **最佳策略**：不解析 NUXT 函数，而是从渲染后的 HTML 文本中提取关键数字（价格、面积等）
4. **价格提取正则**：`re.findall(r'(\d{4,5})\s*(?:元/㎡|元/m²)', html)` 直接从 HTML 文本段中提取

## 房天下数据

房天下移动版 `https://m.fang.com/fangjia/xiaoqu/sh/<newcode>.html`：
- 参考均价在 `<div class="price">` 内
- 小区 newcode = `1210133094`（馨清佳苑）
- CF Worker 反代可用

## 各平台小区 URL 格式

| 平台 | URL 格式 | ID 类型 |
|------|----------|---------|
| 安居客 | `m.anjuke.com/sh/community/<id>/` | 数字 ID（如 1209363） |
| 房天下 | `m.fang.com/fangjia/xiaoqu/sh/<newcode>.html` | 数字 newcode |
| 链家/贝壳 | `sh.ke.com/xiaoqu/<id>.html` | 数字 ID |
| 我爱我家 | `sh.5i5j.com/xiaoqu/<id>.html` | 数字 ID |
| 大房鸭 | `dafangya.com/bd/nbh/index/<id>.html` | 数字 ID |

搜索时用小区名 + 区域名（如"馨清佳苑 宝山"）在 SearXNG 搜索，snippet 中通常包含 ID 和均价。

## 历史数据替代方案

当平台不提供历史走势数据时：
1. **搜索快照**：用 `site:` 搜索限定特定时间段，从搜索引擎缓存中获取历史页面上的均价
2. **Wayback Machine**：`web.archive.org/web/*/m.anjuke.com/sh/community/<id>/` 查看历史快照
3. **用户手动**：在手机 APP 上查看走势截图，最可靠
4. **在售房源反推**：从不同时间点的在售房源价格推算趋势（需要多次查询）
