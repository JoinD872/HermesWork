# 小红书无法自动化爬取的记录

## 测试日期：2026-05-18

## 测试环境
- VPS: 洛杉矶 RackNerd (192.3.241.244)
- 桌面: 上海宝山 Windows 桌面 (Tailscale SSH joind@100.86.150.37)
- 浏览器: Edge headless

## 所有方案均失败

| 方案 | 结果 |
|------|------|
| VPS agent-browser `browser_navigate` | 超时（JS SPA 太重，网络链路差） |
| VPS curl + Playwright 直连 | Playwright 进程 crash (EPIPE) |
| 上海桌面 PowerShell `Invoke-WebRequest` | 拿到 565KB JS 空壳（SPA无渲染） |
| 上海桌面 Edge headless `--dump-dom` | **安全限制 300012「IP存在风险」** |
| 上海桌面 Edge headless + 360ChromeX 用户数据目录 | **安全限制 300012** |
| 上海桌面 Edge `--headless --screenshot` | 截图文件正常（1920x1080）但内容是拦截页面 |

## 结论
小红书的反爬是 **headless 检测**级别的，不是 IP 归属地问题（上海桌面也被拦）。唯一可行方案：用户已打开的非 headless 浏览器（如 360ChromeX）配合手动操作（F12 → Console → `copy(document.body.innerText)`）。
