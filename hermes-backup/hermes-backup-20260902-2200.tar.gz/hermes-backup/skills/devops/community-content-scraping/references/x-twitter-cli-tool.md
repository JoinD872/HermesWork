# X/Twitter CLI Tool (xurl)

For X/Twitter **operations** (posting, replying, searching, liking, DM, media upload), use `xurl`:

```bash
# Post a tweet
xurl tweet "Hello world"

# Search
xurl search "from:elonmusk"

# Like a tweet
xurl like TWEET_ID

# Upload media
xurl media upload image.jpg
```

Requires X API Bearer Token. This complements the X/Twitter **scraping** endpoints
covered in `references/x-internal-api.md`.
