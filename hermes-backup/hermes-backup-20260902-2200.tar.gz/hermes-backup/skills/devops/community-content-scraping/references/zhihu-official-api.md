# 知乎官方 API — 接入记录

## 注册信息

- **平台**: developer.zhihu.com（知乎数据开放平台）
- **注册时间**: 2026-05-20
- **Access Secret**: 存于 `.env` 的 `ZHIHU_ACCESS_SECRET`
- **免费额度**: 每天 1000 次搜索 / 10 次热榜

## 已验证的接口

### 1. 知乎搜索 API

```bash
GET https://developer.zhihu.com/api/v1/content/zhihu_search
```

参数：
| 参数 | 类型 | 必填 | 说明 |
|------|------|:----:|------|
| Query | String | 是 | 搜索关键词 |
| Count | Int32 | 否 | 默认 10，最大 10 |

2026-05-20 实测结果：搜索"虚幻引擎5"返回了 3 条相关结果，包含标题、作者、赞同数、评论数、摘要等信息。返回数据质量高，可直接用于早报。

### 2. 知乎热榜 API

```bash
GET https://api/v1/content/hot_list
```

无参数，固定返回 30 条热榜内容。2026-05-20 实测成功返回 30 条热榜数据。

### 3. 全网搜索 API

```bash
GET https://developer.zhihu.com/api/v1/content/global_search
```

参数同知乎搜索。尚未实测。

### 4. 直答 API

Agent 对话式查询接口。尚未实测。

## 请求头（所有接口通用）

```bash
-H "Authorization: Bearer $ZHIHU_ACCESS_SECRET"
-H "X-Request-Timestamp: $(date +%s)"     # 秒级Unix时间戳，必填
-H "Content-Type: application/json"
```

## 响应格式

```json
{
  "Code": 0,
  "Message": "success",
  "Data": { ... }
}
```

成功 Code=0。Token 过期或无效返回 20001。

### 搜索响应 Items 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| Title | String | 内容标题 |
| ContentType | String | 内容类型（Article/Answer/Question） |
| ContentID | String | 内容标识 |
| ContentText | String | 内容摘要 |
| Url | String | 内容链接（含 utm 溯源参数） |
| CommentCount | Int32 | 评论数 |
| VoteUpCount | Int32 | 赞同数 |
| AuthorName | String | 作者昵称 |
| AuthorAvatar | String | 作者头像 URL |
| AuthorBadge | String | 作者认证图标 |
| AuthorBadgeText | String | 作者认证文案 |
| EditTime | Int32 | 发布时间戳 |
| AuthorityLevel | String | 权威等级（如 "2"） |
| RankingScore | Float32 | 排序分数 |
| CommentInfoList | Array | 精选评论列表 |

### 热榜响应 Items 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| Title | String | 问题标题 |
| Url | String | 问题链接 |
| ThumbnailUrl | String | 缩略图 |
| Summary | String | 内容摘要 |

## 错误码

| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| 10001 | 参数错误 |
| 20001 | 鉴权失败（Token 无效/过期） |
| 30001 | 频率限制 |
| 90001 | 内部错误 |

## 集成方式

目前通过 curl 直接调用。后续可考虑：
1. 配置为 Hermes MCP server（知乎已支持 MCP 协议）
2. 直接替换小研每日早报中的 SearXNG 知乎搜索步骤
3. 作为热榜监控的独立 cron 任务源

## 注意事项

- `X-Request-Timestamp` 必须传**秒级** Unix 时间戳，不能是毫秒
- 每天 1000 次搜索免费，超过后可能收费或被限流
- 知乎搜索的 Count 最大为 10，不支持分页（HasMore 固定 false）
- 搜索 API 返回的 URL 带 utm 溯源参数，不影响跳转
