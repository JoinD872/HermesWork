# V2EX 解析降级技术

## 背景

V2EX 首页是服务端渲染 HTML (https://www.v2ex.com/)，通过 curl 直接获取约 120KB。页面结构稳定，但 LLM 的 HTML 解析行为有**非确定性**——同一条指令有时能解析、有时不能。

## 已验证的三级降级模式

### 第1级：CSS 选择器提取（优先）
```bash
curl -sS -L --max-time 20 -o /tmp/v2ex.html -A "Mozilla/5.0" https://www.v2ex.com/
grep -oP 'item_title.*?href="\K/t/[0-9]+' /tmp/v2ex.html
```
实测结果：约 **50 条**话题链接

### 第2级：正则 fallback（CSS 失效时）
```bash
grep -Eo 'href="/t/[0-9]+"' /tmp/v2ex.html | sort -u
```
实测结果：约 **10 条**唯一链接（注意排序后数量可能少于 CSS，因为去重了）

### 第3级：debug 保存（极端失败）
```bash
if [ $(grep -c '/t/[0-9]' /tmp/v2ex.html) -lt 3 ]; then
  head -c 2000 /tmp/v2ex.html > /tmp/v2ex_debug.html
  echo "🟡 V2EX 解析结果偏少，已保存 debug"
fi
```

## 推荐逻辑伪码

```python
topics = parse_v2ex_by_css_selector(html)  # 第1级
if len(topics) < 5:
    topics = parse_v2ex_by_regex_fallback(html)  # 第2级
if len(topics) < 3:
    save_debug_html("v2ex", html[:2000])
    mark_yellow("V2EX 解析结果偏少，已保存 debug")

# 稳定字段提取（标题 + 链接已够用）
for link in topics[:20]:
    # 从 link 前后文取标题：<a href="/t/12345">标题文本</a>
    title = extract_title_around_link(html, link)
    yield {"url": f"https://v2ex.com{link}", "title": title}
```

## 注意事项

- **从不标 🔴**，最多标 🟡
- 标题提取失败不影响链接提取——即使只有链接没标题，也算成功
- `/t/` 链接格式已稳定多年，正则 fallback 非常可靠
