# crawl4ai Reddit 绕过方案 — 2026-05-26 实测

## 适用场景
VPS IP（192.3.241.244）被 Reddit 网络策略封锁时，用 crawl4ai 的 Playwright 浏览器后端绕过。

## 安装
```bash
python3 -m venv /root/.crawl4ai-venv
/root/.crawl4ai-venv/bin/pip install -U crawl4ai
/root/.crawl4ai-venv/bin/crawl4ai-setup
```

## 使用助手脚本（推荐）
```bash
/root/.crawl4ai-venv/bin/python /root/.hermes/scripts/crawl4ai_reddit.py <subreddit> [limit=5]
# 输出: JSON 数组，title/score/comments/author/url/selftext
```

## Python 集成
```python
from crawl4ai import AsyncWebCrawler, CrawlerRunConfig, CacheMode
import re, json

async def fetch(subreddit, limit=5):
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(
            url=f"https://www.reddit.com/r/{subreddit}/hot/.json?limit={limit}",
            config=CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
        )
    m = re.search(r"```(?:json)?\s*(.*?)```", result.markdown, re.DOTALL)
    return json.loads(m.group(1)) if m else None
```

## 已验证子版（均 ~1.1s）
r/unrealengine, r/VPS, r/LocalLLaMA, r/MachineLearning

## 局限性
- ❌ 新版 Reddit HTML（Cloudflare challenge）
- ❌ nitter.net / 小红书（传输层封锁）
- ✅ old.reddit.com HTML（~18K chars）
- ✅ JSON API 最稳定，推荐优先用

## 要点
- 基础模式即可绕过，不需要 magic/stealth
- JSON 被 markdown 代码块包裹，提取时需 strip 反引号
- 每次调用独立上下文，用完即释放，不常驻
