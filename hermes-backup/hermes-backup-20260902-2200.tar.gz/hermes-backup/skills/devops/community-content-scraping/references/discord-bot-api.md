# Discord Bot API 使用说明

## 凭据

Bot Token 存于 `/root/.hermes/credentials/social_scraper.json`

当前环境（大佬）：
- Bot 名：总管
- Bot ID：1492859994977075281
- 服务器 ID：1492858402060107787
- 服务器名：总管

## 频道列表

| 频道 | ID | 用途 |
|------|-----|------|
| #总管 | 1492858402504708217 | 日常对话 |
| #常规（语音） | 1492858402504708218 | 语音频道 |
| #任务看板 | 1492919523698020442 | 定时任务状态 |
| #ue5助手 | 1492919591108870174 | UE5 问题解答 |

## 可用端点

### 获取 Bot 自身信息
```bash
curl -s "https://discord.com/api/v10/users/@me" \
  -H "Authorization: Bot $TOKEN"
```

### 读取频道消息（最后 N 条）
```bash
curl -s "https://discord.com/api/v10/channels/$CHANNEL_ID/messages?limit=5" \
  -H "Authorization: Bot $TOKEN"
```

### 发送消息
```bash
curl -s -X POST "https://discord.com/api/v10/channels/$CHANNEL_ID/messages" \
  -H "Authorization: Bot $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"content":"消息内容"}'
```

## 消息响应结构

```json
[
  {
    "id": "消息ID",
    "channel_id": "频道ID",
    "author": {
      "id": "用户ID",
      "username": "用户名",
      "bot": true/false
    },
    "content": "消息文本内容",
    "timestamp": "2026-05-18T22:34:44.000+00:00",
    "mentions": [...]
  }
]
```

## 注意事项

- Bot Token 格式：`MTQ5...MQ.GAPEAn.VZI...`（3段，点分隔）
- 请求头必须带 `Authorization: Bot <token>`（注意 `Bot ` 前缀不能丢）
- 限制：只能读取 Bot 已加入的服务器/频道
- 消息列表按时间倒序（最新的在前）
