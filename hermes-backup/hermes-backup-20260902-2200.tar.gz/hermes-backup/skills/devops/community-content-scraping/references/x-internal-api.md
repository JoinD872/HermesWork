# X/Twitter 内部 API 使用细节

## 已验证可用的端点

### 首页 Timeline

**请求：**
```bash
curl -s --connect-timeout 10 --max-time 20 "https://x.com/i/api/2/timeline/home.json?count=10" \
  -H "Authorization: Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA" \
  -H "x-csrf-token: $ct0" \
  -H "x-twitter-auth-type: OAuth2Session" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -H "Cookie: auth_token=$auth_token; ct0=$ct0" \
  -H "Origin: https://x.com" \
  -H "Referer: https://x.com/"
```

**参数：**
- `count=N` — 返回 N 条推文（已验证 10〜20 条正常）

**响应结构：**
```json
{
  "globalObjects": {
    "tweets": {
      "1234567890": {
        "created_at": "Sun May 17 14:42:49 +0000 2026",
        "id_str": "1234567890",
        "text": "推文内容...",
        "full_text": "完整推文内容...",
        "user_id_str": "987654321",
        "retweet_count": 322,
        "favorite_count": 1171,
        "entities": {
          "urls": [{"url": "...", "expanded_url": "..."}]
        }
      }
    },
    "users": {
      "987654321": {
        "id_str": "987654321",
        "screen_name": "用户名",
        "name": "显示名"
      }
    }
  },
  "timeline": {
    "instructions": [
      {
        "addEntries": {
          "entries": [...]
        }
      }
    ]
  }
}
```

**提取推文：**
```python
tweets = data['globalObjects']['tweets']
users = data['globalObjects']['users']
for tid, t in tweets.items():
    uid = t['user_id_str']
    user = users[uid]
    screen_name = user['screen_name']
    text = t.get('full_text', t.get('text', ''))
    rt = t['retweet_count']
    fav = t['favorite_count']
```

## 已验证不可用的端点

| 端点 | 返回 | 原因 |
|------|------|------|
| `api.twitter.com/2/tweets/search/recent` | 403 Client Forbidden | 需注册开发者账号 |
| `x.com/i/api/graphql/*/HomeTimeline` | "Query not found" | QueryID 频繁变更 |
| `x.com/i/api/1.1/search/tweets.json` | 34 page not found | 不再支持 |
| `x.com/i/api/2/search/adaptive.json` | 空响应 | 搜索接口受限 |
| `x.com/i/api/2/search/typeahead.json` | 空响应 | 搜索接口受限 |
| `x.com/i/api/2/guide.json` | 空响应 | 趋势接口受限 |

## Bearer Token 说明

此为 X 网页版公开 Bearer Token，所有浏览器端用户共用：
```
AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA
```

不需要用户单独提供，但必须配合 `auth_token` + `ct0` 使用。

## 凭据过期处理

`auth_token` 和 `ct0` 不定期过期。用户发现 X 抓取失败时：
1. 在 x.com 重新登录
2. F12 → Application → Cookies → x.com
3. 复制新的 `auth_token` 和 `ct0`
4. 更新 /root/.hermes/credentials/social_scraper.json
