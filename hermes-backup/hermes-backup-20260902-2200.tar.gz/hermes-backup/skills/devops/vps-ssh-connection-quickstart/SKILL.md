---
name: vps-ssh-connection-quickstart
description: VPS SSH 连接快速起步 — 连接前必读 SOUL.md 获取正确端口（2222），避免无效重试
tags: [vps, ssh, connection, quickstart]
category: devops
risk: read-safe
---

# VPS SSH 连接快速起步

## 触发条件
连接 VPS（192.3.241.244）之前必须先执行此流程。

## 标准连接步骤

### 1. 先读 SOUL.md 获取连接参数
```bash
cat ~/.hermes/profiles/vps-technician/SOUL.md | grep -E "SSH|端口|IP"
```
**必须确认：SSH 端口（2222，不是默认 22）**

### 2. 直接用正确端口连接
```bash
ssh -o StrictHostKeyChecking=no -o ConnectTimeout=15 -p 2222 root@192.3.241.244
```

### 3. 如果连接被拒绝（Connection refused）
- 先 ping 确认宿主机存活：`ping -c 3 -W 3 192.3.241.244`
- 再读 SOUL.md 查真实端口
- **不要反复用 22 重试**，这是浪费时间

## 已知连接参数（来自 SOUL.md）
| 参数 | 值 |
|------|-----|
| VPS 公网 IP | 192.3.241.244 |
| SSH 端口 | **2222** |
| Xray 端口 | 8081 |
| nginx 端口 | 8080 |
| 机房 | 洛杉矶 RackNerd / HostPapa |

## 为什么不能直接用 22
这是 RackNerd 常见配置：SSH 改为非标准端口 2222 以减少暴力破解。22 端口 connection refused 不代表机器挂了。

## 快速验证连接
```bash
ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 -p 2222 root@192.3.241.244 'echo alive'
```
