# 2026-08-05 华为平板住宅出口实装全过程

## 背景
VPS 192.3.241.244（RackNerd/HostPapa 洛杉矶，ASN 36352 ColoCrossing）在 Spamhaus ZEN + CBL 双黑名单。
用户想提高 IP 信誉，实测确认是段级连坐 + 前任租户遗产，非用户行为。
方案：借家里闲置华为平板（家宽住宅 IP）当出口。

## 诊断链（按踩坑顺序）

### 1. 确认 VPS IP 黑名单（公共 DNS 交叉验证）
```bash
for bl in zen.spamhaus.org cbl.abuseat.org; do
  dig +short @1.1.1.1 "244.241.3.192.$bl" A
done
# zen.spamhaus.org → 127.255.255.254 (列入)
# cbl.abuseat.org → 127.255.255.254 (列入)
```

### 2. VPS 侧准备（路线 A）
- SSH 2222 端口转发默认允许（AllowTcpForwarding 注释状态 = yes）
- 10808 端口空闲
- 生成平板专用密钥（推荐平板本地生成，私钥不出设备）
- 授权时踩坑：`permitlisten="127.0.0.1:10808"` 导致 `remote port forwarding failed for listen port 10808`
  - 原因：ssh -R 不带绑定地址时，客户端请求的绑定与精确 permitlisten 不匹配
  - 修复：`permitlisten="10808"`（允许任意回环地址绑 10808）

### 3. 路线 A 失败记录
- Termux 装 openssh + microsocks + termux-api
- 平板开着 v2rayN → **所有流量（含 SSH 隧道本身）被劫持**，VPS 日志显示 `Accepted publickey for root from 192.3.241.244`（源 IP = VPS 自己）
- 隧道"通"（10808 被 sshd 监听）但出口永远是 VPS IP
- 关掉 v2rayN → 平板直连 VPS 公网 IP **被阻断**（ping 100% 丢包，ssh timeout）
- 结论：路线 A 需要家宽直连 VPS 通，本环境不通 → 放弃

### 4. 路线 B：Tailscale + ssh -D（成功）
- 华为平板无 GMS → 从 GitHub releases 下载 universal APK 侧载（95MB）
- Tailscale 登录用 "Email me a code"（不需要 Google 账号）
- 平板拿到 100.78.214.117（设备名 mrx-w19，华为 MatePad 系列代号 MRX）
- VPS 侧 `tailscale status` 看到新设备，`tailscale ping` 验证双向连通
- 平板 Termux 启动 sshd（8022），VPS 公钥加入平板 authorized_keys
- VPS 侧建动态转发：
```bash
ssh -i /root/.ssh/id_ed25519 -N -D 10808 -o StrictHostKeyChecking=accept-new \
    -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -o ExitOnForwardFailure=yes \
    u0_a154@100.78.214.117 -p 8022
```
- 验证成功：`curl --socks5-hostname 127.0.0.1:10808 https://ifconfig.me` → `180.164.97.180`（家宽 IP）

### 5. 稳定性问题：Android 后台冻结
- 隧道首次测通后，用户切走/锁屏 → SSH 连接 ESTAB 但数据不流动
- `ss -tnp` 显示 Send-Q 持续积压（568 → 804 字节），sshd 进程还在但不处理数据
- 直接 SSH 平板执行命令正常（说明 sshd 活着）但 `curl` 从平板出网失败
- 判断：华为系统 SIGSTOP 冻结 Termux 后台进程
- 修复：电池优化白名单 + 应用启动管理手动 + termux-wake-lock + 插电亮屏

### 6. 收尾发现：HTTPS 443 vs HTTP 80
- HTTP 出站通（180.164.97.180），HTTPS 443 超时
- 平板自身 `curl https://api.ipify.org` 也失败 → 不是隧道问题，是平板出网环境
- 疑似 Tailscale exit node 设置劫持 443 → 待用户检查 exit node = None

### 7. Tailscale App 华为连接失败 + CLI 兜底
- 华为平板 Tailscale App 登录成功（邮箱验证码）但 **"Not connected"，点 Connect 无响应**
- 检查 Tailscale App → 显示 Not connected 需重新 Connect；点了没反应 = App 在无 GMS 设备上不稳定
- **兜底方案（CLI 版）**：
  ```bash
  pkg install -y tailscale
  termux-wake-lock; tailscaled --tun=userspace-networking --socks5-server=127.0.0.1:1055 &
  sleep 2; tailscale up   # 打印 login.tailscale.com/a/xxx 授权 URL
  ```

### 8. ssh.cloudjoind.com 隧道入口存在但 DNS 缺失
- JoinD 隧道 ingress 已配置 `ssh.cloudjoind.com → https://localhost:22`（docker logs 可确认）
- 但 **DNS 无 A 记录**（`dig +short ssh.cloudjoind.com A` 为空）→ 入口实际不可用
- 对比：proxy.cloudjoind.com 有 A 记录（104.21.84.119 / 172.67.191.241）
- 想加 DNS 记录时发现：`/root/.hermes/.cf_credentials` 里 cfat_ token **只有 Workers 权限，无 DNS 权限**（API 返回 Authentication error）→ 加 DNS 需要用户去 Cloudflare 面板手动操作
- 教训：JoinD 配置了 ingress ≠ 域名可用，必须先 dig 验证 DNS 记录存在

## 经验总结
- **方案验证成功**：VPS → Tailscale → 平板 sshd → 家宽出口，架构可行
- **两条路线选择关键**：家宽能否直连 VPS 公网 IP（ping 测试）
- **华为系设备无 GMS 不影响 Tailscale**（APK 侧载 + 邮箱验证码）
- **Android VPN App 与住宅出口互斥**：v2rayN/NekoBox 会劫持隧道流量
