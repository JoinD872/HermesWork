# -*- coding: utf-8 -*-
"""
冒险岛怀旧服 自动喝药工具 v1.0
================================
原理：屏幕像素颜色检测 HP/MP 条比例，低于阈值时模拟按键喝药。
不读内存、不注入、不改游戏文件 —— 等同物理外设宏，风险最低。

用法:
    python auto_potion.py            # 加载 config.json 正常运行
    python auto_potion.py --scan     # 自动扫描屏幕找 HP/MP 条位置, 写入 config
    python auto_potion.py --manual   # 手动校准: 按提示点击条的两端

热键:
    F9   暂停 / 继续
    F11  退出程序

依赖: pip install mss numpy pydirectinput pywin32
"""

import ctypes
import ctypes.wintypes
import json
import os
import sys
import time

try:
    import mss
    import numpy as np
    import pydirectinput
except ImportError as e:
    print("[错误] 缺少依赖: %s" % e)
    print("请先运行: pip install mss numpy pydirectinput pywin32")
    input("按回车退出...")
    sys.exit(1)

# Windows API
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
VK_F9 = 0x78
VK_F11 = 0x7A

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

DEFAULT_CONFIG = {
    "hp_threshold": 40,       # HP 低于此百分比(0-100)喝红药
    "mp_threshold": 30,       # MP 低于此百分比喝蓝药
    "hp_key": "f1",           # 红药快捷键
    "mp_key": "f2",           # 蓝药快捷键
    "interval": 0.3,          # 检测间隔(秒)
    "cooldown": 1.2,          # 喝药后冷却(秒)
    "max_attempts": 6,        # 连续按 N 次比例仍不回升 -> 蜂鸣报警
    "hp_bar": None,           # [x1, y1, x2, y2] 屏幕坐标, --scan 自动写入
    "mp_bar": None,           # [x1, y1, x2, y2]
    "game_process": [         # 游戏进程名(前台保护用)
        "MapleStory.exe", "MapleStoryV.exe", "MapleStoryC.exe",
        "MapleStoryGMS.exe", "MapleStory.exe.old"
    ],
    "beep_alert": True
}


# ---------------- 基础工具 ----------------

def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        merged = dict(DEFAULT_CONFIG)
        merged.update(cfg)
        return merged
    return dict(DEFAULT_CONFIG)


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=4)
    print("[配置] 已写入 %s" % CONFIG_PATH)


def key_down(vk):
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)


def beep(times=3):
    try:
        for _ in range(times):
            ctypes.windll.kernel32.Beep(880, 300)
            time.sleep(0.25)
    except Exception:
        pass


# ---------------- 颜色检测 ----------------

def make_masks(region):
    """region: HxWx3 numpy uint8 -> (hp_mask, mp_mask) 布尔矩阵"""
    R = region[:, :, 0].astype(np.int16)
    G = region[:, :, 1].astype(np.int16)
    B = region[:, :, 2].astype(np.int16)
    hp_mask = (R > 80) & (R - G > 40) & (R - B > 40)
    mp_mask = (B > 80) & (B - R > 40) & (B - G > 25)
    return hp_mask, mp_mask


def measure_bar(sct, bar, kind):
    """bar=[x1,y1,x2,y2]; kind='hp'|'mp'; 返回 0.0~1.0 填充比例, 异常返回 None"""
    x1, y1, x2, y2 = bar
    if x2 - x1 < 5 or y2 - y1 < 5:
        return None
    try:
        shot = sct.grab({"left": x1, "top": y1, "width": x2 - x1, "height": y2 - y1})
        arr = np.array(shot)[:, :, :3]
    except Exception:
        return None
    if arr.size == 0:
        return None
    hp_mask, mp_mask = make_masks(arr)
    mask = hp_mask if kind == "hp" else mp_mask
    return float(mask.mean())


# ---------------- 自动扫描校准 ----------------

def find_bar(sct, kind, search_region):
    """在搜索区域内找最宽的横条。kind='hp'/'mp'。返回 [x1,y1,x2,y2] 或 None"""
    img = np.array(sct.grab(sct.monitors[1]))[:, :, :3]
    h, w = img.shape[:2]
    x1, y1, x2, y2 = search_region
    sub = img[y1:y2, x1:x2]
    hp_mask, mp_mask = make_masks(sub)
    mask = hp_mask if kind == "hp" else mp_mask

    row_sum = mask.sum(axis=1)
    # 找行投影连续段
    rows = []
    i = 0
    n = len(row_sum)
    while i < n:
        if row_sum[i] > 5:
            j = i
            while j < n and row_sum[j] > 5:
                j += 1
            rows.append((i, j))
            i = j
        else:
            i += 1

    best = None
    best_area = 0
    for r1, r2 in rows:
        rh = r2 - r1
        if rh < 4 or rh > 60:          # 条高度合理范围
            continue
        sub_mask = mask[r1:r2, :]
        col_sum = sub_mask.sum(axis=0)
        cols = []
        i = 0
        m = len(col_sum)
        while i < m:
            if col_sum[i] > 3:
                j = i
                while j < m and col_sum[j] > 3:
                    j += 1
                cols.append((i, j))
                i = j
            else:
                i += 1
        for c1, c2 in cols:
            cw = c2 - c1
            if cw < 80:                # 条宽度下限
                continue
            area = cw * rh
            if area > best_area and cw > rh * 2.5:   # 长条形状约束
                best_area = area
                best = [x1 + c1, y1 + r1, x1 + c2, y1 + r2]
    return best


def auto_scan():
    print("=" * 50)
    print("自动扫描模式: 请先把 HP/MP 回满(红色/蓝色填充要明显, 血条别是空的)")
    print("按回车开始扫描... (游戏窗口请保持在前台)")
    input()
    with mss.mss() as sct:
        mon = sct.monitors[1]
        sw, sh = mon["width"], mon["height"]
        # 搜索范围: 整屏下半部分(血条通常在屏幕下部)
        search = (0, sh // 3, sw, sh)
        print("[扫描] 屏幕 %dx%d, 搜索下半屏..." % (sw, sh))
        hp = find_bar(sct, "hp", search)
        mp = find_bar(sct, "mp", search)
    if hp:
        print("[结果] HP 条: %s" % hp)
    else:
        print("[结果] 未找到 HP 条! 试试 --manual 手动校准")
    if mp:
        print("[结果] MP 条: %s" % mp)
    else:
        print("[结果] 未找到 MP 条! 试试 --manual 手动校准")
    if hp or mp:
        cfg = load_config()
        if hp:
            cfg["hp_bar"] = hp
        if mp:
            cfg["mp_bar"] = mp
        save_config(cfg)
        print("[提示] 如果坐标明显不对, 请手动改 config.json 或跑 --manual")
    else:
        print("[提示] 扫描失败, 请确认: 游戏窗口化可见 / 血条在屏幕下半部分 / 未开滤镜")
    print("=" * 50)


# ---------------- 手动校准 ----------------

def get_cursor_pos():
    pt = ctypes.wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y


def manual_calibrate():
    print("=" * 50)
    print("手动校准模式")
    print("步骤: 鼠标移到条的最左端 -> 按回车记录起点; 移到最右端 -> 按回车记录终点")
    cfg = load_config()
    for kind, key in (("HP", "hp"), ("MP", "mp")):
        print("\n--- %s 条 ---" % kind)
        print("把鼠标移到 %s 条【左端】(填充部分开始处), 然后按回车:" % kind)
        input()
        x1, y1 = get_cursor_pos()
        print("已记录起点 (%d, %d). 现在移到 %s 条【右端】, 按回车:" % (x1, y1, kind))
        input()
        x2, y2 = get_cursor_pos()
        if x2 < x1:
            x1, x2 = x2, x1
        # 高度上下各扩 6px, 保证盖住整条
        bar = [x1, y1 - 6, x2, y2 + 6]
        print("  %s 条坐标: %s" % (kind, bar))
        cfg[key + "_bar"] = bar
    save_config(cfg)
    print("校准完成! 运行 python auto_potion.py 开始自动喝药")
    print("=" * 50)


# ---------------- 游戏窗口前台保护 ----------------

def enum_windows():
    """返回 [hwnd, ...] 顶层可见窗口"""
    result = []
    EnumWindowsProc = ctypes.WINFUNCTYPE(
        ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p
    )
    user32.EnumWindows(EnumWindowsProc(lambda h, l: (result.append(h) or True)), 0)
    out = []
    buf = ctypes.create_unicode_buffer(512)
    for h in result:
        if user32.IsWindowVisible(h):
            user32.GetWindowTextW(h, buf, 512)
            out.append((h, buf.value))
    return out


def find_game_window(process_names):
    """按进程名找游戏主窗口句柄; 找不到返回 None"""
    try:
        process_names = [p.lower() for p in process_names]
        hwnds = enum_windows()
        for hwnd, _ in hwnds:
            pid = ctypes.c_ulong()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value:
                hproc = kernel32.OpenProcess(0x1000, False, pid.value)  # PROCESS_QUERY_LIMITED_INFORMATION
                if hproc:
                    exe = ctypes.create_unicode_buffer(512)
                    size = ctypes.c_ulong(512)
                    kernel32.QueryFullProcessImageNameW(hproc, 0, exe, ctypes.byref(size))
                    kernel32.CloseHandle(hproc)
                    name = os.path.basename(exe.value).lower()
                    if name in process_names:
                        return hwnd
    except Exception:
        return None
    return None


# ---------------- 主循环 ----------------

def run(cfg):
    if not cfg.get("hp_bar") and not cfg.get("mp_bar"):
        print("[警告] 还没有血条坐标! 先运行: python auto_potion.py --scan")
        input("按回车退出...")
        return

    game_hwnd = find_game_window(cfg.get("game_process", []))
    if game_hwnd:
        print("[前台保护] 已锁定游戏窗口, 切出去会自动暂停按键")
    else:
        print("[警告] 未找到游戏进程窗口(%s), 前台保护关闭。"
              "全屏模式可继续, 窗口模式请在 config.json 的 game_process 加进程名"
              % ", ".join(cfg.get("game_process", [])))

    paused = False
    last_print = 0
    hp_count = mp_count = 0
    hp_attempt = mp_attempt = 0
    last_hp = last_mp = 0

    print("=" * 50)
    print("自动喝药已启动")
    print("  阈值: HP<%d%% 按 %s | MP<%d%% 按 %s" % (
        cfg["hp_threshold"], cfg["hp_key"], cfg["mp_threshold"], cfg["mp_key"]))
    print("  热键: F9 暂停/继续 | F11 退出")
    print("=" * 50)

    with mss.mss() as sct:
        while True:
            if key_down(VK_F11):
                print("[退出] 再见!")
                break
            if key_down(VK_F9):
                paused = not paused
                print("[%s] %s" % ("暂停" if paused else "继续",
                                   "按 F9 继续" if paused else ""))
                time.sleep(0.4)

            if paused:
                time.sleep(0.15)
                continue

            now = time.time()

            # --- HP ---
            if cfg.get("hp_bar"):
                hp_ratio = measure_bar(sct, cfg["hp_bar"], "hp")
                if hp_ratio is not None and hp_ratio * 100 < cfg["hp_threshold"] \
                        and now - last_hp > cfg["cooldown"]:
                    pydirectinput.press(cfg["hp_key"])
                    last_hp = now
                    hp_count += 1
                    hp_attempt += 1
                    print("[喝药] HP=%.0f%% -> 按 %s (第%d次)" % (
                        hp_ratio * 100, cfg["hp_key"], hp_attempt))
                elif hp_ratio is not None and hp_ratio * 100 >= cfg["hp_threshold"]:
                    hp_attempt = 0

            # --- MP ---
            if cfg.get("mp_bar"):
                mp_ratio = measure_bar(sct, cfg["mp_bar"], "mp")
                if mp_ratio is not None and mp_ratio * 100 < cfg["mp_threshold"] \
                        and now - last_mp > cfg["cooldown"]:
                    pydirectinput.press(cfg["mp_key"])
                    last_mp = now
                    mp_count += 1
                    mp_attempt += 1
                    print("[喝药] MP=%.0f%% -> 按 %s (第%d次)" % (
                        mp_ratio * 100, cfg["mp_key"], mp_attempt))
                elif mp_ratio is not None and mp_ratio * 100 >= cfg["mp_threshold"]:
                    mp_attempt = 0

            # --- 报警: 连按无回升 = 药水用完 ---
            if hp_attempt >= cfg["max_attempts"]:
                print("[警告] HP 连按 %d 次未回升! 可能药水用完了" % hp_attempt)
                if cfg.get("beep_alert"):
                    beep()
                hp_attempt = 0
            if mp_attempt >= cfg["max_attempts"]:
                print("[警告] MP 连按 %d 次未回升! 可能药水用完了" % mp_attempt)
                if cfg.get("beep_alert"):
                    beep()
                mp_attempt = 0

            # --- 状态显示(每2秒) ---
            if now - last_print > 2:
                hp_s = "%.0f%%" % (hp_ratio * 100) if cfg.get("hp_bar") else "n/a"
                mp_s = "%.0f%%" % (mp_ratio * 100) if cfg.get("mp_bar") else "n/a"
                print("  [状态] HP:%s MP:%s | 已按键 HP x%d MP x%d%s" % (
                    hp_s, mp_s, hp_count, mp_count, " (暂停)" if paused else ""))
                last_print = now

            time.sleep(cfg.get("interval", 0.3))


def main():
    if sys.platform != "win32":
        print("[错误] 本工具只支持 Windows。")
        sys.exit(1)
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    args = sys.argv[1:]
    if "--scan" in args:
        auto_scan()
    elif "--manual" in args:
        manual_calibrate()
    else:
        cfg = load_config()
        run(cfg)


if __name__ == "__main__":
    main()
