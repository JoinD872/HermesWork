---
name: windows-game-automation
description: Windows 游戏自动化工具设计（像素检测+模拟按键）— 自动喝药/打怪/寻怪/寻路类挂机工具的技术选型、工具架构、血条校准流程、反作弊风险评估。适用于冒险岛等 2D MMORPG 及任何"看屏幕+按键盘"类自动化需求。
tags: [gaming, automation, windows, pixel-detection, maplestory]
category: devops
risk: write-safe
---

# Windows 游戏自动化（像素检测 + 模拟按键）

## 触发场景
- 用户要"自动喝药 / 自动打怪 / 挂机 / 宏"类游戏工具
- 需要评估"像素级 vs 内存读取"技术路线
- 需要校准屏幕坐标 / 血条位置 / 游戏窗口前台保护

## 核心决策框架：像素级 vs 内存级

一句话：**像素级 = 只能看屏幕的观察者；内存级 = 直接翻游戏记事本**（坐标/怪物列表/地图ID全在里面）。

| 能力 | 像素级(截图) | 内存级(读进程) |
|------|:---:|:---:|
| HP/MP 条 | ✅ 可靠 | ✅ 精确数值 |
| 打屏幕上的怪 | ✅ | ✅ |
| 怪的血量/坐标 | ❌ 靠猜 | ✅ |
| 自身坐标/地图 ID | ❌ | ✅ |
| 跨屏寻路 | ❌ | ✅ |
| 稳定性 | 特效/伤害数字/光影干扰 | 稳定 |

功能可行性（2D 横版 MMORPG，如冒险岛）：
- **自动喝药**：像素 ✅（血条是固定 UI，最可靠）
- **站桩打怪**：像素 ✅（范围攻击 = 走到怪旁 + 按攻击键，不需要精确点怪）
- **屏幕内寻怪**：像素 🟡（怪不在屏幕就无解；站桩挂机场景够用）
- **真·寻路**：像素 ❌（无自身坐标 + 看不到屏幕外地图结构，只能退化成死记硬背路径宏——被怪卡住/击退就乱套）；需内存读取 + 平台连接图 + A*

## 反作弊风险阶梯（决定路线的关键）
| 方案 | 原理 | 风险 |
|------|------|------|
| 纯像素(截图+按键) | 看屏幕 | **最低** — 不碰游戏进程，在反作弊(NP等)检测面外，等同物理宏 |
| 内存读取 RPM | OpenProcess+ReadProcessMemory | 中 — 可能被 NP 盯上 |
| 注入 DLL | 进游戏进程 | 高 |
| 封包伪造 | 改网络数据 | 最高 |

⚠️ 国服盛趣/NEXON 冒险岛标配 **NProtect GameGuard**（官方怀旧服 2026-07 官宣，盛趣代理）。像素方案完全绕开检测面；内存读取有真实封号风险，需用户知情。

## 分阶段建议（避免一步到位）
1. 自动喝药（像素，无风险）
2. **定点自动打怪**（像素，无风险）— 冒险岛挂机 90% 需求就这个
3. 小范围巡逻（像素 + 路径宏）
4. 真·寻路/自动任务（内存读取，高风险，除非跨图需求否则不做）

## 工具架构（参考实现：`templates/auto_potion.py`）
- 截图：`mss`（区域截图快，支持 grab region dict）
- 图像：`numpy`（颜色掩码布尔矩阵）
- 按键：`pydirectinput`（⚠️ 依赖 pywin32，requirements 要显式加）
- 热键：`ctypes.GetAsyncKeyState`（零依赖；F9=0x78, F11=0x7A）
- 前台保护：`EnumWindows + GetWindowThreadProcessId + QueryFullProcessImageNameW + GetForegroundWindow`
- 报警：`kernel32.Beep(880, 300)`

### 颜色检测核心（血条）
```
HP红条掩码: R>80 & (R-G)>40 & (R-B)>40
MP蓝条掩码: B>80 & (B-R)>40 & (B-G)>25
比例 = 掩码像素占比；低于阈值(如0.4)触发按键；冷却 1.2s 防连按
```

### 校准两种模式
- `--scan`：全屏截图 → 行投影找连续段 → 列投影找宽度 → 长条约束（宽>80px、高4~60px、宽>2.5倍高）→ 搜索区域限下半屏滤掉伤害数字
- `--manual`：GetCursorPos 鼠标点条两端（上下各扩 6px）

## Pitfalls
1. **校准前血条必须回满** — 低血量时红/蓝填充太少，自动扫描找不到条
2. **游戏必须窗口化** — 全屏独占 mss 截不到（或黑屏）
3. **Windows OpenSSH 会话限制** — sshd 进程在 session 0，截不到交互桌面的游戏画面；工具必须在用户交互会话前台运行，SSH 只用于部署/传文件，不能远程直接跑 GUI 工具
4. **pydirectinput 依赖 pywin32** — requirements 不写 pywin32 会在用户机器上 ImportError
5. Windows 控制台中文乱码：`sys.stdout.reconfigure(encoding='utf-8', errors='replace')` + run.bat 里 `chcp 65001`
6. 伤害数字/特效干扰扫描 — 限制搜索区域（下半屏）+ 长条形状约束滤掉
7. 模拟按键必须做**前台保护**：只在前台窗口是游戏进程时才发，否则切出去聊天会误按
8. 任何辅助都有被反作弊盯上的可能，交付时提示用户先小号验证

## 部署到 DaLao
- 目标路径：`E:\Hermes\auto-potion\`
- 连接方式见 `windows-tailscale-ssh-access` skill
- 用户在前台跑 `run.bat`（不能 SSH 远程直接跑）

## 支持文件
- `templates/auto_potion.py` — 完整可用参考实现（自动喝药 v1，含扫描/手动校准/运行三模式）
- `templates/config.json` — 配置模板（阈值/键位/坐标/游戏进程名）
- `templates/run.bat` — 一键启动（chcp 65001 + python）
- `references/maplestory-pixel-bot.md` — 冒险岛怀旧服会话细节（背景/已交付/待办/阶段2设计）
