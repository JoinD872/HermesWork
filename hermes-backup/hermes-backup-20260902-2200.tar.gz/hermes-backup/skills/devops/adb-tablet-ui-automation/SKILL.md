---
name: adb-tablet-ui-automation
description: 华为平板 ADB 无线接管 + UI 自动化 — USB 一次性授权、adbkey 跨机同步、VPS 经 Tailscale 无线 adb connect、uiautomator+input 注入真人手势。适用 mrx-w19 平板及同类 Android 设备的远程 UI 控制。
version: 1.0.0
created: 2026-08-06
tags: [adb, android, ui-automation, tablet, huawei, tailscale, remote-control]
risk: write-safe
---

# ADB 无线接管 + UI 自动化（华为平板）

## 触发条件

- 需要远程控制 Android 平板/手机的 UI 层（点击、滑动、输入）
- SSH 到 Termux 够不着 UI（Termux 无法模拟触摸）——必须走 ADB
- 目标：注入真人手势规避风控（小红书/知乎/贴吧等 App 正常使用）

## 关键环境（mrx-w19 华为 MatePad）

- 设备：MRX-W19，Android 12（SDK 31），HarmonyOS/EMUI 精简版
- Tailscale IP：100.78.214.117（VPS 走 Tailscale 内网访问，勿直连）
- **无「无线调试」选项**（华为精简 ROM）→ 必须 USB 一次性开启 `adb tcpip`
- 用户电脑 DaLao：100.108.175.15，SSH 用户 61915
- VPS adb 已装（/usr/bin/adb 1.0.41）

## 完整流程（一次性开通 + 日常使用）

### Phase 1 — 平板侧开发者选项（用户手动）

```
设置 → 系统与更新 → 开发人员选项
├── USB 调试                    ← 主开关，必须开（最关键）
└── "仅充电"模式下允许 ADB 调试 ← 仅充电模式连接时需要
```

坑：只开「仅充电」配套开关不开主开关 → ADB 接口不枚举，`adb devices` 空。

### Phase 2 — USB 授权 + 开无线端口（需要电脑）

```powershell
# 电脑装 platform-tools（DaLao 已装 C:\platform-tools\adb.exe）
curl.exe -L -o C:\platform-tools.zip https://dl.google.com/android/repository/platform-tools-latest-windows.zip
Expand-Archive -Path C:\platform-tools.zip -DestinationPath C:\ -Force

C:\platform-tools\adb.exe devices -l        # 设备出现 unauthorized → 平板弹窗点「允许」
C:\platform-tools\adb.exe tcpip 5555         # 开启无线调试端口
```

⚠️ 授权弹窗必须用户在平板上点「允许」（勾选「一律允许」）。

### Phase 3 — adbkey 同步到 VPS（关键！避免二次授权）

VPS 的 adb 用自己独立的 RSA key，直接 connect 会 `unauthorized` 且平板弹窗。
**把电脑已授权的 key 拷到 VPS**，指纹一致 → 免弹窗直连：

```bash
# 注意：Windows scp 路径必须用正斜杠，反斜杠会被 shell 转义吃掉
scp "61915@100.108.175.15:C:/Users/61915/.android/adbkey" /root/.android/adbkey
scp "61915@100.108.175.15:C:/Users/61915/.android/adbkey.pub" /root/.android/adbkey.pub
```

### Phase 4 — VPS 无线接管（日常使用）

```bash
adb kill-server && adb connect 100.78.214.117:5555
adb devices -l   # 期望：100.78.214.117:5555  device  product:MRX-W19
```

## UI 自动化核心命令

### 读取界面（不依赖视觉模型！）

```bash
# 抓 UI 层级树（文本+坐标）——核心手段，比截图+视觉快且精确
adb shell uiautomator dump /sdcard/ui.xml
adb shell cat /sdcard/ui.xml | grep -oE 'text="[^"]{1,40}"'
```

- 判断页面变化：`screencap` 两次 `md5sum` 对比（只看哈希不看图）
- 判断风控：UI 文本关键词（验证/滑块/登录）
- 找按钮坐标：UI 树里 `bounds="[x1,y1][x2,y2]"`

### 注入操作（全部真实触摸事件，App 无法区分真人）

```bash
adb shell input swipe X1 Y1 X2 Y2 [ms]    # 滑动（刷信息流：600 1600 → 600 500）
adb shell input tap X Y                    # 点击
adb shell input text "hello"               # 输入（中文需 ADBKeyboard）
adb shell input keyevent KEYCODE_HOME      # 按键
```

### 启动 App（组件名可能不是 MainActivity）

```bash
adb shell cmd package resolve-activity --brief com.xingin.xhs   # 查真实组件
adb shell am start -n com.xingin.xhs/.index.v2.IndexActivityV2  # 启动
# 或兜底：adb shell monkey -p com.xingin.xhs -c android.intent.category.LAUNCHER 1
```

已知组件：小红书 com.xingin.xhs/.index.v2.IndexActivityV2；知乎 com.zhihu.android

## 防冻结保活（华为系统会 SIGSTOP 杀后台）

症状：Termux sshd 8022 拒连、隧道断（tablet-tunnel 掉 10808）。

恢复（有 ADB 时）：
```bash
adb shell am start -n com.termux/.app.TermuxActivity   # 拉起 Termux 前台
# 等几秒，runsvdir 自动拉起 sshd + 重新持有 wake-lock
```

用户侧配置（一劳永逸）：
```
设置 → 应用 → Termux（及 Tailscale）
├── 电池 → 耗电保护 → 不限制
└── 启动管理 → 手动管理 → 自启动/关联启动/后台活动 全允许
```

## 已验证事实（2026-08-06 实测）

- VPS → Tailscale → adb connect 5555，全程无线，延迟 ~170ms（relay sfo）
- 小红书刷流 + 进详情页全通过，无风控滑块/验证码/强制登录
- 住宅 WiFi 直连（180.164.97.180）比隧道更稳；真实 App 客户端无浏览器指纹
- uiautomator dump 在 vision 模型不可用时完全够用（实测 vision 400 报错不影响流程）

## 已知坑

| 坑 | 现象 | 解决 |
|:---|:-----|:-----|
| ADB 接口不枚举 | devices 空，设备管理器只有 MTP+Mass Storage | 开 USB 调试主开关 + 重插 USB |
| adbkey 未同步 | connect 后 unauthorized，平板弹窗 | Phase 3 拷贝电脑 key 到 VPS |
| Windows scp 反斜杠 | No such file or directory | 路径用正斜杠 `C:/Users/...` |
| Windows 无 tail | `tail: invalid context` | 全用 PowerShell 处理 |
| pnputil 装 USB 驱动 | 签名验证失败（Authenticode） | 不用装，MTP 枚举自带驱动够用；ADB 接口出现后 Windows Update 自动装 |
| MainActivity 名错 | Error type 3 | resolve-activity 查真实组件 |
| uiautomator dump 失败 | 偶发 | 重试或先 `input keyevent KEYCODE_WAKEUP` |
| adb server 起不来 | 5037 拒绝 | `Get-Process adb | Stop-Process -Force` 后重启 |

## 关联

- vps-residential-ip-egress — 家宽出口隧道完整方案（本 skill 是它的 UI 控制补充）
- camoufox-install — 浏览器方案（无 ADB 时抓取兜底）
- 记忆：华为防冻结 SIGSTOP 曾致隧道断，adbd 同风险
