---
name: vps-domestic-zero-cost-bypass
description: 零成本绕过国内网站封锁 + IP 黑名单复活 — RSSHub 公共实例 / Cloudflare Workers / GitHub Actions / 官方 API 优先 / 黑名单移除路线图。当 VPS 数据中心 IP 被国内站（豆瓣/微博等）封禁时的完整行动方案。
tags: [vps, china, bypass, rsshub, cloudflare, blacklist, zero-cost]
version: 2026-08-02-v1
risk: read-only
---

# VPS 国内站零成本绕过 + 黑名单复活

## 适用场景
- 用户问"被封了如何零成本复活" / "怎么绕过国内网站封锁"
- VPS 直连国内站返回 000/403（豆瓣、微博 API 等）
- 需要在不花钱买住宅代理的前提下访问被风控的国内内容

> 互补关系：诊断"为什么封"看 `vps-domestic-site-access`（手动 skill）+ `vps-ip-reputation-check`（含自建工具 `/root/.hermes/scripts/ip_reputation.py`）；本文档只讲"封了以后怎么零成本继续用"。

## 核心原则
1. **先分层诊断，再选方案**：网络层封禁（000 稳定）→ 必须换通道；JS 层风控（200 但 browser 拦）→ 走 API/RSS。判断法：`curl -s -m 8 -o /dev/null -w "%{http_code}" <url>` 连测 5 次，000×5 = 网络层断；一次 000 一次 200 = DNS 轮询抖动
2. **优先官方 API**：知乎 ZHIHU_ACCESS_SECRET（每日 1000 次免费搜索）、B站公开 API（api.bilibili.com 直连通）——官方通道最稳，别绕
3. **零成本通道按顺序用**：RSSHub 公共实例 → Cloudflare Workers（绑定自有域名）→ GitHub Actions 免费算力

## 通道一：RSSHub 公共实例（首选，零部署，2026-08-02 实测）

原理：RSSHub 实例跑在第三方服务器，从它们 IP 抓国内站，VPS 只访问实例 = 完全绕开 VPS 自身 IP。

```bash
# 豆瓣正在上映（VPS 直连 000，经此 200 全通，含评分/导演/主演）
curl -s -A "Mozilla/5.0" "https://rsshub.ktachibana.party/douban/movie/playing"
# 豆瓣新书
curl -s -A "Mozilla/5.0" "https://rsshub.ktachibana.party/douban/book/latest"
```

| 实例 | 首页 | 豆瓣 route | 备注 |
|------|------|-----------|------|
| rsshub.ktachibana.party | ✅ 200 | ✅ 200 完整 | **首选** |
| rsshub.rssforever.com | ✅ 200 | ❌ 503 | 限流 |
| hub.slarker.me | ✅ 200 | ❌ 503 | 限流 |
| rsshub.woodland.cafe | ✅ 200 | 未测 | 备选 |
| rsshub.app | ❌ 403 | - | 官方实例反爬 |
| rsshub.feeded.xyz / tangwudi | ❌ 000 | - | 不可达 |

**坑：**
- 不同实例对不同 route 成功率不同（ktachibana 豆瓣 200 但微博 503；知乎热榜 429）→ **多实例轮询**
- 公共实例是共享资源，偶发查询够用；要稳定私有通道 → 通道二
- RSSHub route 列表：https://docs.rsshub.app/routes （github 有镜像）

## 通道二：Cloudflare Workers 免费反代（私有稳定，零成本）

### 免费额度（官方文档实测，2026-08）
| 限制项 | Free 计划 |
|--------|----------|
| 每日请求 | 100,000 次/天（UTC 重置） |
| CPU 时间 | 10 ms/请求（纯反代够；重 HTML 解析可能不够） |
| 内存 | 128 MB |
| 子请求 | 50/请求 |

**额度与域名无关**（账户级固定）。但**自定义域名有真实价值**：`workers.dev` 子域国内被墙，绑定自有域名后国内可直连。用户已有 cloudjoind.com 系域名可绑定。

### 项目
- **QImageLab/cf-proxy**（⭐186）— 零配置 HTTP/HTTPS 反代，适合代理 API
- **Mikotwa/reverse-proxy-cf**（⭐39）— Worker 变在线网页代理/镜像

**用量判断**：Hermes 日均 ~10 次 LLM 回复、~100 次请求级，即使放大 100 倍，离 10 万/天限额仍差一个数量级 → **免费额度余量 1000 倍+，放心用**。

## 通道三：GitHub Actions 免费算力
公开仓库 2000 分钟/月，runner 出口是 GitHub IP，可定时爬国内站后 push 仓库或回调。适合"每天定时抓一次"的场景。

## 黑名单复活路线图（治本）

### A. 让记录消失（免费）
| 方法 | 操作 | 时效 |
|------|------|------|
| 等自动过期 | CBL 行为性列入，滥用停止后 24h~几周自动移除；Spamhaus ZEN 几天内自动 delist。前提：VPS 无残留垃圾流量 | 几天~几周 |
| 自助提交移除 | `cbl.abuseat.org/lookup.cgi` 自助 delist 页（⚠️ 该站对数据中心 IP 直连 000，需从用户国内浏览器打开）；Spamhaus 有 delist 流程 | 1~3 天 |
| 联系 ISP | 工单给 HostPapa：误列 + 已停止滥用，要求提交移除申请或免费换 IP | 1~5 天 |

### B. 持续监控（确认"复活"）
建 cron 每天跑 `python3 /root/.hermes/scripts/ip_reputation.py <出口IP>`，黑名单记录消失那天通知用户。

## 明确不建议
**WARP 不当复活方案**：WARP 出口也是数据中心段，国内站照样可能封；warp 模式触发 Tailscale DNS 接管（用户只允许 proxy 模式）。治标还添乱。

## 关键教训（2026-08-02 实测）
1. 不要凭印象判断"连不上国内网"——实测后大部分站其实通（百度/B站/知乎/163/QQ/淘宝/抖音全 200），只有豆瓣整站 000 + 微博 API 403
2. 数据中心 IP 封禁状态会变，关键判断前现场重测，别用旧结论
3. 测 IP 信誉的第三方站（Scamalytics/AbuseIPDB/whatismyipaddress）全被 CF 拦截 → 用自建工具走 DNSBL + ipapi.is，见 `vps-ip-reputation-check`
