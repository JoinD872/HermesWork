---
name: vps-home-exit-node
description: VPS 借家庭设备住宅 IP 当出口（SSH 反向隧道 + microsocks）— 解决 VPS 数据中心 IP 黑名单/被拒、仅限国内 IP 的站。含 v2rayN 劫持排查、permitlisten 语法坑、常驻防杀配置
tags: [vps, network, reverse-tunnel, residential-ip, exit-node]
version: 2026-08-05
risk: write-safe
---

# VPS 家庭设备反向隧道出口

## 触发条件
- VPS 出口 IP 在黑名单（Spamhaus ZEN/CBL）导致访问被拒
- 需要访问仅限国内 IP 的站（bsedu 等）
- 用户有闲置安卓平板/手机可作常驻出口

## 一句话本质
借家里闲置设备的**住宅 IP**（家宽，不在任何黑名单）当 VPS 出口：
VPS 上只有**显式指定**走代理的流量经隧道跑到家庭设备，再从家宽出去。
不动 Tailscale/NekoBox，零 VpnService 冲突，对现有服务（Docker 隧道/Xray/Hermes）零影响。

## 架构
```
VPS(192.3.241.244) ──SSH反向隧道──► 家庭设备(家里WiFi住宅IP)
   │                                      │
   └─ 127.0.0.1:10808 = 设备出口        └─ microsocks 监听 127.0.0.1:10808
```
VPS 用法：`curl --socks5-hostname 127.0.0.1:10808 https://ifconfig.me`

## 实施步骤

### 1. VPS 侧（root@192.3.241.244:2222）
- 确认 10808 空闲：`ss -tlnp | grep 10808`
- 确认 sshd 允许转发（默认 yes，无覆盖即可）
- authorized_keys 加固（只允许 10808 反向转发，不能登录 shell）：
  ```
  no-agent-forwarding,no-X11-forwarding,no-pty,permitlisten="10808" ssh-ed25519 AAAA... 注释
  ```

### 2. 设备端（Termux，华为/安卓平板）
1. 装 Termux（F-Droid 或 GitHub releases，华为应用市场没有）
2. `pkg update && pkg install -y openssh microsocks termux-api`
3. 生成密钥，**公钥以文本粘贴形式发给 VPS 管理员**（私钥不出设备）：
   ```
   ssh-keygen -t ed25519 -N "" -f ~/.ssh/id_ed25519 && cat ~/.ssh/id_ed25519.pub
   ```
4. 一键拉起（先 killall 清残留，避免 Address already in use）：
   ```
   killall -9 microsocks ssh 2>/dev/null; sleep 1; microsocks -i 127.0.0.1 -p 10808 & sleep 1; ssh -N -R 10808:127.0.0.1:10808 -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -o ExitOnForwardFailure=yes -i ~/.ssh/id_ed25519 root@192.3.241.244 -p 2222
   ```
   卡住不动 = 成功。

### 3. 常驻防杀（华为/荣耀系统必做，锁屏才不掉线）
- 电池优化 → 不允许优化
- 应用启动管理 → 手动 → 允许自启动 + 后台活动
- WLAN → 已连接网络 → 始终连接
- Termux 内 `termux-wake-lock`（需 termux-api）
- 平板插电放家里

## 排查顺序（实战踩坑，按序执行）
1. VPS 侧看监听：`ss -tlnp | grep 10808` → 无监听 = 隧道没建立
2. 看认证记录：`journalctl -u ssh | grep Accepted` → 平板密钥是否认证成功
3. **出口 IP 显示 VPS 自己 = 设备上有代理劫持**（v2rayN/NekoBox 等）：
   设备开着 v2rayN 时，SSH 隧道和 microsocks 出网**全走代理**从 VPS 进出
   （sshd 日志里认证来源 IP 也是 VPS 自己），出口 IP 永远不变。
   必须**关掉设备上的 v2rayN**，让流量走家宽直连。
4. 关 v2rayN 后原 SSH 会话会断（Broken pipe）→ 重新 killall + 拉起
5. 直连被墙（ping 通但 2222 nc 超时）→ 改 Tailscale 内网方案（设备装 Tailscale 走 100.x 内网 IP 连 VPS）

## 关键坑位（每条都是真金白银）
1. **permitlisten 必须写 `"10808"`（不带绑定地址）**，不能写 `"127.0.0.1:10808"`：
   OpenSSH 对 `-R 10808:...`（不带 bind_address）的默认绑定与显式 127.0.0.1 不匹配，
   拒绝请求报 `Error: remote port forwarding failed for listen port 10808`，但**端口其实是空闲的**——别误判为端口被占。
2. **v2rayN 全流量劫持**：设备上的代理 App 不关，隧道再通出口 IP 也不变（就是 VPS 自己）。
   诊断信号：sshd 日志 Accepted 来源 = VPS 自己的 IP。
3. **microsocks 反复 `Address already in use`** = 旧进程残留，`pkill -f microsocks` 杀不干净，用 `killall -9`。
4. **公钥传递以用户粘贴文本为准**，不要依赖视觉 OCR（0/O、D0/DO 易错读，公钥错一个字符授权失败）。
5. 华为平板无 GMS：Tailscale/Google Play 安装受限，Termux 方案（F-Droid APK）是首选。

## 验证
- VPS：`curl --socks5-hostname 127.0.0.1:10808 https://ipinfo.io/json` → 出口应为家宽 IP（非 AS36352/HostPapa）
- 锁屏 30 分钟后重测仍通 = 常驻配置生效
