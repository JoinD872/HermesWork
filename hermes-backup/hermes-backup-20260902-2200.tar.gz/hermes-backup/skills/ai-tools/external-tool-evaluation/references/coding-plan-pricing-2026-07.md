# 国外 AI 编码计划定价快照（2026-07-29 调研）

> 用途：评估「国外 coding plan / API 订阅」时的数据底稿。价格会变，用前复核官网。
> 汇率基准：2026-07-29 xe.com 中间价 1 USD ≈ 6.77 CNY。

## 核心结论速览

- **OpenCode Go 已订阅（$10/月）包含大量模型**，但只有 V4 Flash / MiMo 系列额度宽松；V4 Pro / Grok 4.5 等高级模型额度低，不适合当主力。
- **IDE 计划（Cursor/Copilot IDE）≠ API Provider**，不能配进 Hermes。唯一例外：GitHub Models API（速率限制极低）。
- 国外 API 月订阅市场极小：主流（OpenAI/Anthropic/Google/xAI/DeepSeek/OpenRouter/Together/Fireworks/Groq）全是 PAYG 或限制多，OpenCode Go 是 $10 价位独一份。

## OpenCode Go（opencode.ai/go）— 用户已订阅

- $10/月（首月 $5），订阅制，OpenAI 兼容 base_url: `https://opencode.ai/zen/go/v1`
- 包含模型清单（2026-07 官网）：**Grok 4.5, GLM-5.2, GLM-5.1, Kimi K3, Kimi K2.7 Code, Kimi K2.6, MiMo-V2.5-Pro, MiMo-V2.5, Qwen3.7 Max, Qwen3.7 Plus, Qwen3.6 Plus, MiniMax M2.7, MiniMax M3, DeepSeek V4 Pro, DeepSeek V4 Flash, Hy3**
- ⚠️ 额度结构：flash/mimo 宽松，pro/grok 等其他模型额度低（"Kimi K3 限时 2×"促销暗示默认额度紧张）
- 另一个产品 OpenCode Zen：PAYG（充 $20 起步），非订阅

## DeepSeek 官方 API（api-docs.deepseek.com/quick_start/pricing）— PAYG

| 模型 | 输入 cache miss/1M | 输入 cache hit/1M | 输出/1M | 上下文 | 并发 |
|------|------|------|------|------|------|
| deepseek-v4-flash | $0.14 | $0.0028 | $0.28 | 1M | 2500 |
| deepseek-v4-pro | $0.435 | $0.003625 | $0.87 | 1M | 500 |

- 双 API 兼容：OpenAI `https://api.deepseek.com` + Anthropic `https://api.deepseek.com/anthropic`
- thinking 模式默认开启可切换；V4 Pro 是 flash 约 3 倍价
- 按用户月用量 ~$11 换算：V4 Pro 直连 ≈ $33/月

## xAI / SpaceXAI Grok 4.5（docs.x.ai/developers/pricing）— PAYG

- grok-4.5：短上下文(<200k) 输入 $2.00 / 缓存 $0.30 / 输出 $6.00 per 1M；长上下文(≥200k) 输入 $4.00 / 缓存 $0.60 / 输出 $12.00
- 上下文 500k；"flagship for code"，agentic tool calling、可配置 reasoning
- 速率：Tier0 默认 150 RPS / 50M TPM（按累计消费升档：$50/$250/$1000/$5000）
- 同量下比 V4 Flash 贵约 20 倍 → 不适合当 Hermes 主力

## GitHub Copilot / Models（github.com/features/copilot + docs.github.com/en/github-models）

- 个人计划：Free $0（2000 补全/月）/ Pro $10（$15 信用/月）/ Pro+ $39（$70 信用/月）/ Max $100（$200 信用/月）
- Pro 含第三方 agent（Claude Code/Codex）接入；Pro+ 含 Opus；Max 优先访问
- **GitHub Models API**：`https://models.github.ai/inference/chat/completions`，PAT + `models` scope，OpenAI 兼容
- ⚠️ 速率限制极低：免费/Pro 层普通模型 15 req/min、150 req/day；高级模型 5 req/day（→ 不适合 Hermes 主力）

## Cursor（cursor.com/pricing）— IDE，无对外 API

- 月付：Hobby Free / Pro $20 / Pro+ $60 / Ultra $200；Teams Standard $40/人 / Premium $120/人 / Enterprise 自定义
- 年付 = 月付 8 折：Pro $16、Pro+ $48、Ultra $160、Teams $32/$96（2026-07 无其他限时活动）
- 两个用量池：Cursor Models（Grok 4.5 + Composer 2.5，慷慨）+ Other Models（第三方，Pro 起含 ≥$20/月，按 API 价扣）
- 模型（2026-07）：Composer 2.5(200k)、Grok 4.5(256k)、Claude Sonnet5/Opus5/Fable5(200k/300k, max 1M)、Gemini 3.1 Pro/3.6 Flash(200k, max 1M)、GPT-5.6 Sol/Luna/Terra(272k)
- 文档要点：Pro = "extended limits on Agent"；Pro+ = 3x；Ultra = 20x + 优先新功能

## Devin（devin.ai/pricing）— 独立 agent，非 API

- Free / Pro $20（前沿模型 + SWE-1.7 + Cloud agents）/ Max $200 / Teams $80/人 / Enterprise 自定义

## Claude / Anthropic（claude.com/pricing）— 订阅不含 API

- Free / Pro $17-20（含 Claude Code、Cowork、Design、Science）/ Max $100（5x）/ Max $200（20x）
- ⚠️ 订阅是聊天产品，不含 API 调用；API 走 Console PAYG

## 其他查过：均 PAYG 无月订阅

- OpenRouter（openrouter.ai/pricing）：PAYG + 5.5% 平台费，400+ 模型；免费层 50 req/day
- Together AI / Fireworks / Groq / Mistral / Novita / AIMLAPI / Hugging Face Pro($9 推理积分)：全部按量计费
- HF Pro $9/月只是 HF 生态开源模型，无 deepseek/claude/gpt 闭源

## 推荐结论（2026-07-29 对当前用户）

1. 保持 OpenCode Go $10 主力 V4 Flash（性价比无敌、额度耐用）
2. 想升级编码能力 → DeepSeek 国际站直连 V4 Pro（PAYG ~$33/月，换 base_url 即可）
3. 想"国外公司" → DeepSeek 国际站 / OpenRouter PAYG；xAI Grok 太贵；Copilot 速率太低；Cursor 无 API
