# 三工具评估 — 2026-06-03

来源：X 帖子 GitTrend 推荐 5 个 GitHub Trending 项目，用户问"对你有帮助吗"

## 1. microsoft/markitdown (143K⭐)

**结论：观察（observe）**
- 强项：Office 文档（Word/Excel/PPT）→ Markdown 质量好
- 弱项：PDF 转换极弱（标题识别 0.000，表格保真度 0.273 基准测试垫底）
- AI 增强需要额外付费 API（Azure 或 OpenAI key）
- 轻量（251MB），MIT License
- 触发条件：遇到批量 Office 文档需要喂给 LLM 时

## 2. supermemoryai/supermemory (25K⭐)

**结论：否决（reject）**
- 远程云 API（TypeScript 主仓），非本地库
- Python SDK 是对 Cloud API 的瘦客户端
- 自托管仅对企业客户开放
- 隐私痛点：用户日记/记忆数据经第三方服务器
- 架构理念（混合搜索 + 关系版本化 + 时间戳双层体系）可借鉴，不接入

## 3. chopratejas/headroom (9K⭐)

**结论：试验（experiment）— 先装 proxy 测效果**

### 核心能力
- LLM 上下文压缩层，拦截工具输出 → 压缩 → 再发给 LLM
- 三阶段流水线：CacheAligner → ContentRouter → IntelligentContext
- 压缩率：JSON 90.6% / 构建日志 93.9% / shell 输出 85.5%
- 可逆压缩（CCR）：原数据存本地 LRU 缓存，LLM 通过 `headroom_retrieve` 工具按需检索
- 错误/异常 100% 保留

### 关键发现：收益被高估的地方
- **代码和 RAG 内容默认透传**（安全机制 `protect_analysis_context=True`）→ 不压缩
- 这意味着 Hermes 的 read_file/search_files 等核心工作负载不在此列
- 能压的是：terminal shell 输出、web_search JSON 结果
- 中位压缩率在短对话中仅 4.8%（因为短消息透传）

### 集成方式
- **代理模式（推荐，零代码变更）**：
  ```bash
  pip install "headroom-ai[proxy]" --break-system-packages
  headroom proxy --port 8787
  # 然后设 ANTHROPIC_BASE_URL=http://localhost:8787
  ```
- Python 库模式：`from headroom import compress`
- MCP 模式：`headroom mcp install`

### 本机验证
- VPS: 2.4GB RAM，安装后 1.0GB 可用
- proxy 启动内存：~93MB RSS
- 安装包包含 transformers (107MB) 但无 PyTorch（Kompress ML 压缩不可用，但不影响核心功能）
- 测试命令：`pip install "headroom-ai[proxy]" --break-system-packages`

### 风险点
- 单人维护（Tejas Chopra，5个月历史）
- 139 open issues（修正：实际约 77，来自 GitHub API）
- P99 延迟 4172ms（修正：需要确认数据来源）
- 已有社区 Hermes 支持请求（Issue #526）

### 试验路线
Phase 1（~1h）：装 proxy → 对比 token 消耗 → 测延迟
Phase 2（1-2天）：测兼容性 → crash 恢复 → CacheAligner 冲突
Phase 3：成功则固化 skill
