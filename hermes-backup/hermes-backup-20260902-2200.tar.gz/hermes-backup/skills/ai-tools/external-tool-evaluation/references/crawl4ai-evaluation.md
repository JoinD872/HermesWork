# Crawl4AI 评估记录（2026-05-26）

评估上下文：用户提供 GitHub 链接（unclecode/crawl4ai），要求评估是否对 Hermes 有用。

## 基本数据

| 指标 | 数值 |
|------|------|
| Stars | 66.4k（GitHub 爬虫类 #1） |
| Forks | 6.8k |
| 最新版本 | v0.8.6（安全热修复版） |
| License | Apache 2.0 |
| 依赖 | Playwright（浏览器后端，~200MB） |
| 安装 | `pip install -U crawl4ai` + `crawl4ai-setup` |

## 决策：试验（experiment）

仅作为 **curl 403 时的 Reddit fallback** 接入，不融入早报主流程。

## 实测结果

| 目标 | 结果 | 结论 |
|------|------|------|
| Reddit JSON API | ✅ 1.1s，4个子版均通 | 最有价值——之前curl死活403 |
| old.reddit.com | ✅ 2.1s，17K+ chars | 可用但数据不如JSON API干净 |
| 小红书 | ❌ Tencent EdgeOne网络层拦截 | 无法绕过 |
| nitter.net (X) | ❌ 结构检测阻止 | 无法绕过 |

## 最小接入方式

脚本：`/root/.hermes/scripts/crawl4ai_reddit.py`
用法：`/root/.crawl4ai-venv/bin/python crawl4ai_reddit.py <subreddit> [limit]`

早报中条件逻辑：curl Reddit 返回 403 时才调此 fallback。不增加常驻开销。

## 安全风险

v0.8.6 曾遭遇 litellm PyPI 供应链投毒事件（已替换为 unclecode-litellm）。
Chromium 进程需按需启动，不常驻。
