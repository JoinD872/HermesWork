# X 推文链接匿名读取 + GitHub/网站验证（2026-08-09 实测）

用户甩 `https://x.com/<user>/status/<tweet_id>` 链接问「有帮助吗/这是什么/靠谱吗」时的完整匿名验证流程。**不用任何账号凭据**——不触发 community-scraping 的 X 红线（账号凭据 API 仅限早报用，防封号）。

## 为什么走匿名 API

- 账号凭据（bearer_token/auth_token/ct0）是 community-scraping 红线，按需爬 X 禁用（防封号）
- fxtwitter/vxtwitter 是第三方转换 API，无凭据、VPS 直连可用、不消耗任何 X API 额度
- 返回已结构化的 JSON，直接能看互动量判断是否为推广贴

## 命令

```bash
# 主 API
curl -s -m 15 "https://api.fxtwitter.com/i/status/<tweet_id>"
# 备用 API（字段略不同）
curl -s -m 15 "https://api.vxtwitter.com/i/status/<tweet_id>"
```

## fxtwitter 返回结构要点

```json
{
  "code": 200,
  "tweet": {
    "text": "...",                 // 完整正文（含展开后的链接）
    "raw_text": {                  // 含 facets 数组，可拿 t.co 短链的真实 URL
      "facets": [{"type": "url", "indices": [...], "original": "...", "replacement": "https://github.com/..."}]
    },
    "author": {"name": "...", "screen_name": "...", "followers": 122500, "verified": true},
    "likes": 29, "retweets": 3, "replies": 17, "bookmarks": 27, "views": 4103,
    "created_at": "...", "lang": "zh"
  }
}
```

## vxtwitter 返回结构要点

```json
{
  "text": "...", "user_name": "...", "user_screen_name": "...",
  "likes": 967, "retweets": 172, "replies": 22,
  "mediaURLs": ["https://pbs.twimg.com/media/...png"],   // 图片/视频
  "date": "...", "lang": "zh"
}
```

## 推广贴识别技巧

互动量是核心判据：**高粉 + 低互动 = 广告/推广**。
- 案例 1：Agent-Reach 推文（1.5K 赞 / 2K 收藏 / 124K 浏览）→ 确实是 viral 项目，需查仓库验证
- 案例 2：fanqiang 推文（12.25 万粉，仅 29 赞 / 3 RT / 4103 浏览）→ 高粉低互动，推广痕迹重，内容仍可核实
- 注意：互动低 ≠ 内容假，只是更可能是推广；仓库验证说了算

## GitHub 仓库验证（推文安利开源项目时）

```bash
curl -s -m 20 "https://api.github.com/repos/<owner>/<repo>"
```

关键字段：`stargazers_count`、`forks_count`、`created_at` vs `pushed_at`（最近推送时间判断是否烂尾）、`license.spdx_id`、`description`、`language`。

后续验证步骤（按需）：
- README：`curl -s https://raw.githubusercontent.com/<owner>/<repo>/main/README.md`
- 仓库内容结构：`curl -s https://api.github.com/repos/<owner>/<repo>/contents/`
- 判断是否值得深读：stars 数量级 + 最近推送新鲜度 + README 质量 + 与现有能力对比

## 网站类推广验证（推文安利的是网站/服务时，2026-08-09 TG知道 案例）

推文推广的不是 GitHub repo 而是网站（如导航站/工具站）时，验证链路：

1. **t.co 短链解包**：`curl -s -o /dev/null -w "%{url_effective}" -L "https://t.co/<code>"` —— 注意 X 可能把短链重定向回原推文（TG知道 案例就是这样），此时用 DNS 探测候选域名 + 图内网址识别兜底
2. **DNS/域名探测**：`python3 -c "import socket; socket.gethostbyname('<candidate>')"` 试候选域名
3. **curl 首页验证**：
   ```bash
   curl -s -m 15 -L "<url>" -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" -o /tmp/page.html -w "HTTP %{http_code}"
   grep -o "<title>[^<]*</title>" /tmp/page.html   # title 对版？
   ```
4. **外链 + 灰词扫描**（判断是否钓鱼/引流/付费推广）：
   ```bash
   python3 - <<'EOF'
   import re
   html = open('/tmp/page.html', encoding='utf-8', errors='ignore').read()
   ext = [l for l in set(re.findall(r'href="(https?://[^"]+)"', html)) if '<domain>' not in l]
   print("外链数:", len(ext))          # 外链少 = 干净
   for kw in ['邀请码','返利','佣金','推广','充值','付费','钱包','USDT','广告']:
       if html.count(kw): print(f"[{kw}]: {html.count(kw)}次")
   EOF
   ```
   判据：外链 2-3 个以内且无灰词 = 干净；外链多/有返利充值词 = 引流站，警惕
5. **JS 渲染确认**：搜索页/内容页常是前端渲染，静态 curl 拿不到结果数据（TG知道 案例：`/search?q=AI` 返回 200 但无结果条目，只有导航模板）——这不代表功能坏，只说明需要浏览器验证
6. **作者可信度**：粉丝数 vs 互动比、账号创建时间、认证类型（蓝勾现在花钱可买，不构成背书）、简介风格

## 账号时间线抓取（用户问「这个号都发什么/有哪些对我们有用」时，2026-08-09 实测）

**评估整个账号**（如「看看鸟哥发布的东西」）需要拉近期推文，单推 API 不够。实测路线：

### 1. nitter 路线已死 — 不要浪费时间
nitter.net / nitter.privacyredirect.com / nitter.tiekoetter.com 等实例全部被 Cloudflare "Making sure you're not a bot!" 拦截（HTTP 200 但 0B 或 challenge 页），RSS 端点（`/user/rss`）同样被拦。**不要再探测 nitter 实例列表**。

### 2. vxtwitter 用户端点只给资料
```bash
curl -s "https://api.vxtwitter.com/<screen_name>"
```
只返回资料（粉丝数/简介/推文总数），**不含推文列表**。

### 3. camoufox headless 抓 x.com 用户主页（可行 ✅）
```python
from camoufox.async_api import AsyncCamoufox
async with AsyncCamoufox(headless=True) as browser:
    page = await browser.new_page()
    await page.goto(f"https://x.com/{screen_name}", timeout=45000, wait_until="domcontentloaded")
    await page.wait_for_timeout(5000)
    for i in range(6):            # 滚动触发懒加载，否则推文不出现
        await page.mouse.wheel(0, 3000)
        await page.wait_for_timeout(2000)
    html = await page.content()
    open("/tmp/x_profile.html", "w").write(html)   # 存盘后解析，比 page.evaluate 稳
```
**提取陷阱（实测踩坑）**：
- 游客视图页面里 `<article>` 元素存在（~28 个），但 `[data-testid="tweetText"]` 选择器 **0 命中**——X 改了结构，别用 tweetText
- 正确解析：`re.findall(r'<article[^>]*>(.*?)</article>', html)` → 剥离 HTML 标签 → 正则提取 `datetime` 时间戳 + 外链（过滤 x.com/twitter.com/t.co）
- 游客模式每次新建 profile 无登录态，安全；只能看到 ~8-9 条近期推文（含置顶），评估「这个号发什么」够用，全量历史不行
- 脚本化滚动 + 保存 HTML 再解析，比在 page.evaluate 里做 DOM 序列化更稳（曾遇 evaluate 返回空）

### 4. 账号内容画像判断（鸟哥 @NFTCPS 案例）
拉完时间线后按类型归组：币圈投机 / 网赚教程 / 工具安利 / AI 资源引流。对照用户已有能力逐个给价值：
- 币圈/网赚/返佣类 → 无价值（且镰刀属性）
- 工具安利 → 查是否与现有 skill 重复（HomeTube vs yt-dlp/youtube-content-extraction；mubeng vs 无代理池=需求不匹配）
- 高粉低互动 + 简介挂币安/OKX/收徒 → 推广带货号，信息密度低，不值得关注

## 案例总结

| 推文 | 项目 | 类型 | 结论 | 判据 |
|------|------|------|------|------|
| 2086033678472233247 (lumxss, 1.5K赞) | Agent-Reach (69.5K stars) | GitHub | 无新帮助——2026-07-13 已评估，三子能力已落地为 Hermes skill | 先查既往评估 references/agent-reach-evaluation.md |
| 2085974035561685293 (鸟哥, 29赞) | bannedbook/fanqiang (50.1K stars) | GitHub | 无帮助——小白向教程，用户是自建 VPS 生产者 | 对照用户已有能力（Xray/Tailscale/CF Tunnel 全套）|
| 2086387427657322734 (Suu, 227赞) | TG知道 (tgzhidao.com) | 网站 | 靠谱但对用户价值有限——TG 中文导航黄页，无钓鱼/引流外链，收录人工筛选 | 外链仅官方 TG 频道+CF 统计、无灰词；用户主力飞书 TG 是备用 |

## 决策原则

- **靠谱 ≠ 有用**：网站/项目本身真实安全，但对用户工作流零增量也要直说（用户是生产者不是目标用户）
- **已评估过就复用结论**：先扫本 skill 的 references/ 目录，同款工具不重复做桌面研究
- **结论要分开答**：「靠谱吗」答真实性，「有帮助吗」答对用户价值，两个问题不是同一个
