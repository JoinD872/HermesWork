---
name: minimax-image-gen-workflow
description: MiniMax 图片生成标准化工作流——理解图片→生成→发送飞书，含 img2img reference_image 参数正确用法
tags: [minimax, image-generation, img2img, workflow]
category: ai-tools
risk: write-safe
---

# MiniMax 图片生成标准化工作流

## 核心流程

```
第一步：用 mmx vision describe <图片路径> 看清参考图内容
    ↓ 绝对不能猜！不能凭记忆用！
第二步：构造 prompt + reference_image（base64）
第三步：response_format: base64 获取图片
第四步：上传 GitHub → 发飞书
```

---

## 第一步：理解参考图（必须先做）

**正确工具**：
```bash
mmx vision describe /path/to/image.png
```

**MCP `understand_image`（api.minimaxi.com）平台级 404 不可用**，`vision_analyze` tool 也读不到任何图片。MMX CLI 是唯一可靠途径。

**降级**：如果 MMX CLI 报 `exit_code=1, input sensitive`，降级到 `vision_analyze` tool。

---

## 第二步：构造生成请求

### 普通生成
```python
import requests, json, base64

with open('/root/.mmx/config.json') as f:
    KEY = json.load(f)['api_key']

url = 'https://api.minimaxi.com/v1/image_generation'
payload = {
    'model': 'image-01',
    'prompt': '英文描述...',
    'response_format': 'base64',
    'aspect_ratio': '1:1'  # 可选
}
r = requests.post(url, headers={'Authorization': f'Bearer {KEY}'}, json=payload, timeout=120)
img_bytes = base64.b64decode(r.json()['data']['image_base64'][0])
```

### img2img（reference_image）
```python
with open('ref_a.png', 'rb') as f:
    ref_a = base64.b64encode(f.read()).decode()
with open('ref_b.png', 'rb') as f:
    ref_b = base64.b64encode(f.read()).decode()

payload = {
    'model': 'image-01',
    'prompt': '描述：图A决定角色外观，图B决定姿势',
    'reference_image': [ref_a, ref_b],  # base64 数组，按顺序起作用
    'response_format': 'base64'
}
```

### 关键参数
- `model`：只用 `image-01`（`image-01-live` 不支持 base64）
- `response_format: base64`：绕过阿里云 OSS URL 从 VPS 不可访问的问题
- `reference_image`：base64 数组，最多支持多张参考图

---

## 第三步：保存结果
```python
with open('/root/.hermes/image_cache/output.png', 'wb') as f:
    f.write(img_bytes)
```

---

## 第四步：发飞书群

```python
import requests, json, urllib.request, uuid

# GitHub upload first
import base64
with open('/root/.git-credentials', 'r') as f:
    token = f.read().strip().split('://')[1].split('@')[0]
headers = {'Authorization': f'token {token}', 'Accept': 'application/vnd.github.v3+json'}
path = '/root/.hermes/image_cache/output.png'
with open(path, 'rb') as f:
    content = base64.b64encode(f.read()).decode()
url = 'https://api.github.com/repos/JoinD872/HermesWork/contents/sucai/output.png'
r = requests.get(url, headers=headers, timeout=10)
sha = r.json().get('sha') if r.status_code == 200 else None
data = {'message': 'Upload', 'content': content}
if sha: data['sha'] = sha
r = requests.put(url, headers=headers, json=data, timeout=30)

# Feishu
with open('/root/.hermes/.env') as f:
    env = dict(line.strip().split('=', 1) for line in f if '=' in line and not line.startswith('#'))
app_id, app_secret = env['FEISHU_APP_ID'], env['FEISHU_APP_SECRET']
req = urllib.request.Request(
    "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    data=json.dumps({"app_id": app_id, "app_secret": app_secret}).encode(),
    headers={"Content-Type": "application/json"}, method="POST"
)
with urllib.request.urlopen(req, timeout=30) as resp:
    tenant_token = json.loads(resp.read())["tenant_access_token"]

boundary = uuid.uuid4().hex
body = (
    f"--{boundary}\r\nContent-Disposition: form-data; name=\"image_type\"\r\n\r\nmessage\r\n"
    f"--{boundary}\r\nContent-Disposition: form-data; name=\"image\"; filename=\"output.png\"\r\nContent-Type: image/png\r\n\r\n"
).encode() + open(path, 'rb').read() + f"\r\n--{boundary}--\r\n".encode()
req2 = urllib.request.Request("https://open.feishu.cn/open-apis/im/v1/images", data=body,
    headers={"Authorization": f"Bearer {tenant_token}", "Content-Type": f"multipart/form-data; boundary={boundary}"},
    method="POST")
with urllib.request.urlopen(req2, timeout=30) as resp:
    image_key = json.loads(resp.read())["data"]["image_key"]

payload = json.dumps({
    "receive_id": 'oc_5a883cbe523b1a93ee269bba2f8536a0',
    "msg_type": "image",
    "content": json.dumps({"image_key": image_key})
}).encode()
req3 = urllib.request.Request(
    "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id", data=payload,
    headers={"Authorization": f"Bearer {tenant_token}", "Content-Type": "application/json"}, method="POST")
with urllib.request.urlopen(req3, timeout=30) as resp:
    result = json.loads(resp.read())
    print('✅' if result.get('code') == 0 else result)
```

---

## 常见错误

| 错误 | 原因 | 解决 |
|------|------|------|
| `Network request failed (HTTP 200)` | VPS 无法访问阿里云 OSS | 改用 `response_format: base64` |
| `image-01-live does not support base64` | live 模型不支持 base64 | 改用 `image-01` |
| 生成的图姿势/形象不对 | prompt 嵌 URL 效果差 | 改用 `reference_image: [base64...]` 参数 |
| vision 工具读不到图片 | MCP `understand_image` 平台级 404 | 用 `mmx vision describe <路径>` |
| img2img 效果不佳 | 多张参考图同时传可能混淆 | 分步：先只传姿势图确认构图，再叠角色形象 |

---

## 经验教训（2026-05-08）

**绝对不能猜参考图内容**。必须先用 `mmx vision describe` 看清楚再用于 prompt。

2026-05-08 教训：凭记忆描述参考图 → 姿势理解错误（把"剑横脸前"当成"双后举手剑"）→ 连续生成失败多轮 → 浪费时间。

正确流程永远是：**看图 → 描述确认 → 生成 → 反馈 → 调整**。
