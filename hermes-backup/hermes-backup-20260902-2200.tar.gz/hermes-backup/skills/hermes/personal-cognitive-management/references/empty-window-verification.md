# 空窗口三连确认（state.db 直查）

2026-08-07 归档 2026-08-06 时验证：`daily_archive_search.py` 只打印了会话头
（`20260803_094226_fef6628f` 幼儿园床垫选购指南, msgs=83）却没有 `[HH:MM]` 消息行——
会话跨窗口但窗口内 0 条 user 消息。以下直查用于把「无内容」从「日期选错/查错库」中区分出来。

## ① 窗口内该 chat_id 所有角色消息数（排除「日期选错」嫌疑）

```python
import sqlite3, datetime
DB='/root/.hermes/state.db'
TZ=datetime.timezone(datetime.timedelta(hours=8))
start=int(datetime.datetime(2026,8,6,tzinfo=TZ).timestamp())
end=start+86400
conn=sqlite3.connect(DB); cur=conn.cursor()
cur.execute("""SELECT COUNT(*) FROM messages m JOIN sessions s ON m.session_id=s.id
  WHERE s.chat_id='oc_ec9adb3139cd38ac706cd7a54c4d059d' AND m.timestamp>=? AND m.timestamp<?""",(start,end))
print("朵朵群窗口内所有角色消息数:", cur.fetchone()[0])
```

## ② 窗口内 user 消息按 chat_id 分布（排除「内容在别的频道」）

```python
cur.execute("""SELECT s.chat_id, s.chat_type, COUNT(*) FROM messages m
  JOIN sessions s ON m.session_id=s.id
  WHERE m.timestamp>=? AND m.timestamp<? AND m.role='user'
  GROUP BY s.chat_id ORDER BY COUNT(*) DESC LIMIT 20""",(start,end))
```

判读（2026-08-06 实测分布）：
- default DM `oc_8391fa2b38acbd759ff75ab3616d5d1f`（517 条）→ 平板/ADB/网络技术话题，不属于朵朵职责
- VPS 群 `oc_cc9c8289c9520ff326578703ff17392c`（1 条）→ 技术话题，不归档
- 朵朵群 0 条 → 无个人认知内容

## ③ profile 是否有独立 DB（排除「查错库」嫌疑）

```bash
ls /root/.hermes/profiles/duoduo/            # 无 state.db
ls /root/.hermes/profiles/duoduo/sessions/   # 空
```

朵朵数据在主库 state.db 按 chat_id=`oc_ec9adb3139cd38ac706cd7a54c4d059d` 存，无独立库；
主库 sessions 表的 profile_name 列对朵朵会话为 None（default）。

## 结论

三连确认全空 → 无内容 → 输出 `[SILENT]`，不写 Draft、不通知。
