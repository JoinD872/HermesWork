# 每日归档 — state.db 直接检索法（2026-07-31 归档 7/30 对话时验证）

归档 cron 只靠 session_search 关键词搜索有盲区：FTS 靠关键词命中，关键词没覆盖就漏；
返回的 session id 是短前缀，直接 scroll 报 `around_message_id not in session_id`；
且无法按 chat_id 过滤。改为直接查库后，一步覆盖窗口内全部会话，判断更完整。

## 数据源

- DB 路径：`/root/.hermes/state.db`（SQLite）。服务器上无 sqlite3 CLI，用 python3 内置 sqlite3 模块
- `sessions` 表：`id`（完整 id 带随机后缀，如 `20260729_173742_bc739f06`）、`chat_id`、
  `chat_type`（group/dm）、`started_at`、`ended_at`（NULL=未结束）、`message_count`、`title`、`profile_name`
- `messages` 表：`session_id`（完整 id）、`role`（user/assistant/tool/session_meta）、`content`、`timestamp`（epoch 秒）

## 检索步骤（scripts/daily_archive_search.py 已封装）

1. 北京时间日期 → epoch 窗口：`start = 该日00:00(UTC+8)`，`end = start + 86400`，查询用 `>= start AND < end`
   （例：2026-07-30 北京时间 = epoch 1785340800 ~ 1785427200）
2. 找窗口内活跃的会话：`WHERE started_at < end AND (ended_at IS NULL OR ended_at > start)`
3. 按 chat_id 过滤（朵朵群 `oc_ec9adb3139cd38ac706cd7a54c4d059d`）；chat_id 为 NULL 的是 cron/内部会话，跳过
4. 逐个会话拉 `role='user'` 的消息——只看用户说了什么来判断价值，assistant 回复不用读
5. 已知 chat_id 参考：朵朵群 `oc_ec9adb...`；DM（小H 身份）`oc_8391fa2b38acbd759ff75ab3616d5d1f`

## 关键坑

| 坑 | 说明 |
|---|---|
| session id 短前缀 | session_search 返回 `20260729_173742_bc73`，DB 里是 `20260729_173742_bc739f06`。按返回 id 查库时用 LIKE 前缀匹配 |
| scroll 报错 | `around_message_id` 必须用完整 id 且确实在该会话内，否则报 `not in session_id` |
| 时区 | timestamp 是 epoch 秒（UTC），换算北京时间 +8h；会话名里的时间是 UTC |
| 归档范围 | 只归档朵朵群对话；DM 里纯技术内容（API/模型/Hermes/VPS/游戏）不记，但可扫一眼确认无个人话题混入 |
| cron 会话 | `cron_*` 开头、chat_id 为 NULL 的 session 不是用户对话，跳过 |

## 判断标准（沿用技能正文）

技术讨论（API 套餐/模型对比/Hermes 配置/VPS/游戏设计）一律不记；只有认知、情绪、家庭、育儿、
生活状态变化、明确的观点立场才值得写 Draft。即使当天全天只有技术对话，也直接 [SILENT] 跳过。
