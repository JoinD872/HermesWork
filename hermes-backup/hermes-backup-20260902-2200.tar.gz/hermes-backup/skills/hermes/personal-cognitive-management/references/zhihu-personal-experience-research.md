# 知乎 API 个人经验文章检索 — 使用记录

## 背景

2026-07-18，用户问「有没有详细成功的案例和我讲讲吧，最好是有权威性的」。在搜索引擎全被封的情况下，使用知乎 API 找到了完全符合用户情况的个人经验文章。

## 结果

搜索词：`坚持早睡30天身体会发生什么变化`

找到文章：《坚持早睡30天,身体到底会发生什么变化?》
作者：湖中小船
作息：凌晨1点睡、早上7点起（与用户完全一致）
链接：https://zhuanlan.zhihu.com/p/2060079887013172035

## API 端点

```python
import os, urllib.request, json, time

token = os.environ.get('ZHIHU_ACCESS_SECRET', '')
# 备用：从 .env 文件读取
if not token:
    with open('/root/.hermes/.env') as f:
        for line in f:
            if line.startswith('ZHIHU_ACCESS_SECRET='):
                token = line.strip().split('=', 1)[1]

query = urllib.request.quote('搜索词')
url = f'https://developer.zhihu.com/api/v1/content/zhihu_search?Query={query}&Count=5'
req = urllib.request.Request(url)
req.add_header('Authorization', f'Bearer {token}')
req.add_header('X-Request-Timestamp', str(int(time.time())))

resp = urllib.request.urlopen(req, timeout=10)
data = json.loads(resp.read())
```

## 响应结构

```json
{
  "Code": 0,
  "Message": "success",
  "Data": {
    "HasMore": false,
    "Items": [
      {
        "Title": "文章标题",
        "ContentType": "Article",
        "ContentID": "数字ID",
        "ContentText": "摘要/片段（注意：非全文，约200-500字）",
        "Url": "完整链接",
        "CommentCount": 0,
        "VoteUpCount": 0,
        "AuthorName": "",
        "EditTime": 1782222250
      }
    ]
  }
}
```

## 关键发现

1. **ContentText 字段返回的是摘要而非全文** — 但足够让用户决定是否要打开链接读全文
2. **AuthorName 有时为空** — 但不影响内容检索
3. **搜索效果很好** — 对于「个人经验分享」类内容，知乎比其他平台更适合中文用户
4. **API 确实稳定可用** — 免费 1000次/天，这个搜索场景用不掉多少

## 适用场景

- 用户问「有没有人成功过」「有案例吗」
- 要展示真实普通人（而非专家/医生）的成功经验
- 搜索词建议用用户自己的语言描述，不用学术术语

## ⚠️ 注意

- 不要在 cron prompt 中直接用 `$ZHIHU_ACCESS_SECRET` shell 变量（会被 tirith 改写）
- 必须用 Python `os.environ.get()` 或 `source /root/.hermes/.env` 再引用
