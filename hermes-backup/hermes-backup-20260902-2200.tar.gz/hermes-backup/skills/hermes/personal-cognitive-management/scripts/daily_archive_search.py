#!/usr/bin/env python3
"""朵朵每日归档 — 按北京时间日期窗口检索 Hermes state.db 中的用户消息。

用法:
    python3 daily_archive_search.py 2026-07-30 [chat_id]

参数:
    date_str : 北京时间日期 YYYY-MM-DD（归档该日 00:00-23:59 的消息）
    chat_id  : 可选，只显示指定 chat 的会话
               朵朵群: oc_ec9adb3139cd38ac706cd7a54c4d059d
               不传则显示窗口内所有非 cron 会话（DM 也要扫一眼确认无个人话题）

数据源: /root/.hermes/state.db
  - sessions 表: id(完整带后缀), chat_id, chat_type, started_at, ended_at, title, message_count
  - messages 表: session_id(完整), role, content, timestamp(epoch 秒, UTC)

背景: 2026-07-31 验证 —— session_search 关键词法有盲区（FTS 命中依赖关键词、
返回短前缀 id 无法 scroll、不能按 chat_id 过滤），直查 state.db 更完整可靠。
"""
import sqlite3
import sys
import datetime

DB = '/root/.hermes/state.db'
TZ = datetime.timezone(datetime.timedelta(hours=8))  # 北京时间 = UTC+8


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    date_str = sys.argv[1]
    chat_filter = sys.argv[2] if len(sys.argv) > 2 else None

    d0 = datetime.datetime.strptime(date_str, '%Y-%m-%d').replace(tzinfo=TZ)
    start = int(d0.timestamp())
    end = start + 86400  # 次日 00:00，查询用 >= start AND < end 包住全天

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute(
        """SELECT id, chat_id, chat_type, title, started_at, ended_at, message_count, profile_name
           FROM sessions
           WHERE started_at < ? AND (ended_at IS NULL OR ended_at > ?)
           ORDER BY started_at""",
        (end, start),
    )
    sessions = cur.fetchall()
    for sid, chat_id, ctype, title, s, e, mc, prof in sessions:
        if chat_id is None:  # cron / 内部会话，跳过
            continue
        if chat_filter and chat_id != chat_filter:
            continue
        print(f"\n=== {sid} | chat={chat_id} ({ctype}) | {str(title)[:50]} | msgs={mc} ===")
        cur.execute(
            """SELECT role, content, timestamp FROM messages
               WHERE session_id=? AND timestamp >= ? AND timestamp < ? AND role='user'
               ORDER BY id""",
            (sid, start, end),
        )
        for role, content, t in cur.fetchall():
            hm = datetime.datetime.fromtimestamp(t, TZ).strftime('%H:%M')
            print(f"[{hm}] {str(content)[:300]}")
    conn.close()


if __name__ == '__main__':
    main()
