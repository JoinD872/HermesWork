# 反向联邦部署实例：朵朵 (duoduo)

部署日期：2026-07-28
**状态：已取消** — 用户反馈「我觉得你的方法不好，还是全部还原吧」，所有组件已清理。

## 教训

用户不需要自动化联邦管道。正确做法：
1. 朵朵的记忆里加一行「遇到技术问题告诉用户找小H」
2. 用户会自己在 default profile 提出需求
3. 不需要任何后台自动化

## 原计划（已取消，保留供参考）

### 1. pending/default/ 目录

```bash
mkdir -p ~/.hermes/federation/pending/default
```

### 2. 扫描脚本

路径：`~/.hermes/scripts/check-duoduo-pending.sh`

内容见本 skill 的 SKILL.md 中的「脚本实现参考」章节。不同 profile 可自定义脚本中的消息前缀。

### 3. Cron

```json
{
  "job_id": "4eb5e6ef62b5",
  "name": "朵朵派活扫描",
  "script": "check-duoduo-pending.sh",
  "no_agent": true,
  "schedule": "every 30m",
  "deliver": "origin"
}
```

### 4. 子 Agent MEMORY.md 追加内容

在 `~/.hermes/profiles/duoduo/memories/MEMORY.md` 末尾添加联邦协作章节（见 SKILL.md 中的「子 Agent 端配置」）。

### 5. 注意事项

- MEMORY.md 属于另一个 profile，写入时需加 `cross_profile=True`
- SOUL.md 通常不需要改——联邦协作写在 MEMORY.md 即可
- task_id 前缀：朵朵=DUODUO_，老V=VPS_，小策=GAME_，小健=HEALTH_
- no_agent cron 的 deliver 设为 "origin" 才会推到当前 profile 的 home channel
