# 飞书 API 直发 default Home 群 — 可复用脚本

> 2026-08-02 朵朵实测验证（message_id 返回 success）。子 Agent profile 向 default（小H）Home 群发消息的完整路径。

## 前置

- 凭据：Hermes 环境变量 `FEISHU_APP_ID` / `FEISHU_APP_SECRET`（在 `~/.hermes/.env`，用 `source ~/.hermes/.env` 载入）
- 目标：default 的 Home 群 chat_id = `oc_8391fa2b38acbd759ff75ab3616d5d1f`（与 config 中 `FEISHU_HOME_CHANNEL` 一致）

## 完整脚本（bash + python 构造 payload）

```bash
source ~/.hermes/.env 2>/dev/null
TOKEN=$(curl -s -m 10 -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d "{\"app_id\":\"$FEISHU_APP_ID\",\"app_secret\":\"$FEISHU_APP_SECRET\"}" \
  | python3 -c "import sys,json; print(json.load(sys.stdin).get('tenant_access_token',''))")
[ -z "$TOKEN" ] && echo "❌ token 获取失败" && exit 1

MSG='消息内容（支持中文和换行）'
python3 -c "
import json, sys
msg = '''$MSG'''
payload = json.dumps({
    'receive_id': 'oc_8391fa2b38acbd759ff75ab3616d5d1f',
    'msg_type': 'text',
    'content': json.dumps({'text': msg})
}, ensure_ascii=False)
print(payload)
" > /tmp/feishu_payload.json

curl -s -m 15 -X POST "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d @/tmp/feishu_payload.json \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print('code:', d.get('code'), '| msg:', d.get('msg')); print('message_id:', d.get('data',{}).get('message_id','') if d.get('data') else 'N/A')"
```

## 成功判定

- `code: 0` + `msg: success` + 返回 `message_id`（形如 `om_x100b...`）= 发送成功
- 非 0 code：检查 token 是否过期、chat_id 是否正确、机器人是否在该群

## 注意事项

1. **自发消息不触发 agent**：消息只会出现在群里，不会自动唤醒 default profile 的 agent 会话。需要用户在群里 @ 小H，或小H下次在该群被唤醒时读历史消息。
2. **消息可见性**：用户在群里也能看到这条消息（朵朵 → 小H 的反馈本来就是给用户看的内容，无妨）。
3. **payload 编码**：`content` 字段必须是 JSON 字符串（`json.dumps({'text': msg})`），不能直接放纯文本。
4. **中文**：`ensure_ascii=False` 保证中文正常；curl `-H "Content-Type: application/json; charset=utf-8"` 不可省。
5. **清理**：/tmp/feishu_payload.json 与 /tmp/feishu_token.txt 用完可删（含敏感 token）。

## 回执约定

小H处理后写 callback 到 `~/.hermes/federation/callbacks/{task_id}.json`（扁平结构，格式见主 SKILL.md），子 Agent 下次会话读取。
