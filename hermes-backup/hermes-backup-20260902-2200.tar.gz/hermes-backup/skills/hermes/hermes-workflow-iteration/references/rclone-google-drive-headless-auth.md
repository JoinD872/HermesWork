# rclone Google Drive Headless Auth 流程

## 场景

在无 GUI 的 VPS 上配置 rclone Google Drive remote，用于 Cloud Inbox 或备份。

## 标准流程

### Step 1: 安装 rclone

```bash
apt-get install -y rclone
# 或从 rclone.org 下载最新版
```

### Step 2: 创建 remote 配置（无 token 版）

```bash
rclone config create mydrive drive config_is_local=false
```
这行命令创建 remote 配置项但不触发 OAuth。需要在 VPS 上生成 `~/.config/rclone/rclone.conf`。

### Step 3: 触发 headless OAuth 流程

```bash
rclone config reconnect mydrive:
```

当出现提示 `Use auto config? (y/n)` 时：

- `y` = 自动打开浏览器（需要 GUI）
- `n` = headless 模式

选择 `n` 后，rclone 会提示：

```
Execute the following on the machine with the web browser (same rclone version recommended):
    rclone authorize "drive"
Then paste the result.
```

### Step 4: 获取授权 token

有两种方式：

**方式 A（目标机器有 rclone）**：在带浏览器的机器上运行：
```bash
rclone authorize "drive"
```
浏览器自动弹出 Google 登录页面 → 授权 → 终端显示 token JSON → 复制粘贴回 VPS。

**方式 B（目标机器无 rclone，不推荐）**：
1. 在 VPS 运行 `rclone authorize "drive"`，得到 URL（如 `http://127.0.0.1:53682/auth?...`）
2. 用户访问该 URL → Google OAuth 登录
3. 授权后 Google 重定向回 `127.0.0.1:53682`（用户本机）→ 失败
4. 用户从地址栏复制失败 URL 中的 `?code=...` 参数
5. 用该 code 手动构造 token

**方式 B 的局限性**：
- 重定向 URI 硬编码为 `http://127.0.0.1:53682/auth`，用户浏览器访问后重定向失败
- 需要用户在地址栏手动提取 code，体验差
- 推荐尽量用方式 A

### Step 5: 粘贴 token

在 `config_token>` 提示处粘贴上一步获得的完整 token JSON。

## 验证

```bash
rclone ls mydrive:
```

应列出 Google Drive 根目录的文件。

## 常见陷阱

| 陷阱 | 说明 | 解决 |
|------|------|------|
| `rclone authorize "drive"` 绑定 127.0.0.1 | VPS 上的端口用户无法直接访问 | 用方式 A（在用户机器上跑） |
| `rclone config create` 不触发 OAuth | 只创建配置骨架，不获取 token | 必须额外执行 `rclone config reconnect` |
| `--auth-no-open-browser` 只对 `authorize` 子命令有效 | `config reconnect` 不支持此 flag | 直接回答 `n` 进入 headless 模式 |
| 端口 53682 被占用 | 之前失败的 authorize 进程未清理 | `pkill -f "rclone authorize"` 后重试 |
| SSH 到 Windows 打不开浏览器 | SSH 会话运行在 session 0，无 GUI 权限 | 用户需手动在浏览器打开 `http://127.0.0.1:53682/auth?state=...` |
| SSH 超时杀进程 | `rclone authorize` 阻塞等待，超过 SSH timeout 后进程被 kill | 用 `start /b` 后台启动，输出重定向到文件，再轮询文件 |
