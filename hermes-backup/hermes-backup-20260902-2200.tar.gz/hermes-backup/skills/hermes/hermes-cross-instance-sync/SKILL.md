---
name: hermes-cross-instance-sync
description: 跨 Hermes 实例同步知识/配置 — 同步到子 profile（vps-technician/researcher 等）以及另一台 Windows 机器上的 Hermes（DaLao 桌面版，配置在 AppData\Local\hermes 而非 ~/.hermes）。当用户说「跟家里的 hermes 说一下 XX 配置」「把 XX 同步给其他 agent」时使用。
category: hermes
risk: write-safe
---

# Hermes 跨实例同步（profile 与 Windows 桌面版）

## 触发条件

- 用户说「跟家里的 hermes 说一下 XX 配置」（另一台 Windows 机器上的 Hermes 实例）
- 用户说「把 XX 同步给其他 agent/profile」（同机子 profile）
- 学到新知识/更新 skill 后需要同步给 vps-technician、researcher 等 profile（memory 里的既有协作规则）

## 同步给同机子 profile（快，符号链接/复制）

```bash
# 方式 A：符号链接（保持同步，推荐给技能目录）
cd ~/.hermes/profiles/<profile>/skills/
ln -s ../../../skills/<name> <name>

# 方式 B：复制文件（一次性）
cp ~/.hermes/skills/<name>/SKILL.md ~/.hermes/profiles/<profile>/skills/<name>/SKILL.md
```

注意：不要用复制覆盖符号链接目标；先确认 profile 目录结构（skills/<category>/<name>/ 两级 vs skills/<name>/ 单级）。

## 同步给 Windows 上的 Hermes（DaLao 实例）

### ⚠️ 关键：DaLao 的 Hermes 配置目录是 `C:\Users\61915\AppData\Local\hermes\`，不是 `~/.hermes`！

`%USERPROFILE%\.hermes` 只有散 Python 脚本（bilibili_final.py 等），**不是** Hermes 的 home，会误导。判据：
- `dir /b C:\Users\61915\AppData\Local\hermes` 里有 config.yaml/.env/cron → 该实例配好了
- 记忆文件：`C:\Users\61915\AppData\Local\hermes\memories\MEMORY.md`
- 桌面版 exe：`...\hermes-agent\apps\desktop\release\win-unpacked\Hermes.exe`
- 桌面快捷方式 `C:\Users\61915\OneDrive\Desktop\Hermes.lnk` 的 TargetPath 可解析出 exe 路径

### 写 UTF-8 中文到 Windows 记忆文件（实测可行流程）

```bash
# 1) 本机写内容 → scp 到 Windows（落盘 C:\tmp\，不是 ~/）
scp -i /root/.ssh/id_ed25519 /tmp/content.md 61915@100.108.175.15:/tmp/content.md

# 2) 备份原记忆
ssh -i /root/.ssh/id_ed25519 61915@100.108.175.15 "cmd /c \"copy C:\\Users\\61915\\AppData\\Local\\hermes\\memories\\MEMORY.md C:\\Users\\61915\\AppData\\Local\\hermes\\memories\\MEMORY.md.bak-before-sync\""

# 3) PowerShell 追加（-LiteralPath 防反斜杠转义；Add-Content -Encoding UTF8 实测可写对中文）
ssh -i /root/.ssh/id_ed25519 61915@100.108.175.15 "powershell -NoProfile -Command \"\$c = Get-Content -LiteralPath 'C:\tmp\content.md' -Raw -Encoding UTF8; Add-Content -LiteralPath 'C:\Users\61915\AppData\Local\hermes\memories\MEMORY.md' -Value ([Environment]::NewLine + [char]167 + [Environment]::NewLine + \$c) -Encoding UTF8\""

# 4) 验证必须用 PowerShell Select-String（cmd findstr 匹配不了 UTF-8 中文，会误报「没写入」）
ssh -i /root/.ssh/id_ed25519 61915@100.108.175.15 "powershell -NoProfile -Command \"Select-String -LiteralPath 'C:\Users\61915\AppData\Local\hermes\memories\MEMORY.md' -Pattern '100.78.214.117' | Select-Object -First 3\""
```

### 内容模板（设备/配置类）

```
§
## <设备名>远程访问配置（<型号>）<日期> 记录
- 设备：<型号>，<系统>
- Tailscale 节点名 <node>，IP <tailscale-ip>
- 远程通道：<协议> <命令>（标注哪些是运行时设置、重启失效）
- 断电重启后恢复顺序：① 自愈项 ② 需用户操作项
- 已知限制：<中文输入/权限等>
```

## 坑位表

| 坑 | 现象 | 解决 |
|:---|:-----|:-----|
| 找错 Hermes home | 在 `%USERPROFILE%\.hermes` 找不到 config.yaml 以为没装 | Windows 桌面版在 `AppData\Local\hermes` |
| scp 目标路径 | `/tmp/x.md` 落在 `C:\tmp\x.md` | 确认用 `if exist C:\tmp\file (echo YES)` |
| findstr 找不到中文 | 追加成功但 `findstr /i tablet` 返回空 | UTF-8 文件 cmd findstr 匹配不了，用 PowerShell Select-String |
| 终端显示乱码 | PowerShell 输出中文变 � | 文件没坏（SSH 管道显示编码问题），用 Select-String 验证内容 |
| 引号嵌套 | ssh + cmd + powershell 多层引号 | 单层 PowerShell 命令直接用 -Command 字符串 + -LiteralPath |
| 段间分隔符 | 追加内容与原有记忆粘连 | 用 `§`（[char]167）分隔，与 Hermes 记忆格式一致 |

## 验证

- 同机 profile：`ls -la ~/.hermes/profiles/<p>/skills/` 确认符号链接/文件存在
- Windows：PowerShell Select-String 命中关键串（IP/端口），且 `Get-Content -Tail 3` 能看到新段落

## 关联

- multi-agent-config-sync — 同机多 agent 群 chat_id 同步（飞书群消息通知）
- windows-tailscale-ssh-access — Windows SSH 连接细节（授权、admin key 路径、cmd 比 PowerShell 稳）
- adb-tablet-ui-automation — 平板设备信息源头（本 skill 常同步它的关键配置）
