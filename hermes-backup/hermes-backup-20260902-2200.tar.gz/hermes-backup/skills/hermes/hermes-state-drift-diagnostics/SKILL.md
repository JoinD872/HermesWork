---
name: hermes-state-drift-diagnostics
description: Hermes 自身状态漂移诊断 — 路由表与 MEMORY 一致性检查（SOUL.md 陈旧连接信息）、gateway_state.json 平台状态真伪判定（陈旧残留 vs 活跃故障）、动态指标硬编码清理。当用户报告「路由表陈旧」「平台一直重连失败」「配置不一致」「状态显示异常」时使用。
category: hermes
risk: read-only
---

# Hermes 状态漂移诊断

Hermes 有多个独立的状态来源（SOUL.md 路由表、MEMORY.md、channel_directory.json、gateway_state.json、config.yaml），它们**不会自动联动**，变更遗漏就产生「漂移」。本 skill 覆盖两类最常见的漂移与诊断方法。

## 一、SOUL.md 路由表 vs MEMORY.md 一致性

### 症状
用户/其他 agent 报告「SOUL.md 路由表里 X 还指向旧信息，但 MEMORY.md 已更新」——两个文件是独立静态文件，改了一个忘了另一个。

### 实例（2026-08）
黑翼段仍写 `DESKTOP-TG4LOEN / joind@100.86.150.37`，而 MEMORY.md 早已更新为 `DaLao / 100.108.175.15 / 用户 61915`。另外老V段硬编码「已用 15GB」，实际磁盘 29GB/71%。

### 检查方法
1. 读取 `~/.hermes/SOUL.md` 各身份段，提取所有主机名/IP/SSH 用户/端口
2. 与 `MEMORY.md`、`~/.hermes/channel_directory.json` 交叉核对
3. 实际可验证项（磁盘、IP、服务状态）用命令实测，如 `df -h`、`tailscale ip`

### 规则
- **路由表与 MEMORY.md 必须同步维护**，改人设/连接信息时两处都改
- **不要在 SOUL.md 硬编码动态指标**（磁盘用量、实时 IP、内存占用）——写进去必然过期。路由表只放身份/职责/连接方式等稳定事实，用量留给巡检命令实时查
- 修复用 patch 直接改 `/root/.hermes/SOUL.md`（每 session 重读，无需重启网关）

## 二、gateway_state.json 平台状态真伪判定

### 症状
用户报「XX 平台一直重连失败」。**先判定真故障还是死记录**，不要直接去修平台。

### 判定流程（2026-08 Discord 案例验证）
1. **看 `updated_at` 时间戳**：`~/.hermes/gateway_state.json` → `platforms.<name>.updated_at`。活跃平台的 updated_at 应接近网关最近重启时间；若停在几周/几个月前（如 04-19 而 feishu/api_server 是 07-21），说明网关重启后根本没再尝试连接 → **陈旧残留，非活跃故障**
2. **查插件启用状态**：`hermes plugins list`，该平台为 `not enabled` ⇒ 网关不启动它，无资源消耗
3. **查主 token 是否真实存在**：`grep -c "DISCORD_BOT_TOKEN" ~/.hermes/.env`（=0 即未配置）。⚠️ shell 环境可能有 `DISCORD_*` 辅助变量（REACTIONS/ALLOWED_CHANNELS 等来自 config.yaml 配置块），但**主 token 缺失才是连不上的根因**。平台启用条件看插件 `plugins/platforms/<name>/plugin.yaml` 的 `requires_env`
4. **结论**：插件未启用 + 无 token + 时间戳陈旧 ⇒ 无需「关闭」操作（它没在跑，关不掉也省不了资源）；可选清理 gateway_state.json 陈旧条目让状态显示干净

### 速查表

| 检查 | 命令/位置 | 活跃故障 | 陈旧残留 |
|------|-----------|---------|---------|
| 状态时间戳 | gateway_state.json → platforms.<name>.updated_at | 接近网关重启时间 | 停在几周/月前 |
| 插件启用 | `hermes plugins list` | enabled | not enabled |
| 主 token | `grep -c "XXX_TOKEN" ~/.hermes/.env` | 存在 | =0 |
| 平台启用条件 | `plugins/platforms/<name>/plugin.yaml` → requires_env | — | — |

### 清理注意
- 清理 gateway_state.json 时保留 gateway 进程正在写的字段（pid/active_agents/updated_at），只删陈旧的 platforms 条目
- 平台插件化后不再在 `hermes_cli/gateway.py` 内（如 Discord → `plugins/platforms/discord/adapter.py` + `plugin.yaml`）

## 通用注意
- 本类检查是只读诊断，报告后等用户决定是否修改
- 涉及具体地址（IP/域名/路径）必须从命令输出复制，禁止手写或凭印象缩写
- 报告时把「确认属实 + 证据链」摆清楚，用户偏好数据说话（df -h 实测值 vs SOUL.md 声称值）
