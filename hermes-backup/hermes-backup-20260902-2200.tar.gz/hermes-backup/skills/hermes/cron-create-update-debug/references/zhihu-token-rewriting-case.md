# 知乎 Token 重写案例分析

> 发生时间：2026-06-03
> 涉及 cron job：每日早报 - 社区情报聚合（job_id: 22c677b8acac）
> 涉及技能：cron-prompt-authoring

## 问题现象

每日早报的知乎采集段，后半部分搜索词全部返回 `Authorization failed`。连续多天出现，被当作「API 速率限制」误判了数周。

## 调查过程

### Step 1：手动测试原始命令

```bash
source /root/.hermes/.env
curl -s -G 'https://developer.zhihu.com/api/v1/content/zhihu_search' \
  --data-urlencode 'Query=AI' -d 'Count=3' \
  -H "Authorization: Bearer $ZHIHU...RET"
```

### Step 2：发现 $ZHIHU...RET 不是有效变量

发现 cron prompt 中实际存储的是 `$ZHIHU...RET` 而非 `$ZHIHU_ACCESS_SECRET`。

### Step 3：对比验证

```bash
# 用错误变量名 → 全部失败
echo "${ZHIHU...RET}"    # 空

# 用正确变量名 → 全部成功
source /root/.hermes/.env
echo "${ZHIHU_ACCESS_SECRET}"  # sk-xxxx...
```

### Step 4：Python os.environ 绕过

```python
# 24 次连续搜索全部成功，不需要 sleep
import os
token = os.environ.get('ZHIHU_ACCESS_SECRET')
# ... 正常调用
```

## 关键数据

- 知乎 API 实际限速：**约 20 次/分钟**（非硬限，实际 24 次连续不 sleep 也能过）
- 内容保护改写：将 `$ZHIHU_ACCESS_SECRET` → `$ZHIHU...RET`（删除中间 13 字符）
- 改写后变量长度：14 字符 vs 原始 20 字符
- 修复后的搜索词数：22 → 15（精简保留高价值词）
- 修复后 15 个搜索词全部成功，耗时约 18 秒（含 sleep 1s）

## 教训

问题被误判为「知乎 API 限流」持续数周，实际是 bash 变量名被重写。排查此类 Authorization 失败时应优先检查：

1. token 值本身是否有效
2. 变量名是否被内容保护系统改写
3. 使用 os.environ.get() 验证原始值可读
