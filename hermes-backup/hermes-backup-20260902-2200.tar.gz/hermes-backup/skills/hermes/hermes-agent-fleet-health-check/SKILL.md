---
name: hermes-agent-fleet-health-check
description: Hermes Agent 矩阵全面体检——系统性扫描所有 profiles、skills 绑定、频道路由、cron 状态、profile 去重，输出结构化体检报告。在用户要求「看看其他 agent 配置」、「全面体检」、「检查各 agent 状态」时使用。
category: hermes
risk: read-only
---

# Hermes Agent 矩阵 — 全面体检工作流

## 触发条件

用户说出以下任意意图时加载此 skill：
- 「看看其他 agent 配置」
- 「全面体检一下」
- 「检查各 agent 状态」
- 「帮我看看各群聊识别是否有问题」
- 「检查一下整个系统配置」

## 体检清单（按顺序执行）

### 第一步：扫描主配置

```
~/.hermes/config.yaml
```

检查：model provider 是否正确、base_url 是否有效、toolsets 是否完整。

### 第二步：扫描所有 Profile

```
~/.hermes/profiles/
```

对每个 profile 检查：
- ✅ `SOUL.md` 是否存在（核心人设文件）
- ✅ `skills/` 目录是否存在、内部 SKILL.md 文件是否完整
- ✅ 是否有完整的 `memories/MEMORY.md`
- ✅ 检查 profile 目录下的文件时效性（有无残留备份如 .bak 文件）

### 第三步：检测 Profile 冗余

检查是否有两个 profile 服务于同一个人设（如 `health/` + `health-advisor/`）。冗余的信号：
- 两个 profile 内 SOUL.md 的 name/identity 相同
- 一个技能库完整（含 skills/），另一个只有零散文件
- 通过频道路由表确认实际运行时走的是哪个 profile
- 检查 `hermes-per-channel-profile-injection` skill 中的 `_profile_map` 字典确认活跃映射

**清理冗余时的关键检查点：**
1. 先查配置和路由表确认哪个 profile 实际在用（不要假设旧的就没用）
2. 检查对应群的 session 历史，看最近使用的是哪个 profile
3. 迁移数据文件后再删除，不要直接 rm
4. 重命名到 archive 目录而不是直接删除（方便回滚）

### 第四步：检查 Skills 绑定

对每个 profile 下的 `skills/` 目录：
- **注意层级结构陷阱**：旧架构下 skills 是 `skills/<category>/<skill_name>/SKILL.md`（例如 `skills/creative/baoyu-comic/SKILL.md`），不是 `skills/<skill_name>/SKILL.md`。⚠️ 扫描脚本如果只看 `skills/<category>/SKILL.md` 而不是递归查子目录，会把大量正常子技能误报为"碎片"。
- **正确检测方式**：递归扫描所有子目录，找 SKILL.md 文件。代码示例：
  ```python
  for item in os.listdir(skills_dir):
      ipath = os.path.join(skills_dir, item)
      if os.path.isdir(ipath):
          # 检查 item 本身是否有 SKILL.md（单级结构）
          # 以及其子目录是否有 SKILL.md（category/skill 两级结构）
          sk_file = os.path.join(ipath, "SKILL.md")
          if not os.path.exists(sk_file):
              # 可能是分类目录，检查子目录
              has_children = False
              for sub in os.listdir(ipath):
                  subpath = os.path.join(ipath, sub)
                  if os.path.isdir(subpath) and os.path.exists(os.path.join(subpath, "SKILL.md")):
                      has_children = True
                      break
              if not has_children:
                  bad_dirs.append(item)
  ```
- 检查 `skills/.bundled_manifest` 文件（如果存在）以确认哪些 skills 已打包
- 重点关注 `vps-technician/`、`health-advisor/` 等瘦 profile
- **vps-technician 核心 skills 清单（15个）**：`vps-patrol`、`vps-full-health-check`、`vps-ssh-connection-quickstart`、`vps-ssh-noninteractive-auth`、`vps-ssh-unreachable-troubleshooting`、`vps-status-report`、`vps-ip-blocking-solutions`、`vps-file-via-cloudflare-tunnel`、`v2ray-xray-tcp-connection-failed`、`vps-joined-tunnel-troubleshooting`、`cloudflare-joined-tunnel-architecture`、`cloudflare-tunnel-joined-troubleshooting`、`vps-cloudflare-tunnel-ip-pattern`、`racknerd-vps-research`、`racknerd-scraper`

对于**顶层 skills**（`~/.hermes/skills/`），确保关键运维类 skill 被绑定到对应 profile：
- `vps-patrol` → vps-technician
- `vps-full-health-check` → vps-technician
- `vps-ssh-connection-quickstart` → vps-technician
- `v2ray-xray-tcp-connection-failed` → vps-technician
- `cloudflare-joined-tunnel-architecture` → vps-technician
- 无 skills/ 的 profile 需要补充绑定

**绑定方式**：用相对路径符号链接，例如：
```bash
cd ~/.hermes/profiles/vps-technician/skills/
ln -s ../../../skills/vps-patrol vps-patrol
```
注意：不要复制文件，用符号链接保持同步。

### 第五步：检查频道路由表

```python
# 读取 ~/.hermes/channel_directory.json
# 确认各群 chat_id 是否映射到正确的 profile
```

对照路由规则确认：
- 游戏制作组 → game-designer
- 健康助手 → health（或 health-advisor，确认哪个在用）
- 凌晨研究员 → researcher
- VPS 技术支持群 → vps-technician
- DM → 默认

### 第六步：检查 CRON 任务状态

```bash
cronjob list  # Hermes cron tool — 唯一的正确方式
```

⚠️ **不要**通过检查 `~/.hermes/cron/` 目录结构来判断。该目录下可能没有任务子目录（任务在 cron scheduler 启动后才创建），但 `~/.hermes/cron/jobs.json` 中可能仍存储着活跃的任务记录。文件系统扫描 == ❌，`cronjob action=list` == ✅。

**检查清单：**
- 是否有任务因配置变更而静默失效
- 定时任务是否仍按预期运行（`last_status` 字段应为 `ok`）
- 模型切换后 cron 任务的 provider pinning 是否需要更新
- 所有任务都有 `last_run_at` 在合理时间内（不是 `never`）
- 如果 `last_delivery_error` 非空，检查投递目标是否存在
- 注意 `deliver: "origin"` 的含义：投递到任务创建时的聊天上下文，不是"原始位置"

### 第七步：检查 Federation 目录

```
~/.hermes/federation/
├── callbacks/   — 联邦 agent 回调
├── pending/     — 待处理任务
└── archive/     — 已完成归档
```

确保目录结构完整。

### 第八步：输出结构化报告

报告格式：

```
🔍 Agent 矩阵体检报告
时间：YYYY-MM-DD HH:MM

## ✅ 绿色 — 运行正常
逐项列出所有正常项

## 🟡 黄色 — 需要关注
逐项列出待处理问题

## 评分
███ 维度名  ████████████ 百分比%
...

## 建议优先级
P0（影响运行）：
P1（影响效率）：
P2（技术债务）：
```

## 后续行动

每项建议明确标注：
- 要不要修？优先级？
- 具体操作命令（配置路径、文件位置）
- 验证方法（如何确认修好了）

## 注意事项

1. **不要修改任何配置** — 体检是只读操作，报告输出后等用户决定修不修
2. **Profile 文件清单用 `os.walk` 或 `find`** 而不是挨个手动打开
3. **关注 tech debt 信号**：.bak 残留文件、空目录、同名冲突、断链的引用
4. **CRON 状态用工具查，不要扫文件系统** — `cronjob action=list` 是唯一可靠方式
5. **Skills 检测要递归** — 单级扫描会误报两级目录结构为"碎片"
6. **Profile 去重先查路由表** — 不要假设旧 profile 没用，先确认 `_profile_map` 指向哪个
