# 三层模型与工作流

## 三层分类模型

| 层 | 持久性 | 存储位置 | 内容 | 管理方式 |
|----|--------|---------|------|---------|
| **Session** | 临时 | 上下文窗口 | 当前讨论、推理过程、调试日志、临时命令 | /new 后消失，不保存 |
| **Checkpoint** | 文件级 | `projects/<name>/checkpoint.md` | 项目进展、决策记录、架构 | 我主动写入，用户 /new 后我读取恢复 |
| **Memory** | 永久 | `~/.hermes/memories/MEMORY.md` | 稳定环境信息、用户偏好、不变配置 | `memory` 工具，受 governance 约束 |

## 检查/保存/新会话工作流（经用户确认）

当用户说"新问题"、"新任务"或"保存进度"时：

```
你说：新问题，XXXX
  ↓
我：评估当前是否有未完成的进展
  ├ 有 → 写 checkpoint → 告知已保存 → 请你发 /new
  └ 无 → 直接进入新话题（无需 reset）
```

**关键限制**：
- 我（agent）无法自己触发 `/new`，需要你手动发
- `/new` 后旧 session 消失，我自动读取 checkpoint 恢复上下文

## 什么写入 checkpoint vs memory

| 内容 | 写入 | 原因 |
|------|------|------|
| "正在做 PetDiffTool 功能 X，还剩 Y" | checkpoint | 项目状态，会变化 |
| "用户用 V2RayN + Shadowrocket 双端" | memory | 长期配置，半年不变 |
| "刚才 curl 测试返回了 200" | 不保存 | 一次性调试 |
| "用户偏好 Go 订阅不用付费 API" | memory | 长期偏好 |
| "DNS 故障原文："cat /etc/resolv.conf" 没检查" | checkpoint/文档 | 不是 memory（可写 skill 或文档）|
