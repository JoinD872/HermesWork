---
name: memory-governance
description: 管控写 memory 的纪律——只存长期事实，不存一次性事件/项目状态/会话日志
version: 1.0.0
risk: write-informational
---

# Memory Governance

## 核心原则

Memory 不是日志，不是 checkpoint，不是 todo list。

| 层级 | 保存内容 | 示例 | 保存方式 |
|------|---------|------|---------|
| **Memory** | 半年后还有效的事实 | VPS IP、用户偏好、协作规则 | `memory(add)` |
| **Checkpoint** | 项目当前进展/决策/架构 | 某功能做到哪了、技术选型理由 | 写入 `projects/<name>/` 下的文件 |
| **Session** | 临时讨论/调试/一步操作 | 某次 curl 测试结果、临时排查过程 | 不保存，/new 后消失 |

## ✅ 应该存到 Memory

- 用户长期偏好（沟通风格、报告格式、隐私边界）
- 固定环境配置（VPS IP/端口、模型选择、API key 位置）
- 长期有效的系统规则（协作模型、排查流程、安全准则）
- 已确认不易变的重要决策（订阅方案、技术栈选择）

## ❌ 不要存到 Memory

- **一次性故障/事故**（某次 DNS 挂了 → 写到文档或 skill）
- **临时命令/调试过程**（某次 curl 返回了什么 → session 层就够了）
- **项目当前状态**（功能做到哪了、有什么 bug 没修 → 写 checkpoint）
- **未经验证的观点**（"可能可以用 X 方案"→ 确认后再写入）
- **日志型时间线**（"2026-07-08 今天做了 X"→ 没价值）

## 写入前自检清单

每次调用 `memory(action='add', ...)` 前，问自己三个问题：

1. **半年后还有用吗？** 如果答案是「不会」→ 不写
2. **属于哪个层级？** Session / Checkpoint / Memory → 只把 Memory 层的写进去
3. **会不会撑满 5K？** 每条争取控制在 200 字符以内，多行条目合并压缩

## 清理触发条件

- MEMORY.md 超过 4,000 字节 → 主动审查
- 新信息使旧信息过时 → 用 `memory(replace)` 替换而非追加
- 用户说「你记忆里怎么还有这个」→ 立即删除

## 与 USER.md 的边界

- **MEMORY.md**（agent 视角）：环境事实、工具规则、工作流
- **USER.md**（用户视角）：个人偏好、性格特征、隐私边界、个人背景

USER.md 同样受 governance 约束——不存一次性事件，只存稳定的用户画像信息。

详见 `references/three-layer-model.md`——Session/Checkpoint/Memory 三层边界定义，以及"新问题"工作流的实操流程。
