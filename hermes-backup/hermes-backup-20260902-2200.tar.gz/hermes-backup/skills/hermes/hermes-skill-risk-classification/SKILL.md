---
name: hermes-skill-risk-classification
description: Hermes Skill 风险等级分类系统 — 将所有 skill 分为 read-only/write-safe/write-dangerous 三级，用于自动确认、自动备份要求、自动 change-log、危险操作拦截
category: hermes
tags: [hermes, skills, risk, governance]
risk: read-only
version: 2026-04-27
---

# Hermes Skill 风险等级分类系统

## 背景

Hermes 141 个 skill 需要统一的风险标签，用于：
1. 加载 skill 时一眼判断操作谨慎程度
2. 危险操作自动要求备份确认
3. 自动生成 change-log
4. 高风险 skill 操作前强制输出回滚命令

## 三级分类定义

| 等级 | 定义 | 触发场景 | Agent 行为 |
|------|------|---------|-----------|
| **read-only** | 仅查询/读取，不产生文件修改 | 搜索、诊断、只读 API 调用 | 可自动执行，无需确认 |
| **write-safe** | 写入产出文件（报告/生成物），不修改系统配置 | 生成图片/文档/视频、写报告到用户目录 | 可自动执行，但不得修改系统文件 |
| **write-dangerous** | 修改配置文件/系统状态/服务重启 | 修改 nginx/xray/cron/docker/systemd/.env/config.yaml | **必须先备份 + 回滚命令**，需明确授权 |

## 分类决策树

```
skill 做什么？
├── 只调用 API / 搜索 / 读取文件 / 诊断检查
│   └── → read-only
│
├── 创建新文件到用户可见目录（报告/生成物）
│   ├── 不修改系统配置
│   │   └── → write-safe
│   └── 覆盖已有系统文件
│       └── → write-dangerous
│
└── 执行以下任一操作
    ├── 删除/覆盖系统配置文件
    ├── 修改 / 重启服务（systemd/nginx/xray/docker）
    ├── 修改 cron job / .env / config.yaml
    ├── 添加/删除 Docker 容器
    ├── 修改防火墙规则
    ├── 执行 git push --force
    └── 安装系统级依赖
        └── → write-dangerous
```

## Frontmatter 标签格式

在 SKILL.md 顶部的 YAML frontmatter 中添加：

```yaml
---
name: <skill-name>
description: <简短描述>
risk: read-only  # 或 write-safe 或 write-dangerous
---
```

## 分类原则

1. **就高原则**：一个 skill 包含任何 write-dangerous 操作 → 整体评为 write-dangerous
2. **就多原则**：同时有 read-only 和 write-safe 段落 → 评 write-safe（因为包含写操作）
3. **命名不决定分类**：名字带 "troubleshooting" 不一定是 dangerous，名字带 "report" 也不一定是 safe
4. **以实际操作为准**：看 skill 里的 CLI / 代码实际会做什么，不是看描述

## 141 个 skill 分类结果（2026-04-27 基准）

| 风险等级 | 数量 | 示例 |
|---------|------|------|
| read-only | 50 | arxiv, vps-health-check, systematic-debugging, research-workflow |
| write-safe | 58 | vps-status-report, federation-result-beautifier, powerpoint, github-pr-workflow |
| write-dangerous | 33 | vps-patrol, mmx-cli, v2ray-xray-tcp-connection-failed, hermes-agent |

## 实施方法

批量打标签脚本（Python）：

```python
from pathlib import Path
import re

skills_dir = Path("/root/.hermes/skills")
CLASSIFICATION = {
    "skill-name-1": "read-only",
    "skill-name-2": "write-safe",
    "skill-name-3": "write-dangerous",
}

risk_re = re.compile(r'^risk:\s*(\S+)\s*$', re.MULTILINE)
frontmatter_re = re.compile(r'^---\n(.*?)\n---\n', re.MULTILINE | re.DOTALL)

for p in skills_dir.rglob("SKILL.md"):
    skill_name = p.parent.name
    if skill_name not in CLASSIFICATION:
        continue
    risk = CLASSIFICATION[skill_name]
    content = p.read_text()
    fm = frontmatter_re.match(content)
    if fm:
        frontmatter = fm.group(1)
        risk_match = risk_re.search(frontmatter)
        if risk_match:
            if risk_match.group(1) != risk:
                new_frontmatter = risk_re.sub(f'risk: {risk}', frontmatter)
                p.write_text(content.replace(frontmatter, new_frontmatter, 1))
        else:
            new_frontmatter = frontmatter.rstrip() + f"\nrisk: {risk}\n"
            p.write_text(content.replace(frontmatter + '\n---\n', '---\n' + new_frontmatter + '---\n', 1))
```

## 已知分类决策案例

| Skill | 分类 | 原因 |
|-------|------|------|
| `vps-health-check` | read-only | 纯诊断命令，无任何写操作 |
| `vps-patrol` | write-dangerous | 包含 `systemctl restart` 等危险操作 |
| `vps-status-report` | write-safe | 生成报告文件，不修改系统 |
| `vps-file-via-cloudflare-tunnel` | write-dangerous | 写 systemd service 文件 |
| `hermes-env-patch-workaround` | write-dangerous | 写入受保护的 .env 文件 |
| `cloudflare-joined-tunnel-architecture` | read-only | 纯知识文档，无操作步骤 |
| `v2rayn-screenshot-analysis` | read-only | OCR 截图分析，无写操作 |
| `github-file-transfer-hermes` | write-dangerous | 写 git credentials 和 remote 配置 |
| `mmx-cli` | write-dangerous | 涉及 API key 更换和配置修改 |
| `cron-job-federation-debug` | write-dangerous | 修改 cron jobs.json |
| `research-workflow` | read-only | 纯研究流程规范，无写操作 |
| `dogfood` | write-safe | QA 测试生成文件到测试目录 |

## 未来扩展方向

1. **自动确认**：加载 `write-dangerous` skill 时自动要求用户确认
2. **自动备份**：执行危险 skill 前自动执行备份命令
3. **自动 change-log**：记录所有 `write-dangerous` skill 的调用历史
4. **高危操作拦截**：禁止某些 `write-dangerous` skill 在特定时间自动执行（如老V白天不自动改 nginx）
