# Profile 生命周期审计与清理

## 背景

多 Agent 架构（多个 profile + chat_id 路由）配好后，可能会进入"配好了但没人用"的状态。 
需要定期审计各 profile 的实际使用情况，判断是否保留、归档或清理。

## 审计方法

### 1. 确认路由通路

```bash
# SOUL.md 路由表
grep "oc_" ~/.hermes/SOUL.md

# feishu.py profile_map（源码级别）
grep -A 15 "_profile_map" ~/.hermes/hermes-agent/gateway/platforms/feishu.py | grep -E "oc_|#"
```

### 2. 用量审计

```bash
# cron 输出——看各 job 是否还在跑
ls -lt ~/.hermes/cron/output/ | head -20

# 检查关联 cron job 详情
cat ~/.hermes/cron/jobs.json | python3 -c "
import sys,json
data=json.load(sys.stdin)
jobs=data if isinstance(data,list) else data.get('jobs',data)
for j in jobs if isinstance(jobs,list) else jobs.values():
    print(j.get('name','?'), j.get('schedule','?'))
"
```

### 3. Profile 实际活跃度判断

| 信号 | 含义 |
|------|------|
| 对应飞书群近 30 天无对话 | ❌ 群聊未使用 |
| session_search 搜不到指定 chat_id 的近期记录 | ❌ 无路由流量 |
| profile 的 SOUL.md 人设描述与用户当前偏好冲突 | ❌ 身份过时 |
| 关联 cron job 正常运行但跑在 default profile 下 | ⚠️ 功能还在但 profile 未生效 |

### 4. 磁盘占用估算

```bash
for p in ~/.hermes/profiles/*/; do
    name=$(basename "$p")
    disk=$(du -sh "$p" 2>/dev/null | cut -f1)
    soul_lines=$(wc -l < "$p/SOUL.md" 2>/dev/null || echo 0)
    echo "$name  $disk  ${soul_lines}lines SOUL"
done
```

## 清理决策框架

| 状态 | 推荐操作 |
|------|---------|
| 群聊从未使用 + 人设过时 | 归档到 `profiles/archive/`，从 SOUL.md 路由表移除 |
| 群聊从未使用 + 人设可能有未来价值 | 归档，SOUL.md 路由表移除，保留 profile 目录 |
| 群聊偶尔使用 | 保留，标记为"低活跃" |
| cron 依赖该 profile | 保留，确保 backup 覆盖该 profile 的 memories/ |
| 用户明确表示过时 | 归档或删除，路由表清理，SOUL.md 对应人设描述移除 |

## 归档操作

```bash
# 归档（推荐 — 可回滚）
mkdir -p ~/.hermes/profiles/archive/
mv ~/.hermes/profiles/<name> ~/.hermes/profiles/archive/<name>_$(date +%Y%m%d)

# 从 SOUL.md 路由表移除
# 编辑 ~/.hermes/SOUL.md，删除该 chat_id 对应的行

# 验证 feishu.py profile_map 是否需要更新
grep "<chat_id>" ~/.hermes/hermes-agent/gateway/platforms/feishu.py
```

## 恢复方法

```bash
mv ~/.hermes/profiles/archive/<name>_<date> ~/.hermes/profiles/<name>
# 恢复 SOUL.md 路由行
# 重启 gateway：systemctl --user restart hermes-gateway
```

## 已知坑

- 即使 profile 被归档，memories/ 目录中的知识仍在——归档不是删除
- SOUL.md 路由表清理后，对应 chat_id 的消息会走 default 身份
- feishu.py 的 `_profile_map` 和 SOUL.md 路由表是两个独立系统——改一个不会自动同步到另一个
