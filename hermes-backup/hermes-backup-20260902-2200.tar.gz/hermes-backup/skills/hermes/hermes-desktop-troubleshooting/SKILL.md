---
name: hermes-desktop-troubleshooting
description: 从 VPS 远程诊断和修复 Hermes 桌面端（Electron app）的完整工作流 — Electron 崩溃分析、WebSocket file:// 协议修复、asar 提取/修改/打包/部署、源码编译 + 远程文件传输到 Windows
tags: [hermes, desktop, electron, asar, debugging, windows]
risk: write-safe
---

# Hermes Desktop Troubleshooting

从 VPS 远程诊断和修复 Hermes 桌面端（Electron app）的完整工作流。

## 核心原则

### 自验证原则

**每次改完后必须自己验证，不能直接让用户试。** 验证步骤：

1. **编译后确认 fix 在 dist 文件里** — grep 关键特征字符串确认改动存在
2. **部署后确认 fix 在 asar 里** — 重新提取 asar，grep 验证
3. **确认文件大小不同** — 新旧 asar 大小应有差异（确认不是静默覆盖失败）
4. **清理全部临时文件** — `asar_extract`、`asar_verify`、temp script 全部删除

用户纠正示例：`"你自己改完，能否自己去验证吗？"`

### 第一原则：不要改变桌面端 UI

**不要改 `createWindow()` 的加载方式。** 桌面端从 `file://` 加载渲染器是设计选择——HTTP 加载会显示 Web Dashboard 而非桌面端 UI（pet overlay、自定义 title bar、原生窗口管理等桌面专属功能）。

✅ 正确的修复方向：在 renderer 的 WebSocket 连接链路中加固（`resolveGatewayWsUrl`、`JsonRpcGatewayClient.connect`）
❌ 错误的修复方向：把 `mainWindow.loadURL()` 改为从后端 HTTP 端口加载

## 架构概览

Hermes 桌面端 = Electron 壳 + React 渲染器（从 `file://` 加载）+ Python 后端（`hermes serve`）。

```
Electron 主进程 (main.ts)
  │  createWindow() → loadURL(file://dist/index.html)
  │  startHermes() → 启动 Python 后端 → port 9120
  │
  ├→ IPC: getConnection() → 返回 { baseUrl, wsUrl, token, ... }
  │
  React 渲染器 (file:// 环境)
  │  boot() → getConnection() → resolveGatewayWsUrl() → connect(wsUrl)
  │                                                          │
  │                                                    new WebSocket(wsUrl)
  │
  Python 后端 (127.0.0.1:9120)
     ├─ REST API (HTTP)
     └─ WebSocket API (ws://127.0.0.1:9120/api/ws)
```

## 1. 连接 Windows

通过 Tailscale SSH 操作 Windows 机器：

```bash
ssh 61915@100.108.175.15 "command"
```

详见 `windows-tailscale-ssh-access` skill。

## 2. 常见问题与诊断

### 2.1 Electron 主进程崩溃

症状：
```
A JavaScript error occurred in the main process
Uncaught Exception: TypeError: Object has been destroyed
  at readTitle
  at Timeout._onTimeout
```

**根因**：Electron 经典 bug — 定时器在 BrowserWindow 销毁后访问 window/webContents 属性。

**检查源码**（`apps/desktop/electron/link-title-window.ts`）：
```typescript
// 修复后的安全版本应包含 isDestroyed() 检查：
function readLinkTitleWindowTitle(window) {
  try {
    if (!window || window.isDestroyed()) return ''
    const contents = window.webContents
    if (!contents || contents.isDestroyed()) return ''
    return contents.getTitle() || ''
  } catch {
    return ''
  }
}
```

**修复 commit**：`359518bea`（fix(desktop): guard link-title readTitle against destroyed windows）

### 2.2 WebSocket file:// 协议错误

症状：
```
Failed to construct 'WebSocket': The URL's scheme must be either 'ws', or 'wss'.
'file' is not allowed.
```

**根因**：renderer 从 `file://` 加载时，`window.location.protocol = 'file:'`、`host = ''`。若 `wsUrl` 被设为空字符串、undefined，`new WebSocket('')` 或 `new WebSocket(undefined)` 会将空串/undefined 解析为相对路径，拼接 `file://` 前缀导致错误。

**修复路径**：在 `resolveGatewayWsUrl()`（`apps/shared/src/websocket-url.ts`）中加防御性检查

```typescript
// 修复思路：在 return conn.wsUrl 前检查 URL scheme
// 若 wsUrl 缺失或 scheme=file:，从 baseUrl 构建 wsUrl 兜底
// 注意 GatewayWsConnection 类型只有 wsUrl/authMode/profile，没有 baseUrl/token
// 所以兜底需要扩展类型或在外层处理
```

**不要修改 `createWindow()` 的加载方式。** `file://` 加载是设计选择。

### 2.3 其他诊断技巧

- **日志位置**：错误对话框里有「打开日志」按钮，或 `%APPDATA%/Hermes/logs/`、`%LOCALAPPDATA%/hermes/logs/`
- **连接配置**：`%APPDATA%/Hermes/connection.json`
- **后端启动标志**：`HERMES_DASHBOARD_READY port=<port>` — 后端就绪
- **Windows 路径差异**：Windows 配置在 `%LOCALAPPDATA%/hermes/`（不是 `~/.hermes/`）

## 3. 修改 → 编译 → 部署 → 验证 完整工作流

### 3.1 源码位置

```
/root/.hermes/hermes-agent/
├── apps/desktop/electron/
│   ├── main.ts                    ← Electron 主进程
│   ├── preload.ts                 ← 预加载脚本
│   ├── backend-ready.ts           ← 后端就绪检测
│   ├── connection-config.ts       ← 连接配置
│   └── link-title-window.ts       ← 链接标题窗口
├── apps/desktop/src/              ← React 渲染器源码
│   └── app/gateway/hooks/use-gateway-boot.ts  ← 启动流程
├── apps/shared/src/
│   ├── websocket-url.ts           ← WebSocket URL 构建（关键文件）
│   ├── json-rpc-gateway.ts        ← WebSocket 客户端
│   └── ...
└── apps/desktop/scripts/
    └── bundle-electron-main.mjs   ← 编译脚本（esbuild）
```

### 3.2 编译 main process（改 main.ts 只需这步）

```bash
cd /root/.hermes/hermes-agent/apps/desktop
# 确保有 esbuild（如无则 npm install --no-save esbuild）
node scripts/bundle-electron-main.mjs
```
输出：`dist/electron-main.mjs`（~500KB）、`dist/electron-preload.js`（~17KB）

### 3.3 改 shared package（websocket-url.ts / json-rpc-gateway.ts）

shared package 会被编译进 BOTH main process bundle AND renderer bundle。改完 shared 后需要：
- 重新编译 main process（上述步骤）
- 重新编译 renderer：`npm run build`（需全量构建，VPS 上可跑但较慢）

### 3.4 文件传输到 Windows

**SCP 不可靠**：`scp file user@win:C:\Users\...` 在 OpenSSH for Windows 上会静默失败（路径解析问题）。

✅ 推荐方案 — HTTP 服务器 + PowerShell：

```bash
# VPS 起 HTTP 服务器
python3 -m http.server 19999 --bind 0.0.0.0 &
# （记录 session_id，用完后 process kill）

# Windows 下载
ssh user@win "powershell Invoke-WebRequest \
  -Uri http://<vps-tailscale-ip>:19999/filename \
  -OutFile C:\\path\\to\\destination \\ -UseBasicParsing"
```

❌ 不推荐方案 — base64 通过 SSH 传：~50KB 的 base64 超出 SSH exec 命令长度限制（~32KB）。

### 3.5 ASAR 操作

```bash
# 安装（仅首次）
npm install -g asar

# 提取 → 替换 → 打包 → 验证
mkdir C:\path\to\asar_extract
asar extract "C:\path\to\app.asar" "C:\path\to\asar_extract"
copy /y new_main.mjs asar_extract\electron\main.mjs
copy /y asar_extract\electron\main.mjs asar_extract\electron\main.cjs
copy app.asar app.asar.backup /y
asar pack C:\path\to\asar_extract app.asar

# 验证 fix 存在
asar extract app.asar C:\path\to\verify
grep "fix_signature" verify\electron\main.cjs
```

### 3.6 自验证清单（必做）

- [ ] 编译后的 `dist/electron-main.mjs` 含 fix 签名
- [ ] 文件已部署到 asar（检查 `asar_extract\electron\main.*` 大小与旧文件不同）
- [ ] 重新打包后提取验证 fix 确实在 asar 里
- [ ] 新旧 asar 文件大小不同（确认不是静默覆盖失败）
- [ ] 桌面端只改动必要文件，未改 `createWindow()` 的加载方式
- [ ] 全部临时文件已清理

## 4. 坑点与注意事项

1. **asar 里的 `main.cjs` 和 `main.mjs` 必须同时更新** — 两者都要替换
2. **文件传输后必须验证大小** — SCP 可能静默失败，用 dir 对比字节数
3. **HTTP 服务器绑定 `0.0.0.0`** — Windows 通过 Tailscale 访问 VPS IP
4. **Base64 通过 SSH 传输不可行** — 超出命令长度限制（~32KB）
5. **`mainWindow.loadURL(file://)` 不能改为 `http://`** — 会显示 Web Dashboard 而非桌面端 UI
6. **`window.location.host` 在 `file://` 下为空** — 任何依赖 window.location 的 WebSocket 构建都会出错
7. **Electron IPC 序列化** — 使用结构化克隆算法，字符串类型的 `wsUrl` 可以正常序列化
8. **清除临时文件** — 每次操作后清理 `Temp\asar_*` 目录和 `Temp\*.ps1`
