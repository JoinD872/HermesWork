# Hermes Desktop: WebSocket Boot Failure (file:// protocol)

## Symptom

After backend starts successfully (`HERMES_DASHBOARD_READY port=9120`), the renderer
shows an error dialog:

```
Failed to construct 'WebSocket': The URL's scheme must be either 'ws', or 'wss'.
'file' is not allowed.
```

The app loads its UI shell but the WebSocket connection to the gateway never
opens — the composer stays disabled on "Starting Hermes…".

## Root Cause

The Electron main process loads the renderer from `file://` protocol (line 7725
of `electron/main.ts`):

```typescript
mainWindow.loadURL(pathToFileURL(resolveRendererIndex()).toString())
```

When the renderer runs from `file://`:

- `window.location.protocol` = `file:`
- `window.location.host` = `''` (empty)

Any code that resolves WebSocket URLs from `window.location` gets an invalid
scheme. Meanwhile the Hermes backend is running fine on `http://127.0.0.1:<port>`
and serving the exact same web UI from that HTTP endpoint (where `window.location`
works correctly for both REST and WebSocket).

## Fix

**Change:** In `electron/main.ts`, instead of loading the renderer from `file://`
immediately, wait for the backend to start and then load from its HTTP URL:

```typescript
// instead of:
mainWindow.loadURL(pathToFileURL(resolveRendererIndex()).toString())
startHermes().catch(...)

// do:
startHermes()
  .then(connection => {
    if (connection?.baseUrl && mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.loadURL(connection.baseUrl)
    }
  })
  .catch(error => {
    // fallback to file:// if backend never starts
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.loadURL(pathToFileURL(resolveRendererIndex()).toString())
    }
  })
```

The backend already serves the web UI at its HTTP address (it was spawned with
`HERMES_WEB_DIST` pointing to the bundled frontend). The window stays hidden
(`show: false`) until `ready-to-show` fires, so the user never sees a blank
loading state.

## How to Rebuild the Main Process Bundle

The desktop's Electron main process is bundled into a single file by esbuild.
You don't need the full electron-builder chain:

```bash
cd /root/.hermes/hermes-agent/apps/desktop

# Install esbuild (if not present)
npm install --no-save esbuild

# Bundle electron/main.ts → dist/electron-main.mjs
node scripts/bundle-electron-main.mjs

# Output:
#   dist/electron-main.mjs   (~506KB) — Electron main process bundle
#   dist/electron-preload.js (~17KB)  — preload script
```

## How to Patch an Existing Install (Windows)

Transfer the compiled bundle to the Windows machine via SCP and replace inside
`app.asar`:

```powershell
# 1. Backup the original asar
copy "C:\...\win-unpacked\resources\app.asar" "C:\...\win-unpacked\resources\app.asar.backup"

# 2. Extract asar to temp dir
asar extract "C:\...\app.asar" "C:\Temp\asar_fix"

# 3. Replace both .mjs and .cjs (same content, consumed interchangeably)
copy /y ".\electron-main.mjs" "C:\Temp\asar_fix\electron\main.mjs"
copy /y "C:\Temp\asar_fix\electron\main.mjs" "C:\Temp\asar_fix\electron\main.cjs"

# 4. Repack (remove old first or asar pack overwrites)
asar pack "C:\Temp\asar_fix" "C:\...\app.asar"

# 5. Clean up
rmdir /s /q C:\Temp\asar_fix
```

## Verification

After the fix, the renderer loads from `http://127.0.0.1:<port>` instead of
`file://`. The WebSocket should connect on first attempt. No more renderer
errors about invalid WebSocket schemes.

## Architecture Context

- The Hermes desktop app is an Electron shell that spawns a Python Hermes
  backend as a child process
- The backend serves a web UI on a random local port (`--port 0` = OS-assigned)
- Originally the window loaded from the bundled `dist/index.html` via `file://`
  to show UI immediately, then connected to the backend via WebSocket
- `file://` pages have quirks with `window.location` that break WebSocket URL
  resolution in some code paths
- This fix loads the renderer from the backend's HTTP server after it starts,
  eliminating the protocol mismatch entirely
