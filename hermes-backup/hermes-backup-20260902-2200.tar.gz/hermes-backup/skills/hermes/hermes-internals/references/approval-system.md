# Hermes Tool Execution Approval System — Reference

## 核心源码

| 文件 | 作用 |
|------|------|
| `tools/approval.py` | 危险命令检测 (`DANGEROUS_PATTERNS`)、审批状态、模式判断、辅助 LLM 智能审批 |
| `gateway/run.py` | 审批卡片路由（发送/超时/回调） |
| `cli.py` | `/yolo` 命令、CLI 交互式审批 |

### 关键函数（tools/approval.py）

| 函数 | 作用 |
|------|------|
| `_normalize_approval_mode(mode)` | 规范化审批模式，处理 YAML 1.1 boolean 陷阱 |
| `_get_approval_mode()` | 读取当前审批模式：`manual` / `smart` / `off` |
| `_get_cron_approval_mode()` | 读取 cron 审批模式：`deny` / `approve` |
| `is_approval_bypass_active()` | 汇总三重 bypass 检查（YOLO env + session toggle + mode=off） |
| `detect_dangerous_command()` | 用 `DANGEROUS_PATTERNS` 正则匹配检测危险命令 |
| `_is_gateway_approval_context()` | 判断当前是否是 gateway 上下文（cron 上下文返回 False） |

## 配置

### approvals 段
```yaml
approvals:
  mode: manual       # manual | smart | off
  timeout: 60        # 审批卡片超时秒数
  cron_mode: deny    # deny | approve
  mcp_reload_confirm: true
  destructive_slash_confirm: false
```

### command_allowlist（config.yaml）
约 20+ 项危险操作类别，命中任一即触发审批：
- `recursive delete`, `overwrite system config`, `execute_code`
- `kill process via pgrep expansion`, `script execution via heredoc`
- `hermes update`, `git branch force delete`, 等等

### 审批模式详解

| 模式 | 行为 | 适用场景 |
|------|------|----------|
| `manual`（默认） | 危险操作全部弹卡片等待用户确认 | 保守安全策略 |
| `smart` | 辅助 LLM 自动评估风险：低风险静默放行，高风险弹卡 | 平衡安全与效率 |
| `off` | 完全跳过所有审批，危险命令直接执行 | 信任环境/高频开发 |

**YAML 陷阱**：YAML 1.1 会把裸词 `off` 解析为 boolean `False`。代码在 `_normalize_approval_mode()` 中专门处理了这种情况：`isinstance(mode, bool) and mode is False` → 视为 `"off"`。但建议写配置时加引号 `mode: "off"` 避免歧义。

### cron_mode

| 值 | 行为 |
|----|------|
| `deny`（默认） | cron 上下文完全不能执行 allowlist 中的命令 |
| `approve` | cron 任务可执行危险命令（别名: `off`, `allow`, `yes`） |

## 三重 Bypass 机制

```python
def is_approval_bypass_active() -> bool:
    return _YOLO_MODE_FROZEN        # env var HERMES_YOLO_MODE
        or is_current_session_yolo_enabled()  # session内 /yolo toggle
        or _get_approval_mode() == "off"      # config approvals.mode
```

1. **`HERMES_YOLO_MODE` env var** — 模块导入时冻结，进程期间不可改（防注入）
2. **`/yolo` session toggle** — gateway session 内 `/yolo` 命令切换，仅当前 session 有效
3. **`approvals.mode: off`** — 配置级永久关闭

## 平台适配器（审批卡片 UI）

| 平台 | 文件 | 关键行 |
|------|------|--------|
| Feishu | `feishu/adapter.py` | `_APPROVAL_CHOICE_MAP` L219-223, `_APPROVAL_LABEL_MAP` L225-229 |
| Telegram | `telegram/adapter.py` | Label map L5354-5358 |
| Discord | `discord/adapter.py` | `allow_always()` L6941-6944, `purple()` color |
| Slack | `slack/adapter.py` | Label map with `@user_name` L3624-3629 |

### 审批状态持久化
- 状态存储位置：`tools/approval.py` 内部内存表（per-session），非文件持久化
- `cron_mode: deny` → cron 上下文无审批权限触发路径
- "Approved permanently" 存储在运行时状态中（session 级）；跨进程重启后需要重新授权

## 各平台卡片渲染差异

| 平台 | 按钮样式 | 确认后显示 | 备注 |
|------|---------|-----------|------|
| Feishu | 飞书卡片按钮（蓝色/红色） | `Approved permanently` | 纯文本标签 |
| Telegram | InlineKeyboardButton | `✅ Approved permanently` | 带 emoji，附用户名 |
| Discord | discord.ui.Button（purple/red） | `Approved permanently` | Button 颜色 purple=allow，red=deny |
| Slack | Section block buttons | `✅ Approved permanently by @username` | 平台标准确认交互 |

## 审批流程（伪代码）

```
Agent 请求执行高危命令
  ├─ 检查命令是否在 command_allowlist 中
  │   └─ 否 → 直接执行（不触发审批）
  ├─ 检查是否有已缓存的永久/会话审批
  │   └─ 有 → 直接执行
  ├─ 发送审批卡片到当前平台
  ├─ 等待用户响应（timeout=60s）
  │   ├─ 超时 → 拒绝执行
  │   └─ 响应 →
  │       ├─ deny → 拒绝
  │       ├─ once → 执行一次
  │       ├─ session → 执行 + 缓存到 session 结束
  │       └─ always → 执行 + 持久化到本地存储
  └─ 更新卡片显示审批结果
```

## 常见问题

### Q: 为什么会有 "Approved permanently" 提示？
A: 用户之前对该类危险命令点击了"永久允许"，Hermes 记住了授权。这不是错误。

### Q: 如何撤销永久授权？
A: 目前无集中管理 UI。需要手动清理本地审批状态缓存（路径待确认），或等待下次重启。

### Q: cron 任务能触发审批吗？
A: 不能。`cron_mode: deny` 阻止 cron 上下文的任何自动审批，cron 任务只能执行不在 allowlist 中的操作。

### Q: 会议/群聊中谁可以审批？
A: 取决于平台：Feishu DM 由用户本人审批；群聊中可能任一管理员可响应。
