# Session 管理机制（代码级）

## Session 创建路径

```
用户消息 → gateway/run.py → dispatch_to_agent()
  → SessionStore.get_or_create_session(source)
    → _should_reset(entry, source) 检查是否需要重置
      → policy.mode == "none" → 永不过期
      → policy.mode == "idle" → 检查 updated_at + idle_minutes
      → policy.mode == "daily" → 检查 updated_at < 今天 reset 时间
      → policy.mode == "both" → 两者取先
    → 需要重置 → create_session() → 新 session_id + DB 记录
    → 不需要 → 返回现有 entry
```

## 关键配置参数

```yaml
agent:
  gateway_timeout: 1800           # session 超时（秒）
  gateway_auto_continue_freshness: 3600  # 重启后继续窗口（秒）
  gateway_timeout_warning: 900    # 超时前 15 分钟告警
  gateway_notify_interval: 600    # 通知间隔
```

## gateway_auto_continue_freshness 机制

Gateway 重启后，旧 session 在 `freshness` 秒内可自动继续。
超过后标记为 zombie，下次用户发消息时自动开新 session。
默认 3600s（1小时）。

## /new 处理流程

`/new` 在 gateway/run.py 被截获（`_dispatch_slash_command`）：
1. `reset_session()` 被调用
2. 旧 session `end_session(session_reset)` 写入 DB
3. 新 session 在下次用户消息时创建
4. **agent 收不到 `/new` 消息，也无法在其之前执行任何代码**

## 检查命令

```bash
# 查看 session DB
ls ~/.hermes/sessions/
sqlite3 ~/.hermes/sessions/sessions.db "SELECT id, session_id, created_at, ended_at FROM sessions ORDER BY id DESC LIMIT 10;"

# 查看当前 session
hermes gateway status | grep session
