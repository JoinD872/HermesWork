---
name: hermes-cross-agent-session-query
description: 跨 Profile 会话检索 — 用户说"去问问老V/朵朵/小策查了什么"时，从共享 state.db 读取其他 profile agent 群会话结论的工作流。含检索顺序、SQL、已知陷阱
version: 1.0.0
metadata:
  hermes:
    tags: [hermes, multi-agent, session, state-db, cross-profile, retrieval]
risk: read-only
---

# 跨 Profile 会话检索（读其他 agent 的结论）

## 触发条件

用户说"你自己去问问老V/朵朵/小策"、"看看XX查到了什么"、"老V 查了，你去问结论"时触发。目标：**复用其他 agent 已完成的排查/结论，不重复跑一遍**（省资源、避免二次干扰生产）。

## 架构前提（为什么能直接读）

所有 profile（老V/朵朵/小策等）运行在**共享单 gateway** 下，会话全部落在 default 的 `/root/.hermes/state.db`（子 profile 目录下**没有**独立 state.db/sessions —— 见 hermes-multi-agent-architecture）。所以"其他 agent 的群会话"= state.db 里 chat_id 指向该群的 session。

## 检索顺序（先结构化、后原始会话）

1. **联邦 callbacks**：`ls ~/.hermes/federation/callbacks/` — 结构化 `emit_result()` 回执（含 summary/key_findings）
2. **联邦 pending**：`ls ~/.hermes/federation/pending/<profile>/` — 未完成/积压任务
3. **共享 state.db 原始会话**（通常才是答案所在，用下方 SQL）

## SQL 配方

```sql
-- 1. 按群 chat_id 找 session（时间倒序，最近的在最上面）
SELECT id, title, datetime(started_at,'unixepoch','localtime') AS started
FROM sessions
WHERE chat_id LIKE 'oc_cc9c%'          -- 换成目标群的 chat_id 前缀
ORDER BY started_at DESC;

-- 2. 读该 session 指定时间窗的消息（user 提问 + assistant 结论 + tool 证据）
SELECT role, substr(content,1,300) AS content, datetime(timestamp,'unixepoch','localtime') AS ts
FROM messages
WHERE session_id='<第1步的id>'
  AND timestamp > strftime('%s','2026-08-09 00:00')   -- 目标日期
ORDER BY id ASC;
```

**常用群 chat_id**：VPS 技术支持群 = `oc_cc9c8289c9520ff326578703ff17392c`；Home/DM = `oc_8391fa2b38acbd759ff75ab3616d5d1f`（完整路由表见主 SOUL.md）。

**读法要点**：
- 消息时间戳是 Unix epoch，用 `datetime(ts,'unixepoch','localtime')` 转本地
- `role='user'` 行是用户的原始提问，`role='assistant'` 行含结论，`role='tool'` 行含排查证据（ps aux 输出、负载数字、服务状态）
- content 可能很长，`substr()` 截断读取即可；需要完整证据再读全文

## 已知陷阱

| 陷阱 | 说明 |
|------|------|
| `session_search(profile='vps-technician')` 不生效 | 共享单 gateway 下所有 session 的 `profile_name` 列为 NULL，profile 参数是 no-op，会返回 default 的结果 |
| 老会话复用 | 群会话是**长会话**，session id 可能是几周前的（如 `20260518_...`），按 started_at 排序看不出活跃度——必须按 chat_id 查后看最新消息时间戳 |
| tool 行误判 | tool 行内容长且含命令输出，别把 tool 行当 assistant 结论 |
| 联邦目录为空 ≠ 没查 | 老V 等 agent 日常对话不写联邦文件，结论就在群会话里，直接读 state.db |

## 收尾

- 读到结论后先与自己的判断交叉验证（不一致才深挖，一致直接给用户方案）
- 顺手清理自己会话留下的 /tmp 临时文件（用户在意残留）

## 实例（2026-08-09）

小H 抓 X 推文时 camoufox 深滚打满 VPS（load 13.8，camoufox-bin 94.6% CPU），用户让老V 查。小H 用上述 SQL 读到老V 在 VPS 群的完整排查结论（服务全正常、罪魁是爬虫任务），与自判一致后直接给解决方案，未重复排查。VPS 已自愈（timeout 杀进程后 load 回落），root cause 教训已写入 camoufox-install skill。
