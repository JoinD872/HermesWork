---
name: cron-inline-code-type-safety
description: Cron 内联 Python 代码的类型安全规范 — API 字段类型不一致导致的比较错误防御
category: hermes
tags: [cron, python, type-error, api, data-collection]
risk: read-only
---

# Cron 内联代码类型安全

Cron prompt 里的内联 Python 代码在实际运行时，API 返回的字段类型经常和代码假设不一致。本 skill 记录已知的类型陷阱和防御模式。

---

## 核心原则

**在 cron 内联代码中做数值/日期比较前，必须先验证 API 实际返回类型。**

不要假设 API 字段类型 —— 同一个 API 的不同字段可能返回 int、str、float、None。

---

## 已知类型陷阱

### 知乎官方 API（developer.zhihu.com）

| 字段 | 代码假设 | 实际类型 | 比较目标 | 结果 |
|------|---------|---------|---------|------|
| `EditTime` | str 日期 | **int** (Unix 时间戳) | str `seven_days_ago` | `'<' not supported between 'int' and 'str'` |

**修复：** 日期比较统一用 int 时间戳：
```python
seven_days_ago_ts = int((datetime.datetime.now() - datetime.timedelta(days=7)).timestamp())
edit_time = item.get('EditTime', 0)
if edit_time and int(edit_time) < seven_days_ago_ts:
    continue
```

### 掘金 API（api.juejin.cn）

| 字段 | 代码假设 | 实际类型 | 比较目标 | 结果 |
|------|---------|---------|---------|------|
| `ctime` | int/float | **str** (`'1786957353'`) | float `time.time()` | `unsupported operand type(s) for -: 'float' and 'str'` |

**修复：** 显式 `int()` 转换：
```python
ctime = int(article.get('ctime', 0) or 0)  # str → int，空值 → 0
if ctime and (now - ctime > 7 * 86400):
    continue
```

---

## 排障步骤

修改 cron 内联代码前，先在终端实际调用 API 验证字段类型：

```python
# 通用验证模板
item = api_response['Data']['Items'][0]  # 根据实际结构调整路径
for key in ['EditTime', 'CreatedTime', 'ctime', 'created_at_i']:
    val = item.get(key)
    if val is not None:
        print(f'{key}: type={type(val).__name__}, value={repr(val)[:80]}')
```

---

## 外部 API 端点选择

部分 API 的端点选择会影响时间过滤效果。详见：
- `references/hn-algolia-endpoints.md` — HN Algolia `/search` vs `/search_by_date` 的时间过滤差异

---

## 防御模式

在 cron 内联代码中做比较时，始终用 `int()` 或 `float()` 包裹 API 字段值：

```python
# 安全的日期/时间比较模式
value = int(api_field or 0)          # 兼容 str/int/None
threshold = int(reference_timestamp)  # 统一为 int
if value and value < threshold:       # int vs int，不会报类型错误
    continue
```
