# HN Algolia API 端点选择指南

## 核心结论

**时间过滤场景必须用 `/api/v1/search_by_date`，不能用 `/api/v1/search`。**

## 端点对比

| 端点 | 排序 | numericFilters 生效 | 适用场景 |
|------|------|:---:|------|
| `/api/v1/search` | 按**相关性**排序 | ⚠️ 24h窗口可能返回0 | 通用搜索、不限时间 |
| `/api/v1/search_by_date` | 按**时间倒序** | ✅ 稳定生效 | 时间窗口过滤（24h/7d） |

## 已知问题（2026-08 实测）

`/api/v1/search` + `numericFilters=created_at_i>TIMESTAMP` 在 24 小时窗口下返回 **0 结果**（即使不加时间过滤有 190 万条 AI 相关结果）。同样的过滤条件在 `/api/v1/search_by_date` 下返回 160+ 条。

**推测原因：** relevance 排序端点的时间过滤与评分算法冲突，导致窗口内结果被过滤掉。

## URL 编码注意

`numericFilters` 中的 `>` 必须编码为 `%3E`：

```bash
# ✅ 正确
curl -s "https://hn.algolia.com/api/v1/search_by_date?query=AI&tags=story&hitsPerPage=10&numericFilters=created_at_i%3E$(date -d '24 hours ago' +%s)"

# ❌ 可能出问题（未编码的 >）
curl -s "https://hn.algolia.com/api/v1/search_by_date?query=AI&tags=story&hitsPerPage=10&numericFilters=created_at_i>$(date -d '24 hours ago' +%s)"
```

## 查询语法

Algolia HN API 的 `query` 参数支持布尔运算符：
- `AI OR LLM OR deep learning` — 多关键词并集
- 空格需要编码为 `%20`（URL 安全）
- `tags=story` 限制只搜 HN 帖子（排除评论）
