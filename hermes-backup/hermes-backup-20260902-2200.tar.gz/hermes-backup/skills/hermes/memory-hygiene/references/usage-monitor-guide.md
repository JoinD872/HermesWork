# 两条 Memory Store 的使用率监控指南（2026-06-29 确立）

## 背景

Hermes Agent 有两个独立的 memory store：
- `MEMORY.md`：agent 的个人笔记（环境事实、项目规范、工具特性、经验教训）
- `USER.md`：agent 知道的用户信息（偏好、沟通风格、预期、工作流习惯）

**各自有独立字符上限**，且互不共享。
长期以来 **USER.md 被严重忽略**——2026-06-29 实测已达 96%（2,639/2,750 chars）而无人触发告警。

## 监控方法

### 检查脚本（适用于 cron job / 健康检查）

```python
import os

mem_dir = os.path.expanduser('~/.hermes/memories')
limits = {'MEMORY.md': 5000, 'USER.md': 2750}
alerts = []

for name, limit in limits.items():
    path = os.path.join(mem_dir, name)
    if not os.path.exists(path):
        continue
    with open(path, 'r', encoding='utf-8') as f:
        chars = len(f.read())
    pct = chars / limit * 100
    status = '⚠️ 需清理' if pct > 80 else '✓ 正常'
    if pct > 80:
        alerts.append(f'{name}: {chars}/{limit} chars = {pct:.1f}% {status}')
    print(f'{name}: {chars}/{limit} chars = {pct:.1f}% {status}')

if alerts:
    print('\n--- 需关注的 store ---')
    for a in alerts:
        print(a)
```

### 告警阈值

| Store | 上限 | 80% 警告线 | 95% 危险线 |
|-------|------|-----------|-----------|
| MEMORY.md | 5,000 | 4,000 | 4,750 |
| USER.md | 2,750 | 2,200 | 2,612 |

- 超过 80%：输出告警，建议清理
- 超过 95%：危险，add 操作可能失败，需要用 replace 技巧写入

## 清理 USER.md 的特殊策略

USER.md 的内容（用户偏好、行为模式）比 MEMORY.md 每条的价值更高，但同样可能积累过时信息。

### 可以合并的
- 同一用户偏好的多条分散记录 → 压缩为一条综合表述
  - 如多条提及「报告偏好：详细全面」→ 一条带完整描述

### 可以精简的
- 长的用户描述去掉过渡句/解释性文字，只留关键事实
- 「用户说...」→ 直接记事实本身

### 不要删除的
- 用户明确表达的「喜欢 X」「不要 Y」「沟通方式」类偏好
- 这些都是 agent 行为准则，删除会导致 agent 行为回退

### 可以删除的
- 已过时的临时状态（如某次分析的结论 → 已沉淀到 skill/文档）
- 一次性项目快照（某次协作记录 → 已有 session 记录）
- 不再使用的偏好（用户后来改口了）
