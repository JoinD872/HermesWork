#!/usr/bin/env python3
"""
check_memory.py — 扫描 MEMORY.md 和 USER.md

功能：
1. 报告两条 store 的使用率（chars + %）
2. 找出 MEMORY.md 中 stale（28天未验证）记忆
3. 超 80% 使用率时输出告警

用法：
  python3 check_memory.py [--cleanup]
  --cleanup: 删除 status=dead 的记忆块（仅 MEMORY.md）
"""

import re
import sys
from datetime import datetime
from pathlib import Path

MEMORIES_DIR = Path.home() / ".hermes" / "memories"
MEMORY_PATH = MEMORIES_DIR / "MEMORY.md"
USER_PATH = MEMORIES_DIR / "USER.md"

STORES = [
    ("MEMORY.md", MEMORY_PATH, 5000),
    ("USER.md", USER_PATH, 2750),
]

STALE_THRESHOLD_DAYS = 28
FRESH_THRESHOLD_DAYS = 7


def check_usage() -> list:
    """Check character usage for both stores. Returns list of alert strings."""
    alerts = []
    print("=" * 55)
    print("MEMORY USAGE REPORT")
    print(f"Checked: {datetime.now():%Y-%m-%d %H:%M}")
    print("=" * 55)

    for name, path, limit in STORES:
        if not path.exists():
            print(f"\n⚠️  {name}: file not found at {path}")
            continue
        chars = path.read_text(encoding='utf-8').strip().__len__()
        pct = chars / limit * 100
        bar_len = 30
        filled = int(bar_len * pct / 100)
        bar = '█' * filled + '░' * (bar_len - filled)

        if pct > 95:
            status = '🔴 DANGER'
            alerts.append(f'{name}: {chars}/{limit} chars = {pct:.1f}% (danger, add may fail)')
        elif pct > 80:
            status = '⚠️  WARNING'
            alerts.append(f'{name}: {chars}/{limit} chars = {pct:.1f}% (needs cleanup)')
        elif pct > 50:
            status = '🟡 OK'
        else:
            status = '🟢 GOOD'

        print(f"\n{name}:")
        print(f"  {bar}")
        print(f"  {chars:,}/{limit:,} chars = {pct:.1f}%  {status}")

    return alerts


# ---- stale memory detection (MEMORY.md only) ----


def parse_frontmatter(block: str) -> dict:
    fm = {}
    match = re.search(r'<!--\s*(.*?)\s*-->', block, re.DOTALL)
    if not match:
        return fm
    for line in match.group(1).strip().splitlines():
        if ':' in line:
            key, val = line.split(':', 1)
            fm[key.strip()] = val.strip()
    return fm


def get_status_from_fm(fm: dict) -> str:
    status = fm.get('status', '')
    if status in ('dead',):
        return status
    created_str = fm.get('created_at', '')
    if not created_str:
        return 'unknown'
    try:
        last_verified_str = fm.get('last_verified', created_str)
        now = datetime.now()
        days_since_verified = (now - datetime.strptime(last_verified_str, '%Y-%m-%d')).days
        if days_since_verified > STALE_THRESHOLD_DAYS:
            return 'stale'
        elif days_since_verified <= FRESH_THRESHOLD_DAYS:
            return 'fresh'
        return 'valid'
    except (ValueError, TypeError):
        return 'unknown'


def get_status_from_date(date_str: str) -> str:
    if not date_str:
        return 'unknown'
    try:
        created = datetime.strptime(date_str, '%Y-%m-%d')
        now = datetime.now()
        days = (now - created).days
        if days > STALE_THRESHOLD_DAYS:
            return 'stale'
        elif days <= FRESH_THRESHOLD_DAYS:
            return 'fresh'
        return 'valid'
    except ValueError:
        return 'unknown'


def check_stale_memory() -> dict:
    """Scan MEMORY.md for stale entries."""
    if not MEMORY_PATH.exists():
        return {'error': f'MEMORY.md not found at {MEMORY_PATH}'}

    content = MEMORY_PATH.read_text()

    # New format (frontmatter blocks)
    new_format_blocks = []
    pattern = re.compile(
        r'(<!--\s*\n.*?\n-->)\s*\n?(.*?)(?=\n<!--|\Z)',
        re.DOTALL
    )
    for match in pattern.finditer(content):
        fm_block = match.group(1)
        body = match.group(2).strip()
        fm = parse_frontmatter(fm_block)
        new_format_blocks.append({
            'format': 'new',
            'id': fm.get('id', '(no id)'),
            'fm': fm,
            'body': body,
            'status': get_status_from_fm(fm),
        })

    # Old format (§-delimited)
    old_format_entries = []
    sections = content.split('\n§\n')
    for section in sections:
        section = section.strip()
        if not section or section.startswith('<!--'):
            continue
        if re.match(r'^#+\s', section):
            # Headered sections — try to find a date
            date_match = re.search(r'(\d{4}-\d{2}-\d{2})', section)
            date_str = date_match.group(1) if date_match else None
            status = get_status_from_date(date_str) if date_str else 'unknown'
            old_format_entries.append({
                'format': 'old',
                'id': date_str or '(undated)',
                'date': date_str,
                'body': section[:100],
                'status': status,
            })

    all_entries = new_format_blocks + old_format_entries

    stats = {'fresh': 0, 'valid': 0, 'stale': 0, 'dead': 0, 'unknown': 0}
    stale_entries = []
    for e in all_entries:
        stats[e['status']] += 1
        if e['status'] == 'stale':
            stale_entries.append(e)

    return {
        'entries': all_entries,
        'stats': stats,
        'stale': stale_entries,
    }


def main():
    cleanup = '--cleanup' in sys.argv

    # 1. Usage check (both stores)
    alerts = check_usage()

    # 2. Stale memory check (MEMORY.md only)
    result = check_stale_memory()

    if 'error' in result:
        print(f"\n⚠️  {result['error']}")
    else:
        print("\n" + "=" * 55)
        print("STALE MEMORY CHECK (MEMORY.md)")
        print("=" * 55)

        stats = result['stats']
        total = sum(stats.values())
        print(f"Total entries: {total}")
        print(f"  fresh:  {stats['fresh']}  (≤{FRESH_THRESHOLD_DAYS}d old)")
        print(f"  valid:  {stats['valid']}  ({FRESH_THRESHOLD_DAYS}-{STALE_THRESHOLD_DAYS}d old)")
        print(f"  stale:  {stats['stale']}  (>{STALE_THRESHOLD_DAYS}d old)")
        print(f"  dead:   {stats['dead']}")
        print(f"  unknown:{stats['unknown']}")

        if result['stale']:
            print(f"\n⚠️  STALE MEMORIES ({len(result['stale'])}):")
            print("-" * 55)
            for e in result['stale']:
                fmt_label = "[NEW]" if e['format'] == 'new' else "[OLD]"
                try:
                    verified = e['fm'] if e['format'] == 'new' else {}
                    ref_date = verified.get('last_verified', verified.get('created_at', e.get('date', '2000-01-01')))
                    days = (datetime.now() - datetime.strptime(ref_date, '%Y-%m-%d')).days
                except (ValueError, TypeError):
                    days = '?'
                preview = e.get('body', '')[:80]
                print(f"\n  {fmt_label} {e['id']} (stale ~{days}d)")
                print(f"      preview: {preview}...")
        else:
            print("\n✅ No stale memories found.")

    # 3. Exit with code
    if alerts:
        # At least one store > 80%
        print("\n⚠️  RECOMMENDATION: Cleanup needed for stores above.")
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
