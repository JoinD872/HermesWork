---
name: github-file-read-write
description: GitHub 私人仓库文件读写 — 从 JoinD872/HermesWork/workspace/ 上传/下载/修改 Excel 等文件，用 PAT 认证
risk: write-safe
---

# GitHub 私人仓库文件读写

## 认证

Token 在 `/root/.hermes/scripts/hermes-backup.sh`，不要在 `.env` 里找：
```bash
GITHUB_PAT=$(grep -o 'ghp_[a-zA-Z0-9]*' /root/.hermes/scripts/hermes-backup.sh | head -1)
```

## 上传文件

```bash
GITHUB_PAT=$(grep -o 'ghp_[a-zA-Z0-9]*' /root/.hermes/scripts/hermes-backup.sh | head -1)
REPO="JoinD872/HermesWork"
BRANCH="main"
CONTENT=$(base64 -w 0 /path/to/file.xlsx)

curl -s -X PUT \
  -H "Authorization: token $GITHUB_PAT" \
  -H "Content-Type: application/json" \
  "https://api.github.com/repos/${REPO}/contents/workspace/File.xlsx" \
  -d "{
    \"message\": \"📝 提交说明\",
    \"content\": \"${CONTENT}\",
    \"branch\": \"${BRANCH}\"
  }"
```

## 下载文件

```bash
GITHUB_PAT=$(grep -o 'ghp_[a-zA-Z0-9]*' /root/.hermes/scripts/hermes-backup.sh | head -1)
REPO="JoinD872/HermesWork"

curl -s -H "Authorization: token $GITHUB_PAT" \
  "https://api.github.com/repos/${REPO}/contents/workspace/Test.xlsx" | \
  python3 -c "
import sys,json,base64
d=json.load(sys.stdin)
content = base64.b64decode(d['content'])
with open('/tmp/downloaded_file.xlsx','wb') as f:
    f.write(content)
"
```

## 修改已存在文件（需先获取 sha）

```bash
# 获取当前文件的 sha
SHA=$(curl -s -H "Authorization: token $GITHUB_PAT" \
  "https://api.github.com/repos/${REPO}/contents/workspace/Test.xlsx" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['sha'])")

# 用新内容 + sha 更新
curl -s -X PUT \
  -H "Authorization: token $GITHUB_PAT" \
  -H "Content-Type: application/json" \
  "https://api.github.com/repos/${REPO}/contents/workspace/Test.xlsx" \
  -d "{
    \"message\": \"🔄 更新文件\",
    \"content\": \"${CONTENT}\",
    \"sha\": \"${SHA}\",
    \"branch\": \"${BRANCH}\"
  }"
```

## 列出目录内容

```bash
curl -s -H "Authorization: token $GITHUB_PAT" \
  "https://api.github.com/repos/${REPO}/contents/workspace" | \
  python3 -c "import sys,json; items=json.load(sys.stdin); [print(f\"{i['type']:4}  {i['name']}\") for i in items]"
```

## 关键坑

1. **Token 位置**：在 `hermes-backup.sh` 而非 `.env`
2. **上传需 base64**：文件内容必须 base64 编码
3. **修改文件必须带 sha**：否则报 422 错误
4. **更新时先读 sha**：每次更新都要重新 fetch 最新 sha
