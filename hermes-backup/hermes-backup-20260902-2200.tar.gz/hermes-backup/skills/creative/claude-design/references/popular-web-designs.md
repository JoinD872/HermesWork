# Popular Web Designs — Design System Reference

54 production-grade design systems extracted from real websites. Use when the user wants a known brand's visual identity — Stripe, Linear, Vercel, Notion, Airbnb, Figma, GitHub, Discord, etc.

## What each template contains

- **Colors:** Primary, secondary, neutral, functional
- **Typography:** Font family, weights, size hierarchy
- **Components:** Buttons, inputs, cards, navigation
- **Layout rules:** Spacing, grid, responsive breakpoints
- **CSS values:** Complete ready-to-use CSS

## When to use

User wants to match a known brand's look: "make it look like Stripe", "give me Linear vibes", etc.

## How to use

Load `relevant_designs_data` from web_search or the design gallery. The 54 design systems are not stored locally; search for them when needed:

```bash
web_search("Stripe design system colors typography components")
web_search("Linear design system CSS values 2025")
```
