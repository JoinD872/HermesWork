# Gemini vs ChatGPT vs DeepSeek 深度调研报告 (2026年5月)

## 先澄清：不是"Gemini 3.5"，而是「Gemini 2.5 Pro」仍是主力

当前 Google 旗舰模型为 **Gemini 2.5 Pro**（2025年3月发布），而非 Gemini 3.0 或 3.5。Gemini 3.0/3.1 Pro 已发布但**用户反馈普遍认为是降级**（见下文），社区共识是回到 2.5 Pro 作为首选。
