# MEMORY.md — 小H 核心记忆

## 任务规范
多步骤任务：每步完成后立即写入 `~/.hermes/task_checkpoint.json`（单写，不再双写 MEMORY.md）。Reset 重连后必须发飞书通知。

## DM 强制路由协议
大佬 DM 实质任务 → 写入 pending 分发：
- 游戏/UE5 → 小策
- 健康/颈椎/胃炎 → 小健
- AI/ML论文/算力 → 小研
- VPS/隧道/Docker → 老V
- 架构/跨Agent/日常 → 小H 自己处理

## 用户期望
- 给链接直接整理完整内容，不让大佬自己点
- 信息要完整详细，不接受粗略摘要
- "你去验证一下" = 自己验完再汇报
- "先彻底关掉它" = 立即执行

## 浏览器环境
- agent-browser v0.26.0 + Chrome 147，camoufox 已装
- VPS 出口 IP（洛杉矶）被百度/知乎屏蔽，bilibili ✅
- SearXNG（localhost:8888）✅ 正常

## 图片理解
- vision_analyze 已禁用
- 统一走 MMX CLI：`mmx vision describe <路径>`
- MiniMax MCP 有平台级 bug（1004 login fail），不要用

## 联邦 Webhook（实测可用）
| Agent | Webhook |
|-------|---------|
| 小研 | https://open.feishu.cn/open-apis/bot/v2/hook/20acd1d4-fe75-404e-ac5e-5e49bc5c587b |
| 小健 | https://open.feishu.cn/open-apis/bot/v2/hook/00394231-ecf8-4e00-9a9b-50fc747d44bd |
| 小策 | https://open.feishu.cn/open-apis/bot/v2/hook/fd3ea207-82cf-4e19-a134-45926df90c0b |
| 老V | https://open.feishu.cn/open-apis/bot/v2/hook/9fa84937-aa99-4c18-93f2-a0736dcf86fa |

## 联邦 Agent 画像
- **小研**：AI/ML 深度研究，不处理非AI领域，每轮聚焦单一主题
- **小健**：健康顾问，颈椎/腰椎/胃炎/睡眠，医学红线必告医院
- **老V**：VPS/隧道/Docker，不碰域名/DNS/业务代码，Linux only
- **小策**：UE5/游戏策划，不输出完整代码文件

## 搜索方案
SearXNG(localhost:8888) > mcp_searxng_search > 其他

## cron 时区
GMT+8，凌晨3点 = cron 19:00 UTC

## MiniMax 图片生成（无解）
- CN key（sk-cp）无法访问 Global 图片API（api.minimax.io）
- 备用：`https://image.pollinations.ai/prompt/<prompt>.png`

## Agent 共性缺陷
大佬反馈：遇到难点死磕一条路不变通，不会换搜索方式，不会主动查官方文档。

## 联邦 Cron Job ID
- 老V: a259819c24f4（17:00 GMT+8）
- 小研: ef20c63571f7（03:00 GMT+8）
- 小健: a2d3c2998db3（19:00 GMT+8）
- 小策: 5e3728b97221（05:00 GMT+8）
- MiniMax监控: 97cec314a2fa（17:00 GMT+8）

## 联邦验证原则
callback 文件存在 + pending 状态 done = 任务闭环。`success: true` 不代表真正执行。

## 经验归档模板
```
## [<领域>] <坑点标题>
- 现象：<报错>
- 解法：<CLI/代码>
- 时间：<YYYY-MM-DD> | 贡献者：<Agent>
```

## 汇报规范
统一用 federation-result-beautifier：emoji + 表格 + 结论先行 + ⏱时间戳。严禁直接贴原始 JSON。

## ⚡ 观察项（3-5天）
1. Cron 输出是否更清晰（骨架+类型模块）
2. risk 标签（141个skill已加）是否帮助判断风险
3. dangerous skill 是否触发备份/回滚
4. 是否出现格式过重/啰嗦 → 不加规则，压缩输出

## 刚完成（2026-04-28）
- 小研 cron 升级：失败案例库+替代方案+触发式架构提醒
- 11个 dangerous skill 加了备份/回滚/操作分级
- 141个 skill 全部加 risk frontmatter（read-only:50/write-safe:58/write-dangerous:33）
- 新建 cron-output-standard skill：输出格式规范（任务层）
- 8个 cron job 全部附加 cron-output-standard
- Recovery Layer 体系整理完成：P0全部执行
  - task_checkpoint.json 增强字段（task_id/priority/owner_agent/completed_steps/pending_steps/validation_commands/rollback_commands/risks）
  - sync-status skill 重写，支持增强字段 + 强制摘要格式
  - hermes-internals 补充 Gateway 启动检查 + 防盲执行规则
  - session-reset-recovery P0章节对齐增强字段
  - 取消双写 MEMORY.md，任务状态统一写 task_checkpoint.json

## Recovery 安全闭环（核心原则）
重启 / Reset 恢复后，小H第一步必须验证当前系统状态，不得直接继续执行高风险命令。

五环：
1. 飞书预通知（重启前）
2. checkpoint（任务状态）
3. 防盲执行（禁止危险命令）
4. 验证优先（先验证再执行）
5. 用户确认（等用户说继续）

status 保持 free-form 文字，不新增状态机命名规则。
§
## VPS IP 封锁（重要）
VPS 192.3.241.244 被 Epic Games + Cloudflare 屏蔽，无法访问：dev.epicgames.com / docs.unrealengine.com / unrealengine.com。搜索 Epic 相关内容走 SearXNG + 第三方站（Tom Looman / GameFromScratch / Vagon）。
§
## Hermes 系统管理风格（2026-05-02）

用户使用 GPT 作为"架构评审"角色：小H 执行自我审查 → GPT 出评审报告 → 用户转发指令给小H 执行。这是一种「AI 审查、AI 改进」的迭代模式。

执行风格偏好：
- 指令分 P0/P1/P2 优先级，依次执行
- 每个改动都要有验证步骤和回滚方案
- 不接受"先改再说"，必须"先诊断→列影响→再执行"
- 完成后必须出结构化汇报（GPT 要求统一格式）

## 小研研究沉淀问题（未解决）

现状：小研 callbacks（MINIMAX_DAILY/PAIN/UE5WP）存在 callbacks/ 但小H 不主动读取。
结果：研究"存了"但没有"用了"，MEMORY.md 里没有沉淀任何研究结论。
需要：研究结论自动同步 global_knowledge.md，或 cron 输出包含"对小H有用的行动项"。