---
name: hermes-github-backup
description: Hermes Agent 配置备份到 GitHub 私人仓库（PAT认证 + 每日Cron + 10个归档轮换）— 含执行和验证完整工作流
risk: write-dangerous
---

# Hermes GitHub 备份机制

## 核心设计

**格式**：每次备份生成单个 tar.gz 文件，文件名含精确时间戳，永远不覆盖旧文件。
**轮换**：保留最近 10 个归档包，超出自动删除最早的。
**路径**：`hermes-backup/hermes-backup-YYYYMMDD-HHMM.tar.gz`

## 备份内容（P0+P1）

| 类别 | 内容 | 大小 |
|------|------|------|
| P0 核心 | SOUL.md, MEMORY.md, USER.md, global_knowledge.md, config.yaml, auth.json, channel_directory.json, cron/jobs.json | ~200KB |
| P0 profiles | 4个Agent的 SOUL.md + config.yaml | ~50KB |
| P1 skills | ~/.hermes/skills/ 整体（全部SKILL.md） | ~3.8MB |
| P1 research | ~/.hermes/research/ | ~40KB |
| P2 federation | callbacks 历史记录 | ~4KB |

**注意：不要备份 hermes-agent/ 源码（2GB），不要备份 profiles/*/skills/（是 ~/.hermes/skills/ 的副本）**

## GitHub 仓库最终结构

```
HermesWork/
└── hermes-backup/
    ├── hermes-backup-20260427-0732.tar.gz   ← 第一个归档
    ├── hermes-backup-20260427-0737.tar.gz
    └── ...最多10个，到第11个时自动删除最早的
```

## 备份脚本

`/root/.hermes/scripts/hermes-backup.sh`

核心逻辑：
1. **始终做全新克隆**（`rm -rf + git clone`，避免 `git pull` 导致的本地索引损坏累积）
2. 临时目录打包所有备份内容为 tar.gz（含精确时间戳）
3. **先统计已有备份数，再删最旧的旧文件，最后才 add 新文件**
4. git commit + push

> ⚠️ **重要改进（2026-06-09）**：脚本从 `git pull` 策略改为 `rm -rf + git clone` 全量克隆。原 `git pull` 策略在本地仓库索引损坏时（`Error building trees` / `invalid object`）无法恢复，导致备份失败。全量克隆虽多耗几秒带宽，但保证每次运行都是从干净状态开始。

> ⚠️ **仓库只含备份文件**：`HermesWork` 仓库应仅含 `hermes-backup/` 目录。如果发现 `sucai/`、`README.md`、`workspace/` 等无关文件，应清理（`git rm --cached`）并提交，避免 git 对象损坏影响备份流程。

```bash
# 轮换逻辑（✅ 正确实现）
tar -czf "$REPO_DIR/hermes-backup/${ARCHIVE_NAME}" -C "$TEMP_DIR" hermes-backup

# 步骤3：先统计已有备份（git add 之前做，避免新文件干扰计数）
EXISTING_BACKUPS=$(git ls-files hermes-backup/hermes-backup-*.tar.gz 2>/dev/null | sort -t'-' -k2 -k3)
EXISTING_COUNT=$(echo "$EXISTING_BACKUPS" | wc -l)

if [ "$EXISTING_COUNT" -ge "$MAX_BACKUPS" ]; then
    # 已有 >= 10 个时，删除最旧的 N 个（留出位置给新备份）
    DELETE_COUNT=$((EXISTING_COUNT - MAX_BACKUPS + 1))
    TO_DELETE=$(echo "$EXISTING_BACKUPS" | head -n $DELETE_COUNT)
    echo "$TO_DELETE" | while read -r old_backup; do
        [ -n "$old_backup" ] && git rm -f "$old_backup" 2>/dev/null || true
    done
fi

# 步骤4：加入新文件
git add "hermes-backup/${ARCHIVE_NAME}"
git commit -m "📦 Backup ${BACKUP_DATE}"
git push origin main
```

> ⚠️ **关键陷阱**：`sort -t'-' -k2 -k3` 按日期升序排列（最旧的在前），`tail -n +11` 会取到**最新**的文件而非最旧的——必须用 `head -n $DELETE_COUNT` 取最旧的来删除。

## 旧版错误逻辑（❌ 勿用）

```bash
# ❌ 错误：先 add 再统计，导致新文件被计入 TOTAL，tail -n +11 会误取最新备份
git add "hermes-backup/${ARCHIVE_NAME}"
BACKUPS=$(git ls-files hermes-backup-*.tar.gz | sort)   # 含新文件，共11个
TOTAL=$(echo "$BACKUPS" | wc -l)                        # 11
TO_DELETE=$(echo "$BACKUPS" | tail -n +11)              # 误取 newest！
```

> ⚠️ **陷阱**：`ls` 列举本地文件系统，`git ls-files` 列举 git 追踪的文件。
> 新创建的 tar.gz 在 `git add` 之前对 git 不可见——若基于 `ls` 做保留判断，
> 刚创建的备份会被误判为第11个最旧备份而差点被删除。

## GitHub PAT 认证（坑点）

```bash
# ❌ 不生效：credential.helper store 方式
git config --global credential.helper "store --file ~/.git-credentials"
git ls-remote https://github.com/USER/REPO.git  # 失败：No such device

# ✅ 有效方式：clone/pull 时直接把 PAT 嵌在 URL 里
git clone "https://ghp_TOKEN@github.com/USER/REPO.git" /tmp/repo
```

## 恢复步骤（新机器）

```bash
# 1. 拉取仓库
git clone https://github.com/JoinD872/HermesWork.git /tmp/restore

# 2. 解压最新归档
LATEST=$(ls -1 /tmp/restore/hermes-backup/*.tar.gz | sort | tail -1)
tar -xzf "$LATEST" -C /tmp/restore

# 3. 恢复配置（覆盖）
cp -r /tmp/restore/hermes-backup/* ~/.hermes/
```

## 备份验证（Cron 执行后验证链）

每次备份运行后，建议按以下链条验证完整性，确保备份可靠到达远程仓库：

### 验证链（五步）

| 步骤 | 检查项 | 命令 | 通过标准 |
|------|--------|------|---------|
| 1 | 脚本退出码 | 脚本 `exit_code=0` | 0 |
| 2 | 归档文件存在 | `ls -lh ${REPO_DIR}/hermes-backup/hermes-backup-*.tar.gz` | 文件存在且 > 0 bytes |
| 3 | Git 提交存在 | `git log -1 --oneline` | 显示最新 commit message 含 `📦 Backup` |
| 4 | 远程同步确认 | `git fetch origin main && git rev-list --count --left-right origin/main..main` | 返回 `0\t0`（无 ahead/behind） |
| 5 | 文件数趋势 | `tar -tzf ${NEW_ARCHIVE} \| wc -l` 与昨日比较 | 无明显骤降（骤降 = 备份内容丢失） |

### 验证命令模板

```bash
# 进入仓库目录
cd /tmp/hermes-backup-daily

# 步骤2+3：确认归档存在且已提交
ls -lh hermes-backup/hermes-backup-$(date +%Y%m%d)*.tar.gz
git log -1 --oneline

# 步骤4：确认远程已同步（最关键的一步）
git fetch origin main --quiet
git rev-list --count --left-right origin/main..main
# 期望输出: "0\t0" — 本地与远端完全一致

# 步骤5：对比归档文件数
NEW_COUNT=$(tar -tzf hermes-backup/hermes-backup-$(date +%Y%m%d)*.tar.gz | wc -l)
YESTERDAY_COUNT=$(tar -tzf $(ls -1 hermes-backup/hermes-backup-*.tar.gz | sort | tail -2 | head -1) | wc -l)
echo "昨日: $YESTERDAY_COUNT 文件 → 今日: $NEW_COUNT 文件"
```

### 异常处理

- **`0 1` 或 `1 0`**（ahead/behind ≠ 0）：push 失败，尝试 `git push origin main` 重推
- **归档为 0 文件**：tar 命令失败，检查 TEMP_DIR 是否有源文件
- **归档大小骤降（>50%）**：可能的 cp 失败或技能目录缺失，手动检查 `$DEST_DIR` 内容

## 健康监控（长期趋势）

### 跟踪指标

| 指标 | 正常范围 | 告警条件 |
|------|---------|---------|
| 归档大小 | 3.0MB – 6.0MB（技能库规模依赖） | < 1MB 或 > 10MB |
| 归档文件数 | 950–1050（P0+P1 固定结构） | < 500（内容丢失）或 骤降 > 200（cp 失败） |
| 每日增量 | +0 ~ +30 文件（新 skill/research） | — |

### 趋势解读

- **文件数稳步增长**：正常 — 技能库和研究资料在扩充
- **大小无变化但文件数增加**：新 skill 为 SKILL.md 文本文件，体积占比极小，合理
- **连续多日大小/文件数完全相同（稳态）**：在无新增 skill/research 的平稳期内，归档内容稳定是正常的预期行为。此时靠**验证链步骤 4（远程同步确认）** 判定备份是否成功，而非靠文件数波动。参见下方【稳态 vs 异常判断矩阵】。

### 稳态 vs 异常判断矩阵

| 场景 | 验证链步骤 1–4 结果 | 判定 | 行动 |
|------|-------------------|------|------|
| 多日相同大小/文件数 | ✅ 全部通过 | **稳态** — 技能库进入平台期 | 无需行动 |
| 多日相同大小/文件数 | ❌ 任何一步失败 | **故障** — 脚本实际未执行或提交失败 | 检查脚本 + 手动重跑 |
| 大小骤降 > 50% | ✅/❌ | **内容丢失** — cp 失败或目录缺失 | 立即检查 `$DEST_DIR` |
| 文件数骤降 > 200 | ✅/❌ | **结构性问题** — skill 目录被截断 | 对比 tar 内容与 `ls ~/.hermes/skills/` |
| 大小突然增长 > 30% | ✅ | **可能新增了大型文件**（参考图/二进制） | 检查 tar 内容确认是否预期 |

## 旧版备份残留说明

`/root/hermes-backups/`（注意带 's'）目录下存在旧版备份（约 4.3GB，含 `hermes-home-*.tar` 和 `hermes-local-diff-*.patch`），这是 2026-05-17 前的旧备份系统残留，与当前每日 Git 备份无关，可安全忽略或清理。当前备份系统统一在 GitHub 仓库管理归档。

## 已知坑点

- **本地 git 索引损坏（git fsck 显示 broken link / missing blob）**：当 `git pull` 报错 `Error building trees` 或 `invalid object ... for 'filename'`，且 `git fsck` 显示 missing tree/blob 时，`git read-tree HEAD` 和 `rm -f .git/index` 都无法修复（因 HEAD commit 本身引用了损坏的 tree）。**唯一修复方法**：删除本地仓库目录并重新克隆（`rm -rf $REPO_DIR && git clone ...`）。远程仓库通常是完好的，损坏仅限本地副本。
- `git ls-remote` 不读取 `~/.git-credentials`，认证失败 → 用 embedded token URL 解决
- skills 目录复制用 `cp -r ~/.hermes/skills/ skills/` 会嵌套成 `skills/skills/` → 先 mkdir -p 再复制
- **归档轮换用 `ls` 而非 `git ls-files`**：新创建的 tar.gz 在 git add 之前对 git 不可见，会被误判为第11个最旧归档而差点被删除 → 改用 `git add` 先加文件，再用 `git ls-files` 做判断
- **轮换逻辑顺序**：必须先统计旧备份并删除，再 add 新文件；若顺序反过来（先 add 再统计），`git ls-files` 会把新文件也算进去，导致 `tail -n +11` 误取**最新**的备份来删除
- **排序+tail 陷阱**：`sort -t'-' -k2 -k3` 对 `YYYYMMDD-HHMM` 格式按日期升序（最旧的在前），`tail -n +11` 取的是**最后一行 = 日期最晚的最新文件**，应该用 `head -n $DELETE_COUNT` 取最旧的文件来删除
- **du 命令失效**：`du -sh` 对已被 `git rm` 删除的文件返回错误，配合 `set -e` 会导致脚本提前退出 → 用 `du ... 2>/dev/null || echo "unknown"` 容错
- **git rm 返回非零**：`git rm` 对已删除但未提交的文件返回错误码 → 加 `|| true`
- PAT 写在脚本里，Security scan 会报警但用户自己批准，属于正常操作

## 关键信息

| 项目 | 值 |
|------|-----|
| 备份脚本 | `/root/.hermes/scripts/hermes-backup.sh` |
| Cron Job ID | `858137a1ff62` |
| Cron 表达式 | `0 22 * * *` = 每天 06:00 上海时间 |
| 目标仓库 | `github.com/JoinD872/HermesWork` |
| 归档路径 | `hermes-backup/hermes-backup-YYYYMMDD-HHMM.tar.gz` |
| 保留数量 | 永远 10 个（超出自动删除最早的） |
