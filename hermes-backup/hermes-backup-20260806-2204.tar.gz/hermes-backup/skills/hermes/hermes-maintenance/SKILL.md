---
name: hermes-maintenance
description: Hermes 升级/维护/回滚/网关重启全流程 — 升级前检查、依赖更新、重启模式、回滚预案、事后验证。避免「升完飞书断了」类事故。
version: 1.0.0
author: Hermes Agent (self-taught)
tags: [hermes, upgrade, gateway, maintenance, rollback, dependency]
risk: write-dangerous
---

# Hermes Maintenance

Hermes 大版本升级、网关重启、依赖管理、回滚的标准操作流程。

## ⚠️ 第一步：加载本 Skill

```bash
# 执行任何升级/维护操作前，先加载本技能
skill_view(name='hermes-maintenance')
```

失败案例：v0.19.0 升级时未加载本 skill，遗漏了依赖检查和沟通步骤，导致飞书断连事故（2026-07-21）。

## Upgrade Execution

### Phase 1: Pre-flight (升级前)

1. **LOAD THIS SKILL FIRST** — 往下每一步都不要跳过

2. **Read release notes** — 不要只看版本号，看 Highlights + Breaking Changes
   ```bash
   hermes --version                              # 当前版本
   ```

3. **Check dependency changes** — 平台插件可能有新的依赖参数
   重点检查 files changed 中的 plugins/platforms/ 目录：
   ```bash
   # 查看 feishu/telegram 等平台插件的最新改动
   git diff vOLD..vNEW -- plugins/platforms/ | grep -E '^[+-].*import|^[+-].*pip|^[+-].*requirement'
   ```
   特别关注：
   - `from lark_oapi` 相关 import 变化 → 需要升级 lark-oapi
   - 新出现的第三方库 import → pip install 先

4. **Update dependencies FIRST** — 在重启网关之前更新所有相关包
   ```bash
   cd ~/.hermes/hermes-agent
   source venv/bin/activate
   pip install lark-oapi --upgrade --break-system-packages  # Feishu SDK
   # 其他平台同理
   pip install -r requirements.txt 2>/dev/null || true
   ```

5. **Save rollback point** — 记录当前版本 tag，准备好回滚命令
   ```bash
   CURRENT_TAG=$(git describe --tags --always)
   echo "Current: $CURRENT_TAG  →  rollback: git checkout $CURRENT_TAG"
   ```

6. **Communicate** — 告知用户可能有一小段不可用时间（网关重启会断连）

### Phase 2: Upgrade (升级执行)

```bash
# 拉取新 tag
git fetch origin --tags
# 切换到目标版本
git checkout v2026.X.Y
# 验证版本
hermes --version
```

⚠ **不要依赖 `hermes update` 做 tag 级大版本升级**。`hermes update` 的行为：
- 只在 `main` 分支上 `git stash + git pull`，如果当前是 detached HEAD 或非 main 状态可能出错
- 本会话实测：`hermes update` 说"Already up to date"但版本还是旧的，原因是本地有 +4981 个 carry commits 导致 HEAD detached，update 没真正升级
- 正确方式：`git fetch --tags && git checkout v2026.X.Y`
- `hermes update` 适合小版本/patch 升级，大版本跳级用 git 手动操作

### Phase 3: Gateway Restart (重启网关)

⚠ **关键限制: 不能在网关进程内重启网关**
`hermes gateway restart`、`systemctl --user restart hermes-gateway` 等指令在 Feishu/Telegram 会话中会被网关拦截（SIGTERM 传播到子进程）。

正确做法 — 使用 Python subprocess 分离进程组：

```python
import subprocess, os
proc = subprocess.Popen(
    ['systemctl', '--user', 'restart', 'hermes-gateway'],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
    preexec_fn=os.setpgrp,  # 脱离网关进程组
)
```

或者从另一个终端/SSH 会话执行（不在网关内）。

⚠ **重要：重启网关后当前会话会被杀死，正在编辑的回复会丢失。**
- Python subprocess 返回后网关可能还在关闭中，不能立即发消息
- 重启后的第一条消息应简短确认网关是否恢复（如「在吗」）
- 不要在重启前发送长回复——那条回复极大概率丢失，用户收不到

### Phase 4: Post-flight (升级后验证)

1. **检查网关状态**
   ```bash
   systemctl --user status hermes-gateway
   # Active: active (running)  ✓
   ```
2. **检查平台连接**
   ```bash
   tail -50 ~/.hermes/logs/gateway.log | grep -E "connected|error|TypeError|traceback"
   # 应看到: ✓ feishu connected
   ```
3. **检查关键平台特有的兼容性**
   - Feishu: 确认 WebSocket 连接成功，无 `TypeError: unexpected keyword argument`
   - Telegram/Discord: 确认 bot 在线
4. **发一条测试消息** 确认能正常回复

### Safety Net: Systemd Auto-Recovery

如果升级后 gateway 崩溃，**不要慌**——默认配置下 `Restart=on-failure` 会自动重启：

```
# 日志中会出现：
TypeError → gateway exit(1) → systemd revive → 重连成功
```

常见首次失败模式：
- 依赖缺失 → 网关崩溃 → systemd 重启 → 第二次成功（可能因为缓存/重试路径不同）
- 本事故中 lark-oapi 缺失就是这样恢复的

所以升级后如果看到飞书短暂不可用（~1-2min），先检查日志而不是直接 rollback：

```bash
tail -50 ~/.hermes/logs/gateway.log | grep -E "error|Error|TypeError|connected|Exiting"
```

但如果持续 >5min 仍不可用，执行 Rollback。

### Phase 5: Rollback (回滚)

如果新版本有问题：

```bash
cd ~/.hermes/hermes-agent
git checkout <前一版本tag>
# 重启网关
```
注：rollback 后如果依赖有变化，可能需要降级依赖包版本。

## Known Pitfalls

| 陷阱 | 表现 | 处理 |
|------|------|------|
| **lark-oapi 版本不兼容** | `TypeError: Client.__init__() got an unexpected keyword argument 'extra_ua_tags'` | 升级 lark-oapi: `pip install lark-oapi --upgrade` |
| **在网关内重启网关** | `Blocked: cannot restart or stop the gateway from inside the gateway process` | 用 Python subprocess + os.setpgrp 或通过另一个 SSH 会话 |
| **hermes update 的 stash/restore** | `hermes update` 可能 stash 了本地提交后再 restore，导致版本混乱 | 升级用 `git fetch --tags + git checkout` 代替 |
| **PEP 668 (Debian/Ubuntu)** | pip 安装被阻止 | 加 `--break-system-packages` 或在 venv 内操作 |
| **版本检测混乱** | 部分升级后 `hermes --version` 显示错误版本号 | 确认 `git describe --tags --always` 指向正确 tag |
| **网关内重启被拦截** | `at`、`nohup`、`systemctl` 全部被网关拦截 | 只有 Python `subprocess.Popen(preexec_fn=os.setpgrp)` 有效 |

## Gateway Restart Reference

| 场景 | 可行方法 |
|------|---------|
| 从 CLI 终端（非网关） | `hermes gateway restart` |
| 从 SSH 会话 | `systemctl --user restart hermes-gateway` |
| 从网关内（飞书/Telegram 对话） | Python `subprocess.Popen([...], preexec_fn=os.setpgrp)` |
| 定时/自动化 | `echo "systemctl --user restart hermes-gateway" | at now + 1 minute`（可能被拦截）|

## Related

- `hermes-doctor` — 健康自检，升级后运行 `hermes doctor` 验证
- `hermes-agent` (bundled) — 升级评估方法论（是否该升级），本 skill 为升级执行流程
- `references/desktop-ws-boot.md` — Electron 桌面端 WebSocket 启动失败（`file://` 协议问题）：根因分析、修复方案、主进程重编译与 `app.asar` 打包流程
