---
name: netdisk-aggregator-search
description: 网盘聚合搜索 API 方案（PanHub/PanSou）——当主流搜索引擎被 VPS IP 风控时，找百度/夸克/阿里/UC/迅雷网盘资源的替代路径。一次搜索覆盖全网盘类型。
triggers:
  - 搜索引擎全部弹人机验证/验证码（Google、Bing、DDG、Yandex、百度、搜狗）
  - 需要找中文影视/动画/短剧资源的网盘链接
  - 需要跨多个网盘类型（百度/夸克/阿里/UC/迅雷）找同一资源
  - 用户要"最高清"版本，需要快速确认某资源是否已有高清流出
risk: read-only
created: 2026-07-31
---

# 网盘聚合搜索（PanHub/PanSou）

> 📎 延伸：VPS 被国内站封 IP 时（豆瓣 000 / 微博 403）的零成本绕行通道 —— RSSHub 公共实例实测可用，见 `references/rsshub-public-instance-bypass.md`

## 核心原则

> 搜索引擎不是网盘资源搜索的唯一入口。
> VPS 数据中心 IP 会被主流搜索引擎**全部**风控（人机验证），此时网盘聚合 API 直接爬 Telegram 资源频道，完全绕过搜索引擎。
> 搜狗可能首次成功，但第二次必被限流——不要依赖它。

## 首选：PanHub 在线 API（零部署，实测可用）

```bash
curl -s "https://panhub.shenzjd.com/api/search?kw=$(python3 -c 'import urllib.parse;print(urllib.parse.quote("资源名"))')"
```

- **参数名必须是 `kw`**（用 `keyword` 会报 400 `kw is required`）
- 返回 JSON 结构：
  ```json
  {"code":0, "message":"success", "data":{
    "total": 10,
    "merged_by_type": {
      "quark":  [{"url":"https://pan.quark.cn/s/xxx","password":"","note":"...","datetime":"2026-07-31T09:11:35Z"}],
      "baidu":  [{"url":"https://pan.baidu.com/s/xxx?pwd=y2wt","password":"","note":"...","datetime":"..."}],
      "aliyun": [...], "uc": [...], "xunlei": [...]
    }}}
  ```
- 聚合 80+ TG 频道 + 20+ 插件，按网盘类型自动归类
- 结果常是"目录合集"帖子（一个帖子含多部资源），目标资源要从 `note` 字段里确认，其余链接是合集里其他资源

## 备选：PanSou 自部署（fish2018/pansou，⭐14k）

```bash
# 纯后端 API 版
docker run -d --name pansou -p 8888:8888 ghcr.io/fish2018/pansou:latest
# 访问受限地区 TG 需要代理
#   PROXY=socks5://127.0.0.1:1080 或 HTTPS_PROXY/HTTP_PROXY
# 默认搜索 TG 频道 tgsearchers3，可用 CHANNELS 环境变量配置多个
```

特性：并发多频道搜索、插件扩展、二级缓存、网盘类型自动识别（含 115/PikPak/123/磁力/ed2k）。

## GitHub 找网盘搜索项目入口

```bash
# 中文关键词必须 urllib.parse.quote 编码；用 + 连接中文会解析失败/返回非 JSON
curl -s "https://api.github.com/search/repositories?q=$(python3 -c 'import urllib.parse;print(urllib.parse.quote("网盘 搜索 API"))')&sort=stars&per_page=5" -H "User-Agent: HermesAgent"
```

| 项目 | Stars | 说明 |
|:---|:---:|:---|
| fish2018/pansou | ⭐14k | 高性能网盘搜索 API，TG+插件，Docker 部署 |
| wu529778790/panhub.shenzjd.com | ⭐1.5k | PanHub 聚合搜索，**有在线站 panhub.shenzjd.com 可直接用** |
| Xwudao/lzpan_search | ⭐628 | 懒盘搜索，短剧网盘搜索 |
| towelong/panxiaozi | ⭐248 | 盘小子一站式网盘搜索 |

## 输出格式

沿用资源帖规范：画质/大小/集数/音轨 + 各网盘链接分行列出（百度链接 + 提取码单独标注，飞书会拦截 markdown 链接）。

## 常见坑

1. **新片判断**：院线上映 <1 月的电影，聚合搜索只会命中同名短剧/插曲/枪版在线站，不会有高清网盘资源——这是规律，不是搜索失败。高清要等院线期结束 + 流媒体上线（通常 2-6 个月）
2. **同名区分**：热门电影常有同名短剧（如《功夫女足》电影 vs 短剧《功夫女足之外星人篇》），先确认用户要哪个再搜
3. **合集目录**：TG 频道发的"短剧更新目录"类帖子含多部资源，链接指向整个目录，需要用户自行筛选
4. **Telegram 频道直接搜索**：`https://t.me/s/<channel>?q=<关键词>` 无需登录、不反爬，是最可靠的补充路径（bdwpzhpd / Aliyun_4K_Movies / YioveComplex / vip115hot / Netdisk_Movies）
