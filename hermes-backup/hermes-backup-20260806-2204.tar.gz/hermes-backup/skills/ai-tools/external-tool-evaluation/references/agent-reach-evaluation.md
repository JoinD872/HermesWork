# Agent Reach 评估报告（2026-07-13）

## 项目信息

- **仓库**: [Panniantong/Agent-Reach](https://github.com/Panniantong/Agent-Reach)
- **Stars**: 56.2k ⭐
- **版本**: v1.5.0
- **定位**: 给 AI Agent 一键装上互联网能力（多平台内容读取 + 搜索）
- **安装方式**: `pip install agent-reach` → `agent-reach install --env=auto`

## 评估总结（五维矩阵）

| 维度 | 结论 |
|------|------|
| **痛点匹配** | 🟡 部分匹配 — 用户已有 `community-scraping` 覆盖 7 个社区，但 YouTube 字幕、RSS、语义搜索是空白 |
| **能力冗余深度** | 🟡 部分冗余 — 网页/B站/V2EX/GitHub 与现有能力重叠；Exa 语义搜索、RSS 是新能力 |
| **集成成本** | 🟢 低 — 工具级，pip 安装即可，skill 文件装在 `~/.agents/skills/` 不冲突 |
| **激活条件** | 🟡 需要手动将渠道能力映射到 Hermes skill 体系，不能直接用它的 skill 机制 |
| **价值量级** | 🟢 有价值 — Exa 语义搜索 + RSS 是两个之前没有的能力 |

## 实测环境

- **VPS**: 192.3.241.244 (ColoCrossing AS36352)
- **OS**: Linux 6.8.0-134-generic
- **Python**: 3.11.15 via uv venv

## 7 个基础渠道实测结果

| 渠道 | 状态 | 实测详情 |
|------|:----:|---------|
| **GitHub** | ✅ | `gh repo view` / `gh search` 全部正常。`stargazersCount`（字段名带 s）⚠️ |
| **Exa 语义搜索** | ✅ | 通过 mcporter 接入，免费免 Key。工具名 `web_search_exa` / `web_fetch_exa`。参数必须用 `mcporter call exa.web_search_exa query="xxx" numResults=N` 格式，JSON 格式会报 validation error |
| **Exa web_fetch** | ✅ | 读取任意 URL 返回清洗后的 Markdown 内容 |
| **RSS/Atom** | ✅ | feedparser 完美工作，直接从 Python 调用 |
| **B站** | ✅ | 搜索 API (`/x/web-interface/search/all/v2`) + 视频详情 (`/x/web-interface/view`) 均可用，无需登录 |
| **V2EX** | ✅ | 公共 v1 API (`/api/topics/hot.json`) 工作正常。v2 API 需要 Token。Agent Reach doctor 可能报 API 问题但实际上是正确检测了 v2 |
| **YouTube** | ⚠️ | 热门视频标题可提取；部分视频需要 Cookie 认证（`Sign in to confirm you're not a bot`）。yt-dlp 有 JS challenge 警告但 title 仍能拿到 |
| **Jina Reader (网页)** | ❌ | VPS IP (AS36352) 被封锁，返回 401 `AuthenticationRequiredError`。桌面端应该正常 |

## mcporter 关键用法（实测验证）

mcporter 使用 `key=value` 参数格式（不是 JSON）：

```bash
# ✅ 正确
mcporter call exa.web_search_exa query="AI coding agent comparison 2025" numResults=2

# ❌ 错误（会报 validation error）
mcporter call exa.web_search_exa '{"query":"xxx","numResults":2}'
```

查看可用工具：
```bash
mcporter list-tools exa
```

## 与现有 Hermes 能力的对比

| 能力 | Hermes 现有方案 | Agent Reach 方案 | 建议 |
|------|---------------|-----------------|------|
| 网页阅读 | 浏览器工具 / curl | Jina Reader (r.jina.ai) | Jina 在 VPS 上被拦，暂不采用 |
| B站 | community-scraping 有方案 | bili-cli | 现有方案已够用 |
| V2EX | community-scraping 用 JSON API | 同一方案 | 已覆盖 |
| YouTube 字幕 | ❌ 无 | yt-dlp | **值得封装进 Hermes skill** |
| RSS | ❌ 无 | feedparser | **值得封装进 Hermes skill** |
| 语义搜索 | ❌ 无（SearXNG 是关键词搜索） | Exa via mcporter | **值得封装进 Hermes skill** |
| 小红书 | headless 被拦 | OpenCLI (需桌面浏览器) | 同思路，不可替代现有方案 |
| Twitter | community-scraping 有 | twitter-cli | 已有，不重复 |
| Reddit | community-scraping 有 crawl4ai | OpenCLI / rdt-cli | 已有，不重复 |

## 决策

**观察（observe）** — 不适合全盘接入 Hermes，但值得提取三个子能力：

1. **Exa 语义搜索** — 通过 mcporter 已有配置，可直接封装
2. **RSS 订阅** — feedparser 零依赖可用
3. **YouTube 字幕** — yt-dlp 已安装，需解决 Cookie 问题

**不采用的组件：**
- Agent Reach 的 skill 机制（为 OpenClaw/Claude Code 设计，与 Hermes skill 体系不兼容）
- Jina Reader（VPS IP 被拦）
- 需要浏览器登录态的渠道（小红书/Twitter 等，现有方案已覆盖）

## 触发条件

当以下情况出现时，升级为 experiment：
1. 用户频繁需要 YouTube 视频内容提取/总结
2. 用户需要追踪特定 RSS 源
3. 用户明确要求语义搜索能力
