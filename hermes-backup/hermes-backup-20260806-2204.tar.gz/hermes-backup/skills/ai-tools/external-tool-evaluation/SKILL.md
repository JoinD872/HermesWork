---
name: external-tool-evaluation
description: 评估第三方 AI 工具/代理是否值得接入 Hermes 工作流的决策框架。回答"你对 X 有什么看法？"时的思考模型。
version: 1.2.0
risk: read-only
---

# External Tool Evaluation

当用户问「Reasonix / 某个新 AI 工具 对我有帮助吗？」时的评估框架。

## 核心原则：两个问题，不是同一个

| 问题 | 含义 | 容易犯的错误 |
|------|------|-------------|
| **Q1: 用户本人有用吗？** | 工具对用户的工作流有没有直接价值 | 低估非编程用户的工具链差异 |
| **Q2: 对 Hermes 执行层有实验价值吗？** | 工具能否增强小H的能力（执行器、缓存、成本优化） | 混淆"小H能操作终端"与"小H有专用执行循环" |

**必须分别回答两个问题，再综合决策。** 不能因为 Q1=否 就直接判死刑，也不能因为 Q2=是 就强行接入。

## 六维评估矩阵

| 维度 | 检查项 | 结论方向 |
|------|--------|---------|
| **触点匹配** | 用户当前是否明确为此困扰？还是纯好奇？ | 有痛点→高优先级；纯好奇→观察 |
| **能力冗余深度** | 小H现有能力是否真正等价？还是"能做但不等于做得好"？ | 真正等价→冗余；能但不够专业→互补 |
| **集成成本** | 是否要改架构？新 Agent？新协议？新权限？ | 加工具=低；加Agent=中；改架构=高 |
| **隐私/安全合规** | 见下方「隐私安全评估维度」| 安全→可用；有风险→标注风险类型后再决策 |
| **触发条件** | 什么情况下值得重新评估？ | 无触发=无限期观察；有触发=候选 |
| **价值量级** | 解决了多疼的问题？节省了多少时间/成本？ | 微优化 vs 质变 |

## 🔴 隐私安全评估维度（2026-07-20 新增）

当用户问「X 对隐私好吗？」或评估需要用户提供凭据的第三方工具时，必须检查：

| 检查项 | 问什么 | 风险等级 |
|--------|--------|---------|
| **数据流向** | 用户数据去了哪里？经过谁的服务器？是端到端加密还是服务商明文可见？ | 本地处理=低；加密中转=中；服务商明文可见=高 |
| **凭据暴露** | 需要提供什么凭据？是只读 token 还是完整账号密码？AI 能操作到什么程度？ | API token=低；OAuth 只读=中；完整账号密码=高 |
| **AI 可见范围** | agent 能访问/看到什么级别的用户数据？屏幕内容？聊天记录？文件？ | 无访问=低；仅元数据=中；完整内容=高 |
| **处理模型** | 数据处理在本地（端侧）还是云端？云端处理后是否有留存政策？ | 纯本地=低；云端处理不留存=中；云端留存=高 |
| **服务商信誉** | 公司背景？公开安全白皮书？泄密历史？SOC2/ISO 认证？ | 知名厂商+认证=低；不知名=需警惕；曾有重大泄密=高 |
| **退出成本** | 停用后数据能完全删除吗？账号关联的第三方服务会受影响吗？ | 一键注销=低；需手动清理=中；无法彻底移除=高 |

**评估流程：**
1. 画出数据流图：用户 → 工具服务 → 第三方 API → AI（谁在哪个环节能看到什么）
2. 识别凭据暴露点：用户需要把什么交出去？交出去后能否撤销？
3. 如果任意一项风险等级为「高」→ 标注风险，提供替代方案（自托管/本地替代）
4. 参考案例见 `references/airtap-privacy-evaluation.md`

**典型案例：**
- **Airtap（云手机）**：用户在对方云手机上登录真实账号 → AI 能看见屏幕全部内容 → 凭据暴露=高，AI可见范围=高 → **不推荐**
- **Hermes（自托管 VPS）**：用户自己控制服务器，数据不经过第三方 → 凭据暴露=低（仅 API key），AI可见范围=中（但服务器用户可控） → **安全**

## 🔴 新增：资源约束预检查（进入 experiment 前必须做）

**2026-06-03 Headroom 案例驱动：** 桌面研究给 experiment，但实际验证发现 2.4GB 内存装不了 PyTorch，核心功能不可用 → 降级为 reject。

在进入实验（Phase 1）之前，先检查：

| 检查项 | 查什么 | 被什么拦住 |
|--------|--------|-----------|
| **内存** | `free -h` — 工具所需 vs 可用 | 大模型/ML 依赖（PyTorch ~2GB） |
| **磁盘** | `df -h` — 模型缓存大小 | 基础模型下载（ONNX/GGUF 几百 MB~GB） |
| **架构** | `uname -m` / GPU | CUDA-only 工具在 CPU-only 机器上不能用 |
| **Python 版本** | `python3 --version` | 部分库要求 3.10+ 甚至 3.12+ |
| **网络** | 能否连上 HuggingFace/GitHub | 国内 VPS 连 HF 可能超时 |

**如果任何一项红线被拦，直接从 experiment 降级为 observe（记录触发条件），不要等装上了再发现。**

## 决策分类

```
├─ 接入（adopt）       → 现在就用，融入主流程
├─ 试验（experiment）  → 最小接入，工具级，不建Agent
├─ 观察（observe）     → 暂缓，记录触发条件
└─ 否决（reject）     → 明确排除，技术或理念层面不兼容
```

**观察（observe）是最容易被跳过的分类**——直觉倾向直接否决或接入，但"暂缓+记录触发条件"往往是最诚实的结论。

## 试验→否决的过渡路径（新增）

有时工具的桌面评估给出 experiment，但实际 Phase 1 验证发现不可逾越的障碍：

```
desk research → experiment → Phase 1 安装验证 → 发现硬件瓶颈 → reject
```

**允许这样的路径。** 不能因为说了 experiment 就硬着头皮继续。关键是要干净地回退：
1. 杀掉启动的进程（proxy/daemon）
2. 卸载已安装的包（`pip uninstall`）
3. 清除下载的模型缓存（`rm -rf ~/.cache/huggingface/`）
4. 恢复被修改的配置
5. 验证状态恢复（`free -h`, `ss -tlnp`, `df -h`）

**案例：** Headroom proxy 启动后下载了 156MB ONNX 模型 + 配置 proxy 路由到 DeepSeek → 发现无 PyTorch 文本压缩不可用 → 全部还原，回到 observe。

## 最小接入原则（仅针对试验级决策）

如果决定试验，**只能以工具形式接入**：

```
小H 判断场景匹配 → 调用外部工具 → 获取输出（diff/验证结果）→ 小H审查 → 小H汇报
```

禁止：
- ❌ 外部工具作为独立 Agent
- ❌ 外部工具拥有独立 MEMORY
- ❌ 外部工具接入 federation/pending/callbacks
- ❌ 外部工具直接写 checkpoint
- ❌ 外部工具直接改关键系统

## 能力冗余陷阱（重要）

小H 能操作终端 **≠** 小H 有专用执行循环。

对照表：

| 能力 | 小H（通用） | 专用工具 | 差距 |
|------|-----------|---------|------|
| 执行单次终端命令 | ✅ 强 | ✅ 强 | 无 |
| 多轮代码 fix→test→fix 循环 | ⚠️ 能，但每轮打断+重建 prefix | ✅ 字节级 prefix 稳定 | 有差距 |
| 长时间项目级上下文 | ❌ 无项目概念 | ✅ 文件级持续上下文 | 差距大 |
| 低成本持续执行 | ⚠️ 依赖对话缓存 | ✅ 架构级缓存设计 | 有差距 |

**不要混淆"有能力做"和"有最优方式做"。**

## 🔴 新增：VPS IP 敏感度预检查（2026-07-13 新增）

**Agent Reach 案例驱动：** README 宣称 Jina Reader "装好即用"，但在 VPS (ColoCrossing AS36352) 上返回 401，因为该 ASN 被 Jina 列入匿名查询黑名单。

评估依赖**外部 API 的网页读取类工具**时，先检查 VPS IP 对目标的连通性：

```bash
# 快速连通性检查
curl -sI "https://<target-service>/" 2>&1 | head -5

# 检查 ASN
curl -s http://ip-api.com/json/$(curl -s ifconfig.me) | python3 -c \
  "import sys,json; d=json.load(sys.stdin); print(f'{d[\"org\"]} | proxy={d[\"proxy\"]} hosting={d[\"hosting\"]}')"
```

| ASN 类型 | 例子 | 常见问题 |
|----------|------|---------|
| ColoCrossing (AS36352) | 低价 VPS | Jina Reader、部分 CDN 会封锁 |
| Hetzner (AS24940) | 德国 VPS | Reddit、部分 AI API 会封 |
| AWS/GCP (AS16509/AS15169) | 云厂商 | Google 自家服务不受影响，但第三方网站常封锁 |
| 住宅 IP | 原生宽带 | 几乎无限制（最佳） |

**处理建议：**
- 如果工具依赖特定 API 且 VPS IP 被拦 → 标注 "桌面端可用，VPS 不可用"
- 不考虑换 IP，只考虑评估时有这个前置条件
- 记录被拦的服务名称和返回码，避免后续重复踩坑

## Claims vs Reality 陷阱（2026-06-03 新增）

第三方工具的 README/博客/Benchmark 数据**不可信直到本地验证**。这次会话的教训：

| 来源 | 宣称 | 本地实测 |
|------|------|---------|
| Headroom 文档 | 压缩率 60-95%，文本+日志+JSON 全覆盖 | JSON 69.4%（可用），文本/日志 0%（无 PyTorch） |
| Headroom 文档 | 零代码变更 | 只支持 OpenAI/Anthropic 路由，DeepSeek 需 `--openai-api-url` 配置 |

**核实策略：**
1. 找到宣称数据的来源——是作者自测还是第三方？
2. 在本地环境用真实工作负载重测（不跑 demo 用例）
3. 特别注意"not applicable"场景——工具可能没问题，但你的工作负载不在它的优化范围内
4. 区分"核心功能"和"附加功能"——核心不行就不要为附加功能买单

## 🔴 编码工具/订阅评估：先分清「IDE 工具」还是「API Provider」（2026-07-29 新增）

**案例驱动：** 用户问「国外 coding plan 有哪些」，小H 直接深挖了 Cursor/Devin/Copilot 的 IDE 套餐定价。用户随后纠正「我方向搞错了，我是需要用在 hermes 上的」。两次方向误判：第一次误以为要 IDE 计划，第二次差点又回到 Cursor。

**评估编码相关工具/订阅时，第一件事是确认需求轨道：**

| 轨道 | 用户要什么 | 评估什么 | 典型例子 |
|------|-----------|---------|---------|
| **A. IDE 工具** | 用户自己在编辑器里写代码 | IDE 计划、模型池、代码审查 | Cursor Pro / Copilot IDE |
| **B. API Provider** | Hermes 当后端用（配 base_url + api_key） | API 端点、月订阅、额度、速率限制 | OpenCode Go / DeepSeek / xAI / OpenRouter |

**关键检查（避免再次误判）：**
1. 先问/先判断：这个工具**有没有通用 API 端点**（`/v1/chat/completions` 之类）？没有 → 不是轨道 B。
2. **Cursor 类 IDE 计划不能当 Hermes provider** —— 无论额度多慷慨（如 Cursor Pro 含 Grok 4.5 畅用），模型只能在 IDE 内用，没有对外 API key。用户反复被这个吸引力吸引，必须每次明确点破。
3. GitHub Copilot 是特例：**有** GitHub Models API（`https://models.github.ai/inference/chat/completions`，PAT + models scope），但免费/Pro 层速率限制极低（高级模型 ~5 req/day），不适合当 Hermes 主力。
4. 已订阅的 OpenCode Go 本身是多模型聚合——先查它已包含哪些模型再评估外部方案（见 references/coding-plan-pricing-2026-07.md）。

**定价调研实操（SearXNG 反复返回 0 结果时的兜底）：**
1. 直接用浏览器访问**官方定价页**（cursor.com/pricing、github.com/features/copilot、api-docs.deepseek.com/quick_start/pricing、docs.x.ai/developers/pricing 等）
2. JS 渲染页用 `browser_console` 执行 `document.querySelector('main')?.innerText` 提取纯文本，比 snapshot/vision 更准
3. 汇率换算：xe.com/currencyconverter 拿当日中间价（2026-07 约 1 USD ≈ 6.77 CNY），标注"换算基于当日汇率"
4. 每个方案必须标注：付费模式（订阅 vs PAYG）、是否兼容 OpenAI/Anthropic API、速率限制、额度是否"耐用"

## 平行研究模式（2026-06-03 推荐）

评估多个工具时，并行优于串行：

```
小H 出研究框架（每个工具的 8-10 个问题）
  ↓
3 个 Codex 子任务并行（每个独立 browser/terminal 会话）
  ↓  ~8-10 分钟后同时返回
小H 综合对比 → 输出推荐矩阵
  ↓
Codex 审查结论（确保无遗漏）
```

**实测数据：** 3 个深度的 web 研究 + 代码审查，共约 **9 分钟**完成。串行估计要 25-30 分钟。

**注意事项：**
- 每个子任务需要有独立的搜索入口和明确的问题列表
- 共享的上下文（如 VPS 配置）必须在每个子任务的 context 中重复
- 返回后小H 必须用统一的评估框架对比，不能三个报告各自独立

## 触发条件记录

对每个观察级工具，必须记录具体触发条件。示例（Reasonix）：

```
触发条件：
1. 小H连续遇到多轮代码修复任务（实际痛点驱动）
2. Hermes 项目需要长时间自动修补
3. 小H改代码成功率持续不稳定
4. Codex 使用成本或额度受限
5. 需要验证 DeepSeek 专用 coding agent 是否更稳

警告：仅当条件1（实际痛点）出现时，才真正考虑。
条件2-5 只是"门槛"，不是"理由"。
```

## 参考案例

| 案例 | 文件 | 说明 |
|------|------|------|
| Airtap | `references/airtap-privacy-evaluation.md` | 云手机远程控制工具 — 隐私安全评估 + 数据流分析 + 凭据暴露评估 + 替代方案对比 |
| Reasonix | `references/reasonix-evaluation.md` | 外部代码执行器评估 |
| Crawl4AI | `references/crawl4ai-evaluation.md` | AI 爬虫评估（2026-05-26） |
| MarkItDown / Supermemory / Headroom | `references/2026-06-03-three-tools-evaluation.md` | 三工具对比 + Codex 审查 + Headroom 本地验证数据 |
| Agent Reach | `references/agent-reach-evaluation.md` | 多平台内容读取工具 — 安装 + 7 渠道实测 + 与 Hermes 社区情报体系对比 + 提取三个子能力（Exa/RSS/YouTube）|
| Cursor/Copilot/DeepSeek/Grok 编码计划 | `references/coding-plan-pricing-2026-07.md` | 国外 AI 编码计划 + API 订阅定价快照 — OpenCode Go 模型清单、DeepSeek/xAI/Copilot/Cursor/Devin/Claude 价格、IDE vs API 判断结论 |

## 本 skill 下的文件

- `references/airtap-privacy-evaluation.md` — Airtap 隐私安全评估（数据流分析 + 凭据暴露评估 + 替代方案）
- `references/reasonix-evaluation.md` — Reasonix 评估完整复盘
- `references/crawl4ai-evaluation.md` — Crawl4AI 评估（含实测数据、Reddit 绕过方案）
- `references/2026-06-03-three-tools-evaluation.md` — MarkItDown/Supermemory/Headroom 三工具评估（含本机验证数据）
- `references/agent-reach-evaluation.md` — Agent Reach 评估（2026-07-13，含 VPS 实测、渠道可用性矩阵、mcporter 参数坑）
- `references/coding-plan-pricing-2026-07.md` — 国外 AI 编码计划/API 订阅定价快照（2026-07-29，含 OpenCode Go 模型清单与 IDE vs API 判断结论）
