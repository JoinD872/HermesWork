---
name: adb-text-input-android
description: 通过 ADB 向 Android 注入文本 — ASCII 可用路径、中文输入的完整死路图（华为 ROM input text NPE、ADBKeyboard 无 receiver、Termux:API 签名不匹配、service call clipboard 构造难）、富文本编辑框的删除/全选技巧。当远程 UI 自动化需要往输入框打字（小红书发帖标题正文、搜索框等）时使用。
version: 1.0.0
created: 2026-08-06
tags: [adb, android, text-input, chinese, huawei, clipboard, ui-automation]
risk: write-safe
---

# ADB 文本注入（Android）

往 Android 输入框注入文本是远程 UI 自动化的老大难，尤其中文。本 skill 记录 2026-08-06 在华为 MatePad MRX-W19（Android 12 / HarmonyOS 精简版）上实测过的全部路径与死路。

## 触发条件

- 需要往 App 输入框（标题/正文/搜索）打字，但没有物理键盘
- 配合 adb-tablet-ui-automation 使用（本 skill 是它的「输入」子问题）

## ✅ 唯一可靠路径：ASCII

```bash
adb shell input text "Hermes AI on DeepSeek V4 Flash"
```

- 纯 ASCII（含空格，**用原始空格**，不要 `%20`）实测可用
- 前提：**先点击输入框让光标进去**（`input tap` 到 EditText 中心），否则 text 无声丢失
- `input keyevent KEYCODE_MOVE_END` + 逐字符 `KEYCODE_DEL` 可以清空/编辑

## ❌ 中文输入：全部死路（华为 ROM 实测）

| 方案 | 现象 | 结论 |
|:-----|:-----|:-----|
| `input text "中文"` | NPE `Attempt to get length of null array`（InputShellCommand.sendText 华为 bug） | 死 |
| `input text "%E4%B8%AD..."`（URL 编码） | **不解码**，`%20`/`%E4` 字面显示 | 死 |
| ADBKeyboard（senzhk/ADBKeyBoard GitHub APK） | `am broadcast -a ADB_INPUT_TEXT --es msg '...'` result=0 但**无 receiver 收到**——该 APK manifest 根本没声明广播接收器（dex 里有 AdbReceiver 类但 manifest 未注册），显式 `-n com.android.adbkeyboard/.AdbIME$AdbReceiver` 也无效；dumpsys package 查 receiver 为空 | 死 |
| termux-clipboard-set | 需要 Termux:API app 接收广播，未装则**静默哑弹**（exit 0 但没写入） | 死 |
| 装 Termux:API（F-Droid com.termux.api_51.apk） | `INSTALL_FAILED_SHARED_USER_INCOMPATIBLE` — 签名与已装 Termux 不匹配（HarmonyOS 严格校验） | 死 |
| `service call clipboard 2 ...` | 需构造 ClipData 复杂对象，各种 s16/i32 组合都 "not enough data" | 死 |
| `cmd clipboard set-text` | ROM 无此命令（"No shell command implementation"，adb shell 和 Termux 内都 255） | 死 |
| `input keycombination 113 29`（Ctrl+A） | 华为不支持，无效果 | 死 |

**结论**：中文正文在华为 ROM 上无法纯 adb 注入。务实出路：
1. 标题/链接用 ASCII（完全可行）
2. 中文正文要么用户手打，要么 App 自带「语音输入」按钮（无法 adb 模拟语音）
3. 小红书等有「推荐标签」快捷填入——点击标签可快速填标题，但内容受限于推荐

## 富文本编辑框操作技巧（小红书 CapaPostNotePlatformActivity 实测）

- 小红书发帖编辑页是一个**大富文本 EditText**（标题+正文一体），UI dump 里 text 就是当前全部内容
- **删不干净陷阱**：`--repeat N KEYCODE_DEL` 在富文本里每次只删 1~2 字符（编辑器限速），且 **uiautomator dump 会重置输入焦点**——每轮 dump 后 DEL 又失效。正确节奏：点击→立即 DEL（不 dump）→再 dump 查长度
- **全选**：长按输入框弹系统浮层菜单（粘贴/全选/更多），**浮层不在 uiautomator 树里**，只能截图+视觉定位，且按钮位置随光标浮动
- 删除验证看 **UI 树 text 属性**（权威），不要信截图视觉误读（滚动位置/缩略图会被误读成"乱码"）
- 误触返回会出现「返回编辑/保存并退出」菜单；App 重启后有「继续编辑图文笔记吗？→ 去编辑」可恢复草稿

## 截图可靠性（慢链路）

- `adb exec-out screencap -p > file` 在 Tailscale relay 慢链路下**经常截断**（PIL 报 "image file is truncated"，文件 600KB~2MB 不等）
- 可靠姿势：`adb shell screencap -p /sdcard/x.png` + `adb pull /sdcard/x.png`（2.3MB 完整）

## 视觉不可用时的定位兜底（相册网格等 Canvas 界面）

相册/网格 UI 树无图片节点（Canvas 绘制），vision 又 400 时：
1. 用 MediaStore 查图片真实排序：`adb shell content query --uri content://media/external/images/media --projection _id:_display_name`（列名要 `_id:_display_name` 这种分号格式，逗号格式报错）
2. 像素分析定位：PIL 读完整截图（pull 方式），按网格格子算平均亮度+顶部条亮度，白底黑条=宣传图候选（vision-model-benchmark 有独立基准方法）
3. 小红书相册网格实测：3 列，格子 528×528，x 列起始 [0,535,1070]，y 行起始 [302,837,1372,1907]

## 已知坑

| 坑 | 解决 |
|:---|:-----|
| exec-out screencap 截断 | 用 shell screencap + pull |
| dump 后 DEL 失效 | 点击→DEL→再 dump，别交叉 |
| UI 树 text 与视觉不一致 | 以 UI 树 text 为权威，视觉只用于浮层菜单定位 |
| input text 无声丢失 | 先 tap 输入框中心确保光标/焦点（dumpsys input_method 看 mServedView 非 null） |
