---
name: community-content-scraping
description: 多社区内容抓取 — X/Twitter、Discord、V2EX、B站、Reddit、GitHub、知乎的可用方案与凭据管理
tags: [scraping, twitter, discord, reddit, github, bilibili, v2ex, zhihu]
version: 1.2.0
risk: write-safe
---

# 多社区内容抓取

## 抓取策略（降级链）

```
VPS 直取 ──成功──→ ✅ 返回结果
  │ 失败
  ↓
SearXNG 关键词搜索 ──成功──→ ✅
  │ 或
Exa 语义搜索 ──成功──→ ✅ （适合深度调研，见 skill `exa-semantic-search`）
  │ 都失败
  ↓
黑翼 SSH 桌面浏览器 ──成功──→ ✅ 
  │ 失败
  ↓
用户手动配合 ──→ 指导用户 F12 → Console 操作
```

## 社区可用性矩阵

| 社区 | 方式 | 状态 | 额外要求 |
|------|------|:----:|---------|
| **V2EX** | `curl` 直接提取 | ✅ | 无 |
| **B站** | 公开 API | ✅ | 无 |
| **Reddit** | crawl4ai 绕过 JSON API | ✅ curl 403，crawl4ai 可绕过（见 `references/crawl4ai-reddit-bypass.md`） | 基础模式即可，~1.1s/次。New Reddit HTML 仍有 Cloudflare challenge |
| **GitHub** | REST API | ✅ | 无，匿名也可搜 |
| **X/Twitter** | 内部 API | ✅ | 需 auth_token + ct0 cookie + Bearer Token |
| **Discord** | Bot API | ✅ | 需有效 Bot Token |
| **知乎** | 官方 API (developer.zhihu.com) | ✅ | `ZHIHU_ACCESS_SECRET` 存于 .env，每天 1000 次免费搜索 |
| **Telegram 频道** | `t.me/s/<频道>?q=<关键词>` curl 直取 | ✅ | 中文网盘/影视资源首选通道（bdwpzhpd / Aliyun_4K_Movies / YioveComplex / vip115hot / Netdisk_Movies），不触发验证码 |
| **小红书** | 无自动化方案 | ❌ | headless 全拦截（VPS + 桌面），仅用户手动浏览器可行 |
| **掘金** | 无有效方案 | ❌ | SPA 渲染 + 无 API |

## 凭据管理

所有社区凭据统一存于 `/root/.hermes/credentials/social_scraper.json`，格式：
```json
{
  "x": {
    "bearer_token": "...",
    "auth_token": "...",
    "ct0": "..."
  },
  "discord": {
    "bot_token": "...",
    "guild_id": "...",
    "channels": { "name": "channel_id" }
  }
}
```

### X/Twitter 凭据获取

用户需从 browser F12 → Application → Cookies → x.com 复制：
- `auth_token` — 会话认证
- `ct0` — CSRF 保护 Token
- Bearer Token 是公开的：`AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA`

### Discord Bot Token 获取

用户需在 Discord Developer Portal 创建/重置 Bot Token，Bot 需已加入目标服务器。

## 知乎官方 API 抓取

知乎数据开放平台 `developer.zhihu.com` 提供官方 API，`ZHIHU_ACCESS_SECRET` 存于 `.env`。

**⚠️ 坑：不要用 bash `$ZHIHU_ACCESS_SECRET` 写法进 cron prompt**
内容保护系统会将变量名改写为 `$ZHIHU...RET`（中间变 `...`），导致认证失败。Python `os.environ.get('ZHIHU_ACCESS_SECRET')` 可绕过。

### 可用接口

| 接口 | 端点 | 说明 |
|------|------|------|
| 知乎搜索 | `GET /api/v1/content/zhihu_search` | 站内内容搜索，Query 必填，Count 最大 10 |
| 全网搜索 | `GET /api/v1/content/global_search` | 全网+知乎双源搜索 |
| 知乎热榜 | `GET /api/v1/content/hot_list` | 实时热榜，固定返回 30 条 |
| 直答 | 相关接口 | Agent 对话式查询 |

### 请求头

```bash
-H "Authorization: Bearer <ZHIHU_ACCESS_SECRET>"
-H "X-Request-Timestamp: $(date +%s)"     # 秒级Unix时间戳
-H "Content-Type: application/json"
```

### 调用示例（仅限 CLI 交互，不要用于 cron prompt）

```bash
# 知乎搜索（Python os.environ 版本用于 cron 场景）
source /root/.hermes/.env 2>/dev/null
python3 -c "
import os, urllib.request, json, time
token = os.environ.get('ZHIHU_ACCESS_SECRET', '')
req = urllib.request.Request(
    'https://developer.zhihu.com/api/v1/content/zhihu_search?Query=虚幻引擎5&Count=5')
req.add_header('Authorization', f'Bearer {token}')
req.add_header('X-Request-Timestamp', str(int(time.time())))
resp = urllib.request.urlopen(req, timeout=10)
print(json.loads(resp.read()))
"
```

### 响应格式

```json
{
  "Code": 0,
  "Message": "success",
  "Data": { ... }
}
```

搜索响应中 `Data.Items[]` 包含：`Title`, `ContentText`, `Url`, `AuthorName`, `VoteUpCount`, `CommentCount`, `EditTime` 等。

热榜响应中 `Data.Items[]` 包含：`Title`, `Url`, `ThumbnailUrl`, `Summary`。

### 免费额度

注册即送：每天 1000 次搜索 + 10 次热榜/直答。

### 错误码

| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| 10001 | 参数错误 |
| 20001 | 鉴权失败 |
| 30001 | 频率限制 |
| 90001 | 内部错误 |

## X/Twitter 抓取

### 第三方镜像 API（即时抓取，推荐）

**内部 API 仅限定时任务，但第三方公开镜像不受此限**——需要立即查看单条推文（如用户临时丢链接问内容）时用镜像，curl 直取即可，无登录墙、VPS 直连可用：

```bash
# fxtwitter：完整 JSON（tweet.text / author / 媒体 / 统计）
curl -s "https://api.fxtwitter.com/i/status/<推文ID>"

# vxtwitter：备用镜像（同格式）
curl -s "https://api.vxtwitter.com/i/status/<推文ID>"
```

- 推文 ID 从 URL 提取：`https://x.com/<user>/status/<ID>` 或 `https://x.com/i/status/<ID>`
- ⚠️ **正文可能不含完整内容**：列表/长文类帖子（如"10个GitHub仓库合集"）具体条目常以**回复线程**形式发出，镜像 API 拿不到回复 → 用浏览器打开 x.com 帖子页（游客可看单帖+回复线程）抓完整列表，再对照评估

### 可用端点

| 端点 | 用途 | 说明 |
|------|------|------|
| `/i/api/2/timeline/home.json?count=N` | 首页 Timeline | ✅ 可用，返回 tweets + users |
| `/i/api/graphql/<QueryID>/QueryName` | GraphQL 操作 | ❌ Query ID 频繁变更，不可靠 |
| 其他 v1.1/v2 REST 端点 | 搜索等 | ❌ 返回 34/NotFound |

### 请求头要求

```bash
-H "Authorization: Bearer <公开 Bearer Token>"
-H "x-csrf-token: <ct0 cookie 值>"
-H "x-twitter-auth-type: OAuth2Session"
-H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
-H "Cookie: auth_token=<auth_token>; ct0=<ct0>"
-H "Origin: https://x.com"
-H "Referer: https://x.com/"
```

### 响应解析

响应体包含 `globalObjects.tweets`（推文字典）和 `globalObjects.users`（用户字典），以及 `timeline.instructions`（排序指令）。从 `timeline.instructions` 中提取推文 ID 列表，再到 `globalObjects.tweets` 中获取详情。

每个推文包含：`text`/`full_text`、`created_at`、`user_id_str`、`retweet_count`、`favorite_count`、`entities.urls` 等。

### 局限性

- timeline endpoint 能正常拉取首页推文（已验证）
- 搜索（搜索推文/用户）和 GraphQL 端点无法稳定使用
- `auth_token` 和 `ct0` 会过期，需要用户重新提供

## Discord 抓取

### 可用端点

```bash
# 获取 Bot 基本信息
curl -s "https://discord.com/api/v10/users/@me"
  -H "Authorization: Bot <token>"

# 获取 Bot 所在的服务器
curl -s "https://discord.com/api/v10/users/@me/guilds"

# 获取服务器频道列表
curl -s "https://discord.com/api/v10/guilds/<guild_id>/channels"

# 读取频道消息（最近 N 条）
curl -s "https://discord.com/api/v10/channels/<channel_id>/messages?limit=N"
```

### 消息解析

返回的消息数组按时间倒序（最新的在前），每条包含：`content`、`author.username`、`timestamp`、`mentions` 等。

### 局限性

- 只能读取 Bot 已加入的服务器和频道的消息
- Google 反查: Discord 内容不公开索引，无法用搜索引擎间接获取

## Telegram 频道抓取（t.me/s 网页版）

Telegram 频道的 `t.me/s/<频道>` 网页端可匿名访问（无需登录、不触发验证码），是 VPS 上最稳定的社区抓取通道之一，尤其适合中文网盘/影视资源搜索。

### 频道内搜索

```bash
# 频道内按关键词搜索（q 参数）
curl -s -L "https://t.me/s/bdwpzhpd?q=%E5%8A%9F%E5%A4%AB%E5%A5%B3%E8%B6%B3" \
  -H "User-Agent: Mozilla/5.0"
```

### 帖子文本 + 网盘链接解析（Python 正则）

```python
import re, html

t = curl_output  # 上面 curl 的 stdout

# 1. 帖子正文：每个帖子在 tgme_widget_message_text div 内
posts = re.findall(r'tgme_widget_message_text[^>]*>(.*?)</div>', t, flags=re.S)
for p in posts[:10]:
    p = re.sub(r'<[^>]+>', ' ', p)
    p = html.unescape(p)
    p = re.sub(r'\s+', ' ', p).strip()
    print('POST:', p[:300])

# 2. 网盘链接：百度/夸克/阿里
links = re.findall(
    r'https?://(?:pan\.baidu\.com|pan\.quark\.cn|www\.alipan\.com)/[^\s"<]+',
    t)
for l in dict.fromkeys(links):   # 去重
    print('LINK:', l[:150])
```

### 中文网盘资源常用频道

| 频道 | 定位 | 订阅 |
|------|------|:----:|
| `t.me/s/bdwpzhpd` | 百度网盘综合（最全） | 48K |
| `t.me/s/Aliyun_4K_Movies` | 阿里/夸克/百度 4K 影视 | 213K |
| `t.me/s/aliyun_4k_movies` | 同上（另一频道） | — |
| `t.me/s/YioveComplex` | 综合资源（阿里/夸克/迅雷/OneDrive） | 10K |
| `t.me/s/vip115hot` | 115/阿里/百度影视 | — |
| `t.me/s/Netdisk_Movies` | 网盘影视 | — |

### 坑

- **同名资源需区分类型**：同一关键词可能对应院线电影（刚上映只有 TC 枪版，无高清网盘）和同名短剧（发片即发网盘 1080P）。先确认用户要哪个再交付
- **新上映院线片**（<1个月）高清网盘资源不存在，只有插曲/OST 等周边先流出；WEB-DL/BD 需等 2-6 个月

## 爬取验证工具

### curl-impersonate（TLS 指纹伪装，2026-08-02 已装）

已安装到 VPS：`/opt/curl-impersonate/`，主二进制 `curl-impersonate-chrome`/`curl-impersonate-ff`，wrapper 软链在 `/usr/local/bin/curl_chrome116`（及 chrome110/ff117/ff109 等）。

**用法**（直接替换 curl 即可）：
```bash
curl_chrome116 -s "https://example.com/"
curl_chrome116 -s -H "Cookie: xxx" "https://..."
curl_ff117 -s "https://..."
```

**安装方法**（若需重装/更新）：
```bash
# 下载 v0.6.1 预编译包（Ubuntu 24.04 x86_64）
curl -sL -o /tmp/ci.tar.gz "https://github.com/lwthiker/curl-impersonate/releases/download/v0.6.1/curl-impersonate-v0.6.1.x86_64-linux-gnu.tar.gz"
mkdir -p /opt/curl-impersonate && tar xzf /tmp/ci.tar.gz -C /opt/curl-impersonate/
chmod +x /opt/curl-impersonate/curl*
ln -sf /opt/curl-impersonate/curl-impersonate-chrome /usr/local/bin/curl-impersonate-chrome
ln -sf /opt/curl-impersonate/curl_chrome116 /usr/local/bin/curl_chrome116
# 其他版本同理
```

**实测结论（VPS 192.3.241.244）**：
- ✅ 对**海外站 TLS 指纹检测**有效（如部分 CF 挑战、Akamai 类），遇到"普通 curl 403 但浏览器能开"的海外站先用它试
- ❌ **对 IP 层封禁无效**：豆瓣（000 TCP 超时）、Reddit JSON API（403，仍是 Cloudflare 对数据中心 IP 拦截）、小红书/大众点评（登录墙+IP 风控）——这些是 IP 黑名单/网络层问题，TLS 指纹救不了
- ❌ 对国内站无增量：百度/知乎/微博/V2EX/B站 普通 curl 本来就通，结果一致
- 结论：**它不是银弹，但作为降级链的"免费反反爬层"保留**，0 成本，仅占 ~8MB

**适用顺序**：普通 curl → 403 时换 `curl_chrome116` → 还不行再走 crawl4ai/浏览器/降级链。

### 国内站连通性快速测试

```bash
# 测一条看看
for site in "https://www.v2ex.com/" "https://www.bilibili.com/" "https://juejin.cn/"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 -A "Mozilla/5.0" -L "$site")
  echo "$site → $code"
done
```

### 国外站连通性

```bash
for site in "https://www.reddit.com/" "https://github.com/" "https://x.com/" "https://discord.com/"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 -A "Mozilla/5.0" -L "$site")
  echo "$site → $code"
done
```

## V2EX 解析模式（CSS + 正则 Fallback）

V2EX 首页是服务端渲染 HTML，提取话题链接时需要做**二级降级解析**，因为纯 CSS 选择器可能因页面微调而失败：

```python
# 第一级：CSS 提取（优先）
# 匹配 item_title 类中的链接
grep -oP 'item_title.*?href="\K/t/[0-9]+' file.html

# 第二级：正则 fallback（降级）
# 如果 CSS 提取数量 < 5，降级到全量正则
grep -Eo 'href="/t/[0-9]+"' file.html | sort -u

# 第三级：debug 保存
# 如果前两级都 < 3 条，保存头 2000 字符供排查
head -c 2000 file.html > /tmp/v2ex_debug.html
```

**关键原则**：不要因为 CSS 选择器失效就直接报 🔴。禁止"一步解析失败 = 该源不可用"。V2EX 的 /t/ 链接格式是稳定的，正则 fallback 通常能兜住。

## 异常分级系统

不要用二进制 ✅/❌ 来判定每个源。使用 4 级分类：

| 情况 | 级别 | 说明 |
|------|:----:|------|
| HTTP 200 + 正常返回数据 | ✅ | 正常绿 |
| HTTP 200 + 返回数据量少 | 🟢 | 如实汇报即可，不标记异常 |
| HTTP 200 + 空结果（技术无相关内容） | 🟡 | "今日无相关更新" |
| HTTP 4xx/5xx 请求失败 | 🟡 | 请求异常，非数据异常 |
| 解析失败但原始 HTML/JSON 存在 | 🟡 | "解析异常，已保存 debug" |
| 网络不可达（timeout/DNS 失败） | 🔴 | "服务不可达" |
| 凭据过期（401） | 🟡 | "凭据需更新" |
| rate limit（429 或 HTTP 403） | 🟡 | "已限流" |

**核心规则**：只有网络层不可达才标 🔴。其他全部降级为 🟡 或更低。

## SearXNG 端点验证

知乎搜索依赖本地 SearXNG 服务。不要假设端口是多少——先验证：

```bash
# 1. 确认 Docker 中 SearXNG 的实际端口
docker ps --format 'table {{.Names}}\t{{.Ports}}' | grep searx

# 2. 测试搜索
curl -sS --max-time 15 "http://127.0.0.1:8888/search?q=site:zhihu.com+DeepSeek&format=json"

# 3. 如果首次搜索无结果，换一个关键词重试
# 不要单次无结果就报失败
```

**已知**：实际端口 8888（Docker 映射）。不要写死 localhost:8080。

## GitHub PAT 安全注意事项

**不要**复用备份脚本、日志文件或聊天记录中已出现的 GitHub PAT。如果 token 出现在以下任一位置，应视为已泄露：
- 备份脚本（如 hermes-backup.sh）
- 聊天对话
- 输出日志
- Memory 记录

正确做法：
1. 去 https://github.com/settings/tokens 创建**新 PAT**
2. 只给最小权限（如 `public_repo` 只读）
3. 写入环境变量 `GITHUB_TOKEN`，不要写死进脚本
4. 新 token 不要在聊天中明文输出
5. 旧 token 立即撤销

---

## 定时情报采集（Intelligence Gathering Pipeline）

当需要将多社区抓取组织为每日定时情报投递时，使用本节的管道配置。

### 适用场景

- 每日定时从多个社区抓取特定关键词相关的情报
- 用户临时要求爬取特定内容（此时禁用 X/Twitter）
- 汇总后自动投递到用户飞书/其他渠道

### X/Twitter 特殊限制（P0 — 必须遵守）

| 规则 | 详情 |
|------|------|
| **仅限定时任务** | X/Twitter **内部 API** 只能在每日定时 cron 任务中使用，绝不能在用户要求**立即/临时**爬取时调用 |
| **镜像例外** | 第三方镜像（fxtwitter/vxtwitter）不是内部 API，**不受本条限制**，用户临时丢单条链接时可即时 curl（见上文"第三方镜像 API"） |
| **请求频率** | 每次请求 count ≤ 20，每天最多触发 1 次（仅内部 API） |
| **凭据过期** | 一旦用户反映 X 要求重新登录，立即停用 X 爬取并通知用户更新 cookie |

### 去重策略

**相似度去重：** 标题精确匹配 / 子串包含 / 编辑距离 >70% → 合并为一条，标注多来源。

**跨天去重：** 读取 `~/.hermes/cron/output/` 下最近 3 天的早报文件，跳过已出现的标题/URL。

**排除内容过滤：** 预先定义的排除关键词命中后直接丢弃。

### 异常通知协议

任何社区连续 3 次重试（间隔 5s）后仍失败，在报告顶部输出：

```text
🔴 [社区名称] 抓取失败
原因：[错误信息]
可能影响：[完整性评估]
建议：[是否需人工介入]
```

注意：遵循异常分级系统（见上文），只有网络层不可达才标 🔴。

### 季度维护检查

每季度检查一次各社区 API 和解析规则的兼容性：

- V2EX 页面 HTML 结构是否变化
- B站 API 返回字段是否更新
- Reddit JSON 格式是否变化
- X/Twitter 内部 API 端点是否失效

---

## 用户配合模式（小红书/掘金等 blocking 站点）

当所有自动化方案都失败时，指导用户在浏览器（非 headless）中操作：

1. 打开目标页面
2. F12 → Console（控制台）
3. 输入 `allow pasting` 回车（安全提示确认）
4. 粘贴 `copy(document.body.innerText)` 回车
5. 将粘贴板内容发回

## 相关参考

- `references/x-twitter-cli-tool.md` — X/Twitter CLI 操作工具（发帖/回复/搜索/DM/媒体上传）
- `references/rss-blog-monitoring.md` — RSS/Atom 博客订阅监控（blogwatcher-cli，Go 工具）
- skill `rss-feed-reader` — 另一套 RSS 方案，使用 Python feedparser 按需解析，更轻量
- skill `exa-semantic-search` — Exa AI 语义搜索引擎，全网语义搜索 + 网页内容读取
