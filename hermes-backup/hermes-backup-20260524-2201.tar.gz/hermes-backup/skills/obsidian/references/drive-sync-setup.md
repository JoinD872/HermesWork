# Google Drive Sync — Vault 同步到用户桌面

## 为什么放弃 SSH 直推

| 方案 | 延迟 | 依赖桌面 | 双向同步 | 结论 |
|------|:----:|:--------:|:--------:|:----:|
| Tailscale SSH (SFTP) | ~180ms relay | ✅ 必须开机 | ❌ | ❌ 太慢 |
| Google Drive 中转 | <10ms (VPS→Google) | ❌ 不用 | ✅ (Drive桌面版) | ✅ 首选 |

## 架构

```
VPS（洛杉矶 RackNerd）
  │   rclone copy (--size-only, --timeout 120s)
  │   no_agent cron, 每30min, 零token
  ▼
Google Drive（用户的 Drive 仓库文件夹）
  │   Google Drive 桌面版自动同步（后台持续）
  ▼
Windows 本地文件夹（例如 C:\Users\JoinD\Google Drive\）
  │   Obsidian "打开文件夹作为仓库"
  ▼
用户可浏览所有 Hermes 笔记 + 自己原有的笔记
```

## rclone 配置

### 前提

- rclone 已安装（`/usr/bin/rclone`）
- Google Drive remote `mydrive` 已授权（通过 headless OAuth 流程，详见 `cloud-inbox-setup.md`）

### 获取目标文件夹 ID

打开 Google Drive 网页版，进入目标文件夹，URL 中 `/folders/` 后的字符串即为 folder_id：

```
https://drive.google.com/drive/folders/1XvPIqFqftMhG_4QSC9LnApxue_ayvAmg ← 这就是 folder_id
```

### 测试访问

```bash
# 列出文件夹内容（空文件夹无输出正常）
rclone lsd "mydrive:" --drive-root-folder-id "FOLDER_ID_HERE"

# 写入测试文件验证权限
echo "test" > /tmp/test_access.txt
rclone copy /tmp/test_access.txt "mydrive:" --drive-root-folder-id "FOLDER_ID_HERE" -q
rclone delete "mydrive:test_access.txt" --drive-root-folder-id "FOLDER_ID_HERE" -q
```

## 同步脚本

位置：`~/.hermes/scripts/sync_vault_to_drive.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

VAULT="$HOME/.hermes/ObsidianVault"
FOLDER_ID="用户的GoogleDrive文件夹ID"

rclone copy "$VAULT/" "mydrive:" \
  --drive-root-folder-id "$FOLDER_ID" \
  --size-only \
  --timeout 120s \
  -q 2>&1
```

### 为什么用 `copy` 而不是 `sync`

| 命令 | 行为 | 适用场景 |
|------|------|---------|
| `rclone sync` | 使目标==源，目标多余文件**被删除** | Hermes 独享的文件夹 |
| `rclone copy` | 只有源→目标的单向增补，**不删除**目标文件 | Hermes 内容**合并到**用户已有仓库 |

如果用户的目标文件夹里已有自己的 Obsidian 笔记，使用 `sync` 会删除它们。使用 `copy` 则安全地将 Hermes 内容合并进去。

### `--size-only`

比 `--checksum` 快得多：
- `--checksum`：下载文件内容哈希比对（Google Drive API 需先拉取文件元信息再比对）
- `--size-only`：仅比对文件大小和修改时间（API 一次往返）

## Cron 配置

```bash
cronjob action=create \
  name="Vault 同步 → Google Drive" \
  script="bash ~/.hermes/scripts/sync_vault_to_drive.sh" \
  no_agent=true \
  schedule="*/30 * * * *" \
  deliver=local     # ⚠️ 必须显式指定，默认 origin 会发到用户聊天！
```

- 频率：每 30 分钟
- 模式：`no_agent=true`（脚本直接输出，无 LLM 参与）
  - 有新内容时输出传输日志
  - 无新内容时输出为空 → cron 静默，不触发通知
- 零 token 成本

### 陷阱：deliver 默认 origin

默认 `deliver=origin` 会把 cron 脚本的所有 stdout 发到创建时的聊天窗口。对每30分钟一次的同步任务而言，每次"nothing to transfer"都会打扰用户。**所有 no_agent cron job 都应显式 `deliver=local`**。

静默脚本 + local 交付 = 用户完全无感知的定时同步。

## 用户侧设置（Windows）

1. **安装 Google Drive 桌面版**
   - 下载：https://dl.google.com/drive-file-stream/
   - 登录用户的 Google 账号

2. **等待同步完成**
   - Google Drive 桌面版会在本地创建虚拟盘符或同步文件夹
   - 默认路径：`C:\Users\用户名\Google Drive\` 或作为 G: 盘
   - 找到目标文件夹（与 VPS 同步的同一 folder_id）

3. **在 Obsidian 中打开**
   - Obsidian → "打开文件夹作为仓库" → 选择同步后的目标文件夹
   - Hermes 的笔记以子目录形式出现在用户已有的 Obsidian 仓库中：
     ```
     目标文件夹/
     ├── 用户原有的笔记...        ← 保持不动
     ├── 00_收件箱-AI/           ← Hermes 自动写入
     ├── 00_收件箱-人工/         ← Cloud Inbox 投递
     ├── 10_文献笔记/            ← 小研研究报告
     └── 40_复盘归档/            ← 每日早报/VPS日志
     ```

## 注意事项

- **回传限制**：rclone 同步是单向的（VPS → Drive）。用户在 Obsidian 中的编辑会通过 Drive 桌面版回到云端，但不会自动回传至 VPS
- **重名冲突**：如果用户的已有笔记与 Hermes 笔记文件名相同，后同步的版本会覆盖。Hermes 笔记遵循 `YYYYMMDD-名称.md` 命名规范，冲突可能性低
- **更新 sync 脚本**：如果更换了目标文件夹，同步脚本中的 `FOLDER_ID` 需手动更新
- **桌面端无需特殊配置**：Google Drive 桌面版装好登录即可，同步自动进行

## 验证命令

```bash
# 手动触发同步
bash ~/.hermes/scripts/sync_vault_to_drive.sh

# 验证两端文件数一致
echo "VPS: $(find ~/.hermes/ObsidianVault -name '*.md' | wc -l)"
echo "Drive: $(rclone ls 'mydrive:' --drive-root-folder-id 'FOLDER_ID' 2>&1 | grep -c '.md')"

# 检查 cron job 状态
cronjob action=list | grep "Vault 同步"
```
