# 每日日记系统

## 概述

用户要求建立每日日记系统，由 Hermes 自动创建当天的日记文件并清理未填写的空日记。日记走 Obsidian Vault → Google Drive → Windows 同步链路。

## 需求

1. **笔笔记要模板**：日记需有固定模板（状态/发生了什么/想说的话 三个板块）
2. **自动创建上海日期日记**：每天 00:00 HKT 创建当天日记文件
3. **未填写则自动删除**：第二天检查昨天的日记——用户没写就删掉

## 架构

```
VPS ~/.hermes/ObsidianVault/
├── 模板/日记模板.md           ← 日记模板（date 占位符 {{date}}）
├── 日记/                     ← 日记文件存放目录
│   ├── 2026-05-24-日记.md    ← 当天日记（00:00 HKT 自动生成）
│   └── ...（第二天被清理或保留）

cron job: 每日 16:00 UTC（= 00:00 HKT）
  script: daily_diary.sh
  mode: no_agent=true
  deliver: local
```

## 文件位置

| 文件 | 路径 |
|------|------|
| 模板 | `模板/日记模板.md` |
| 脚本 | `~/.hermes/scripts/daily_diary.sh` |
| 日记文件 | `日记/{YYYY-MM-DD}-日记.md` |

## 脚本逻辑（daily_diary.sh）

### 清理逻辑

1. 取上海昨天日期
2. 检查 `~/.hermes/ObsidianVault/日记/{昨天}-日记.md` 是否存在
3. 检查 `~/.hermes/inbound/user-notes/日记/{昨天}-日记.md`（用户同步回来的版本）
4. **判断是否填写**：inbound 版本文件大小 > Vault 原版文件大小 → 用户写了；否则没写
5. 没写 → 删除 Vault 中的日记文件（避免重新同步到 Drive）
6. 写了 → 保留

### 创建逻辑

1. 取上海今天日期
2. `日记/{今天}-日记.md` 不存在 → 用 sed 替换模板中的 `{{date}}` → 写入
3. 已存在 → 跳过

### 注意

- `TZ=Asia/Shanghai` 获取上海日期，与 UTC+8 对齐
- cron 在 16:00 UTC 触发 = 上海 00:00
- 文件大小比较是粗粒度判断：用户写了几行/几个字就会导致文件明显大于模板
- 模板约 153 字节，模板加日期替换后约 159 字节，用户填了至少会增加 50+ 字节

## 模板格式

```markdown
---
title: "{{date}} 日记"
date: {{date}}
type: diary
status: draft
---

# {{date}} 日记

## 今天的状态


## 发生了什么


## 想说的话
```

## 同步链路

日记文件在 Vault 中 → `sync_vault_to_drive.sh`（每30min）→ Google Drive → 用户 Windows Obsidian

用户填写 → Google Drive 桌面版同步回云端 → `pull_user_notes.sh`（每30min 作为 sync_vault_to_drive.sh 的一部分）→ `~/.hermes/inbound/user-notes/日记/`

```
VPS 创建日记文件
  → sync_vault_to_drive.sh → Google Drive → Windows Obsidian（用户看到）
    → 用户填写 → Google Drive 桌面版 → 云端
      → pull_user_notes.sh → inbound/user-notes（脚本检查是否填写）
```

## Cron Job 配置

```bash
# 每日 16:00 UTC = 00:00 HKT
cronjob action=create \
  name="每日日记 — 创建+清理" \
  script="bash ~/.hermes/scripts/daily_diary.sh" \
  no_agent=true \
  schedule="0 16 * * *" \
  deliver=local
```

## 反向笔记同步

用户在本地 Obsidian 写的笔记需要同步回 VPS 作为知识库。这是通过 `pull_user_notes.sh` 实现的，它每 30 分钟从 Google Drive 目标文件夹（`--drive-root-folder-id`）拉取全部文件到 `~/.hermes/inbound/user-notes/`。

### 关键设计

- **全部拉取不过滤**：拉取整个 vault 文件夹，不按路径排除。由后续读取任务自行区分用户笔记 vs Hermes 生成内容
- **rclone copy（非 sync）**：不删除本地文件，安全地增量获取
- **与 sync_vault_to_drive.sh 合并**：同一个 cron job 运行两个脚本，共享 deliver=local 和 30 分钟间隔

### 脚本

```bash
#!/usr/bin/env bash
# ~/.hermes/scripts/pull_user_notes.sh
FOLDER_ID="1XvPIqFqftMhG_4QSC9LnApxue_ayvAmg"
STAGE="$HOME/.hermes/inbound/user-notes"
mkdir -p "$STAGE"
rclone copy "mydrive:" "$STAGE/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --size-only --timeout 120s -q 2>&1
```
