GitHub PAT 实际位置在 /root/.hermes/scripts/hermes-backup.sh（不在 .env），用户 JoinD872，仓库 JoinD872/HermesWork（私人），Token 前缀 ghp_6q...XGvJ。以后查 GitHub 认证先看 backup.sh。
§
用户云端迭代工作流 — 主力走 GitHub：文件放 JoinD872/HermesWork/workspace/，用户在网页版改，我读+改+提交推送。不走百度网盘/飞书云盘。补充：Google Drive 用于 Obsidian Cloud Inbox（HermesInbox/ 文件夹，每30min拉取到 Vault 收件箱），仅做灵感投递不用于代码迭代。
§
视觉：OpenCode Go mimo-v2.5 已确认可用（auxiliary.vision 配置）；vision_analyze 偶发400=上游抖动自愈，先直接测小图别手写 curl 猜格式。
§
VPS 隧道架构（2026-07-17）：Docker-tunnel = systemd 服务（`cloudflared-docker-tunnel.service`），服务于 `proxy.cloudjoind.com` 翻墙代理；JoinD-tunnel = Docker 容器（`cloudflared-joined`）。两者独立不冲突。Docker 容器有 IPv6 DNS 超时问题（不影响功能）。
§
知乎已升级为官方API：ZHIHU_ACCESS_SECRET存于.env，developer.zhihu.com，每天1000次免费搜索。
§
网络工具/爬取工具学到新知识或更新 skill 时，必须同步给 vps-technician 和 researcher 两个 profiles。当前已同步：camoufox-install、community-scraping（含 references）。vps-patrol 在 vps-technician profile 是软链共享 default 副本，patch default 即自动同步。
§
## 协作模型 V2（2026-07-15 更新）
小H（主控）、Codex（外脑）、小策（方案官）、朵朵（个人认知/知识库）、黑翼（风控官）、老V（执行官）。小研已于2026-07-15被替换为朵朵。Codex强默认前置参与所有任务。
§
## 运维信条
应用层连接错误 ≠ 应用本身故障。排查顺序：① DNS(/etc/resolv.conf + resolvectl) → ② TCP → ③ 代理/出口(WARP/Tailscale) → ④ 服务 → ⑤ 配置 → ⑥ 业务逻辑。网络组件修改必须 Before→Snapshot→Modify→HealthCheck→Rollback。Tailscale 不只是 VPN，它还管理 DNS (MagicDNS)。WARP warp 模式 (全流量隧道) 会触发 Tailscale DNS 接管，只允许 proxy 模式。
§
优选 IP 测试规则：VPS 只能验证隧道连通性（curl --resolve + HTTP 400=通），VPS 端的延迟数字对中国用户无参考价值。严禁报 VPS 侧测速结果（如"这个 IP 只要 72ms"）给用户做优选依据。用户必须自己从 Windows 侧 ping 或 CloudflareSpeedTest 测速。
§
朵朵每日笔记归档 cron: job_id=2db29a49d308, 每天 UTC 15:00 (北京时间 23:00) 运行。扫描当日朵朵对话→有价值内容→写 Draft/→通知用户。关联技能：cognitive-support, duoduo-note-workflow, personal-cognitive-management。
§
用户用 Obsidian 免费版（无 Sync），手机看 .md 文件要么装 Remotely Save 插件要么在 Google Drive App 里预览。不能指望 Obsidian 官方同步。
§
## 个人状态（2026-08）
工作日10-21工作→游戏→2点睡→8:30起。慢性睡眠剥夺6.5h/晚，精力不足。核心动机：父职责任感（怕接不住女儿）+愧对父母。认知到位但执行卡住，周末做最小改变（学做饭）。睡眠是根因，渐进恢复：7h→7.5h→8h，优先固定起床时间。偏好权威学术来源（PubMed/Nature），引用须PMID/DOI。
§
Hermes 大版本升级：先加载 hermes-maintenance skill 按 Phase 1-4 执行。关键：git fetch --tags + git checkout 而非 hermes update；先升级所有依赖（lark-oapi 等）再重启网关；重启前告知用户可能断连；网关内用 Python subprocess + os.setpgrp 或另开 SSH 会话重启，不能直接 restart。记录见 references/v0.19.0-upgrade-incident.md
§
Windows PC (DaLao): Tailscale 100.108.175.15, SSH 用户 61915, workdir E:\Hermes。其 Hermes 配置在 C:\Users\61915\AppData\Local\hermes（非 ~/.hermes），跨机同步用 hermes-cross-instance-sync skill。
§
OpenCode Go ($10/月)：base_url https://opencode.ai/zen/go/v1。2026-08-16 起所有模型统一 mimo-v2.5（主模型+全部 auxiliary+MoA+delegation 继承+fallback 同款）。⚠️同 KEY 也访问 Zen /zen/v1：8 个 -free 免费模型已配 custom:opencode-zen-free 备用+fallback 链；免费模型=数据用于训练勿传敏感；付费模型（claude-opus-5/gemini-3.6-flash/kimi-k3）按量扣费绝不调用。用户说「zen」指 /zen/v1 非 Go。详见 api-cost-tracking skill。
§
Cloudflare（2026-08-02）：账号 619151721@qq.com，域名 cloudjoind.com，ZoneID a56d0c8d2e517d1251f63d67d8096dd0，凭据 /root/.hermes/.cf_credentials（cfat_ Token 有 Workers 权限无 DNS 权限）。CF Worker 反代 cf-proxy：https://rss.cloudjoind.com/<URL> 国内可访问。用量脚本 /root/.hermes/scripts/cf_worker_usage.py 已接入老V巡检。VPS IP 192.3.241.244 在 Spamhaus ZEN+CBL 双黑名单（须公共 DNS 交叉验证），查 IP 用 ip_reputation.py。RSSHub 公共实例 rsshub.ktachibana.party 豆瓣 route 稳定，备用 rssforever/slarker/woodland。
§
跨 profile 通信：朵朵可用飞书 API 直发消息到小H Home 群（oc_8391fa2b38acbd759ff75ab3616d5d1f），凭据在 Hermes 环境变量，替代已拆联邦管道；机器人自发消息不自动触发小H，需用户 @ 唤醒。bsedu 注意：裸域名 bsedu.org.cn 无 DNS/超时，必须用带 www 的 www.bsedu.org.cn。
§
闲置华为平板 MRX-W19（mrx-w19）：无 GMS，Tailscale 100.78.214.117，只能走 Tailscale 内网（家宽直连被阻断）。✅住宅IP中继已生产化：Termux sshd:8022 + VPS systemd tablet-tunnel.service（ssh -D 10808 自动重连+失联降级~30s），出口=家宽IP 180.164.97.180。地域封锁站（bsedu/www.shanghai.gov.cn）走隧道 200；国外站走直连。Xray geosite:cn 分流（domainMatcher=linear、domain/ip 规则拆开）。⚠️纯净模式拦截侧载 APK（termux-boot 装不上、无开机自启）；冻结后台需白名单+wake-lock。开发者选项无无线调试（HarmonyOS精简），ADB 需 USB 一次 adb tcpip 或替代。细节见 skill vps-residential-ip-egress
§
教训：域名/URL/路径必须从实际命令输出复制，禁止手写或凭印象缩写（曾把 www.bsedu.org.cn 手写成 bsedu.org.cn 导致误解）。涉及具体地址写后必须对照原始输出复核。
§
skill_manage 受限：后台 curator 无法 patch/edit/write_file 所有 created_by=None 的手动创建技能（chinese-cloud-resource-search、hermes-internals、community-scraping、camoufox-install、vps-patrol 等全部受限，2026-08-16 实测确认是普遍规律非个别清单）。绕过：正常对话用 write_file/patch 直接写技能文件，或 skill_manage create 新建 agent-created 技能（新技能可正常写 scripts/ 等）。
§
VPS 性能教训：2核/2.4G 内存，禁止跑大版本跨度的本地 git diff --stat（如 4032 commits 会卡几分钟致响应超时）。查 Hermes 新版本用 GitHub API releases 接口。
§
ssh.cloudjoind.com 在 JoinD 隧道有入口（→ localhost:22）但 DNS 无 A 记录，实际不可用；proxy.cloudjoind.com 是 Xray VLESS 入口非通用代理。SSH 反代须用 Tailscale 内网。
§
用户工作风格：偏好实测验证（常'你试试'、主动制造故障测兜底），倾向收益更大的方案；拒绝飞书传文件，设备操作要求直接走 SSH。
§
抓取偏好：匿名抓取公开内容（camoufox+住宅IP），不碰账号登录态（防封号）；APP登录态与网页Cookie两套体系，无法从APP侧获取网页登录。cn-scraper-mcp 已部署 /opt/cn-scraper-mcp（venv），XHS_PROXY=socks5://127.0.0.1:10808 走家宽隧道；经验：小红书搜索页游客报 300012'IP at risk'=强制登录非IP问题（首页可匿名访问）；chromium(snap) headless 指纹易被识别
§
家庭路由器=华为 AX WiFi6（网关192.168.110.1），固件封闭不可刷 OpenWrt；免 V2RayN 用设备端 Clash Verge 分流。