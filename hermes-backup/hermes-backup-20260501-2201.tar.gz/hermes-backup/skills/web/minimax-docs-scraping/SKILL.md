---
name: minimax-docs-scraping
description: MiniMax 文档站点的安全抓取方法 — 绕过 curl|python3 管道拦截，直接获取 .md 页面原始内容
tags: [minimax, scraping, docs, browser]
category: web
risk: read-only
---

# MiniMax 文档站点抓取（安全方法）

## 问题
`tirith` 安全扫描拦截 `curl ... | python3` 管道命令（pattern: `tirith:curl_pipe_shell`），导致常规抓取方法全部失败。

## 解法
MiniMax 文档站点的 `.md` 页面（`/docs/xxx.md`）返回原始 Markdown 内容，无需 HTML 解析或 JavaScript 渲染。

### 可直接抓取的页面
| 用途 | URL |
|------|-----|
| 模型发布日志 | `https://platform.minimax.io/docs/release-notes/models.md` |
| API 更新日志 | `https://platform.minimax.io/docs/release-notes/apis.md` |
| 价格总览 | `https://platform.minimax.io/docs/pricing/overview.md` |
| 完整文档索引 | `https://platform.minimax.io/docs/llms.txt` |

### 工具选择
- **Browser 工具**（推荐）：`browser_navigate` → `browser_console(expression)` 提取纯文本
- **不要用** `curl | python3`（会被 tirit 拦截）

## 流程
1. `browser_navigate(url)` → 加载页面
2. `browser_console(expression)` → `document.body.innerText` 获取纯文本内容
3. 内容即为原始 Markdown，可直接解析

## 状态
验证日期：2026-05-01，通过
