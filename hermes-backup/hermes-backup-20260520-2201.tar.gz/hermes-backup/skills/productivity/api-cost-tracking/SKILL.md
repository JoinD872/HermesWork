---
name: api-cost-tracking
description: 多 provider API 费用追踪 — 实时余额查询、每次任务成本核算、人民币计价报告。所有 provider 通用框架 + DeepSeek 具体实现参考。
version: 1.1.0
metadata:
  hermes:
    tags: [cost, billing, balance, deepseek, pricing, tracking]
risk: read-only
---

# API Cost Tracking

通用框架：每次执行任务后自动报告本次花费和账户余额。

## 用户偏好

**成本报告必须用人民币（¥）**。即使 API 以美元计价，最终输出前也要按汇率换算为人民币再报告。

**格式偏好（用户明确指定）**：`本次对话：¥X.XX | 余额：¥X.XX` — 一行搞定，不要 emoji 前缀，不要多余解释。

**每条回复都要附上**，不论任务大小。用户会检查是否遗漏。

用户偏好自动化方案（通过余额 API 实时查询）而非手动估算。信"实时差值"不信"手动推算"。

## 通用架构

```
任务开始      任务结束      回复用户
   │            │            │
   ▼            ▼            ▼
[查余额A] → [执行任务] → [查余额B] → [余额B - 余额A = 本次花费] → [附在回复末尾]
```

### 方案选择

| 方案 | 适用场景 | 准确度 | 实现复杂度 |
|------|----------|--------|-----------|
| **余额 API 差值法** | provider 提供余额查询 API | ⭐⭐⭐ | 低 |
| **Token 反算法** | provider 无余额 API 但已知定价 | ⭐⭐ | 中 |
| **手动记账法** | 无 API 无定价信息 | ⭐ | 低 |

**DeepSeek 用户优先用方案1**（余额 API 直通）。

## DeepSeek 实现

### 余额查询 API

```bash
# 从 .env 读取 API Key 并查询余额
source /root/.hermes/.env 2>/dev/null && \
curl -s https://api.deepseek.com/user/balance \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY"
```

响应示例（**直接返回人民币 CNY**，无需汇率换算）：
```json
{
  "is_available": true,
  "balance_infos": [
    {
      "currency": "CNY",
      "total_balance": "21.50",
      "granted_balance": "0.00",
      "topped_up_balance": "21.50"
    }
  ]
}
```

- `total_balance`: 当前总余额（CNY）
- `granted_balance`: 赠送余额（不可退款）
- `topped_up_balance`: 充值余额（可退款）

### DeepSeek V4 Flash 定价（每百万 tokens）

| 类型 | 美元 | 人民币 (≈6.80) |
|------|------|----------------|
| 输入（缓存命中 cache_hit） | $0.0028 | ¥0.019 |
| 输入（缓存未命中 cache_miss） | $0.14 | ¥0.95 |
| 输出 | $0.28 | ¥1.90 |

> 缓存命中价比原始发布价再降 1/10（2026/4/26 生效）。实际使用中因大量缓存命中，成本极低。

DeepSeek V4 Pro 当前 75% 折扣（至 2026/05/31 15:59 UTC）：
| 类型 | 折扣价 | 原价 |
|------|--------|------|
| 缓存命中输入 | $0.003625 | $0.0145 |
| 缓存未命中输入 | $0.435 | $1.74 |
| 输出 | $0.87 | $3.48 |

### Token 反算法（备用）

当余额 API 不可用时（仅作为 fallback）：

```python
cost = (
    cache_miss_tokens / 1_000_000 * 0.14 +
    cache_hit_tokens / 1_000_000 * 0.0028 +
    output_tokens / 1_000_000 * 0.28
)
cny_cost = cost * 6.80
```

但**优先用余额 API 差值法**，避免因定价变更导致算错。

## ⚠️ 强制执行规则（不得遗漏）

**每次回复前必须执行余额查询，不得跳过。** 用户对此严格——如果你忘了查，用户会立即指出。

> 用户原话："为什么你回答时没显示余额和花费？"

请把余额查询视为回复的**前置步骤**，如同写回复内容一样自然。不要等到"任务完成"才想起查——每一条回复都要附上。

## 费用报告格式

每次回复末尾附上（**精确到两位小数，一行搞定，不要 emoji 前缀**）：

> 本次对话：¥X.XX | 余额：¥X.XX

示例：`本次对话：¥0.14 | 余额：¥21.13`

- 本次花费和余额均来自 API 实时差值
- 若余额低于 ¥5.00，末尾追加提醒「余额不足 ¥5，建议充值」

## Memory 管理

记忆当前余额用于差值计算：
```
## DeepSeek 余额追踪
上次余额: ¥21.50 (2026-05-20 12:34 HKT)
初始充值: ¥21.50 (全部自充值)
```

注意：memory 中的余额仅作参考，实际以 API 实时查询为准。

## 常见陷阱

1. **API Key 不在环境变量中** — 仅在 `.env` 文件中。必须用 `source /root/.hermes/.env` 加载后再用 `$DEEPSEEK_API_KEY`，不能直接 `os.environ.get()`
2. **余额不变** — 如果两次查询余额相同，可能因为：(a) 缓存命中率极高导致花费 ¥0.00xx 级别，金额太小小数点截断；(b) 本轮是纯读取操作没调 API
3. **多 provider 混合** — 如果使用了 fallback provider（如 openrouter），余额 API 只查 DeepSeek 的余额，需要分别追踪
4. **任务内多轮 API 调用** — 一个任务可能产生多次 LLM 调用（工具使用 + 多轮对话），余额差值法自动聚合了所有调用成本
