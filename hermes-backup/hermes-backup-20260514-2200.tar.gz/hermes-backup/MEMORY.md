## 搜索策略（2026-05-09 更新 — 移除 MiniMax web_search）

**统一引擎**：SearXNG (`mcp_searxng_search`) — google 引擎，中文英文都覆盖。
**原因**：MiniMax web_search (`mcp_minimax_plan_web_search`) 平台级 404，全部下线。不再使用。

**执行习惯**：搜索前先判断语言和平台，但引擎统一走 SearXNG。不需要两个引擎分场景切换了。
§
## VPS IP 封锁（重要）
VPS 192.3.241.244 被 Epic Games + Cloudflare 屏蔽，无法访问：dev.epicgames.com / docs.unrealengine.com / unrealengine.com。搜索 Epic 相关内容走 SearXNG + 第三方站（Tom Looman / GameFromScratch / Vagon）。
§
## Hermes 系统管理风格（2026-05-02）

用户使用 GPT 作为"架构评审"角色：小H 执行自我审查 → GPT 出评审报告 → 用户转发指令给小H 执行。这是一种「AI 审查、AI 改进」的迭代模式。

执行风格偏好：
- 指令分 P0/P1/P2 优先级，依次执行
- 每个改动都要有验证步骤和回滚方案
- 不接受"先改再说"，必须"先诊断→列影响→再执行"
- 完成后必须出结构化汇报（GPT 要求统一格式）

## 小研研究沉淀问题（未解决）

现状：小研 callbacks（MINIMAX_DAILY/PAIN/UE5WP）存在 callbacks/ 但小H 不主动读取。
结果：研究"存了"但没有"用了"，MEMORY.md 里没有沉淀任何研究结论。
需要：研究结论自动同步 global_knowledge.md，或 cron 输出包含"对小H有用的行动项"。
§
## VPS 安全事件（2026-05-03 已修复）
- SSH 被暴力破解后停掉 → 已恢复（服务在运行）
- 端口已改为 2222
- ✅ Fail2Ban 已安装运行（帮你挡了 47k+ 次攻击）
- ✅ SSH 公钥免密登录已配置（小H 用 ed25519 私钥）
- nginx 因 /tmp/vpsfiles.conf 被清空而挂 → 已修复并移到永久路径
- cloudflared tunnel 521 错误 → 已恢复
- proxy.cloudjoind.com → HTTP 200 正常
§
GitHub PAT 实际位置在 /root/.hermes/scripts/hermes-backup.sh（不在 .env），用户 JoinD872，仓库 JoinD872/HermesWork（私人），Token 前缀 ghp_6q...XGvJ。以后查 GitHub 认证先看 backup.sh。
§
用户云端迭代工作流：文件放 GitHub JoinD872/HermesWork/workspace/，用户在网页版改，我读+改+提交推送。不走 Google Drive/百度网盘/飞书云盘。
§
## Google Sheets 宠物技能设计工作流（2026-05-07 确立）

**主表格**：159VrH0vBDT41xHGZnuzCoYxUE7i6u1xvEJvlFKYqUsw（宠物技能设计）
**Drive 素材根文件夹**：1pOtpgVsnMONss2GrsSUv0PUahSmnn5t2（每个宠物一个同名子文件夹）
**Github Repo**：JoinD872/HermesWork（public，sucai/ 目录存技能参考图）

**完整链路**：Google Drive 读素材 → 写动作/特效描述到表格 → pollinations.ai 生图 → GitHub Contents API 上传 → IMAGE 公式嵌入表格
**规范**：先中文草案确认方向再生成；回合制小技能1.5-3s，大招2.5-4s；姿态参考隼龙低桩横刀
**Skill 已建**：/root/.hermes/skills/pet-skill-design-workflow/SKILL.md
§
## 图片理解（2026-05-09 更新 — 切 DeepSeek V4 原生 Vision）

**首选**：DeepSeek V4 原生 Vision（直接通过文字引用图片路径或 URL）
**备用**：`mmx vision describe <图片路径>`（仅当 DeepSeek Vision 不可用时）
**不再使用**：MCP `understand_image`（平台级 404）

注意：`mmx vision describe` 对某些图片可能静默返回 exit_code=1（`input sensitive`），此时降级到浏览器截图等方式。
§
## 宠物技能参考图生成工作流（2026-05-07 确立）

**核心需求**：Google Sheet Mega甲贺忍蛙页面，生成技能动作参考图（G/I列）
**参考规范**：技能设计参考1~6（宠物图片文件夹里）

**成功方案**：
分帧生成 + PIL合成：分开生成干净单帧（强调flat minimalist silhouette）→ PIL亮度阈值后处理统一背景 → 横向拼合

**关键参数**：
- 单帧 prompt：flat minimalist warrior silhouette, 纯色统一背景, 只用能量色点缀
- 背景分离：numpy亮度阈值~95，亮于阈值替换为统一深灰BG_COLOR=(55,55,62)
- 裁切：src_h * 12% 顶部去掉（纯背景区域）
- 拼合：FRAME_W=380, FRAME_H=500, GAP=6px, 输出1200px宽
- pollinations.ai：单次90s超时，30s sleep重试，~30KB/帧

**失败教训**：
- pollinations.ai 无法在单次prompt里生成多格漫画（总是输出2x3网格或变形）
- 竖屏单帧（600x600）角色一致性最稳定
- 横向条带prompt（16:9）生成出来背景不一致、帧数不对
- 纯灰色剪影（不是绿色忍蛙）更符合参考图风格

**GitHub路径**：JoinD872/HermesWork/sucai/final_Skill_A~D.png
**表格公式**：=IMAGE("URL",2)，列宽420px，行高250px
§
## 图片理解工具（2026-05-09 更新）

| 方式 | 状态 | 说明 |
|------|------|------|
| DeepSeek V4 原生 Vision | ✅ 首选 | 直接通过文本引用图片，模型原生理解 |
| `mmx vision describe` (CLI) | ✅ 备用 | 仅当 DeepSeek Vision 不可用时 |
| `mcp_minimax_plan_understand_image` | ❌ 已下线 | MiniMax MCP 网关 endpoint 404 |
| `vision_analyze` | ❌ 已下线 | 不再使用 |
§
Windows 桌面 (desktop-tg4loen) Tailscale SSH 连接：`ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37`。Tailscale IP 100.86.150.37，用户 joind（Windows 本地用户，非 Tailscale 账号）。工作目录 E:\Hermes\。DERP relay 模式，约 180ms 延迟。vps-technician 的 SOUL.md 已有 SOP。
§
## 用户 Windows 桌面 SSH 连接方法（2026-05-10 已打通）

**连接命令：**
```bash
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 "<command>"
```

**参数详解：**
| 参数 | 值 |
|------|-----|
| Tailscale IP | 100.86.150.37 |
| 主机名 | desktop-tg4loen |
| SSH 用户 | `joind`（Windows 本地用户，不是 Tailscale 账号） |
| 私钥 | `/root/.ssh/id_ed25519`（VPS 已有，已授权） |
| 工作目录 | `E:\Hermes`（已在 Windows E 盘创建） |
| 连接方式 | Tailscale DERP relay（延迟 ~180ms，无直连但也够用） |
| SSH 端口 | 22（默认） |

**网络状态：** 通过 Tailscale 网络，VPS 洛杉矶 <-> 上海宝山。ping 通，但无直连（DERP relay）。连接有时会超时，重试即可。

**无需操作：** 不改 sshd_config，不重启 sshd，不换用户。

**已验证：** 2026-05-10 成功写入 E:\\Hermes\\hermes_test.txt
§
用户有两台 Windows 电脑通过 Tailscale 连接到同一账号：
1. `desktop-tg4loen`（桌面台式机，上海宝山，在线）— SSH 已打通，joind 用户
2. `laptop-fof8llrf`（笔记本，截至2026-05-10已离线约30+天，状态 offline/last seen 32d ago）— 待配置 SSH 连接