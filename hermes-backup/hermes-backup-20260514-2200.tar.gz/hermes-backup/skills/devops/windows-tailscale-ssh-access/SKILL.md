---
name: windows-tailscale-ssh-access
description: SSH from Hermes VPS into a Windows desktop over Tailscale — identity discovery, connection troubleshooting, and working commands for file operations on Windows drives.
tags: [windows, tailscale, ssh, devops]
category: devops
risk: write-safe
---

# Windows Tailscale SSH Access

## Background

Hermes runs on a Linux VPS. The user's Windows desktop is connected via Tailscale (same account). Windows has OpenSSH Server running. The goal is to read/write files on the Windows machine (typically `E:\Hermes\` directory).

## Working Connection Command

```bash
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 "<command>"
```

**Key Parameters:**
| Parameter | Value | Why |
|-----------|-------|-----|
| **User** | `joind` | Windows local user, NOT Tailscale account name (w619151721@) |
| **SSH Key** | `/root/.ssh/id_ed25519` | VPS's existing SSH key, added to Windows `joind` user's `authorized_keys` |
| **Host** | `100.86.150.37` | Tailscale IP of `desktop-tg4loen` |
| **Fallback hostname** | `desktop-tg4loen.tail3a58b3.ts.net` | Works but first connect needs `StrictHostKeyChecking=accept-new` |

## Windows Machine Info

| Property | Value |
|----------|-------|
| Hostname | DESKTOP-TG4LOEN |
| Tailscale IP | 100.86.150.37 |
| Status | Online, DERP relay only (~180ms via SFO) |
| Home directory | `C:\Users\JoinD` |
| Hermes work dir | `E:\Hermes\` |

## Common Operations

### Verify connection
```bash
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=10 joind@100.86.150.37 "echo WINDOWS_OK && hostname && whoami"
```

### List E drive
```bash
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=10 joind@100.86.150.37 "dir E:"
```

### Write a file (Windows cmd syntax — use `>>` and escape `^` for special chars)
```bash
# Single line
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=15 joind@100.86.150.37 "echo Hello >> E:\\Hermes\\test.txt"

# With special chars — escape `^` before `(` `)` `&` `|` `>`
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=15 joind@100.86.150.37 'echo Hello from Agent ^(VPS^) >> E:\Hermes\test.txt'
```

### Read a file
```bash
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=10 joind@100.86.150.37 "type E:\\Hermes\\test.txt"
```

### Create directory
```bash
ssh -i /root/.ssh/id_ed25519 -o ConnectTimeout=10 joind@100.86.150.37 "if not exist E:\\Hermes mkdir E:\\Hermes"
```

## Connection Troubleshooting

### Symptom: `Permission denied (publickey,password,keyboard-interactive)`
**Cause:** Wrong username or wrong SSH key.

**Fix:**
1. Use Windows local username (`joind`), NOT the Tailscale account name (`w619151721@`)
2. Put the VPS's public key (`/root/.ssh/id_ed25519.pub`) into Windows user's `C:\Users\<user>\.ssh\authorized_keys`
3. DO NOT modify `C:\ProgramData\ssh\sshd_config` or restart sshd — Windows default config allows key auth for local users
4. DO NOT use `Administrator` — connection gets reset

### Symptom: `Connection timed out during banner exchange`
**Cause:** Tailscale relay instability, or the Windows machine briefly unreachable.

**Fix:** Retry after a few seconds. Use `-o ConnectTimeout=15` for more tolerance.

### Symptom: `No direct connection` (DERP relay only)
**Normal.** The VPS and Windows desktop are on different NATs (VPS in US, Windows in China behind CGNAT). DERP relay adds latency (~180ms) but works fine for file operations.

### Symptom: PowerShell commands time out
**Fix:** Prefer cmd.exe commands (`dir`, `echo`, `type`) over PowerShell. PowerShell on Windows SSH sometimes hangs on first invocation.

## Pitfalls

1. **Public key ≠ private key.** If the user sends a `.pub` file, they still need to provide the corresponding private key. The VPS's own `id_ed25519` was the correct key all along.
2. **Tailscale username doesn't map to SSH username.** Windows SSH uses the local Windows username, not the Tailscale identity.
3. **Don't change sshd_config.** Windows defaults work. Changing them can break more than it fixes.
4. **cmd.exe is more reliable than PowerShell** for SSH-triggered commands on Windows.
5. **Connection is intermittent** due to DERP relay. Always expect occasional timeouts and retry.
