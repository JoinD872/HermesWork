---
name: vps-cloudflare-tunnel-ip-pattern
description: Cloudflare Tunnel (JoinD) 架构下优选 IP 的识别与手机端复用配置
risk: read-only
version: 1.0
created: 2026-04-28
---

# Cloudflare Tunnel 优选 IP：识别与手机端复用

## 核心发现

JoinD Cloudflare Tunnel 架构下，PC 通过 hosts 绑定的"优选 IP"不是 CDN IP（104.x.x.x / 172.67.x.x），而是 **Cloudflare 隧道直连节点 IP**，位于 `108.162.x.x` 网段。

```
查询结果：
proxy.cloudjoind.com DNS 解析 → 104.21.84.119（标准 CDN IP，不是优选）
PC hosts 绑定 → 108.162.198.81（隧道直连节点 IP，这才是优选）
```

**验证方法**：查 cloudflared 日志里的 `RegisterTunnelConnection` 记录，连接 IP 在 `198.41.x.x`（CF 边缘节点），但 hosts 里的 IP 通常是 `108.162.x.x`——两者不同，需要从 PC hosts 文件中提取真实优选 IP。

## 已知 JoinD 优选 IP

| IP | 域名 | 备注 |
|----|------|------|
| `108.162.198.81` | proxy.cloudjoind.com | LA 节点 |
| `108.162.198.81` | open.cloudjoind.com | 同节点 |

## 手机端配置（V2RayNG / 通用）

目标：复现 PC hosts 效果，让手机绕过 DNS 直接命中优选节点。

| 字段 | 值 |
|------|-----|
| 服务器地址 | `108.162.198.81`（从 PC hosts 提取）|
| 端口 | `443` |
| SNI / Host | `proxy.cloudjoind.com`（保持原域名）|
| TLS | ✅ 开启 |
| 传输协议 | 保持原配置（WebSocket / gRPC 等）|

**原理**：地址栏填 IP 绕过 DNS，sni/host 填原域名让 Cloudflare TLS 证书正确验证，Tunnel 继续正常工作。

## 如何找到自己环境里的优选 IP

### 方法 1：从 PC hosts 文件提取
```
在 PC 上找：
108.x.x.x proxy.cloudjoind.com
108.x.x.x open.cloudjoind.com
```
那个 `108.x.x.x` 就是优选 IP。

### 方法 2：从 cloudflared 日志推断
```bash
docker logs cloudflared-joined 2>&1 | grep -i "198.41\|108.162"
```
找 `RegisterTunnelConnection` 行，记录里的 IP 即为隧道连接目标。

### 方法 3：Cloudflare Speedtest
访问 `speed.cloudflare.com` 或 `cloudflare.com/cdn-cgi/trace`，查看返回的 IP 和延迟。

## 注意事项

- **不要把 VPS IP（192.3.241.244）当作优选 IP 填入手机**——VPS IP 已被墙/不稳定，Tunnel 正是用来隐藏源站的
- **保留原始域名配置作为 fallback**：如果优选 IP 失效，手机端切回 `proxy.cloudjoind.com` 即可
- **108.162.x.x 是 Anycast 入口 IP**，不是单一服务器 IP，Cloudflare 会自动路由到最近边缘节点

## JoinD Tunnel 架构速查

```
设备(V2RayN)
→ proxy.cloudjoind.com:443
→ Cloudflare Tunnel (108.162.198.81 入口)
→ Cloudflare 全球 Anycast 网络
→ 198.41.x.x 边缘节点
→ Tunnel 回源
→ VPS (192.3.241.244)
```
