     1|---
     2|---
     3|name: hermes-internals
     4|description: Hermes Agent 内部机制核心知识 — 基于官方文档。Frozen Snapshot Pattern、字符限制、Skills 三级加载、OpenClaw 迁移。
     5|version: 1.0.0
     6|metadata:
     7|  hermes:
     8|    tags: [hermes, internals, memory, skills, openclaw, migration]
     9|risk: read-only
    10|---
    11|
    12|# Hermes Internals
    13|
    14|## ❄️ Frozen Snapshot Pattern（最重要）
    15|
    16|**Session 期间对 MEMORY.md 的修改，下个 session 才生效。**
    17|
    18|> "The system prompt injection is captured once at session start and never changes mid-session. When the agent adds/removes memory entries during a session, the changes are persisted to disk immediately but won't appear in the system prompt until the next session starts."
    19|
    20|**实际影响**：
    21|- `memory` 工具的 add/replace 操作 → disk 立即写入，下次 session 生效
    22|- 我现在 session 里更新的记忆，刷新页面/重连后才能在 prompt 里看到
    23|- 每次 session 开始时 prompt 里显示的 `%` 利用率是**上个 session 结束时**的快照
    24|
    25|## 📏 Memory 字符限制（bounded memory）
    26|
    27|- `MEMORY.md` 上限：**2,200 chars**
    28|- `USER.md` 上限：**1,375 chars**
    29|- 满了会自动 consolidation（合并/替换旧记忆）
    30|- 当前利用率在每次 session 启动时显示，如：`[67% — 1,478/2,200 chars]`
    31|
    32|**记忆必须精简**，不能往里塞大量原始内容。
    33|
    34|## 📚 Skills 三级加载（Progressive Disclosure）
    35|
    36|```
    37|Level 0: skills_list() → [{name, description, category}, ...] (~3k tokens)
    38|Level 1: skill_view(name) → 完整内容 + metadata（实际使用时才加载）
    39|Level 2: skill_view(name, path) → 具体引用文件（最细粒度）
    40|```
    41|
    42|agent 调用 skill 时按需加载，不是全量加载。
    43|
    44|## 🆕 Skills 新字段（我的 skills 缺的）
    45|
    46|SKILL.md 支持但我目前没用到的字段：
    47|
    48|```yaml
    49|platforms: [macos, linux]        # OS 限制
    50|metadata:
    51|  hermes:
    52|    fallback_for_toolsets: [web]  # 条件激活
    53|    requires_toolsets: [terminal]  # 依赖条件
    54|    config:                        # 安装时用户配置
    55|      - key: my.setting
    56|        description: "..."
    57|        default: "value"
    58|        prompt: "Prompt for setup"
    59|```
    60|
    61|## 🗂️ OpenClaw 迁移状态
    62|
    63|**重要发现**：OpenClaw workspace 文件夹没有自动迁移。
    64|
    65|```
    66|OpenClaw 旧数据:  ~/.openclaw/workspace/knowledge/
    67|  deep-learning.md   ← 还在这里！
    68|  network.md         ← 还在这里！
    69|
    70|Hermes skills:      ~/.hermes/skills/knowledge/  ← 不存在，未迁移
    71|```
    72|
    73|如果要从 OpenClaw 迁移 knowledge 文件，需要手动复制到 `~/.hermes/skills/`。
    74|
    75|迁移命令 `hermes claw migrate` 只迁移人格/记忆/技能/消息配置/凭据，不迁移 workspace 普通文件。
    76|
    77|## 🖼️ Vision 识别（2026-05-09 更新 — MiniMax 迁移后）

**主流模型切换**：主力模型从 MiniMax 切换为 **DeepSeek V4**。
MiniMax MCP server（`minimax-coding-plan-mcp`）已全部移除，包括 `understand_image` 和 `web_search`（均为平台级 404）。

**当前 Vision 方案（按优先级）**：

| 方式 | 状态 | 说明 |
|------|------|------|
| `vision_analyze` tool | ✅ 可用 | 走独立 vision 路由链（主 provider → OpenRouter → Nous）。通过 `vision_analyze(image_url, question)` 调用 |
| `mmx vision describe` CLI | ⬜ 备用 | 仅当 `vision_analyze` 不可用时降级使用（注意可能报 `input sensitive`） |
| `mcp_minimax_plan_understand_image` | ❌ 已移除 | MiniMax MCP 网关 endpoint 404，MCP server 已从 config 移除 |

**`vision_analyze` 机制**：独立于主模型路由。通过 `task="vision"` 走 `resolve_vision_provider_client()` 链：
1. 主 provider 的 vision 模型（DeepSeek V4）
2. → fallback OpenRouter
3. → fallback Nous Portal

**有效文件判断**：`file /root/.hermes/image_cache/img_xxx.jpg` 返回有效 JPEG（文件本身没坏）|