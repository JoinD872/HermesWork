---
name: cron-create-update-debug
description: Hermes Cron create/update 报错 "<=' not supported between instances of 'str' and 'int'" 的排障与绕行方案
category: hermes
tags: [cron, debug, troubleshooting, hermes]
risk: read-only
---

# Cron Create/Update 报错排障

## 症状

通过 `cronjob(action='create')` 或 `cronjob(action='update')` 创建/更新 cron job 时：
- 返回 `{"success": false, "error": "'<=' not supported between instances of 'str' and 'int'"}`
- `list`、`pause`、`resume`、`remove` 正常，只有 `create` 和 `update` 失败

## 已验证的触发条件

| 操作 | 短 prompt (如 `echo hello`) | 带中文+比较符的 prompt | 含 `deliver: "origin"` 参数 |
|------|--------|--------|--------|
| create | ✅ | ❌ 类型错误 | ❌ 类型错误 |
| update | ✅ | ❌ 类型错误 | ❌ 类型错误 |

## 根因（推测）

Hermes Cron 在处理 prompt 时，对某些字符组合（比较符 `<=` + 中文）的序列化或验证逻辑存在 bug。

## 临时绕行方案

### 方案 A：用极短 prompt 调用脚本（推荐）

1. 把完整逻辑写入独立脚本
2. Cron prompt 只写脚本路径：`bash /root/.hermes/scripts/xxx.sh`
3. 脚本内部完成所有复杂逻辑

```bash
# 示例
cronjob(action='create', prompt='bash /root/.hermes/scripts/xiaojian-daily-reminder.sh', ...)
```

### 方案 B：用 skill 调用脚本

1. Cron prompt 引用 skill，skill 内容是调用脚本的指令
2. Cron 加载该 skill，由 skill 内部执行脚本

## 已验证可行的 Cron 创建方式

```
# ✅ 有效
cronjob(action='create', prompt='echo hello', repeat='forever', schedule='0 12 * * *')

# ❌ 无效（无论多短，只要 prompt 含比较符/中文混排就可能触发）
cronjob(action='create', prompt='你是小健，健康顾问', ...)

# ✅ 有效：极短 prompt + skills 分离逻辑
cronjob(action='create', prompt='bash /root/.hermes/scripts/xxx.sh', skills=['productivity:cron-output-standard'])
```

## Cron 满额处理

- 默认上限 8 个 job
- 满额时无法 create，需要先 pause 或 remove 低优先级 job

## 验证命令

```bash
# 测试是否能创建
cronjob(action='create', prompt='echo test', schedule='0 12 * * *')

# 测试是否能更新
cronjob(action='update', job_id='<现有ID>', prompt='echo test2')

# 如果两者都成功，说明问题已修复
```

## 回滚方式

若在调试中破坏了现有 cron：
- `cronjob(action='list')` 查看所有 job
- `cronjob(action='resume', job_id='<暂停的ID>')` 恢复
- 根据 job 的 prompt_preview 重建被删除的 job

## 相关文件

- 小健 cron job 已 pause：a2d3c2998db3
- 小健脚本：`/root/.hermes/scripts/xiaojian-*.sh|py`
- 健康数据：`~/.hermes/profiles/health-advisor/data/`
