# Provider Prompt Caching Behavior

Different LLM providers implement prompt caching fundamentally differently. Understanding these differences determines whether cache optimization recommendations actually make sense for your setup.

## DeepSeek (V4 Flash / V4 Pro / R1)

**Mechanism:** Automatic byte-level prefix caching. No code/API changes needed.

- Cache granularity: 64-token chunks, full prefix units
- Matches must be **byte-exact** on the prefix. One character difference → cache miss
- Server-side distributed disk cache, persists across requests automatically
- No `cache_control` markers, no TTL configuration available

**Confirmed in practice (May 2026, deepseek-v4-flash):**
- `usage.prompt_tokens_details.cached_tokens` **IS populated** in API responses
- First request (cold session): ~3% hit rate — still hits shared prefix from other sessions
- Second request (same session, +1 tool turn): **~100% cache hit**
- Cache survives across requests from different sessions/users as long as the byte prefix matches

**What this means for agent frameworks like Hermes:**

| Factor | Impact |
|--------|--------|
| `_cached_system_prompt` frozen per session | ✅ Prefix stable → high in-session hit rate |
| `sorted(tool_names)` in `registry.get_definitions()` | ✅ Cross-session tool order stable |
| `_deterministic_call_id()` | ✅ No random UUIDs in tool call IDs → prefix stays clean |
| Context compression (`/compress`) | ❌ Calls `_invalidate_system_prompt()` → full cache reset |
| `ephemeral_system_prompt` (channel_prompt) | Appended at tail of system prompt — last cache unit only |
| Timestamp in volatile layer | Per-session, at tail — ~2-4% of prefix affected |

**Cache pricing:** $0.28/M tokens (miss) → $0.028/M (hit) — 90% savings.

**Measured cache behavior (DeepSeek V4 Flash, May 2026):**
- First request in a new session: ~3% hit rate (640/20,225 tokens) — partial prefix preserved from prior sessions' shared prefix (the ~2.1KB default SOUL.md routing rules). DeepSeek's distributed disk cache does hold common prefixes across sessions.
- Second request (same session, one tool call appended): **100% hit rate** (20,352/20,420 tokens) — only 68 new tokens (the tool result) missed cache.
- `usage.prompt_tokens_details.cached_tokens` **IS populated** — confirmed from actual API response.
- Hermes `--verbose` mode exposes these stats at the "API Response received" log line.

**Cross-session/cross-channel sharing:**
**Cross-session/cross-channel sharing:**\nAll profiles under the default profile share the same `_cached_system_prompt` prefix (~2.1KB routing rules). Per-channel identity (SOUL.md + MEMORY.md) is injected via `ephemeral_system_prompt` at the tail via `channel_prompt` — only affects the last cache unit. So all 4 groups (小策/黑翼/小研/老V) + DM share the first 2.1KB of prefix across sessions automatically.

**Toolsets must match for cross-session hits:** `registry.get_definitions()` uses `sorted(tool_names)` — if two sessions have different enabled_toolsets, tool_names differ, tool list in the API `tools` parameter differs, prefix doesn't match.

**System prompt invalidation:** `_invalidate_system_prompt()` (run_agent.py:10722) is called on `/compress` / context compression — sets `_cached_system_prompt = None` and rebuilds from scratch. This resets the DeepSeek server-side cache entirely for subsequent requests. Accept this as a cost of compression, not an optimizable thing.

## Anthropic (Claude Sonnet/Opus/Haiku)

**Mechanism:** Explicit `cache_control` markers. Requires code changes.

- You mark specific content blocks with `{"cache_control": {"type": "ephemeral"}}`
- Cache TTL: 1 hour (cross-session if within window)
- Breakthrough token: minimum prefix write cost on first request
- Controlled entirely client-side — what you mark is what gets cached

**What this means:**

| Factor | Impact |
|--------|--------|
| Cross-session 1h cache | ✅ Works — Hermes v0.14.0 supports this natively |
| `cache_control` insertion | Hermes handles automatically for system prompt |
| Context compression | Resets like DeepSeek — cache lost |
| Dummy warmup requests | ✅ Useful — breakthrough tokens needed first time |

## OpenAI (GPT-4o / GPT-4.1)

**Mechanism:** Automatic prefix caching, similar to DeepSeek.

- No `cache_control` needed — works on repeated prefix
- Returns `prompt_tokens_details.cached_tokens` in usage stats
- Cache TTL: 5-10 minutes of inactivity
- Per-organization, not per-user

**What this means:** Similar optimization strategy as DeepSeek — keep prefix stable, avoid mid-session schema changes.

## Summary: Optimization Strategy Per Provider

| Question | DeepSeek | Anthropic | OpenAI |
|----------|----------|-----------|--------|
| Need to change code? | No | Yes (cache_control) | No |
| Dummy warmup useful? | No | Yes (breakthrough) | No |
| Cross-session works? | Auto (disk) | 1h TTL | Short TTL |
| Return cache stats? | Yes (confirmed) | Yes (via headers) | Yes |
| Compression impact? | Cache reset | Cache reset | Cache reset |

## Hermes Code Points (for verification)

- `run_agent.py:4803` — `_format_tools_for_system_message()`: **trajectory format only**, not runtime
- `run_agent.py:1864` — `self.tools = get_tool_definitions(...)`: runtime tool loading
- `run_agent.py:10228` — `tools=tools_for_api`: tools passed as separate API param
- `run_agent.py:6056-6262` — `_build_system_prompt_parts()`: stable/context/volatile tiers
- `run_agent.py:10722` — `_invalidate_system_prompt()`: called on compression, resets cache
- `tools/registry.py:354` — `sorted(tool_names)`: deterministic tool order
- `run_agent.py:6655` — `_deterministic_call_id()`: avoids UUID prefix drift
