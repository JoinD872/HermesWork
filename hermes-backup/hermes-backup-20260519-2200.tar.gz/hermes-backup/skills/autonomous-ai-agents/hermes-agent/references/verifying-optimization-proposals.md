# Verifying Agent-Optimization Proposals Against Actual Code

When an external AI (or a user) proposes an optimization, configuration change, or workflow improvement, the proposed steps often reference CLI commands, code paths, or config keys that **do not exist**. This reference documents a verification pattern to avoid implementing imaginary things.

## The Drill

Before accepting any proposed change, **trace at least one of these**:

### 1. CLI Commands — Do they actually exist?

Check: `hermes --help` shows all valid subcommands. If the proposal references `hermes context compress`, `hermes tools serialize`, `hermes chat --log-usage`, or any other subcommand not in the help output, it's fabricated.

**Pitfall:** AI models (both proposing and executing) tend to invent plausible-sounding CLI flags. The only ground truth is `hermes --help` and the actual source code.

### 2. Code paths — Do the function names and file paths match?

If a proposal says "fix `_format_tools_for_system_message()`", check:
- Does that function exist? `grep -rn "def _format_tools" run_agent.py`
- Is it actually on the runtime path, or is it for something else (e.g., trajectory saving)?
- Where is it actually called? `grep -rn "_format_tools_for_system_message" --include="*.py"`

**Pitfall:** A function name that sounds right for the task may serve a completely different purpose.

### 3. Config keys / environment variables — Do they exist?

If a proposal references `HERMES_CACHE_COMPRESS_DISABLE`, `schema缓存优化标志`, or any suggested env var:
- `grep -rn "ENV_VAR_NAME" config.yaml .env --include="*.py"` — does it appear anywhere?
- If not, it's made up.

### 4. File paths — Do the directories exist?

If a proposal says "back up to `~/.hermes/prompts/system_prompt.bak`":
- `ls ~/.hermes/prompts/` — does this directory exist?
- If the path references a convention the proposal invented, flag it.

### 5. Concept verification — Is it a real Hermes feature?

Checklist of commonly fabricated concepts:

| Fabrication | Reality |
|------------|---------|
| `hermes context compress` CLI | ❌ Doesn't exist. Compression is auto-triggered preflight or manual `/compress` slash command |
| `HERMES_STATIC_PREFIX` | ❌ Doesn't exist. System prompt is built by `_build_system_prompt_parts()` in run_agent.py |
| `schema缓存优化标志` | ❌ No such flag |
| `hermes tools serialize` | ❌ Doesn't exist. Tools are serialized by `json.dumps()` internally |
| `~/.hermes/prompts/` dir | ❌ Doesn't exist |
| `dummy warmup requests` for provider cache | Only useful for Anthropic (breakthrough tokens). Harmful/pointless for DeepSeek/OpenAI which auto-cache |

## Signals That Warrant the Drill

- The proposal is the **third or later iteration** trying to salvage an approach — diminishing returns set in
- The proposal references **CLI subcommands/arguments/encodings** you don't recognize
- The proposal creates **new env vars, config keys, or directory structures** as "hooks" for future use
- The proposal says "accept compression destroys cache" but then suggests ways to "mitigate" it in the same breath
- The proposal contains **验收标准 with percentage targets** (≥80% cache hit) that have no empirical basis

## What to Do Instead

1. **Run the actual CLI command** and see if it works
2. **Trace the actual source code** — find the function definition, read the docstring, check call sites
3. **Export verbose logs** (`--verbose`) to see what APIs return
4. **Accept what the architecture already does well** before trying to optimize it further
5. Prefer deleting speculative steps over "keeping them in case they're useful later"
