---
name: google-sheets-service-account
description: Google Sheets API 通过 Service Account 授权实现私密 AI 读写 — 无需 OAuth 用户登录、无需审核、无测试用户限制
version: 1.0.0
tags: [google, sheets, api, automation, service-account]
risk: write-safe
---

# Google Sheets + Service Account 读写指南

## 核心优势（对比 OAuth）

| 对比项 | OAuth 用户授权 | Service Account ✅ |
|--------|--------------|-------------------|
| 配置步骤 | 5-6步 + Google 审核 | 3步 |
| 测试用户 | 必须添加 | 不需要 |
| 发布审核 | 需要 | 不需要 |
| 适用场景 | 公共应用 | 私有 AI 自动化 ✅ |
| 封号风险 | 存在 | 极低 |

## 完整配置流程

### Step 1：创建 Service Account + 下载 JSON

1. 打开 [console.cloud.google.com](https://console.cloud.google.com)
2. 左侧菜单 → **API 和服务** → **库** → 启用 **Google Sheets API**
3. **凭据** → **创建凭据** → **服务账号**
4. 创建后进入服务账号详情 → **密钥** → **添加密钥** → **创建新密钥** → **JSON**
5. 下载的 JSON 文件发给 Hermes（安全存放）

### Step 2：Hermes 端配置

JSON 文件存放路径：
```
/root/.hermes/credentials/google-sheets-sa.json
```

Python 依赖：
```bash
pip install google-api-python-client google-auth
```

### Step 3：分享表格给 Service Account

1. 打开目标 Google Sheet
2. 右上角 **分享** → 添加人员输入：
   ```
   hermes-sheets-996@bold-circuit-495508-s6.iam.gserviceaccount.com
   ```
3. 权限选 **编辑者** → 发送

## Python 读写代码模板

```python
from google.oauth2 import service_account
from googleapiclient.discovery import build

CREDS_FILE = '/root/.hermes/credentials/google-sheets-sa.json'
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

creds = service_account.Credentials.from_service_account_file(CREDS_FILE, scopes=SCOPES)
service = build('sheets', 'v4', credentials=creds)

SPREADSHEET_ID = '表格ID（URL中 /d/ 和 /edit 之间的部分）'

# ========== 读取 ==========
result = service.spreadsheets().values().get(
    spreadsheetId=SPREADSHEET_ID,
    range="'工作表名'!A1:Z100"
).execute()
values = result.get('values', [])
for row in values:
    print(row)

# ========== 写入（覆盖） ==========
service.spreadsheets().values().update(
    spreadsheetId=SPREADSHEET_ID,
    range="'工作表名'!B2",
    valueInputOption='RAW',
    body={'values': [['新的单元格值']]}
).execute()

# ========== 批量写入 ==========
service.spreadsheets().values().update(
    spreadsheetId=SPREADSHEET_ID,
    range="'工作表名'!A1:Z5",
    valueInputOption='RAW',
    body={'values': [['行1Col1', '行1Col2'], ['行2Col1', '行2Col2']]}
).execute()
```

## 踩坑记录

### Sheet Name 导致 "Unable to parse range"

**问题**：`Sheet1!A1` 报错 — 实际工作表名不是 "Sheet1"  
**解决**：先用 `spreadsheets().get()` 获取 metadata，找到真实 sheet title（含中文/Mega等）  
```python
meta = service.spreadsheets().get(spreadsheetId=SPREADSHEET_ID).execute()
for s in meta['sheets']:
    print(s['properties']['title'])
```

### 403 "The caller does not have permission"

**原因**：Service Account 没有该 Sheet 的访问权限  
**解决**：在 Sheet UI 右上角分享 → 添加 Service Account 邮箱（`hermes-sheets-996@...`）→ 编辑者权限

### URL 中找 Spreadsheet ID

格式：`https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/edit`  
ID 是 `/d/` 和 `/edit` 之间的字符串

## 写入 IMAGE() 公式（嵌入公网图片）

Google Sheets API 可以写 `=IMAGE(url, mode, height, width)` 公式到单元格，实现图片嵌入。

```python
# 嵌入公网直链图片
SHEET_NAME = "'Mega甲贺忍蛙'"  # 含中文或特殊字符必须加引号
IMG_URL = "https://example.com/image.png"

service.spreadsheets().values().update(
    spreadsheetId=SPREADSHEET_ID,
    range=f"{SHEET_NAME}!I1",  # 目标单元格
    valueInputOption='RAW',
    body={'values': [[f'=IMAGE("{IMG_URL}",4,320,320)']]}  # mode=4=自定义尺寸
).execute()
```

**IMAGE 公式参数：**

| 参数 | 值 | 含义 |
|------|-----|------|
| mode | 1 | 自动适应单元格 |
| mode | 2 | 拉伸填满 |
| mode | 3 | 原尺寸 |
| mode | 4 | **自定义尺寸（最常用）** |
| height | 像素值 | 图片高度 |
| width | 像素值 | 图片宽度 |

**图片直链要求：**
- 必须是`.png`、`.jpg` 等浏览器可直接打开的图片 URL
- 不能有防盗链（Pixiv/ArtStation/百度图片等大概率失败）
- Pokemon 官方图可直链：`https://legends.pokemon.com/_next/image?url=%2F...&w=1080&q=75`

---

## 调整行高 & 列宽（batchUpdate）

写入图片后需调整行列尺寸才能正常显示。

```python
SHEET_ID = 1138954322  # 从 meta['sheets'][n]['properties']['sheetId'] 获取

requests = [
    # 调整列宽
    {
        "updateDimensionProperties": {
            "range": {"sheetId": SHEET_ID, "dimension": "COLUMNS", "startIndex": 8, "endIndex": 9},
            "properties": {"pixelSize": 340},
            "fields": "pixelSize"
        }
    },
    # 调整行高
    {
        "updateDimensionProperties": {
            "range": {"sheetId": SHEET_ID, "dimension": "ROWS", "startIndex": 0, "endIndex": 1},
            "properties": {"pixelSize": 340},
            "fields": "pixelSize"
        }
    },
]

result = service.spreadsheets().batchUpdate(
    spreadsheetId=SPREADSHEET_ID,
    body={"requests": requests}
).execute()
```

**踩坑：**
- `dimension` 写 `"COLUMNS"` 别拼错
- `startIndex` / `endIndex` 是索引不是像素值
- `fields` 必须写 `"pixelSize"` 否则不生效

---

---

## Google Drive API 扩展（同一 Service Account）

Service Account 开通后不仅可以读 Sheets，还能读 Drive 文件。需要额外开通 Drive API。

### Step 1：开通 Drive API（用户操作）

1. 打开 https://console.developers.google.com/apis/api/drive.googleapis.com/overview?project=77775222475
2. 点击顶部 **「启用」**
3. 几秒后刷新页面确认显示"API 已启用"
4. 完成后回来通知 Hermes 重试

> **项目编号固定**：`77775222475`（即 Service Account 所在项目）

### Step 2：Drive API 读写代码模板

```python
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import io

CREDS_FILE = '/root/.hermes/credentials/google-sheets-sa.json'
SCOPES = ['https://www.googleapis.com/auth/drive.readonly']  # 只读即可

creds = service_account.Credentials.from_service_account_file(CREDS_FILE, scopes=SCOPES)
service = build('drive', 'v3', credentials=creds)

# ========== 列出文件夹内容 ==========
FOLDER_ID = '文件夹ID（URL末尾那段）'

results = service.files().list(
    q=f"'{FOLDER_ID}' in parents and trashed=false",
    pageSize=100,
    fields='files(id, name, mimeType, size, modifiedTime)'
).execute()

for f in results.get('files', []):
    is_folder = 'folder' in f.get('mimeType', '')
    size = f.get('size', '')
    size_str = f'{int(size)/1024:.0f}KB' if size else ''
    icon = '📁' if is_folder else '📄'
    print(f"{icon} {f['name']} {size_str}")

# ========== 递归列出子文件夹 ==========
def list_folder(folder_id, indent=0):
    results = service.files().list(
        q=f"'{folder_id}' in parents and trashed=false",
        pageSize=100,
        fields='files(id, name, mimeType, size)'
    ).execute()
    for f in results.get('files', []):
        is_folder = 'folder' in f.get('mimeType', '')
        size = f.get('size', '')
        size_str = f'{int(size)/1024:.0f}KB' if size else ''
        icon = '📁' if is_folder else '📄'
        print(f"{'  '*indent}{icon} {f['name']} {size_str}")
        if is_folder:
            list_folder(f['id'], indent + 1)

list_folder('根文件夹ID')

# ========== 下载文件 ==========
file_id = '文件的Drive_ID'
file_name = '下载后保存的名字.png'
request = service.files().get_media(fileId=file_id)
fh = io.FileIO(f'/tmp/{file_name}', 'wb')
downloader = MediaIoBaseDownload(fh, request)
done = False
while not done:
    status, done = downloader.next_chunk()
print(f"下载完成: /tmp/{file_name}")
```

### Step 3：Drive API 踩坑记录

**坑1：Drive API 未开通 → 403 "accessNotConfigured"**
- 错误信息：`Google Drive API has not been used in project 77775222475`
- 解决：让用户去 console 启用 Drive API（同 Step 1）

**坑2：文件夹内容分层混淆**
- Drive API 用 `parents` 查询时，**直接放在根目录的文件**和**子文件夹内的文件**都可能被返回
- 正确做法：先确认目标文件在哪个文件夹 ID 下，逐层深入
- 子文件夹里实际有文件 ≠ 子文件夹 ID 就是查询入口

**坑3：urllib 直接下载 Drive 文件失败 → 改用 MediaIoBaseDownload**
- Google Drive 的下载 URL（`drive.google.com/uc?export=download&id=...`）会触发浏览器验证，无法在服务端直接下载
- 正确做法：用 Drive API 的 `files().get_media()`：
  ```python
  from googleapiclient.http import MediaIoBaseDownload
  import io
  request = service.files().get_media(fileId=file_id)
  fh = io.BytesIO()
  downloader = MediaIoBaseDownload(fh, request)
  done = False
  while not done:
      _, done = downloader.next_chunk()
  fh.seek(0)
  with open('/local/path.png', 'wb') as f:
      f.write(fh.read())
  ```

**坑4：MMX CLI 分析图片返回 "sensitive" 静默失败**
- `mmx vision describe "<图片路径>"` 返回 exit_code=1 但无错误信息（`input new_sensitive, input image sensitive`）
- 正确做法：改用 `vision_analyze` tool（走 MiniMax VLM 兜底），或用 `terminal()` 调用时捕获 stderr
- `mcp_minimax_plan_understand_image` MCP 端点平台级 404，一直不可用，勿试

### Step 5：宠物参考图片获取标准工作流

1. Drive API 列出目标文件夹内容（确认有子文件夹则逐层进入）
2. 用 `files().get_media()` + `MediaIoBaseDownload` 下载到 `/root/.hermes/image_cache/`
3. 用 `mmx vision describe` 分析（敏感图静默失败则降级到 `vision_analyze`）
4. 将描述结论写入 Sheets 动作/特效描述字段，并更新 G/I 列的 IMAGE 公式嵌入参考图

### Step 4：分享文件夹给 Service Account

在 Google Drive 网页上：
1. 找到目标文件夹 → 右键 → **分享**
2. 添加用户：`hermes-sheets-996@bold-circuit-495508-s6.iam.gserviceaccount.com`
3. 权限选 **查看者** 或 **编辑者**
4. 发消息通知 Hermes

---

## Google Drive 文件读取

Service Account 邮箱：`hermes-sheets-996@bold-circuit-495508-s6.iam.gserviceaccount.com`
给她分享文件夹（编辑者权限）即可通过 Drive API 读取：

```python
from googleapiclient.discovery import build
creds = service_account.Credentials.from_service_account_file(CREDS_FILE, scopes=['https://www.googleapis.com/auth/drive'])
drive = build('drive', 'v3', credentials=creds)
files = drive.files().list(
    q=f"'{folder_id}' in parents",
    fields="files(id, name, mimeType)"
).execute()
```

- 读取前需先在 GCP Console 启用 **Google Drive API**（项目 77775222475）
- Service Account 无法上传文件到 Drive（无存储配额），用 GitHub Contents API 代替

## pollinations.ai 图片生成

```python
import urllib.request, time
url = f"https://image.pollinations.ai/prompt/{urllib.parse.quote(prompt)}?width=768&height=768&nologo=true"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
resp = urllib.request.urlopen(req, timeout=90)
# 会触发 429，批量生成要加 sleep 间隔
```

**已知限制：** rate limit 频繁，批量生成每张间隔 15-30s；图片内容控制不稳定（动物角色可能变形，需重试）

## Google Sheets IMAGE() 公式写入

```python
service.spreadsheets().values().update(
    spreadsheetId=SPREADSHEET_ID,
    range=f"'{SHEET}'!G{row}",
    valueInputOption='USER_ENTERED',  # 必须是 USER_ENTERED 才能解析公式
    body={'values': [[f'=IMAGE("{url}",4,320,320)']]}
).execute()
```

- 链接必须是直链（raw.githubusercontent.com 可用，cdn.jsdelivr.net 也行）
- 上传后 repo 需设为 public，否则 IMAGE() 无法访问

Service Account 可读取/写入 Drive，但**无法上传文件**（无存储配额）。若需上传图片到 Drive：
- 方案A：用 Drive API 写文件 metadata + 内容，但文件不占 Storage
- 方案B（推荐）：上传到 GitHub Contents API，raw.githubusercontent.com 直链更稳定

**GitHub Contents API 上传图片流程（Python）：**
```python
import urllib.request, json, base64

with open('/root/.git-credentials', 'r') as f:
    token = f.read().strip().split('://')[1].split('@')[0]

with open(fpath, 'rb') as f:
    content = base64.b64encode(f.read()).decode()

body = json.dumps({'message': f'Upload {fname}', 'content': content}).encode()
req = urllib.request.Request(
    f'https://api.github.com/repos/{owner}/{repo}/contents/{path}/{fname}',
    data=body,
    headers={'Authorization': f'token {token}', 'Accept': 'application/vnd.github.v3+json',
             'User-Agent': 'Mozilla/5.0', 'Content-Type': 'application/json'},
    method='PUT'  # ⚠️ 必须用 PUT，POST 不支持
)
resp = urllib.request.urlopen(req, timeout=30)
result = json.loads(resp.read())
raw_url = result['content']['download_url']  # raw.githubusercontent.com 直链
```

**坑：**
- 更新已有文件必须传 `sha` 字段（从 GET 请求获取）
- repo 必须是 **public** 才能让 Sheets IMAGE() 公式访问 raw URL
- raw URL 格式：`https://raw.githubusercontent.com/{owner}/{repo}/main/{path}/{fname}`

## 当前已接入的表格

| 表格 | Spreadsheet ID | 状态 |
|------|--------------|-----|
| PG2宠物需求（宝可梦技能数据） | 159VrH0vBDT41xHGZnuzCoYxUE7i6u1xvEJvlFKYqUsw | ✅ 已验证读写，含 IMAGE 公式写入 |

## 当前可访问的 Drive 文件夹

| 文件夹 | Folder ID | 内容 |
|--------|-----------|------|
| 宠物图片 | 1pOtpgVsnMONss2GrsSUv0PUahSmnn5t2 | 📁 Mega甲贺忍蛙（子文件夹）+ 2个PNG参考图 |
