---
name: google-sheets-service-account
description: Google Sheets API 通过 Service Account 授权（Hermes 私有自动化专用）— 不走 OAuth 用户同意流程
version: 1.0.0
tags: [google, sheets, api, automation, service-account]
risk: write-safe
---

# Google Sheets API — Service Account 授权方式

## 背景

Hermes 是私有自动化系统，**不能用 OAuth 用户同意流程**（需要账号类型为 Google Workspace / 内部选项 / 测试用户 / 审核发布）。

正确路线：**Service Account + JSON 密钥**

## 完整配置步骤

### 第一步：启用 Google Sheets API

1. [console.cloud.google.com](https://console.cloud.google.com) → 选已有项目
2. 左侧菜单 → **"API 和服务"** → **"库"**
3. 搜索 `Google Sheets API` → **启用**

### 第二步：创建 Service Account

1. 左侧菜单 → **"API 和服务"** → **"凭据"**
2. 点 **"创建凭据"** → **"服务账号"**
3. 名称随意（如 `Hermes Sheets Access`）
4. 角色选 **"编辑者"（Editor）** 或留空
5. 创建完成

### 第三步：创建 JSON 密钥

1. 进入刚创建的服务账号详情页
2. 点 **"密钥"（Keys）** → **"添加密钥"** → **"创建新密钥"**
3. 选 **JSON** → 创建 → **自动下载 .json 文件**

### 第四步：获取 Service Account 邮箱

打开下载的 JSON 文件，字段 `client_email` 即为 Service Account 邮箱，格式如：
```
hermes-sheets@project-id.iam.gserviceaccount.com
```

### 第五步：分享 Google Sheet 给 Service Account

1. 打开目标 Google Sheet（[sheets.new](https://sheets.new) 创建）
2. 右上角 **"分享"（Share）**
3. 粘贴 Service Account 邮箱
4. 角色选 **"编辑者"**
5. 发送

### 第六步：把 JSON 文件发给 Hermes

将下载的 JSON 密钥文件内容（或文件路径）提供给 Hermes。

## 为什么不用 OAuth

| 对比项 | OAuth 用户授权 | Service Account |
|--------|-------------|----------------|
| 适用场景 | 公共应用/用户登录 | 私有自动化 ✅ |
| 配置步骤 | 5-6步 + 审核 | 3步 |
| 封号风险 | 有 | 极低 |
| 维护成本 | 需添加测试用户 | 零 |
| 内部选项 | 需要 Google Workspace | ✅ 个人账号即可 |

## Python 使用示例

```python
import google.auth
from googleapiclient.discovery import build
from google.oauth2 import service_account

SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
SERVICE_ACCOUNT_FILE = '/path/to/key.json'

creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES
)
service = build('sheets', 'v4', credentials=creds)

# 读取
SPREADSHEET_ID = 'your-sheet-id-from-url'
result = service.spreadsheets().values().get(
    spreadsheetId=SPREADSHEET_ID, range='Sheet1!A1'
).execute()
print(result.get('values', []))

# 写入
service.spreadsheets().values().update(
    spreadsheetId=SPREADSHEET_ID,
    range='A1',
    valueInputOption='USER_ENTERED',
    body={'values': [['New Value']]}
).execute()
```

## Sheet ID 获取方式

Google Sheet 链接格式：
```
https://docs.google.com/spreadsheets/d/[SHEET_ID]/edit
```
方框里那串字母数字就是 SHEET_ID。

## 常见错误

- **403 Insufficient Permission**：Service Account 未被分享该 Sheet
- **404 Not found**：SHEET_ID 错误或 Sheet 不存在
- **401 Invalid credential**：JSON 密钥文件损坏或已 revocation
