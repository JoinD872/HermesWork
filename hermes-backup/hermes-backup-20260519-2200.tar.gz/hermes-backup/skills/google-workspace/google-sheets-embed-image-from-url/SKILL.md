---
name: google-sheets-embed-image-from-url
description: 通过 IMAGE() 公式将公网图片嵌入 Google Sheets 单元格——找直链、判断可用性、写入公式、调尺寸的完整流程
version: 1.0.0
tags: [google-sheets, image, embed, vfx, game-design]
risk: write-safe
---

# Google Sheets 嵌入公网图片 — IMAGE() 公式法

## 核心限制（重要）

**Google Sheets REST API v4 不支持在单元格内直接插入图片**。只有两种方式：

| 方式 | API 支持 | 难度 |
|------|---------|------|
| `IMAGE()` 公式 | ✅ 完全支持 | ⭐ 简单 |
| Apps Script `insertImage()` | ✅ 有方法 | ⭐⭐ 需 OAuth |

本 skill 只涉及 `IMAGE()` 公式方案。

---

## IMAGE() 语法

```
=IMAGE(url, [mode], [height], [width])
```

| 参数 | 值 | 含义 |
|------|-----|------|
| url | 字符串 | 公网直链图片 URL |
| mode | 1~4 | 1=自动适应 / 2=拉伸填满 / 3=原尺寸 / **4=自定义尺寸（最常用）** |
| height | 像素 | 高（mode=4 时必需） |
| width | 像素 | 宽（mode=4 时必需） |

**最常用写法：**
```
=IMAGE("https://example.com/image.png", 4, 160, 240)
```

---

## 可用图片来源判断标准

必须是：**公网直链、可浏览器直接打开、不需要登录、不防盗链**

### ✅ 通常可用的来源
- 官方 CDN（如 pokemon.com 的 Next.js 图片服务）
- 部分 GitHub raw 链接
- 部分图床（ImgBB、Imgur 直接链接）
- 明确提供"复制图片链接"的网站

### ❌ 通常不可用的来源
- Pixiv（需要登录，防盗链）
- ArtStation（严格反爬，基本被墙）
- DeviantArt（需要登录才能看大图）
- Pinterest（不是直链，是网页）
- 百度图片（无直链）
- 需要 Referer 检查的 CDN
- Cloudflare 防护的站点

---

## 验证直链的方法

在浏览器新标签页粘贴 URL：
- 直接显示图片 → 可用
- 跳转到网页 / 需要登录 → 不可用

---

## 实战：找 Pokemon 官方图片直链

### 问题背景

找 Pokemon 角色的可直链图片，pokemon.com 官方站是最佳来源。

### 关键发现

Pokemon 官方站使用 Next.js `/_next/image` 服务。图片 URL 格式：

```
https://legends.pokemon.com/_next/image?url=%2Fstatic-assets%2Fcontent%2Fpokemon-images%2FMIGA_GRENINJA_SQUARE.png&w=1080&q=75
```

其中 `url=` 参数是 URL 编码后的图片路径，`w=` 是输出宽度，`q=` 是质量。

### Google Sheets 写入示例

```
=IMAGE("https://legends.pokemon.com/_next/image?url=%2Fstatic-assets%2Fcontent%2Fpokemon-images%2Fmega_greninja_square.png&w=1080&q=75", 4, 320, 320)
```

### 调尺寸配合

写入公式后需要手动调：
- **列宽** ≥ 图片宽度 + 10px
- **行高** ≥ 图片高度 + 10px

否则图片会被压缩显示不全。

---

## 通过 Service Account 写入 IMAGE 公式

用 google-sheets-service-account 的 Service Account 写公式：

```python
from google.oauth2 import service_account
from googleapiclient.discovery import build

creds = service_account.Credentials.from_service_account_file(
    '/root/.hermes/credentials/google-sheets-sa.json',
    scopes=['https://www.googleapis.com/auth/spreadsheets']
)
service = build('sheets', 'v4', credentials=creds)

# 写入 IMAGE 公式
service.spreadsheets().values().update(
    spreadsheetId='SPREADSHEET_ID',
    range="'Sheet1'!B2",
    valueInputOption='USER_ENTERED',  # 注意：用 USER_ENTERED 让公式生效
    body={'values': [['=IMAGE("https://example.com/img.png",4,160,240)']]}
).execute()
```

**关键**：`valueInputOption` 必须用 `USER_ENTERED`（不是 `RAW`），这样公式才会被解析执行。

---

## 踩坑记录

### 1. 公式不生效

**原因**：`valueInputOption` 用了 `RAW`，公式被当作字符串处理  
**解决**：改用 `USER_ENTERED`

### 2. 图片不显示

**原因**：URL 不是直链 / 防盗链 / 需要登录  
**解决**：换用官方 CDN 链接，或用 ImgBB 等可靠图床上传

### 3. 列宽行高没调，图片显示被截断

**解决**：公式写入后立即调尺寸：
```python
# 调列宽
service.spreadsheets().batchUpdate(
    spreadsheetId='SPREADSHEET_ID',
    body={
        'requests': [
            {
                'updateDimensionProperties': {
                    'range': {'sheetId': SHEET_ID, 'dimension': 'COLUMNS', 'startIndex': 1, 'endIndex': 2},
                    'properties': {'pixelSize': 340},
                    'fields': 'pixelSize'
                }
            },
            {
                'updateDimensionProperties': {
                    'range': {'sheetId': SHEET_ID, 'dimension': 'ROWS', 'startIndex': 1, 'endIndex': 2},
                    'properties': {'pixelSize': 340},
                    'fields': 'pixelSize'
                }
            }
        ]
    }
).execute()
```

### 4. Sheet name 有中文或特殊字符

**原因**：range 解析失败  
**解决**：先 GET spreadsheet metadata 确认真实 sheet title，再用单引号包裹：
```python
range="'Mega进化'!B2"
```

---

## 工作流总结

1. **找图** → 优先官方 CDN / 明确提供直链的站点
2. **验证** → 浏览器新标签页打开确认直链
3. **写入公式** → `valueInputOption='USER_ENTERED'`
4. **调尺寸** → 列宽 + 行高配合图片像素

---

## 相关 Skill

- `google-sheets-service-account` — Service Account 配置与基础读写
