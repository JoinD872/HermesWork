---
name: vps-ip-reputation-check
description: VPS 出口 IP 信誉检测工作流 —— 检测 IP 是否在黑名单/代理/VPN/数据中心，评估适合订阅 AI 服务（Gemini/ChatGPT等）的清洁度
tags: [vps, network, ai-service, ip-reputation]
version: 2026-05-16
risk: read-only
---

# VPS 出口 IP 信誉检测工作流

## 适用场景

当用户问以下问题时使用此工作流：
- "这个 VPS IP 干净吗？"
- "用这个 IP 订阅 Gemini/ChatGPT 会不会被降智？"
- "检测一下我的出口 IP 信誉"
- "这个 IP 适不适合用来注册 AI 服务？"

## 前置注意事项

**不要搞混用户需求场景。** 此工作流仅适用于：
- 用户想知道自己的 VPS IP 是否**干净**（无黑名单、非代理）
- 用户想了解这个 IP 是否适合**订阅 AI 服务**（Gemini/ChatGPT 等）

**不适用场景**（跳过此工作流）：
- 用户已经在实际使用 AI 服务、体验正常，只是随口问 IP 干不干净 → 告诉用户目前实测正常即可
- 用户问的是 VPS 是否可以解锁 Netflix/流媒体 → 用专门的流媒体检测工作流

## 完整检测流程

### 步骤 1：获取 IP 基础信息

```bash
curl -s ifconfig.me
curl -s ipinfo.io/json
```

关键字段：`ip`, `org`（ASN 信息）, `country`（国家）, `city`（城市）

### 步骤 2：核心检测 —— proxy + hosting 判定

```bash
# ip-api.com 返回 proxy/hosting 两个关键布尔字段
curl -s "http://ip-api.com/json/<IP>?fields=status,message,country,regionName,city,isp,org,as,proxy,hosting,query"
```

**判读标准：**
| proxy | hosting | 含义 | 对 AI 服务风险 |
|-------|---------|------|---------------|
| false | false | 住宅 IP / 原生 IP | 🟢 最佳，适合所有服务 |
| false | true | 数据中心 IP（VPS/云主机） | 🟡 中等，大部分 AI 服务可用，个别可能策略降级 |
| true | true | 公开 VPN/代理/机场 | 🔴 高风险，极易被降智 |

### 步骤 3：DNSBL 黑名单检查

**原理**：将 IP 反转后到各 DNSBL 服务商查 A 记录。返回 NXDOMAIN = 未列入，返回 127.x.x.x = 已列入。

```bash
# 反转 IP：192.3.241.244 → 244.241.3.192
# 添加到各个黑名单域名后查询
for bl in "zen.spamhaus.org" "b.barracudacentral.org" "bl.spamcop.net" "dnsbl.sorbs.net" "dnsbl.httpbl.org" "cbl.abuseat.org"; do
    result=$(host -t A "244.241.3.192.$bl" 2>&1)
    case "$result" in
        *NXDOMAIN*) echo "✅ $bl — 未列入" ;;
        *127.*)     echo "🔴 $bl — 已列入！" ;;
        *)          echo "⚠️  $bl — 查询失败" ;;
    esac
done
```

**注意**：始终使用反转后的 IP 格式 `LAST.3RD.2ND.1ST.blacklist.domain`。

### 步骤 4：Google / Gemini 直连测试

直接测试从该 IP 到 AI 服务的连通性和响应：

```bash
# 测试 Google 首页
curl -s -I "https://www.google.com/" 2>&1 | head -5

# 测试 Gemini
curl -s -o /dev/null -w "HTTP %{http_code} | %{remote_ip}\n" "https://gemini.google.com/"

# 测试 ChatGPT
curl -s -o /dev/null -w "HTTP %{http_code} | %{remote_ip}\n" "https://chat.openai.com/"
```

HTTP 200 ✅ 说明该 IP 未被 AI 服务主动封锁。

### 步骤 5：浏览器可视化验证（可选，实测推荐）

当脚本检测完成后，用浏览器登录目标 AI 服务的页面做可视化确认，这能发现 curl 不容易暴露的信息（如区域限制横幅、价格被隐藏、地理重定向等）。

**操作流程：**
1. 浏览器打开 `https://gemini.google.com/app` — 确认页面完整加载，无"not available in your country"横幅
2. 浏览器打开 `https://one.google.com/about/ai-premium` — 查看价格方案是否正常显示（如果被重定向或显示空白，说明 IP 被区域限制了）
3. 浏览器打开 `https://accounts.google.com/` — 观察登录页默认语言，如果显示 English (US) 说明 Google 识别为美国用户，显示中文说明识别为中国用户

**判断标准：**
| 现象 | 含义 |
|------|------|
| 英文页面 + 美国默认语言 | ✅ IP 被 Google 视为美国用户，最佳 |
| 中文页面 + 中国相关提示 | ⚠️ IP 被识别为中国用户，订阅可能被拦截 |
| 页面提示"not available" | ❌ IP 被 Google 屏蔽/区域限制 |

**在浏览器中确认的信息比 curl 更可靠**，因为某些反爬响应和用户实际看到的页面不同（例如有些网站对 bot 返回 200 但内容实际是占位符）。

### 步骤 6：Google 地域识别检测（新增）

从该 IP 访问 Google 时，Google 如何识别你的地理位置，这对 AI 服务订阅至关重要：

```bash
# 方式 1：看搜索结果是否包含本地化
curl -s -I "https://www.google.com" 2>&1 | grep -i "location\|country\|region"

# 方式 2：直接打开 Google One 订阅页
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://one.google.com/about/ai-premium"

# 方式 3：检查浏览器中登录页的默认语言（需要通过浏览器进行）
# 如果是 "English (United States)" → 被识别为美国用户，最佳状态
# 如果是 "简体中文" → 被识别为中国用户
```

**关键发现**：Google 默认语言和页面区域设置比 IP 地理位置 API 的结果对订阅成功率的预测更准确。ip-api.com 说 IP 在美国只是第一步，Google 自己认不认你是美国用户才是决定性的。

### 步骤 7：rDNS / ASN 检查

```bash
# rDNS 查看
host <IP>

# ASN 信息
whois -h whois.radb.net "AS<number>" 2>/dev/null | head -20
```

rDNS 命名格式能揭示 IP 的所有者类型：
- `*.colocrossing.com` → 低价 VPS 供应商
- `*.googleusercontent.com` → GCP 云
- `*.awscloud.com` → AWS
- `*.broadband.*` / `*.residential.*` → 住宅 IP（最好）

### 步骤 8：CDN 架构下的特殊分析（当用户说"我套了CDN"时）

当用户说"我有套 CDN"时，不要假设 CDN 改变了出口 IP。需要先搞清楚用户的网络架构。

**常见架构识别：**

```bash
# 1. 检查是否有 Tunnel/Agent 在运行
ps aux | grep -E "xray|v2ray|trojan|hysteria|cloudflared|tailscale" | grep -v grep

# 2. 查看 nginx 配置和监听端口
ss -tlnp | head -20
ls -la /etc/nginx/sites-enabled/
cat /etc/nginx/sites-enabled/*

# 3. 查看 Xray 配置
cat /usr/local/etc/xray/config.json
# 注意 outbounds 部分——如果只有 "freedom" 协议，说明是直连

# 4. 查看 Cloudflare Tunnel 配置
cat /root/.cloudflared/config.yml 2>/dev/null || cat /etc/cloudflared/config.yml
```

**三种典型架构及影响：**

| 架构 | 描述 | Google 看到的 IP | 需要加 WARP 吗？ |
|------|------|-----------------|----------------|
| **CLIENT → VPS(出口)** | VPS 是梯子服务端，客户端连过来，VPS 直连目标 | **VPS 的公网 IP** | 如果需要改善 IP 质量可以加 |
| **CLIENT → Cloudflare → VPS(出口)** | CDN 只用作入口反代，VPS 出站仍然是直连 | **VPS 的公网 IP** | 同上（这就是你的架构） |
| **CLIENT → VPS → WARP(出口)** | VPS 的 Xray outbound 走了 Cloudflare WARP | **Cloudflare IP 池** | 已经加了，不需要 |

**关键洞察**：用户说"我有套 CDN"时，**Cloudflare Tunnel 通常只是入站反代（隐藏 VPS IP + 抗封锁），不影响出站方向**。Google 看到的仍然是 VPS 的 IP，不是 Cloudflare 的 IP。

**如何向用户解释这个区别（口语化表达例子）：**
> "Cloudflare 在这里防的是墙，不是防 Gemini 降智。Google 看到的仍然是你 VPS 的 IP，因为 Cloudflare Tunnel 只是把你连到 VPS 的入口通道，VPS 出站到 Google 还是用自己的 IP。"

### 步骤 9：WARP 方案适用性判断（基于当前架构）

当用户问是否要加 WARP 时，基于检测结果给出决策树：

**决策树：**

```
实测 Gemini/Google 是否正常？
├── 🟢 正常（HTTP 200，无区域限制，英文页面）
│   ├── 轻度使用 → 没必要加 WARP，直接用
│   └── 重度/长期使用 → 加 WARP 做保险，但非必须
│
└── 🔴 异常（区域限制、重定向到中国区、价格不可见）
    ├── 如果你的架构是 VPS 直连出口
    │   └── ✅ 推荐加 WARP，可能解决
    ├── 如果已经是 WARP 出口
    │   └── ❌ WARP 也无法解决，需要换干净住宅 IP
    └── 如果只测了 curl 没测浏览器
        └── ⚠️ 先做浏览器可视化确认，curl 结果可能不准确

```

**向用户推销 WARP 时需要准备回答的三个问题：**

**① 免费吗？**
> 免费版完全够用，不需要花一分钱。WARP+（$4.99/月）是加速版，多了 Argo 智能路由，但对 Gemini 这种场景意义不大。

**② 会降速吗？**
> 几乎无感。VPS 到 Cloudflare 边缘节点只有 1-3ms，比你从上海到洛杉矶的 200ms 延迟小两个数量级。加 WARP 后人感知的总延迟约增加 1-5ms。

**③ 有必要吗？**
> 取决于你的现状。如果实测已经正常（HTTP 200，浏览器能看到完整 Gemini 页面和价格），加 WARP 是锦上添花。若实测被区域限制了，WARP 可能是解决方案。

### 步骤 10：综合报告输出

按以下结构输出报告：

```markdown
## VPS IP 信誉检测报告

**IP：** X.X.X.X | ASN | 地理位置 | 供应商

### ✅ 黑名单检测
| 黑名单 | 结果 |
|-------|------|
| Spamhaus | ✅ 未列入 |
| ... | ... |

### 🟢/🟡/🔴 综合评估

| 维度 | 评级 | 说明 |
|-----|------|------|
| 黑名单 | 🟢 | 所有列表清空 |
| 代理检测 | 🟢 | proxy=false，非代理 |
| 数据中心 | 🟡 | hosting=true，数据中心 IP |
| ASN 声誉 | 🟡/🔴 | 说明 |
| 目标服务直连 | 🟢 | HTTP 200 |

**结论：** [一句话总结 + 行动建议]
```

## 常见陷阱

1. **不要依赖第三方网站**：IPQS、AbuseIPDB、WhatIsMyIPAddress、Scamalytics 等站点都有 Cloudflare 保护，浏览器和 curl 都会被拦截。用 DNSBL 协议直接查询更可靠
2. **搜索引擎搜不到有用信息**：用 SearxNG 搜 `IP 192.3.x.x reputation` 基本只返回检测工具的首页（而不是针对该 IP 的结果页），不要在这个方向上浪费时间
3. **ip-api.com 用 `http://` 而非 `https://`**：免费版 API 只支持 HTTP。⚠️ HTTP 请求有中间人风险，但只用于非敏感 IP 查询是可接受的
4. **ipinfo.io 不返回 proxy/hosting 字段**：免费版信息有限，主要用于获取 ASN 和地理位置
5. **黑名单查询失败不要惊慌**：某些 DNSBL（如 httpbl）需要 API Key，NXDOMAIN 不代表"查询失败"，代表"未列入"
6. **`proxy=false, hosting=true` 是最常见的 VPS 场景**：这是中立结果，不是坏结果——比机场节点好得多，但不如原生住宅 IP
7. **浏览器测试优先于 curl 测试**：有些网站（如 Gemini、ChatGPT）对 curl 返回的内容和对真实浏览器返回的内容不同。能看到完整的 UI（价格卡片、语言设置、登录按钮）本身就是最好的验证
8. **用户说"我套了CDN"时，不要自动认为出口IP变了**：Cloudflare Tunnel 通常只影响入站。**出站方向（VPS → Google）默认仍然用 VPS 自己的 IP**。需要检查 Xray 的 outbounds 配置才知道出口路径
9. **不要忽略用户的已有网络架构**：在做 WARP 推荐之前，先搞清楚用户现在的网络架构。加 WARP 意味着在 Xray 的 outbounds 里增加一个 WireGuard 出口，然后配 routing 分流。这是对现有架构的增量修改，不需要重构
10. **Gemini 的"降智"问题核心归因是 IP 类型（hosting vs residential），不是家庭组共享**：虽然家庭组跨区可能导致订阅被拦截，但大部分国内用户说的"感觉变笨"主要源于 IP 被识别为数据中心/VPN，导致模型策略降级

## 测试过的查询工具对比

| 工具 | 可用性 | 提供的信息 | 推荐度 |
|------|--------|-----------|-------|
| `curl ip-api.com/json` | ✅ 免费无限制 | proxy/hosting/ASN/geo | ⭐ 首选 |
| `curl ipinfo.io/json` | ✅ 免费有限 | ASN/geo/hostname | ⭐ 辅助 |
| `host -t A ...dnsbl` | ✅ 离线协议 | 黑名单状态 | ⭐ 首选 |
| 浏览器打开 Gemini/Google | ✅ 无限制 | 区域识别、页面完整性、语言设置 | ⭐ 必备验证 |
| `whois -h whois.radb.net` | ✅ 免费 | ASN 详情 | 备用 |
| AbuseIPDB 网页 | ❌ Cloudflare 拦截 | — | 不要用 |
| IPQualityScore 网页 | ❌ Cloudflare 拦截 | — | 不要用 |
| WhatIsMyIPAddress | ❌ Cloudflare 拦截 | — | 不要用 |
| Scamalytics | ❌ Cloudflare 拦截 | — | 不要用 |
| 搜索引擎搜索 IP 信誉 | ❌ 无效 | 返回工具首页而非 IP 具体信息 | 不要用 |
