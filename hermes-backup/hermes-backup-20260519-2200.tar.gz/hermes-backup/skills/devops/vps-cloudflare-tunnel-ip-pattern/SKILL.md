---
name: vps-cloudflare-tunnel-ip-pattern
description: Cloudflare Tunnel (JoinD) 架构下优选 IP 的识别与手机端复用配置
risk: read-only
version: 1.1.0
created: 2026-04-28
---

# Cloudflare Tunnel 优选 IP：识别与手机端复用

## 核心发现

JoinD Cloudflare Tunnel 架构下，PC 通过 hosts 绑定的"优选 IP"不是 CDN IP（104.x.x.x / 172.67.x.x），而是 **Cloudflare 隧道直连节点 IP**，位于 `108.162.x.x` 网段。

```
查询结果：
proxy.cloudjoind.com DNS 解析 → 104.21.84.119（标准 CDN IP，不是优选）
PC hosts 绑定 → 108.162.198.81（隧道直连节点 IP，这才是优选）
```

**验证方法**：查 cloudflared 日志里的 `RegisterTunnelConnection` 记录，连接 IP 在 `198.41.x.x`（CF 边缘节点），但 hosts 里的 IP 通常是 `108.162.x.x`——两者不同，需要从 PC hosts 文件中提取真实优选 IP。

## 已知 JoinD 优选 IP

| IP | 域名 | 备注 |
|----|------|------|
| `108.162.198.81` | proxy.cloudjoind.com | LA 节点 |
| `108.162.198.81` | open.cloudjoind.com | 同节点 |

## 手机端配置（V2RayNG / 通用）

目标：复现 PC hosts 效果，让手机绕过 DNS 直接命中优选节点。

| 字段 | 值 |
|------|-----|
| 服务器地址 | `108.162.198.81`（从 PC hosts 提取）|
| 端口 | `443` |
| SNI / Host | `proxy.cloudjoind.com`（保持原域名）|
| TLS | ✅ 开启 |
| 传输协议 | 保持原配置（WebSocket / gRPC 等）|

**原理**：地址栏填 IP 绕过 DNS，sni/host 填原域名让 Cloudflare TLS 证书正确验证，Tunnel 继续正常工作。

## 如何找到自己环境里的优选 IP

### 方法 1：从 PC hosts 文件提取
```
在 PC 上找：
108.x.x.x proxy.cloudjoind.com
108.x.x.x open.cloudjoind.com
```
那个 `108.x.x.x` 就是优选 IP。

### 方法 2：从 cloudflared 日志推断
```bash
docker logs cloudflared-joined 2>&1 | grep -i "198.41\|108.162"
```
找 `RegisterTunnelConnection` 行，记录里的 IP 即为隧道连接目标。

### 方法 3：Cloudflare Speedtest
访问 `speed.cloudflare.com` 或 `cloudflare.com/cdn-cgi/trace`，查看返回的 IP 和延迟。

## 为什么 162.159.x.x 不是优选 IP

`162.159.39.141` 等 `162.158.0.0/15` 段的 IP 虽然属于 Cloudflare，但不是 Tunnel 入口节点。该段主要用途：
- WARP 端点
- Spectrum（TCP/UDP代理）
- 1.1.1.1 DNS 辅助节点
- 通用 CDN 边缘

Cloudflare Tunnel 入口节点固定在 `108.162.192.0/18` 和 `198.41.x.x` 段。用户曾用 `162.159.39.141` 正常工作过，但 Cloudflare 持续将 Tunnel 入口收窄到 `108.162.x.x`，Anycast 路由重平衡后该 IP 不再终止 Tunnel 连接。

**验证方法**：对疑似优选 IP 测试 HTTP 80 vs HTTPS 443：
- 80 通 + 443 TLS 握手失败 → 该 IP 不处理 Tunnel 连接（典型症状）
- 80 通 + 443 通 → 可能可作优选 IP

## 注意事项

- **不要把 VPS IP（192.3.241.244）当作优选 IP 填入手机**——VPS IP 已被墙/不稳定，Tunnel 正是用来隐藏源站的
- **保留原始域名配置作为 fallback**：如果优选 IP 失效，手机端切回 `proxy.cloudjoind.com` 即可
- **108.162.x.x 是 Anycast 入口 IP**，不是单一服务器 IP，Cloudflare 会自动路由到最近边缘节点
- **162.158.0.0/15 段已不可靠**：Cloudflare 正在把 Tunnel 入口从 `162.158.0.0/15` 段迁移到 `108.162.x.x` 段。验证结果：`162.159.39.141` 的端口 80 仍可路由 CDN 流量（200 OK），但端口 443 TLS 握手已失败（exit 35），说明该段不再终止 Tunnel 连接

## Tunnel 入口 IP 有效性验证

当怀疑一个优选 IP 是否还可用作 Tunnel 入口时：

```bash
# 快速验证：分别测 80 和 443
# 80 通 + 443 通 → 好 IP，继续用
# 80 通 + 443 TLS 失败 → CF 已收回该 IP 的 Tunnel 功能
# 80 不通 → IP 已死

# HTTP 80 测试（带正确 Host）
curl -s -o /dev/null -w "80: %{http_code} (%{time_total}s)\n" \
  -H "Host: proxy.cloudjoind.com" http://候选IP/

# HTTPS 443 测试（带正确 SNI）
curl -s -o /dev/null -w "443: %{http_code} (%{time_total}s)\n" \
  -H "Host: proxy.cloudjoind.com" https://候选IP/
```

### 测试结果解读

| 80 结果 | 443 结果 | 结论 |
|---------|---------|------|
| 200 | 200 | ✅ 可用作 Tunnel 优选 IP |
| 200 | 35 (TLS 失败) | ⚠️ 仅 CDN 存活，Tunnel 功能已收回 |
| 超时/拒绝 | 超时/拒绝 | ❌ 彻底失效 |

## CF Tunnel 入口 IP 段演变（经验总结）

| IP 段 | 当前状态 | 说明 |
|-------|---------|------|
| `108.162.192.0/18` | ✅ 主力 Tunnel 入口 | 当前最可靠的 Tunnel 节点段 |
| `198.41.x.x` | ✅ 隧道注册节点 | cloudflared 日志中的 `RegisterTunnelConnection` 目标 |
| `162.158.0.0/15` | ⚠️ 逐步淘汰中 | 80 端口仍通（CDN），但 443/Tunnel 功能已被移除 |
| `104.x.x.x` / `172.67.x.x` | ❌ CDN 代理 IP | 走的是 CF CDN 代理，不是隧道直连 |

## JoinD Tunnel 架构速查

```
设备(V2RayN)
→ proxy.cloudjoind.com:443
→ Cloudflare Tunnel (108.162.198.81 入口)
→ Cloudflare 全球 Anycast 网络
→ 198.41.x.x 边缘节点
→ Tunnel 回源
→ VPS (192.3.241.244)
```
