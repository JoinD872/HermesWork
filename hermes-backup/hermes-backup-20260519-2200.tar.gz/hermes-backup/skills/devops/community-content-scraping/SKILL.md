---
name: community-content-scraping
description: 多社区内容抓取 — X/Twitter、Discord、V2EX、B站、Reddit、GitHub、知乎的可用方案与凭据管理
tags: [scraping, twitter, discord, reddit, github, bilibili, v2ex, zhihu]
version: 1.0.0
risk: write-safe
---

# 多社区内容抓取

## 抓取策略（降级链）

```
VPS 直取 ──成功──→ ✅ 返回结果
  │ 失败
  ↓
SearXNG 间接搜索 ──成功──→ ✅ 
  │ 失败
  ↓
黑翼 SSH 桌面浏览器 ──成功──→ ✅ 
  │ 失败
  ↓
用户手动配合 ──→ 指导用户 F12 → Console 操作
```

## 社区可用性矩阵

| 社区 | 方式 | 状态 | 额外要求 |
|------|------|:----:|---------|
| **V2EX** | `curl` 直接提取 | ✅ | 无 |
| **B站** | 公开 API | ✅ | 无 |
| **Reddit** | JSON API | ✅ | 无 |
| **GitHub** | REST API | ✅ | 无，匿名也可搜 |
| **X/Twitter** | 内部 API | ✅ | 需 auth_token + ct0 cookie + Bearer Token |
| **Discord** | Bot API | ✅ | 需有效 Bot Token |
| **知乎** | SearXNG 间接 | ⚠️ | 仅搜索引擎已收录内容 |
| **小红书** | 无自动化方案 | ❌ | headless 全拦截（VPS + 桌面），仅用户手动浏览器可行 |
| **掘金** | 无有效方案 | ❌ | SPA 渲染 + 无 API |

## 凭据管理

所有社区凭据统一存于 `/root/.hermes/credentials/social_scraper.json`，格式：
```json
{
  "x": {
    "bearer_token": "...",
    "auth_token": "...",
    "ct0": "..."
  },
  "discord": {
    "bot_token": "...",
    "guild_id": "...",
    "channels": { "name": "channel_id" }
  }
}
```

### X/Twitter 凭据获取

用户需从 browser F12 → Application → Cookies → x.com 复制：
- `auth_token` — 会话认证
- `ct0` — CSRF 保护 Token
- Bearer Token 是公开的：`AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA`

### Discord Bot Token 获取

用户需在 Discord Developer Portal 创建/重置 Bot Token，Bot 需已加入目标服务器。

## X/Twitter 抓取

### 可用端点

| 端点 | 用途 | 说明 |
|------|------|------|
| `/i/api/2/timeline/home.json?count=N` | 首页 Timeline | ✅ 可用，返回 tweets + users |
| `/i/api/graphql/<QueryID>/QueryName` | GraphQL 操作 | ❌ Query ID 频繁变更，不可靠 |
| 其他 v1.1/v2 REST 端点 | 搜索等 | ❌ 返回 34/NotFound |

### 请求头要求

```bash
-H "Authorization: Bearer <公开 Bearer Token>"
-H "x-csrf-token: <ct0 cookie 值>"
-H "x-twitter-auth-type: OAuth2Session"
-H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
-H "Cookie: auth_token=<auth_token>; ct0=<ct0>"
-H "Origin: https://x.com"
-H "Referer: https://x.com/"
```

### 响应解析

响应体包含 `globalObjects.tweets`（推文字典）和 `globalObjects.users`（用户字典），以及 `timeline.instructions`（排序指令）。从 `timeline.instructions` 中提取推文 ID 列表，再到 `globalObjects.tweets` 中获取详情。

每个推文包含：`text`/`full_text`、`created_at`、`user_id_str`、`retweet_count`、`favorite_count`、`entities.urls` 等。

### 局限性

- timeline endpoint 能正常拉取首页推文（已验证）
- 搜索（搜索推文/用户）和 GraphQL 端点无法稳定使用
- `auth_token` 和 `ct0` 会过期，需要用户重新提供

## Discord 抓取

### 可用端点

```bash
# 获取 Bot 基本信息
curl -s "https://discord.com/api/v10/users/@me"
  -H "Authorization: Bot <token>"

# 获取 Bot 所在的服务器
curl -s "https://discord.com/api/v10/users/@me/guilds"

# 获取服务器频道列表
curl -s "https://discord.com/api/v10/guilds/<guild_id>/channels"

# 读取频道消息（最近 N 条）
curl -s "https://discord.com/api/v10/channels/<channel_id>/messages?limit=N"
```

### 消息解析

返回的消息数组按时间倒序（最新的在前），每条包含：`content`、`author.username`、`timestamp`、`mentions` 等。

### 局限性

- 只能读取 Bot 已加入的服务器和频道的消息
- Google 反查: Discord 内容不公开索引，无法用搜索引擎间接获取

## 爬取验证工具

### 国内站连通性快速测试

```bash
# 测一条看看
for site in "https://www.v2ex.com/" "https://www.bilibili.com/" "https://juejin.cn/"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 -A "Mozilla/5.0" -L "$site")
  echo "$site → $code"
done
```

### 国外站连通性

```bash
for site in "https://www.reddit.com/" "https://github.com/" "https://x.com/" "https://discord.com/"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 -A "Mozilla/5.0" -L "$site")
  echo "$site → $code"
done
```

## 用户配合模式（小红书/掘金等 blocking 站点）

当所有自动化方案都失败时，指导用户在浏览器（非 headless）中操作：

1. 打开目标页面
2. F12 → Console（控制台）
3. 输入 `allow pasting` 回车（安全提示确认）
4. 粘贴 `copy(document.body.innerText)` 回车
5. 将粘贴板内容发回
