---
---
name: hermes-github-backup
description: Hermes Agent 配置备份到 GitHub 私人仓库（PAT认证 + 每日Cron + 10个归档轮换）
risk: write-dangerous
---

# Hermes GitHub 备份机制

## 核心设计

**格式**：每次备份生成单个 tar.gz 文件，文件名含精确时间戳，永远不覆盖旧文件。
**轮换**：保留最近 10 个归档包，超出自动删除最早的。
**路径**：`hermes-backup/hermes-backup-YYYYMMDD-HHMM.tar.gz`

## 备份内容（P0+P1）

| 类别 | 内容 | 大小 |
|------|------|------|
| P0 核心 | SOUL.md, MEMORY.md, USER.md, global_knowledge.md, config.yaml, auth.json, channel_directory.json, cron/jobs.json | ~200KB |
| P0 profiles | 4个Agent的 SOUL.md + config.yaml | ~50KB |
| P1 skills | ~/.hermes/skills/ 整体（全部SKILL.md） | ~3.8MB |
| P1 research | ~/.hermes/research/ | ~40KB |
| P2 federation | callbacks 历史记录 | ~4KB |

**注意：不要备份 hermes-agent/ 源码（2GB），不要备份 profiles/*/skills/（是 ~/.hermes/skills/ 的副本）**

## GitHub 仓库最终结构

```
HermesWork/
└── hermes-backup/
    ├── hermes-backup-20260427-0732.tar.gz   ← 第一个归档
    ├── hermes-backup-20260427-0737.tar.gz
    └── ...最多10个，到第11个时自动删除最早的
```

## 备份脚本

`/root/.hermes/scripts/hermes-backup.sh`

核心逻辑：
1. Clone 或 pull 仓库
2. 临时目录打包所有备份内容为 tar.gz（含精确时间戳）
3. **先统计已有备份数，再删最旧的旧文件，最后才 add 新文件**
4. git commit + push

```bash
# 轮换逻辑（✅ 正确实现）
tar -czf "$REPO_DIR/hermes-backup/${ARCHIVE_NAME}" -C "$TEMP_DIR" hermes-backup

# 步骤3：先统计已有备份（git add 之前做，避免新文件干扰计数）
EXISTING_BACKUPS=$(git ls-files hermes-backup/hermes-backup-*.tar.gz 2>/dev/null | sort -t'-' -k2 -k3)
EXISTING_COUNT=$(echo "$EXISTING_BACKUPS" | wc -l)

if [ "$EXISTING_COUNT" -ge "$MAX_BACKUPS" ]; then
    # 已有 >= 10 个时，删除最旧的 N 个（留出位置给新备份）
    DELETE_COUNT=$((EXISTING_COUNT - MAX_BACKUPS + 1))
    TO_DELETE=$(echo "$EXISTING_BACKUPS" | head -n $DELETE_COUNT)
    echo "$TO_DELETE" | while read -r old_backup; do
        [ -n "$old_backup" ] && git rm -f "$old_backup" 2>/dev/null || true
    done
fi

# 步骤4：加入新文件
git add "hermes-backup/${ARCHIVE_NAME}"
git commit -m "📦 Backup ${BACKUP_DATE}"
git push origin main
```

> ⚠️ **关键陷阱**：`sort -t'-' -k2 -k3` 按日期升序排列（最旧的在前），`tail -n +11` 会取到**最新**的文件而非最旧的——必须用 `head -n $DELETE_COUNT` 取最旧的来删除。

## 旧版错误逻辑（❌ 勿用）

```bash
# ❌ 错误：先 add 再统计，导致新文件被计入 TOTAL，tail -n +11 会误取最新备份
git add "hermes-backup/${ARCHIVE_NAME}"
BACKUPS=$(git ls-files hermes-backup-*.tar.gz | sort)   # 含新文件，共11个
TOTAL=$(echo "$BACKUPS" | wc -l)                        # 11
TO_DELETE=$(echo "$BACKUPS" | tail -n +11)              # 误取 newest！
```

> ⚠️ **陷阱**：`ls` 列举本地文件系统，`git ls-files` 列举 git 追踪的文件。
> 新创建的 tar.gz 在 `git add` 之前对 git 不可见——若基于 `ls` 做保留判断，
> 刚创建的备份会被误判为第11个最旧备份而差点被删除。

## GitHub PAT 认证（坑点）

```bash
# ❌ 不生效：credential.helper store 方式
git config --global credential.helper "store --file ~/.git-credentials"
git ls-remote https://github.com/USER/REPO.git  # 失败：No such device

# ✅ 有效方式：clone/pull 时直接把 PAT 嵌在 URL 里
git clone "https://ghp_TOKEN@github.com/USER/REPO.git" /tmp/repo
```

## 恢复步骤（新机器）

```bash
# 1. 拉取仓库
git clone https://github.com/JoinD872/HermesWork.git /tmp/restore

# 2. 解压最新归档
LATEST=$(ls -1 /tmp/restore/hermes-backup/*.tar.gz | sort | tail -1)
tar -xzf "$LATEST" -C /tmp/restore

# 3. 恢复配置（覆盖）
cp -r /tmp/restore/hermes-backup/* ~/.hermes/
```

## 已知坑点

- `git ls-remote` 不读取 `~/.git-credentials`，认证失败 → 用 embedded token URL 解决
- skills 目录复制用 `cp -r ~/.hermes/skills/ skills/` 会嵌套成 `skills/skills/` → 先 mkdir -p 再复制
- **归档轮换用 `ls` 而非 `git ls-files`**：新创建的 tar.gz 在 git add 之前对 git 不可见，会被误判为第11个最旧归档而差点被删除 → 改用 `git add` 先加文件，再用 `git ls-files` 做判断
- **轮换逻辑顺序**：必须先统计旧备份并删除，再 add 新文件；若顺序反过来（先 add 再统计），`git ls-files` 会把新文件也算进去，导致 `tail -n +11` 误取**最新**的备份来删除
- **排序+tail 陷阱**：`sort -t'-' -k2 -k3` 对 `YYYYMMDD-HHMM` 格式按日期升序（最旧的在前），`tail -n +11` 取的是**最后一行 = 日期最晚的最新文件**，应该用 `head -n $DELETE_COUNT` 取最旧的文件来删除
- **du 命令失效**：`du -sh` 对已被 `git rm` 删除的文件返回错误，配合 `set -e` 会导致脚本提前退出 → 用 `du ... 2>/dev/null || echo "unknown"` 容错
- **git rm 返回非零**：`git rm` 对已删除但未提交的文件返回错误码 → 加 `|| true`
- PAT 写在脚本里，Security scan 会报警但用户自己批准，属于正常操作

## 关键信息

| 项目 | 值 |
|------|-----|
| 备份脚本 | `/root/.hermes/scripts/hermes-backup.sh` |
| Cron Job ID | `858137a1ff62` |
| Cron 表达式 | `0 22 * * *` = 每天 06:00 上海时间 |
| 目标仓库 | `github.com/JoinD872/HermesWork` |
| 归档路径 | `hermes-backup/hermes-backup-YYYYMMDD-HHMM.tar.gz` |
| 保留数量 | 永远 10 个（超出自动删除最早的） |
