---
name: community-intelligence-gathering
description: 多社区情报采集系统 — X/Twitter、Discord、V2EX、B站、Reddit、GitHub、知乎等社区的内容抓取、去重、异常通知和定时投递
risk: write-dangerous
version: 1.0
created: 2026-05-18
---

# 社区情报采集系统

## 适用场景
- 每日定时从多个社区抓取特定关键词相关的大模型/AI行业情报
- 用户临时要求爬取特定内容（此时禁用 X/Twitter）
- 情报汇总后自动投递到用户飞书 DM

## 可爬取性矩阵

| 社区 | 状态 | 方式 | 风险 |
|------|:----:|------|:----:|
| X/Twitter | ✅ | 内部API `/i/api/2/timeline/home.json` + auth_token + ct0 cookie + Bearer | 🔴 高（用用户账号，仅限定时任务） |
| Discord | ✅ | 官方API `channels/{id}/messages` + Bot Token | 🟢 低（Bot合规调用） |
| V2EX | ✅ | curl HTML首页，提取帖子标题 | 🟢 低（纯公开） |
| B站 | ✅ | 公开搜索API `/x/web-interface/search/all/v2` | 🟢 低（公开API） |
| Reddit | ✅ | JSON API `/r/{sub}/hot.json` | 🟢 低（公开API） |
| GitHub | ✅ | REST API `/search/repositories` | 🟢 低（公开API，5000次/h额度） |
| 知乎 | ⚠️ | 本地SearXNG间接搜索（不碰知乎服务器） | 🟢 低 |
| 小红书 | ❌ | headless全部被拦（错误码300012「IP存在风险」），无法SSH自动化 | - |
| 掘金 | ❌ | SPA渲染，无可用的公开API | - |

## 凭据管理

保存在 `/root/.hermes/credentials/social_scraper.json`，格式：
```json
{
  "x": {
    "bearer_token": "BEARER_TOKEN",
    "auth_token": "AUTH_TOKEN",
    "ct0": "CT0_VALUE"
  },
  "discord": {
    "bot_token": "BOT_TOKEN",
    "guild_id": "GUILD_ID",
    "channels": {
      "task_board": "CHANNEL_ID"
    }
  }
}
```

### X/Twitter 凭据获取
1. 用户在 x.com 登录后 F12 → Application → Cookies → x.com → 复制 `auth_token` 和 `ct0` 的 Value
2. Bearer Token 是公开的（X网页版硬编码），不需要用户提供

### Discord Bot Token 获取
1. 用户打开 https://discord.com/developers/applications
2. 找到 Bot 应用 → Bot → Reset Token

## X/Twitter 特殊限制（P0）

**永远遵守**：
- **X 只能在每日定时任务中使用**（cron job ID: 22c677b8acac）
- 用户要求**立即/临时爬取**内容时，禁用 X/Twitter
- 每次请求 count ≤ 20，每天最多触发 1 次
- 一旦用户反映 X 要求重新登录，立即停用 X 爬取

## 去重策略

### 相似度去重
标题精确匹配 / 子串包含 / 编辑距离 >70% → 合并为一条，标注多来源。

### 跨天去重
读取 `~/.hermes/cron/output/` 下最近 3 天的早报文件，跳过已出现的标题/URL。

### 排除内容过滤
预先定义的排除关键词（如 UE5、本地模型等）命中后直接丢弃。

## 异常通知协议

任何社区连续 3 次重试（间隔 5s）后仍失败，在报告顶部输出 🔴 告警：
```
🔴 [社区名称] 抓取失败
原因：[错误信息]
可能影响：[完整性评估]
建议：[是否需人工介入]
```

## 主要 API 端点参考

### X/Twitter
```
GET https://x.com/i/api/2/timeline/home.json?count=20
Headers: Authorization: Bearer <token>
         x-csrf-token: <ct0>
         x-twitter-auth-type: OAuth2Session
         Cookie: auth_token=<token>; ct0=<ct0>
         User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)
         Origin: https://x.com
         Referer: https://x.com/
```

### Discord
```
GET https://discord.com/api/v10/channels/{channel_id}/messages?limit=5
Headers: Authorization: Bot <token>
```

### B站搜索
```
GET https://api.bilibili.com/x/web-interface/search/all/v2?keyword={query}
```

### B站热门
```
GET https://api.bilibili.com/x/web-interface/popular?ps=10
```

### Reddit
```
GET https://www.reddit.com/r/{subreddit}/hot.json
```

### GitHub 搜索
```
GET https://api.github.com/search/repositories?q={query}&sort=stars&order=desc&per_page=5
```

### SearXNG（知乎间接搜索）
```
GET http://localhost:8888/search?q=site:zhihu.com+{keyword}&format=json&pageno=1
```

## V2EX HTML 提取
```bash
curl -s -A "Mozilla/5.0" -L "https://www.v2ex.com/"
```
提取 `<a href="/t/\d+">标题</a>` 或 `<span class="topic-link">标题</span>` 中的标题文本。

## 运维维护（季度检查）
每季度检查一次各社区 API 和解析规则的兼容性：
- V2EX 页面 HTML 结构
- B站 API 字段
- Reddit JSON 格式
- X/Twitter 内部 API 端点 ID

检查日期：2026-08-18
