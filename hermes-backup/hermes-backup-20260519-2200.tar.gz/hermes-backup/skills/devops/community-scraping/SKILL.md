---
name: community-scraping
description: 社区情报爬取完整指南 — 7个社区的爬取方式、凭据位置、去重规则、排除范围、异常处理。供小研使用。
risk: write-dangerous
version: 1.0.0
created: 2026-05-18
---

# 社区情报爬取指南（小研专用）

## 概述

每日北京时间 08:00 触发，从 7 个社区爬取 Hermes Agent / DeepSeek / MiniMax / Gemini / ChatGPT / 大模型技术优化相关情报，汇总成早报。

## 凭据位置

所有 Token/Cookie 存在：`/root/.hermes/credentials/social_scraper.json`

```json
{
  "x": {
    "bearer_token": "...",
    "auth_token": "...", 
    "ct0": "..."
  },
  "discord": {
    "bot_token": "...",
    "guild_id": "1492858402060107787",
    "channels": {
      "task_board": "1492919523698020442"
    }
  }
}
```

## ❌ 排除内容（看到直接丢弃）
- UE5 / 虚幻引擎5 相关
- 游戏开发相关（Unity、Godot、蓝图、C++游戏等）
- 本地模型（ollama、llama.cpp、text-generation-webui、本地部署等任何"本地运行"内容）

## 🔴 X/Twitter 红线规则
- **仅限每日早报定时任务中使用**
- **任何时候用户要求立即/按需爬取内容，禁止使用 X/Twitter**
- 这是为了降低账号被封的风险

## 7个社区爬取方式

### 1. X/Twitter
- 端点：`GET https://x.com/i/api/2/timeline/home.json?count=20`
- Headers：
  - `Authorization: Bearer {bearer_token}`
  - `x-csrf-token: {ct0}`
  - `x-twitter-auth-type: OAuth2Session`
  - `Cookie: auth_token={auth_token}; ct0={ct0}`
  - `User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36`
  - `Origin: https://x.com`
  - `Referer: https://x.com/`
- 返回 JSON，从 `globalObjects.tweets` 和 `globalObjects.users` 提取

### 2. Discord
- Bot Token 方式认证：`Authorization: Bot {bot_token}`
- 端点：`GET https://discord.com/api/v10/channels/1492919523698020442/messages?limit=5`
- 读取 #任务看板 频道的 Bot 状态信息

### 3. V2EX
```bash
curl -s -A "Mozilla/5.0" -L "https://www.v2ex.com/"
```
- 服务端渲染，直接提取帖子标题
- 用正则 `<a[^>]*href="/t/\d+[^>]*>([^<]+)</a>` 提取

### 4. B站
```bash
curl -s -A "Mozilla/5.0" "https://api.bilibili.com/x/web-interface/popular?ps=10"
curl -s -A "Mozilla/5.0" "https://api.bilibili.com/x/web-interface/search/all/v2?keyword=DeepSeek"
```
- 公开 API，无需认证
- 结果在 `data.list[]` 中

### 5. Reddit
```bash
curl -s -A "Mozilla/5.0" "https://www.reddit.com/r/LocalLLaMA/hot.json"
curl -s -A "Mozilla/5.0" "https://www.reddit.com/r/MachineLearning/hot.json"
curl -s -A "Mozilla/5.0" "https://www.reddit.com/r/artificial/hot.json"
```
- 结果在 `data.children[].data`

### 6. GitHub
```bash
curl -s -H "Accept: application/vnd.github+json" "https://api.github.com/search/repositories?q=deepseek&sort=stars&order=desc&per_page=5"
```
- 搜索关键词：deepseek, Hermes+Agent, LLM+optimization, MiniMax

### 7. 知乎（SearXNG 间接）
```bash
curl -s "http://localhost:8888/search?q=site:zhihu.com+DeepSeek&format=json&pageno=1"
```
- 关键词：DeepSeek / MiniMax / Gemini / Hermes Agent / ChatGPT

## 去重规则

### 跨源去重
- 标题完全一致 → 合并
- 标题包含关系（A是B的子串或反之）→ 合并
- 相似度 > 70%（编辑距离/公共子串比例）→ 合并
- 合并后注明「同时出现在 [来源A]、[来源B]」

### 跨天去重
- 读取 `/root/.hermes/cron/output/` 最近3天的早报文件
- 已出现过的标题/URL 跳过

### 源内去重
- 相同 URL/ID 只保留一条

## 异常处理
- 每个社区最多重试3次，间隔5秒
- 3次全失败 → 在报告顶部标注 🔴 告警

## 季度维护
- 每 3 个月检查一次各社区的接口是否变化
- 上次检查：2026-05-18
- 下次检查：2026-08-18
