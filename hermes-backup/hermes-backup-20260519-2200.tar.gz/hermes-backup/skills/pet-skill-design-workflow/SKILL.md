---
name: pet-skill-design-workflow
description: 宠物技能需求设计工作流 — 从 Google Drive 读取素材、编写动作/特效描述、生成参考图（技能概念设计稿格式）、嵌入 Google Sheets
version: 2.0.0
tags: [workflow, game-design, google-sheets, image-gen, skill-design-sheet]
risk: read-only
---

# 宠物技能需求设计工作流

**用途**：设计宠物技能的动作描述 + 特效描述，并配套生成参考图嵌入 Google Sheets
**触发条件**：大佬要求设计某个宠物的技能需求时
**核心工具**：Google Sheets API、GitHub Contents API、pollinations.ai、mmx vision

---

## 一、Google Drive 素材准备

### 1.1 文件夹结构

```
大佬的 Google Drive（共享给 Service Account）
├── 宠物图片/              # ⭐ 正确参考图所在！技能设计参考1~6 在这里
│   ├── 技能设计参考1.png   # 【关键！】VFX概念艺术分格参考
│   ├── 技能设计参考2.png
│   ├── 技能设计参考3.png
│   ├── 技能设计参考4.png
│   ├── 技能设计参考5.png
│   ├── 技能设计参考6.png
│   └── {宠物英文名}/       # 宠物专属文件夹（含角色形象+动作参考）
│       ├── 宠物形象.png    # 定妆照 / Idle 姿势（不用作参考图生成依据）
│       └── 参考Idle姿势1.png  # 角色姿态参考（不直接用于技能图生成）
└── PG2宠物需求（表格）
```

### 1.2 技能设计参考1~6 的真实含义

这6张图是**VFX概念艺术分格图**，不是角色定妆照！核心特征：

| 特征 | 说明 |
|------|------|
| 多阶段分格 | 每个技能分4-6个帧（蓄力→释放→命中→效果） |
| 深色背景 | 黑色/暗灰背景突出能量特效 |
| 角色剪影或简洁轮廓 | 重点在技能表现而非角色细节 |
| 彩色能量标注 | 青色/红色/白色/蓝色光效高对比 |
| Motion lines / 动作箭头 | 展示运动方向和轨迹 |
| 节奏感 | 帧序列概念，连贯 action flow |

**生成参考图时必须参照这个风格**，而不是单一高光时刻图。

**Service Account 邮箱**（用于访问 Drive）：
```
hermes-sheets-996@bold-circuit-495508-s6.iam.gserviceaccount.com
```

### 1.2 Drive API 启用

如果报 `403 accessNotConfigured`，需要手动启用：
> https://console.cloud.google.com/apis/api/drive.googleapis.com/overview?project=77775222475

---

## 二、Google Sheets 格式规范

### 2.1 标准列结构

| 列 | 内容 | 示例 |
|----|------|------|
| A | 宠物名称 | Mega甲贺忍蛙 |
| B | 技能名称 | Skill_A / 大招 |
| C | 技能属性 | 水 / 钢 |
| D | 攻击数量 | 单体 |
| E | 技能描述 | 含威力和范围 |
| F | **动作描述** | 核心产出 |
| G | **动作参考图**（=IMAGE 公式） | 核心产出 |
| H | **特效描述** | 核心产出 |
| I | **特效参考图**（=IMAGE 公式） | 核心产出 |
| J | 备注 | 参考链接等 |

### 2.2 IMAGE 公式嵌入方式

```excel
=IMAGE("直链", 4, 320, 320)
```

**列宽行高调整**（batchUpdate）：
- G/I 列宽：340px
- 行高：300px

---

## 三、动作/特效描述写作规范

### 3.1 时长标准（回合制）

| 类型 | 时长 |
|------|------|
| 小技能 | 1.5-3s |
| 大招 / 乱舞 | 2.5-4s（含前后摇总长） |

### 3.2 动作描述规范

- 写**关键姿态节点** + 阶段时长，不写逐帧
- 参考宠物形象图片和参考姿势（如隼龙低桩横刀）确定角色姿态基线
- 收势/待机统一为「低桩横刀护体」——屈膝下沉，刀横胸前
- 每段攻击注明时长，用「约X.Xs」格式

**模板**：
```
【起手】姿态描述。时长约0.Xs。
【第一击】动作描述。时长约0.Xs。
【第二击】...
【收刀/收势】...
【总时长】约X.Xs@60fps。
```

### 3.3 特效描述规范

- 写**视觉形态** + **色调**，不写引擎实现细节
- 色调用 #HEX 标注主色/辅色/高光
- 音效关键词用「→」连接各阶段

**模板**：
```
【特效层名】视觉描述。
【色调】主色#XXXX，辅色#XXXX，高光#XXXX。
【音效关键词】阶段1 → 阶段2 → 阶段3。
```

### 3.4 避免写太细的原因

- 动画师需要发挥空间
- 逐帧标注会限制创意
- 回合制节奏由时长控制，不靠动作细节规定

---

## 四、图片素材链路

### 4.0 生成策略选择决策树

**⚠️ 重要前提（血的教训）**：参考图（GPT 生成的）不是「单张帅图」，也不是「横向动作条带」，而是**完整的技能概念设计稿（Skill Design Sheet）**——多分区面板，包含角色主图 + Idle参考 + 5步动作流程 + VFX特效拆解 + 信息标注区。

**生成工具优先级（2026-05-08 更新）**：

| 优先级 | 工具 | 适用场景 | 质量 |
|--------|------|---------|------|
| **P0** | MiniMax API + `response_format: base64` | 任何需要 AI 生成图片的场景 | ⭐⭐⭐⭐⭐（质量最高，风格控制最强，绕过 URL 不可访问问题） |
| **P1** | 让用户在 ChatGPT 生成 | 用户已有验证成功的 prompt，且 MiniMax 效果不够好 | ⭐⭐⭐⭐ |
| **P2** | pollinations.ai | 作为备选，但风格控制能力有限 | ⭐⭐⭐ |
| **P3** | PIL 手工绘制 | 仅限「纯黑背景 + 暗色剪影 + 亮能量轮廓线」的极简扁平风格（任何 AI 都无法精准复现此风格时） | ⭐⭐ |

**判断流程**：
1. 首选 MiniMax base64 方案（质量最好，风格控制最强，可直接复现 GPT prompt 效果）
2. MiniMax 效果不够好 → 让用户提供 GPT 生成的图，Hermes 负责上传 + 嵌 Sheets
3. 参考图风格是「极简剪影」且 AI 生成全部跑偏 → PIL 手工绘制（唯一能做到 100% 风格控制的方案）

**MiniMax base64 方案（首选）+ 参考图 URL 嵌入 prompt（关键技巧）**：

> ⚠️ 2026-05-08 新发现：把参考图的 GitHub 公开 raw URL 直接嵌入 prompt，MiniMax 模型能"看到"并参考这两张图——角色形象（URL A）和姿势参考（URL B），效果远优于纯文字描述。

```python
import requests, json, base64, time

KEY = json.load(open('/root/.mmx/config.json')).get('api_key','')

# 两张参考图已上传 GitHub，拿到 raw 公开链接
REF_CHARACTER = 'https://raw.githubusercontent.com/JoinD872/HermesWork/main/sucai/ref_original_character.png'
REF_POSE = 'https://raw.githubusercontent.com/JoinD872/HermesWork/main/sucai/ref_idle_pose.png'

def gen_image(prompt, filename, aspect_ratio='3:4'):
    url = 'https://api.minimaxi.com/v1/image_generation'
    headers = {'Content-Type': 'application/json', 'Authorization': f'Bearer {KEY}'}
    # prompt 里嵌入参考图 URL，模型可参考图 A（角色形象）+ 图 B（姿势）
    data = {
        'model': 'image-01',      # 注意：image-01-live 不支持 base64
        'prompt': f'{prompt}\n\nReference character image: {REF_CHARACTER}\nReference pose image: {REF_POSE}',
        'aspect_ratio': aspect_ratio,
        'response_format': 'base64'   # 关键！绕过 OSS URL 不可访问问题
    }
    r = requests.post(url, headers=headers, json=data, timeout=120)
    d = r.json()
    b64 = d.get('data', {}).get('image_base64', [])
    if not b64:
        print(f'Error: {d}')
        return False
    img_data = base64.b64decode(b64[0])
    path = f'/root/.hermes/image_cache/{filename}'
    with open(path, 'wb') as f:
        f.write(img_data)
    print(f'Saved {len(img_data)} bytes to {path}')
    return True
```

**为什么 MiniMax base64 是首选**：
- `response_format: base64` 让 API 直接返回图片二进制数据，完全绕过阿里云 OSS URL 不可访问的问题
- 生成质量显著优于 pollinations.ai，风格控制更精准
- `aspect_ratio` 支持 1:1、16:9、3:2（推荐 16:9 用于横版概念稿）
- 单次请求间隔 5 秒，连续请求建议 30 秒间隔

**生成的正确目标格式**：
```
┌─────────────────────────────────────────────────────────┐
│ 左：角色主图（单手剑，低桩戒备，蓝色水流特效）           │
├──────────────────┬────────────────────────────────────┤
│ Idle参考区        │ 技能流程区（横向5步）               │
│ 低重心单手剑警戒   │ 起手→蓄力→突进→命中→收招          │
├──────────────────┴────────────────────────────────────┤
│ 特效结构区：水刃轨迹 / 水爆 / 水雾残留 / 地面水纹       │
├─────────────────────────────────────────────────────────┤
│ 信息区（中文）：动作流程 / 设计重点 / 节奏说明 / 禁止项 │
└─────────────────────────────────────────────────────────┘
```

**角色关键特征**（必须严格遵守）：
- 黑色身体 + 红色围巾/面部遮挡 + 金色头部角状结构 + 青蛙型四肢
- **单手剑武器**（不是双刀！）
- Idle：低重心单手剑警戒姿态，剑横向护在身体前方

**判断标准**：
- 参考图是「专业 concept art sheet 格式」→ **让用户在 ChatGPT/原生 AI 生成，Hermes 负责上传 + 嵌 Sheets**
- 参考图是「扁平纯色剪影 + 极简风格」→ 用 PIL 绘制
- 参考图是「写实/半写实角色 + 丰富细节」→ 用 pollinations.ai 一次生成整张

### 4.0A 技能概念设计稿的正确 prompt 结构（来自用户提供的 GPT 原版）

当需要生成「技能概念设计稿」时，必须使用以下 prompt 结构（用户已在 ChatGPT 中验证成功）：

**核心结构要素**：
1. 整体定位：「为游戏项目《PG2》生成一张技能概念设计稿 / Skill Design Sheet」
2. 角色描述：原创宠物形象特征（黑灰身体/红色围巾/金色角状结构/青蛙四肢）+ **单手剑** + Idle姿势逻辑说明
3. Idle 姿势要求：低重心 + 单手剑警戒 + 剑横向或斜向护在身体前方 + 随时可爆发突进
4. 整体风格：不是海报/Tpose/普通插画，是动作/VFX/外包可参考的制作说明图
5. 画面内容分5区：左侧角色主图 / Idle参考区 / 技能流程区（5步横向）/ 特效结构区 / 技能信息区
6. 技能方向 + 动作逻辑 + 特效逻辑（具体描述）
7. 禁止项：不要双刀/Tpose/原版宝可梦/隼龙等

**有效 prompt 示例（简化版，供 pollinations 参考）**：
```
dark tech game concept art sheet, single sword ninja warrior frog character,
low stance ready pose, blue water blade effect,
horizontal 5 action frames: idle crouch, wind-up, dash slash, impact splash, recovery,
Chinese labels, VFX water trail breakdown,
dark background, cyan energy, game design document style
```

**pollinations.ai 的风格控制边界（经验总结）**：
- ✅ 能做到：通用角色图、场景图、概念艺术板（mood board style）、多分区面板概念稿
- ❌ 不能做到：精确指定「扁平纯色剪影 + 暗色角色 + 亮色能量轮廓线」的极简风格——AI 总是往 painterly/beautiful 方向自由发挥
- ⚠️ 表现：即使给详细 prompt，输出经常跑偏为「4视图角色展示」或「单张插画」而非「设计说明面板」
- ⚠️ pollinations.ai 无法复现「PIL几何剪影」那种极致扁平的风格

**何时让用户在 ChatGPT 生成**：
当参考图是「专业技能概念设计稿格式」（多分区、角色主图+流程+VFX+信息区）时，pollinations.ai 复现率低且用户已有验证成功的 GPT prompt，应直接让用户在 ChatGPT 生成。Hermes 的角色是：上传 + 嵌 Sheets。

**何时必须用 PIL**：当参考图是「纯黑背景 + 暗色剪影 + 能量轮廓线」这种高度风格化形式时，AI 生成无法复现，此时必须用 PIL 手工绘制。

### 4.1 当用户在 ChatGPT/原生 AI 生成时

**Hermes 的角色**：用户在自己设备上用 ChatGPT 生成，生成后把图片文件或链接给 Hermes，Hermes 负责：
1. 下载图片（如是链接则 curl 下载）
2. 上传到 GitHub sucai/ 目录
3. 更新 Google Sheet 对应单元格的 IMAGE 公式

**GitHub 文件名规范**：`sheet_Skill_A.png`（风格）/ `5f_Skill_A.png`（动作条带）/ `v4_final_Skill_A.png`（PIL 剪影）

**GitHub token 读取 + 上传（terminal 子进程）**：
execute_code sandbox 里 token 被截断掩码，execute_code 里也无法 git push（credential fill 不工作）。正确方法：**用 terminal 子进程**：
```bash
cd /tmp && python3 -c "
import requests, base64
with open('/root/.git-credentials', 'r') as f:
    token = f.read().strip().split('://')[1].split('@')[0]
headers = {'Authorization': f'token {token}', 'Accept': 'application/vnd.github.v3+json'}
with open('/root/.hermes/image_cache/sheet_Skill_A.png', 'rb') as f:
    content = base64.b64encode(f.read()).decode()
data = {'message': 'Add skill sheet', 'content': content}
r = requests.put('https://api.github.com/repos/JoinD872/HermesWork/contents/sucai/sheet_Skill_A.png',
    headers=headers, json=data, timeout=30)
print(r.status_code)
"
```

**用户给图片后的处理流程**：
```python
# 如果用户给的是 GitHub 直链（如 https://github.com/JoinD872/HermesWork/blob/main/sucai/sheet_Skill_A.png）
# 需要改成 raw 链接：https://raw.githubusercontent.com/JoinD872/HermesWork/main/sucai/sheet_Skill_A.png

# 如果用户给的是本地文件，上传到 GitHub 再嵌 Sheets
# 如果用户直接给了 raw 链接，直接嵌 Sheets，跳过上传步骤
```

### 4.2 pollinations.ai 生成（AI 可控风格时）

**用户期望**：每个技能一张横向条带，5 个关键帧从左到右排列，类似参考图5/6的分格风格，背景连贯、动作流畅。

### 4.1A PIL 绘制几何剪影参考图（pollinations.ai 无法精准控风格时）

**适用场景**：参考图风格为「纯黑背景 + 暗色剪影 + 亮色能量线」的扁平化 VFX 概念图

**PIL 绘制参数规范**：
```
背景色 BG = (10, 10, 14)       # 极深灰近乎黑
角色色 BODY = (20, 22, 30)     # 忍蛙深色剪影
能量色 ENERGY = (0, 180, 255)  # 亮蓝能量线
能量亮色 ENERGY_BRIGHT = (100, 220, 255)
能量暗色 ENERGY_GLOW = (0, 100, 200)
帧尺寸 W, H = 600, 600
```

**绘制函数模板**：
```python
from PIL import Image, ImageDraw
import math

BG = (10, 10, 14)
BODY = (20, 22, 30)
ENERGY = (0, 180, 255)
ENERGY_BRIGHT = (100, 220, 255)

def new_frame():
    img = Image.new('RGB', (600, 600), BG)
    return img, ImageDraw.Draw(img)

def ninja(draw, cx, cy, pose):
    """几何剪影忍者，cx/cy 为角色中心点"""
    def body(pts, fill=BODY):
        draw.polygon([(cx+pt[0], cy+pt[1]) for pt in pts], fill=fill)
    def line(pts, fill=BODY, width=12):
        draw.line([(cx+pt[0], cy+pt[1]) for pt in pts], fill=fill, width=width)
    def ring(cx2, cy2, rx, ry, outline=ENERGY, width=2):
        draw.ellipse([cx2-rx, cy2-ry, cx2+rx, cy2+ry], outline=outline, width=width)

    if pose == 'ready':
        # 低桩戒备：双刀下垂
        body([(-40,-80),(40,-80),(50,50),(-50,50)])
        body([(-28,-110),(28,-110),(30,-82),(-30,-82)])
        body([(-35,40),(-50,130),(-15,130),(-5,60)])
        body([(35,40),(50,130),(15,130),(5,60)])
        line([(-40,-45),(-80,5)], width=13)
        line([(-80,5),(-90,85)], fill=ENERGY, width=3)
        line([(40,-45),(80,5)], width=13)
        line([(80,5),(90,85)], fill=ENERGY, width=3)
        ring(cx, cy-96, 30, 10)
        ring(cx, cy-18, 42, 65)
    elif pose == 'slash':
        # 拔刀横斩：弓步前冲，刀水平
        ...
    # 继续其他 pose...
```

**常见 pose 命名**：
- `ready`：戒备姿态
- `slash` / `slash2`：横斩（不同角度）
- `guard`：防御交叉刀
- `shield_expand`：护盾展开
- `shield_break`：护盾破碎
- `beam`：光束射击
- `charge`：蓄力
- `impact`：命中爆发
- `jump`：跳跃起手
- `upthrust`：上挑
- `sheathe`：收刀
- `land`：落地

**拼合横向条带**：
```python
from PIL import Image

FRAME_W, FRAME_H, GAP = 380, 500, 8
BG_COLOR = (10, 10, 14)

for skill_id in ['A', 'B', 'C', 'D']:
    total_w = FRAME_W * 5 + GAP * 4
    strip = Image.new('RGB', (total_w, FRAME_H), BG_COLOR)
    for fi in range(5):
        frame = Image.open(f'/root/.hermes/image_cache/v4_frames/v4_{skill_id}_f{fi+1}.png')
        frame = frame.resize((FRAME_W, FRAME_H), Image.LANCZOS)
        strip.paste(frame, (fi * (FRAME_W + GAP), 0))
    strip.save(f'/root/.hermes/image_cache/v4_final_{skill_id}.png')
```

**验证**：用 `mmx vision describe` 确认是「纯黑背景 + 深灰剪影 + 蓝色能量线」风格

### 4.1B 生成策略：单次 prompt 生成横向条带（pollinations.ai 可控风格时）
### 4.1 pollinations.ai 生成「技能概念设计稿」格式

**适用场景**：参考图风格为多分区面板概念稿，角色为写实/半写实，不是极简剪影。

**生成参数**：
- 尺寸：`width=1280&height=768`（3:2，横版概念稿比例）
- 每个请求间隔 65s 以上（否则 429 限流：`Queue full for IP`）
- 每个请求独立，超时立即处理已生成的文件（不要等所有图都成功再处理）

**生成 + 上传模板**（terminal 子进程）：
```bash
cd /tmp && python3 -c "
import requests, base64, time

with open('/root/.git-credentials', 'r') as f:
    token = f.read().strip().split('://')[1].split('@')[0]
headers = {'Authorization': f'token {token}', 'Accept': 'application/vnd.github.v3+json'}
api_base = 'https://api.github.com/repos/JoinD872/HermesWork/contents/sucai/'
ua = {'User-Agent': 'Mozilla/5.0'}

skills = [
    ('A', 'blood moon slash...', 100),
    ('B', 'water shield...', 200),
    ('C', 'steel beam...', 300),
    ('D', 'combo rush...', 400),
]

for skill_id, desc, seed in skills:
    prompt = f'dark tech game concept art sheet, single sword ninja warrior frog character, {desc}, dark background cyan energy, game design document style'
    encoded = requests.utils.quote(prompt)
    url = f'https://image.pollinations.ai/prompt/{encoded}?width=1280&height=768&seed={seed}&nologo=true'
    r = requests.get(url, timeout=120, headers=ua)
    if not r.headers.get('Content-Type','').startswith('image/'):
        print(f'Skill {skill_id} failed: {r.text[:100]}')
        continue
    local = f'/root/.hermes/image_cache/sheet_Skill_{skill_id}.png'
    with open(local, 'wb') as f:
        f.write(r.content)
    api_url = api_base + f'sheet_Skill_{skill_id}.png'
    data = {'message': f'Add skill design sheet {skill_id}', 'content': base64.b64encode(r.content).decode()}
    r2 = requests.put(api_url, headers=headers, json=data, timeout=30)
    print(f'Skill {skill_id}: gen={len(r.content)} upload={r2.status_code}')
    if skill_id != 'D':
        time.sleep(65)
"
```

**生成后验证**（mmx vision）：
```bash
mmx vision describe /root/.hermes/image_cache/sheet_Skill_A.png
```
描述应包含：dark background、multi-panel/concept art sheet、ninja warrior、blue/cyan energy、action frames。

### 4.1A PIL 绘制几何剪影参考图（极简扁平风格）

**适用场景**：参考图风格为「纯黑背景 + 暗色剪影 + 亮色能量线」的扁平 VFX 概念图。pollinations.ai 无法精准复现此风格时使用。

**PIL 绘制参数规范**：

### 5.1 读取 Google Sheet

```python
from google.oauth2 import service_account
from googleapiclient.discovery import build

CREDS_FILE = '/root/.hermes/credentials/google-sheets-sa.json'
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
creds = service_account.Credentials.from_service_account_file(CREDS_FILE, scopes=SCOPES)
service = build('sheets', 'v4', credentials=creds)

SPREADSHEET_ID = '159VrH0vBDT41xHGZnuzCoYxUE7i6u1xvEJvlFKYqUsw'
result = service.spreadsheets().values().get(
    spreadsheetId=SPREADSHEET_ID,
    range="'Sheet名'!A1:Z100"
).execute()
values = result.get('values', [])
```

### 5.2 写入单元格

```python
service.spreadsheets().values().update(
    spreadsheetId=SPREADSHEET_ID,
    range=f"'Sheet名'!F2",
    valueInputOption='RAW',
    body={'values': [['内容']]}
).execute()
```

### 5.3 下载 Drive 文件

```python
from googleapiclient.http import MediaIoBaseDownload
import io
request = drive.files().get_media(fileId=file_id)
fh = io.BytesIO()
downloader = MediaIoBaseDownload(fh, request)
done = False
while not done:
    _, done = downloader.next_chunk()
```

### 5.4 GitHub 上传图片（terminal 子进程）

**⚠️ 必须在 terminal 执行，execute_code sandbox 读不到真实 token。**

```python
# 在 terminal 里执行（不是 execute_code）：
cd /tmp && python3 -c "
import requests, base64, json

with open('/root/.git-credentials', 'r') as f:
    token = f.read().strip().split('://')[1].split('@')[0]

headers = {'Authorization': f'token {token}', 'Accept': 'application/vnd.github.v3+json'}

with open('/root/.hermes/image_cache/v4_final_A.png', 'rb') as f:
    content = base64.b64encode(f.read()).decode()

body = json.dumps({'message': 'Upload skill image', 'content': content}).encode()
req = urllib.request.Request(
    f'https://api.github.com/repos/JoinD872/HermesWork/contents/sucai/v4_final_Skill_A.png',
    data=body,
    headers={'Authorization': f'token {token}', 'Accept': 'application/vnd.github.v3+json', 'Content-Type': 'application/json'},
    method='PUT'
)
resp = urllib.request.urlopen(req, timeout=30)
"
```

---

## 六、当前已接入资源

| 资源 | 路径/地址 |
|------|----------|
| Google Sheets SA | `/root/.hermes/credentials/google-sheets-sa.json` |
| GitHub Token | `/root/.git-credentials` |
| 图片缓存 | `/root/.hermes/image_cache/` |
| 主表格 | `159VrH0vBDT41xHGZnuzCoYxUE7i6u1xvEJvlFKYqUsw` |
| Drive 宠物图片根文件夹 | `1pOtpgVsnMONss2GrsSUv0PUahSmnn5t2` |
| Drive 各宠物专属文件夹 | 子文件夹 ID（List files in `1pOtpgVsnMONss2GrsSUv0PUahSmnn5t2` 获取） |

---

## 七、踩坑记录

- [x] Drive API 需单独启用（项目 77775222475）
- [x] GitHub Contents API 上传必须用 PUT 方法 + sha
- [x] Repo 设为 public 后 raw.githubusercontent.com 直链才可在 Google Sheets IMAGE 公式中使用
- [x] pollinations.ai 有 429 限流，多图生成要间隔 4-5s；一次生成超过 4-5 张会触发超时被杀（300s timeout），检查 `/root/.hermes/image_cache/phase_*.png` 已生成哪些文件，缺失的单独补生成
- [x] mmx vision 对图片内容有限制，敏感图会报 `input image sensitive`，用 browser_vision 或描述规避
- [x] GitHub token 在 `/root/.git-credentials`（格式：`https://ghp_***@github.com`）
- [x] **⚠️ 参考图方向**：必须用「宠物图片/」里的「技能设计参考1~6」作为风格基准——它们是**VFX概念艺术分格图**，不是角色定妆照
- [x] GitHub API URL 含中文路径会报 `UnicodeEncodeError`，上传时用纯 ASCII 文件名（`strip_Skill_A.png`）
- [x] **⚠️ Drive 技能设计参考图位置**：技能设计参考1~6 在 `1pOtpgVsnMONss2GrsSUv0PUahSmnn5t2`（宠物图片根文件夹），各宠物专属子文件夹里**没有**技能设计参考图
- [x] **⚠️ GitHub GET sha 响应格式**：文件存在时返回 `{"sha": "..."}` 对象（不是数组）；只有 404 才抛异常，sha 读取后直接用 `data['sha']` 取值
- [x] **⚠️ Google Sheets IMAGE 公式验证**：默认读取 range 不显示公式内容，用 `valueRenderOption='FORMULA'` 才能看到 `=IMAGE(...)` 是否写入成功
- [x] **⚠️ Google Sheets 图片刷新**：表格里图片更新后，用户需按 Ctrl+Shift+R 强制刷新或开无痕窗口；GitHub raw 链接可加时间戳或开新标签页绕过 5 分钟 CDN 缓存
- [x] **⚠️ 横向条带图生成正确方式**：用**单次 prompt 生成整张条带**（一次生成 5 帧，不要分帧生成再拼）——分帧生成会导致：① 角色跨帧不一致；② 背景不连贯；③ 拼合后比例失调在 Sheets 里拉伸变形。正确方式：一个 prompt 描述完整 5 帧动作序列，16:9 比例（1280×720），prompt 里写 `all panels share identical background` + `consistent character in every panel`
- [x] **⚠️ pollinations.ai 风格控制边界**：当参考图风格为「flat silhouette + 纯黑背景 + 暗色角色剪影」时，AI 无法精准遵循，会生成偏 painterly/beautiful 的图。此时必须改用 **PIL 手工绘制几何剪影**，100% 控制风格。判断标准：参考图是「极简几何剪影」还是「写实/半写实」——前者 PIL，后者 AI。
- [x] **⚠️ PIL 绘制适用场景**：极简扁平风格参考图（纯黑/深灰背景 + 暗色角色剪影 + 亮色能量线）。PIL 绘制参数：BG=(10,10,14)、BODY=(20,22,30)、ENERGY=(0,180,255)，帧尺寸 600×600，再 resize 拼合。
- [x] **⚠️ PIL vs AI 生成选择**：如果参考图风格写实、色彩丰富、细节多 → 用 pollinations.ai；如果参考图风格是「纯色背景 + 剪影 + 能量线」的扁平 VFX 图 → 必须用 PIL
- [x] **⚠️ PIL 绘制完整参数**：BG=(10,10,14) 极深灰近乎黑、BODY=(20,22,30) 忍蛙剪影、ENERGY=(0,180,255) 亮蓝、ENERGY_BRIGHT=(100,220,255)、ENERGY_GLOW=(0,100,200)；帧 600×600 全部用 polygon/ellipse/line 组合绘制，不要用文字/渐变/滤镜；pose 命名：ready/slash/slash2/guard/shield_expand/shield_break/beam/charge/impact/jump/upthrust/sheathe/land；帧 resize 到 380×500 再横向拼合（FRAME_W=380, FRAME_H=500, GAP=8, 每技能5帧）；生成后用 `mmx vision describe` 验证风格正确后再上传
- [x] **⚠️ GitHub token 读取（关键！）**：`/root/.git-credentials` 文件内容在 execute_code sandbox 里被截断显示（`ghp_6q...XGvJ`），直接读文件也得到掩码值。正确方法：**用 terminal 子进程** 执行 `python3 -c "..."` 命令读取：
  ```bash
  cd /tmp && python3 -c "
  with open('/root/.git-credentials', 'r') as f:
      token = f.read().strip().split('://')[1].split('@')[0]
  print('Token:', token[:15]+'...')
  "
  ```
  terminal 子进程的 Python 能读到完整 token。upload 完成后记得清空 commit（`git reset HEAD~1`）。
- [x] **⚠️ pollinations.ai 风格控制边界**：当参考图风格为「flat silhouette + 纯黑背景 + 暗色角色剪影」时，AI 无法精准遵循，会生成偏 painterly/beautiful 的图。此时必须改用 **PIL 手工绘制几何剪影**，100% 控制风格。判断标准：参考图是「极简几何剪影」还是「写实/半写实」——前者 PIL，后者 AI。
- [x] **⚠️ pollinations.ai 生成验证**：生成后用 `mmx vision describe` 验证，确认是多分区概念稿格式（而非单张帅图或角色立绘）
- [x] **⚠️ MiniMax 参考图 URL 嵌入 prompt（2026-05-08 新发现）**：把参考图上传 GitHub 后，将 raw URL 直接写在 prompt 末尾（`Reference character image: URL\nReference pose image: URL`），MiniMax 模型能参考这两张图的形象和姿势生成新图。这是「纯文字描述角色特征」的重大升级，显著提升角色形象和姿势一致性。上传参考图到 GitHub 时同步获取 raw URL。
- [x] **⚠️ 单手剑 vs 双刀**：宠物形象是「单手剑」武器，不是双刀。生成 prompt 里必须写明「single sword / 单手剑」，否则 AI 会自动生成双刀忍蛙
- [x] **⚠️ 武器数量和 Idle 姿势是最关键的纠正点**：之前所有失败尝试都在这两个地方出错——要么生成双刀，要么没有遵循单手剑警戒姿势
- [x] **⚠️ MiniMax base64 突破（2026-05-08）**：MiniMax 图片 API 返回的 OSS URL 从 VPS 不可访问（TCP 超时），但加上 `response_format: base64` 参数后，图片数据直接内嵌在 JSON 响应里，完全绕过 URL 访问问题。这是整个图片生成链路的关键突破，必须作为首选工具
- [x] **⚠️ MiniMax base64 vs pollinations.ai**：MiniMax base64 生成的图片质量显著优于 pollinations.ai，风格控制更精准（更接近 GPT 水平）。两者 URL 都返回 OSS，但 base64 不需要访问 URL
- [x] **⚠️ GitHub token 读取方法（execute_code 可用！）**：之前认为 execute_code sandbox 会截断 token，实测 execute_code 可以正常读 `/root/.git-credentials` 并成功调 GitHub Contents API 上传文件。terminal 子进程方法不再需要
- [x] **⚠️ PIL 绘制被用户彻底否定**：用 PIL 几何形状绘制「技能概念设计稿」的结果是幼儿园简笔画水平，完全不可接受。用户明确表示「这是什么乱七八糟的东西啊」。PIL 只适合「极简剪影 VFX 参考图」，不适合「专业 concept art sheet」
