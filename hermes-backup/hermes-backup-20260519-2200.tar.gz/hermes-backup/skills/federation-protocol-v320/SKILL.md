---
name: federation-protocol-v320
description: Hermes Federation Pending 协议统一记录 — V3.0.2 修复「派发写 pending/{agent}/、执行方读 pending/ 扁平」的路径分裂问题。包含目录结构规范、写入/读取/清理规则、cron patch 操作备忘。
version: 1.0.0
category: hermes
tags: [federation, pending, cron, multi-agent, bug-fix]
risk: write-safe
created: 2026-05-02
contributors: [小H, GPT]
sources:
  - 大佬 DM → GPT 诊断 → 小H 执行
  - federation-callback-pool V3.0.1 → V3.0.2
---

# Federation 协议 V3.0.2 修复记录

## 问题背景

**根因**：派发方（federation-dispatch-wake）写 `pending/{agent}/{task_id}.json`，执行方（cron agents）读 `pending/{task_id}.json`（扁平），路径不匹配导致任务卡死。

**症状**：`VPS_STATUS_20260427.json` 卡在 `pending/vps-technician/` 5天无人处理，因为老V cron 扫的是根目录。

## 目录结构（V3.0.2 起生效）

```
~/.hermes/federation/
├── callbacks/
│   ├── {task_id}.json          # 扁平，不按 agent 分
│   └── archive/
├── pending/
│   ├── vps-technician/         # 老V
│   │   └── {task_id}.json
│   ├── researcher/             # 小研
│   │   └── {task_id}.json
│   ├── health/                 # 小健
│   │   └── {task_id}.json
│   └── game-designer/          # 小策
│       └── {task_id}.json
└── archive/
    └── stale_pending_YYYYMMDD_HHMMSS/  # stale pending 归档
```

## 核心规则

| 操作 | 规则 |
|------|------|
| **写入** | 统一写 `pending/{agent_key}/{task_id}.json` |
| **读取** | 兼容双路径：优先 `pending/{agent_key}/*.json` + 兼容 `pending/*.json`（旧结构） |
| **回调** | 写 `callbacks/{task_id}.json`（扁平，不变） |
| **清理** | 删除 `pending/{agent_key}/{task_id}.json` + 兼容删 `pending/{task_id}.json` |

## Agent → 目录名 映射表

```python
AGENT_DIR = {
    "老V": "vps-technician", "vps-technician": "vps-technician",
    "小研": "researcher", "researcher": "researcher",
    "小健": "health", "health": "health",
    "小策": "game-designer", "game-designer": "game-designer",
}
```

## Stale Pending 清理流程（安全删除，不直接 rm）

```bash
TS=$(date +%Y%m%d_%H%M%S)
mkdir -p ~/.hermes/federation/archive/stale_pending_$TS
mv ~/.hermes/federation/pending/{agent}/{task_id}.json \
~/.hermes/federation/archive/stale_pending_$TS/

# 验证
find ~/.hermes/federation/pending -type f | sort  # 应为空
find ~/.hermes/federation/archive/stale_pending_$TS -type f

# 回滚
mv ~/.hermes/federation/archive/stale_pending_$TS/{task_id}.json \
~/.hermes/federation/pending/{agent}/
```

## Cron Job Patching 注意

**patch 对象**：3个 cron job 的 prompt 内嵌代码（非 skill 独立脚本）：
- 老V `a259819c24f4`
- 小研 `ef20c63571f7`  
- 小策 `5e3728b97221`

**每个 cron 需要改 2 处**：
1. pending 扫描循环（扁平 → 双路径）
2. emit_result pending 清理（旧单路径 → 新双路径）

**patch 难点**：小策的 emit_result 用 `pf` 变量名（非 `pending_file`），且与心跳重置代码合并在一行，需要精确匹配。

## 小策 emit_result 精确 patch 备忘

```python
# 原始（小策 cron job line 61-62）：
pf = os.path.expanduser(f"~/.hermes/federation/pending/{task_id}.json")
if os.path.exists(pf): os.remove(pf)

# 替换为：
new_pf = os.path.expanduser(f"~/.hermes/federation/pending/game-designer/{task_id}.json")
old_pf = os.path.expanduser(f"~/.hermes/federation/pending/{task_id}.json")
if os.path.exists(new_pf): os.remove(new_pf)
if os.path.exists(old_pf): os.remove(old_pf)
```

## 验证命令

```bash
# 1. 目录结构
find ~/.hermes/federation -maxdepth 4 -type f | sort

# 2. pending 应为空
find ~/.hermes/federation/pending -type f | sort  # 空 = 正常

# 3. 确认 cron 里有 agent_key 和双路径逻辑
python3 -c "
import json
with open('/root/.hermes/cron/jobs.json') as f:
    data = json.load(f)
for job in data['jobs']:
    jid = job['id']
    if jid in ('ef20c63571f7', 'a259819c24f4', '5e3728b97221'):
        p = job['prompt']
        print(f'{job[\"name\"]}: agent_key={\"agent_key\" in p}, new_scan={\"pending/{agent\" in p}')
"

# 4. grep 旧结构残留
grep -rn "pending/{task_id}" ~/.hermes/skills/hermes/federation-callback-pool/SKILL.md
# 应只有 2 处：描述文字 + old_pending 兼容变量
```

## 遗留项

- `~/.hermes/federation/ue5-trends.json` 孤儿文件待处理（非 pending/callback 协议，P1）
