---
name: research-domain-fallback
description: 官方文档站点被封 / 403 / Cloudflare 拦截时，统一调度 fallback 路径获取知识
triggers:
  - browser_navigate 返回 403 / Cloudflare / access denied
  - curl 返回 403 / 401 / timeout
  - 搜索结果为空或被搜索引擎拦截
  - 目标站点属于高风控域名（Epic / Discord / Cloudflare / Gitbook / Notion）
risk: read-only
version: 1.0
created: 2026-04-28
---

# Research Domain Fallback

当官方文档站点无法访问时，统一调度 fallback 路径获取知识。

## 核心原则

> 研究 ≠ 打开网页，研究 = 获取可信知识
> 官方站被封 ≠ 研究失败，只是路径要换

**禁止**：连续硬刷目标站点。最多各尝试 1 次，失败立刻走 fallback。

---

## 执行流程（按顺序）

### 第一步：判断用户能否提供官方内容（先于所有 fallback）

```
在触发任何 fallback 之前，先判断：

用户是否有条件提供官方内容？
├─ 用户有梯子 / 本地浏览器可访问目标站点
├─ 用户明确表示"我能打开这个页面"
└─ 用户主动发来了页面截图 / 正文
    → 优先：请用户复制/截图给我
    → 不自己绕路搜索
    → 这是最高可信度路径，研究结束
```

**何时跳过此步**：用户明确说"我打不开"、"你帮我查"，或当前对话明显是自动研究任务（cron/子agent）无用户参与。

### 第二步：正常尝试访问

```
browser_navigate(url)
├─ 返回 403 / Cloudflare / access denied → 进入 Fallback
├─ timeout → 进入 Fallback
└─ 成功 → 正常读取，研究结束
```

### 第三步：Fallback（见下一节）

```
browser_navigate(url)
├─ 返回 403 / Cloudflare / access denied → 触发 fallback
├─ timeout → 触发 fallback
└─ 成功 → 正常读取

curl(url)
├─ 返回 403 / 401 / timeout → 触发 fallback
└─ 成功 → 正常读取

搜索结果为空 / 明显被拦截 → 触发 fallback
```

---

## Fallback 优先级（按顺序，跳过已失败的步骤）

> 注意：第一步「请用户提供官方内容」已在上方处理完毕。
> 此处从「用户无法提供」的场景开始。

### B. 第三方权威技术博客（高可信）

针对特定领域的已知可靠来源：

| 领域 | 优先来源 |
|------|---------|
| UE5 / Unreal Engine | Tom Looman、GameFromScratch、Vagon Blog |
| AI/ML 论文 | arXiv (arxiv.org) |
| 医疗健康 | PubMed (pubmed.ncbi.nlm.nih.gov) |
| VPS / Linux | DigitalOcean Community、Linode Guides、Hostinger Tutorial |

### C. 官方 GitHub / SDK / Release Notes

- 官方 GitHub repo 的 release notes、CHANGELOG.md、README.md
- 示例：`https://github.com/EpicGames/UnrealEngine/releases`

### D. 社区讨论（Reddit / Forum / Issues）

- Reddit 相关子版块（注意：时效性好但准确性参差）
- GitHub Issues / Discussions（真实用户问题，含官方回复）

### E. 国内转载（CSDN / 知乎 / 公众号 / 游戏新闻门户）

作为中文补充，注意：可能滞后、可能有错误，需交叉验证，不能作为唯一来源。

**VPS 可直连的游戏类新闻来源（已验证 2026-05-18）：**

| 来源 | URL | curl 状态 | 说明 |
|------|-----|-----------|------|
| **17173游戏新闻** | news.17173.com | ✅ 可直接提取全文 | 端游/网游新闻最全，含怀旧服、测试资讯、版本解读 |
| **新浪财经/科技** | finance.sina.com.cn | ✅ 可直接提取全文 | IT之家等转载，游戏行业新闻、财报、公告 |
| **网易UU加速器博客** | uu.163.com/blog | ✅ 可直接提取全文 | 国际服游戏评测、测试公告、网络优化攻略 |
| **3DM游戏网** | ol.3dmgame.com | ⚠️ 偶有空响应 | 单机/网游新闻，可尝试，不保证每次都提取成功 |

**VPS 不可直连（需 fallback）：**

| 来源 | 状态 | 替代方案 |
|------|------|---------|
| 什么值得买 (post.m.smzdm.com) | curl 返回空 | 通过 SearXNG 搜索该站获取摘要 |
| 搜狐游戏 (m.sohu.com / game.sohu.com) | 多数空内容 | 部分深度链接可用，需逐个尝试 |
| 腾讯新闻 (news.qq.com) | curl 返回空 | 搜索引擎摘要或找转载站 |
| 知乎专栏 (zhuanlan.zhihu.com) | curl 403 | 通过 SearXNG 搜索 site:zhuanlan.zhihu.com 获取摘要 |

### F. 搜索引擎 + 摘要

- `mcp_searxng_search` + `mcp_minimax_plan_web_search`
- 先搜关键词，拿到摘要片段再决定是否需要 browser_navigate

### G. 内参知识库（最后兜底）

- 来自 MEMORY.md、Skills 文档、过往会话中已整理的知识
- 标注：「基于内部知识整理，建议有条件时二次验证」

---

## 已知高风控域名清单

以下站点被确认会拦截 VPS 访问（192.3.241.244），遇到时跳过 browser_navigate 直接 fallback：

- `dev.epicgames.com` — Cloudflare 五层封锁
- `docs.unrealengine.com` — 同上
- `unrealengine.com` — 同上
- `discord.com/developers` — 自动化检测
- `cloudflare.com/docs` — Bot 检测
- `anthropic.com/docs` — Bot 检测（待确认）
- `openai.com/docs` — Bot 检测（待确认）
- `*.gitbook.io` — JS 挑战
- `*.notion.so` — 自动化检测

---

## 输出格式（每次触发 fallback 后必须输出）

```markdown
### 访问结论
- 目标站点：[URL]
- 是否官方站被拦截：✅ 是 / ❌ 否
- 拦截类型：403 / Cloudflare / Timeout / Empty Results
- 是否继续硬刷：❌ 否（进入 fallback）

### 替代来源
- 来源1：[来源名] — [URL] — 可信度：高/中/低
- 来源2：[来源名] — [URL] — 可信度：高/中/低
- 来源3：[来源名] — [URL] — 可信度：高/中/低

### 可信度分级
- 高可信：[内容] — 来源：[来源]
- 中可信：[内容] — 来源：[来源]，建议交叉验证
- 低可信：[内容] — 来源：[来源]，存疑待核实

### 最终研究结论
- 可确认内容：[基于高可信来源的具体结论]
- 存疑内容：[不同来源说法不一的部分]
- 需要用户补充的内容：[必须官方原文才能确认的部分]
```

---

## 风控规则

1. **标注非官方**：官方站不可访问时，所有内容标注「非官方直读」
2. **交叉验证**：单一博客内容不能作为官方结论，必须有 2+ 来源佐证
3. **版本号 / API 参数**：涉及版本号、弃用信息、参数必须标注可信度
4. **用户优先**：用户可访问时，优先建议用户复制正文
5. **不过早放弃**：A→B→C 路径都没结果才到 G，不要跳过能快速验证的高可信路径

---

## 与旧 Skill 关系（统一调度）

| 旧 Skill | 角色 |
|---------|------|
| `search-tool-fallback` | 作为搜索工具切换子模块（MiniMax ↔ SearXNG） |
| `research-fallback-strategy` | 作为研究末级兜底子模块（arXiv / PubMed / 内参） |
| `vps-epic-docs-access` | 作为 Epic 专项案例库（已确认封锁定论） |

这三个 skill 保留但标注「由 research-domain-fallback 统一调度」，不删除以避免破坏现有任务链。
