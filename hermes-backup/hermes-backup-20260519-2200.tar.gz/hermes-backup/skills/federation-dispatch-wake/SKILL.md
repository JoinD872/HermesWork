---
name: federation-dispatch-wake
risk: write-safe
---

# federation-dispatch-wake — DM 路由与即时任务派发

## 功能
将 DM 中的实质性任务拦截并派发给子 Agent，完整执行链路：
```
用户DM → 识别类型 → 写pending → 即时触发子Agent（delegate_task）→ 读callback → 汇报用户
```

## DM 强制路由协议（P0，已写入 MEMORY.md）
触发条件：大佬在 DM 中提出具有执行、分析、研究性质的实质性任务。
**小H 禁止在 DM 中直接生成长篇推理或独立执行，必须强制拦截并分发！**

路由匹配表：
1. 游戏策划 / UE5技术 / 蓝图C++ → 小策
2. 颈椎腰椎 / 睡眠 / 胃炎饮食 → 小健
3. AI/ML论文 / 算力 / 大模型竞品 → 小研
4. VPS / 代理隧道 / Docker排查 → 老V
5. 架构调优 / 跨Agent协调 / 日常闲聊 → 小H 自己处理

执行动作：匹配成功后，写 pending → 即时触发（不用等 cron）→ DM 仅回复"已路由至X，任务编号X，等待闭环。"

**附带上下文规则**：路由时必须将用户画像（腰5骶1/胃炎/睡眠习惯）随任务一起打包进 payload。

---

## 完整操作流程（实测有效，2026-04-27）

### Step 1 — 判断类型，决定路由
对照路由表，确认目标 Agent。

### Step 2 — 写 pending 文件
路径格式：`~/.hermes/federation/pending/{agent}/{task_id}.json`

```json
{
  "task_id": "UE5WP_20260427",
  "agent": "game-designer",
  "created_at": 1745732400,
  "status": "waiting",
  "user_context": {
    "name": "大佬",
    "职业": "游戏技术策划（UE5）",
    "健康备注": "腰5骶1椎盘突出、慢性萎缩性胃炎"
  },
  "task": {
    "type": "技术研究",
    "description": "收集UE5 World Partition内存优化方案",
    "requirements": ["具体要求1", "具体要求2"]
  }
}
```

### Step 3 — 即时触发子 Agent（不等 cron）
**用 `delegate_task`，不用 Webhook 唤醒**（Webhooks 无法唤醒 session，已验证）。

```python
delegate_task(
    goal="""你是{Agent名}。读取任务文件：
~/.hermes/federation/pending/{agent}/{task_id}.json

按task要求执行，完成后将结果写入：
~/.hermes/federation/callbacks/{task_id}.json

然后删除 pending 文件。
""",
    role="leaf",
    toolsets=["terminal", "file", "web"]  # 按需加 web
)
```

### Step 4 — 读 callback 结果
等待 delegate_task 返回后，读取：
`~/.hermes/federation/callbacks/{task_id}.json`

### Step 5 — 清理并汇报
- 删除 `pending/{agent}/{task_id}.json`（如果 delegate_task 没删）
- 删除 `callbacks/{task_id}.json`（读完后）
- 格式化汇报用户（结论先行 + 数据完整）

---

## ⚠️ 关键坑点（已验证）

### Webhook 无法唤醒 session
- 群里发文字 `[@小研]` ≠ 真实飞书 @
- 真实 @ 必须从成员列表选人
- **结论**：不能靠 Webhook 唤醒子 Agent 做即时任务
- **正确做法**：用 `delegate_task` 即时触发

### cron run 的局限性
- `cronjob(action='run')` 返回 `success:true` 只表示触发器启动
- 不代表任务真正执行完成
- **真正验证**：callback 文件存在 + 状态 done

### delegate_task 的适用场景
- 子 Agent cron 未到触发时间，需要立即执行
- 子 Agent 所在群没有飞书 session 在跑
- 代价：没有飞书推送，完全依赖主 Agent 读取 callback 回收结果

---

## 派发格式模板

```json
{
  "task_id": "{AGENT}_{YYYYMMDD}_{序号}",
  "agent": "{agent-name}",
  "created_at": "<int(time.time())>",
  "status": "waiting",
  "user_context": {
    "name": "大佬",
    "职业": "游戏技术策划（UE5）",
    "健康备注": "腰5骶1椎盘突出、慢性萎缩性胃炎、凌晨2点睡"
  },
  "task": {
    "type": "<类型：技术研究/健康咨询/VPS巡检/其他>",
    "description": "<一句话描述>",
    "requirements": ["<具体要求1>", "<具体要求2>"]
  }
}
```

## 各 Agent pending 目录
```
~/.hermes/federation/pending/game-designer/   # 小策
~/.hermes/federation/pending/health/          # 小健
~/.hermes/federation/pending/researcher/       # 小研
~/.hermes/federation/pending/vps-technician/  # 老V
```

## 各 Agent callback 目录（统一）
```
~/.hermes/federation/callbacks/
```
