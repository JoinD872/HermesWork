---
name: vps-full-health-check
description: VPS 完整硬件+网络检测流程，替代简陋的vps-patrol
category: devops
---

# VPS Full Health Check — VPS 全状态检测标准流程

## 触发条件
大佬要求完整检查 VPS 网络与硬件状态时使用。

## 检测命令清单

### 基础配置
```bash
# CPU型号 + 核心数
nproc && cat /proc/cpuinfo | grep "model name" | head -1

# 内存 + Swap
free -h

# 磁盘使用率
df -h

# 磁盘IO（dd实测）
dd if=/dev/zero of=/tmp/test bs=512M count=1 oflag=direct && rm /tmp/test

# 虚拟化类型
systemd-detect-virt || virt-what

# 系统负载 + 在线时长
uptime && last reboot
```

### 网络出口检测
```bash
# 出口IP + ASN
curl -s ipinfo.io

# 去程路由（示例：电信）
mtr -r -c 5 -J 202.96.128.166

# 国际带宽（Cachefly CDN）
curl -sL cachefly.cachefly.net/100MB.bin -o /dev/null -w "%{speed_download}\n"

# DNS污染检测
dig google.com +short && dig youtube.com +short
```

### 国内三网检测
```bash
# 移动（备用DNS）
ping -c 5 223.6.6.6

# 电信
ping -c 5 202.96.128.166

# 联通
ping -c 5 202.106.0.20
```

### 服务状态
```bash
systemctl status nginx xray cloudflared fail2ban 2>/dev/null | grep -E "Active:|●"
```

### Cloudflare Tunnel
```bash
cloudflared tunnel list
cloudflared tunnel info <tunnel_name>
```

## 输出格式
```
【基础配置】
CPU / 内存 / 磁盘 / IO / 虚拟化 / 在线时长

【网络线路】
出口IP / ASN / 线路类型 / 带宽

【国内访问质量】
三网延迟 + 丢包率（表格）

【风险分析】
按严重度列出

【优化建议】

【长期使用结论】
```

## 上次检测结果（2026-05-02）
- IP: 192.3.241.244 / RackNerd LA
- 电信/联通: 100%丢包，仅移动可用(49ms/0%丢包)
- 电信/联通用户不适合科学上网
- 适合作为 Hermes 主节点（Cloudflare Tunnel）
