---
name: ai-model-capabilities-quick-ref
description: 常见 AI 模型多模态能力快速对照 — 图片理解 vs 图片生成，明确各模型能力边界
category: mlops
risk: read-only
version: 1.1
created: 2026-05-08
updated: 2026-05-09
source: 大佬 DM 对话
---

# AI 模型多模态能力快速对照

## 核心原则

> **图片理解 ≠ 图片生成**。买咖啡时确认"有wifi"不等于"有电源"——两个完全不同的能力，必须分别确认。

---

## 主流模型能力矩阵（2026-05-09 更新）

### 图片理解（Image Understanding / Vision）

| 模型 | 状态 | 说明 |
|------|------|------|
| **DeepSeek V4 Vision** | ✅ **首选** | 原生多模态输入，文本引用图片即可理解 |
| **GPT-4o / ChatGPT** | ✅ 极强 | 精确 reference image 控制，姿势迁移可用 |
| **Claude** | ✅ 极强 | 图像理解第一梯队 |
| **Gemini** | ✅ 极强 | Google 原生多模态 |
| **MiniMax Vision** (`mmx vision describe`) | ⬜ 备用 | 仅当 V4 不可用时（CLI 工具） |
| **MiniMax MCP** (`understand_image`) | ❌ 已下线 | 平台级 404 |

### 图片生成（Image Generation / T2I）

| 模型 | 状态 | 说明 |
|------|------|------|
| **GPT-4o** (DALL-E) | ✅ **推荐** | reference image 控制精准，姿势迁移可用 |
| **Gemini** | ✅ 推荐 | Google 图生能力，免费额度可用 |
| **MiniMax `image-01`** | ⬜ 备用 | VPS 不可达 OSS 需 base64 绕过 |
| **pollinations.ai** | ⬜ 免费备用 | 无需 API key，VPS 可访问 |
| **DeepSeek V4** | ❌ **没有** | V4 是纯语言/推理模型，**没有图片生成能力** |
| **DeepSeek Janus Pro** | ✅ 独立服务 | `deepseekimage.org`，与 V4 完全独立 |
| **Midjourney** | ✅ 质量高 | 需要稳定梯子 |

---

## 快速查询

当用户问"XX 模型能生成图片吗？"时：

1. 查本表
2. 如果表里没有 → 搜索「model name + image generation + 2026」
3. 区分清楚是要「看懂图」还是「生成图」

---

---

## 成本速查表（2026-05-10）

### DeepSeek V4 Flash — 图片理解实际成本

| 项目 | 数值 |
|------|------|
| 当前余额 | ¥8.09（充值余额，无赠金）|
| 输入价格 | $0.14 / 1M tokens（Cache Miss）|
| 每张图片编码 | **~90 tokens**（高效 KV 缓存压缩，比 Claude 870 tokens 少 10x）|
| 单次 VISION 请求成本 | ~200 tokens（图90+指令100）× $0.14/M + 输出 ~$0.28/M |
| **≈ 0.003 分/张** | 一天 1000 张 ≈ 3 分钱 |
| 渠道 | 官方 API `api.deepseek.com`（无中间商加价）|
| 隐私 | ✅ DeepSeek 官方 API（付费），数据不用于训练 |

> 用户通常感觉花得快是因为 **thinking mode 默认开启**（输出 token 翻倍）+ **高频 tool call 产生大量上下文**，并非图片识别本身贵。

### Gemini 隐私条款注意事项

| 层级 | 数据用于训练 | 人工审查 | 适用场景 |
|------|:-----------:|:--------:|---------|
| **Free Tier**（无账单） | ✅ **是** | ✅ **可能** | 不能用于敏感/隐私数据 |
| **Paid Tier**（有账单，甚至0消耗） | ❌ **不** | ❌ **不** | 绑卡即享隐私保护 |
| **AI Studio 网页端** | ✅ **是** | ✅ **可能** | 手动测试用，不可自动化 |

> 条款原文：Free Tier 用户的数据会用于"改进和开发 Google 产品"，人工审查员可能阅读你的输入。
> 但如果在 Cloud 项目绑定了有效的账单账号（哪怕没花钱），就自动算 Paid 待遇。

### Gemini 免费 API — 图片理解 vs 图片生成

| 能力 | 免费 API？ | 说明 |
|------|:---------:|------|
| **图片理解（Vision）** | ✅ **有免费** | Gemini 2.5 Flash / 3.1 Flash-Lite 等输入免费，但数据用于训练 |
| **图片生成（Image Gen）** | ❌ **无免费 API** | Gemini 3.1 Flash Image / 3 Pro Image 全部 `Free Tier: Not available` |
| AI Studio 网页端生图 | ✅ 免费（每天 500-1000 张）| 手动操作，不可 API 调用，隐私同上 |

## 更新日志

- 2026-05-08：创建。来源于大佬问 DeepSeek V4 能否改善图片质量
- 2026-05-09：更新图片理解首选为 DeepSeek V4 Vision，移除 MiniMax MCP 相关条目
- 2026-05-10：新增成本速查表、Gemini 隐私条款注意事项、Gemini 生图免费 API 无免费额度的确认
