---
name: minimax-img2img
description: MiniMax image-01 的 reference_image 参数（img2img）使用方法 — 分步策略、已知局限
category: mlops
risk: read-only
version: 1.0
created: 2026-05-08
source: 小策（游戏制作组）
---

# MiniMax image-01 img2img 方法

## 核心发现

MiniMax `image-01` 模型支持 `reference_image` 参数，可以传入参考图做 img2img。

**关键局限：这不是真正的姿势迁移（pose transfer）**，本质是风格参考。模型会"参考"参考图的内容，但不是 1:1 精确套用。

---

## API 调用方法

**Endpoint**: `POST https://api.minimaxi.com/v1/image_generation`
**Model**: `image-01`
**认证**: key 从 `/root/.mmx/config.json` 的 `api_key` 读取

```python
import requests, json, base64

with open('/root/.mmx/config.json') as f:
    KEY = json.load(f)['api_key']

with open('reference_image.png', 'rb') as f:
    ref_b64 = base64.b64encode(f.read()).decode()

payload = {
    'model': 'image-01',
    'prompt': '详细描述期望的画面',
    'reference_image': [ref_b64],   # 传入数组，最多可传多张
    'response_format': 'base64'    # 必须用 base64，URL 方案不可用（阿里云 OSS 从 VPS 不可达）
}

r = requests.post(
    'https://api.minimaxi.com/v1/image_generation',
    headers={'Authorization': f'Bearer {KEY}'},
    json=payload,
    timeout=180
)
data = r.json()
imgs = data.get('data', {}).get('image_base64', [])
if imgs:
    with open('output.png', 'wb') as f:
        f.write(base64.b64decode(imgs[0]))
```

---

## 已知问题（踩坑记录）

### 问题1：两张参考图同时传入会失败

**症状**: `{"success_count": 0, "failed_count": 1}`

**解法**: 分两步走（见下文分步策略）

### 问题2：精确姿势迁移超出模型能力

MiniMax 的 `reference_image` 参数不是 ControlNet 级别的姿势控制，它只是"风格提示"。1:1 复刻姿势是不可能的。

**如果需要精确姿势迁移**：
- 方案A：用户使用 GPT-4o 生成（reference image 控制精准得多）
- 方案B：接受 MiniMax 的模糊参考结果，让美术在此基础上调整

### 问题3：prompt 里的 URL 参考不稳定

尝试把参考图 URL 嵌入 prompt 让模型"看到"——效果不稳定，不可靠。

---

## 分步策略（实测有效）

当需要两张参考图时（比如姿势参考 + 角色形象），使用分步法：

### Step 1：纯姿势剪影
用**姿势参考图**单独生成一个干净的姿势剪影，锁定构图。

```python
payload = {
    'model': 'image-01',
    'prompt': (
        'Recreate the EXACT pose from the reference image: '
        'legs spread wide apart in a deep crouching stance, knees bent low, '
        'a sword held horizontally directly in front of the face at head height, '
        'both hands gripping the sword. '
        'Style: flat minimalist warrior silhouette on transparent background. '
        'Pure silhouette only, no background details.'
    ),
    'reference_image': [pose_b64],
    'response_format': 'base64'
}
```

### Step 2：姿势 + 角色形象融合
用 **Step1 生成的图** + **角色参考图**一起传。

```python
payload = {
    'model': 'image-01',
    'prompt': (
        'Apply the character appearance from the SECOND reference image '
        'onto the pose in the FIRST reference image. '
        'The pose must match the FIRST image exactly. '
        'The character appearance must match the SECOND image. '
        'Character details: dark grey frog body, gold horns, red scarf...'
    ),
    'reference_image': [step1_result_b64, character_b64],
    'response_format': 'base64'
}
```

---

## 图片理解工具（与 img2img 配合）

生成前建议先理解参考图内容，用 `mmx vision describe`（绝对不要用 MCP，MCP 平台级 404）：

```bash
mmx vision describe /path/to/reference.png
```

---

## 2026-05-08 小策实测结论

- `reference_image` 支持数组格式（MiniMax API 层面接受多张）
- 但多张参考图同时传入模型处理失败率高，**必须分步**
- 分步后 Step1 姿势可以较接近，Step2 融合角色特征效果仍不稳定
- 最终限制是**模型能力层面**的，不是 prompt 问题
