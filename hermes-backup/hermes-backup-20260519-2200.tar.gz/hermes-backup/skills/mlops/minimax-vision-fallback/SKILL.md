---
name: minimax-vision-fallback
description: 【已归档】MiniMax 图片理解 — 平台级 404，不再使用。DeepSeek V4 原生 Vision 已替代。
risk: read-only
status: archived
archived_at: 2026-05-09
reason: DeepSeek V4 原生 Vision 已替代 MMX CLI 图片理解，不再需要专用 fallback skill。
---

# 【已归档】MiniMax 图片理解备用方案

**此 skill 已归档。** 图片理解统一走 DeepSeek V4 原生 Vision，不再需要 MMX CLI 作为备用。

参见 MEMORY.md「图片理解（2026-05-09 更新）」条目。
