---
name: minimax-image-pose-transfer
description: MiniMax image-01 reference_image 姿势迁移实战总结——哪些策略有效，哪些是模型能力上限
tags: [minimax, image-generation, img2img, pose-transfer]
created: 2026-05-08
---

# MiniMax 图像生成：姿势迁移与 img2img 实战总结

## 核心结论

**MiniMax image-01 的 `reference_image` 参数不是真正的姿势迁移工具**——它本质上只是"风格参考"，两张 reference_image 同时传入时模型会混在一起理解，无法精确分离"角色形象"和"姿势"。这是模型能力层面的限制，不是 prompt 问题。

## 验证过的策略结果

| 策略 | 精度 | 适合场景 |
|------|------|---------|
| prompt 嵌 URL 参考 | ❌ 姿势+形象都不对 | 不推荐 |
| 单 reference_image + 文字描述姿势 | ⚠️ 形象对，姿势不对 | 气氛图 |
| 两张 reference_image 同时 img2img | ❌ 模型崩溃/混乱 | 不推荐 |
| 分两步走（Step1纯姿势→Step2套角色） | ⚠️ 方向接近但达不到1:1 | 方向探索 |
| **GPT-4o reference image** | ✅ 真正的姿势迁移 | **1:1精确复刻首选** |

## 分两步走操作流程（适合气氛图/方向探索）

**Step 1**：只用姿势参考图生成纯剪影，锁定构图  
**Step 2**：Step1 图作为 reference + 角色图拆成 prompt 文字描述

## GPT-4o 是 1:1 复刻的唯一可靠路径

当目标是"角色形象精确 + 姿势精确"时：
1. 用户在 ChatGPT Plus 里用 GPT-4o 生成（支持真正的 reference image 姿势迁移）
2. 用户把图发飞书群
3. 我接手后续：上传 GitHub → 写入 Google Sheets（IMAGE 公式）

## 关于 MiniMax img2img 的正确用法

- **单张 reference_image**：有效，风格迁移类任务可以用
- **两张同时 reference_image**：模型处理能力不足，会混淆
- **base64 方案**：绕过 OSS URL 不可达问题，model 字段用 `image-01`（不是 `image-01-live`，后者不支持 base64）

## 参考图实际内容（2026-05-08 确认）

**Mega甲贺忍蛙角色图**：
- 黑灰色身体，T-pose站姿
- 头部：金角（上方金色）、白黑面罩、额头红色条纹、红色眼睛
- 颈部：红色围巾垂在左侧
- 腹部：浅棕色星形标记（不是菱形）
- 手脚：白色三指蹼手，白色蹼脚
- 武器：红色半透明刀身 + 左侧月牙装饰（无前臂刀刃）

**隼龙（Ryu Hayabusa）姿势参考图**：
- 剑横在脸前护体（不是双后举手剑）
- 左手扶剑背，右手握柄
- 目光透过剑刃上方缝隙
- 双腿分开深蹲

## 教训

- **不要用"二手记忆"理解参考图**——每次都要用 `mmx vision describe` 重新看原图确认
- **不要猜模型行为**——MiniMax image-01 对多参考图处理能力有限，这是事实，不是可以通过 prompt 技巧解决的
