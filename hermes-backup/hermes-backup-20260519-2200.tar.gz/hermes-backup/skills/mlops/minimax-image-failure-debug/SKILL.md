---
---
name: minimax-image-failure-debug
category: mlops
description: MiniMax MMX CLI image generation failure debugging workflow
risk: read-only
---

# MiniMax Image Generation Failure Debug

## Trigger
MMX CLI `mmx image generate` returns `code: 6, Network request failed`

## Debug Steps

### Step 1: DNS Check
```bash
nslookup image.minimaxi.com 8.8.8.8
nslookup image.minimaxi.com 1.1.1.1
```
- Both return **NXDOMAIN** means image.minimaxi.com globally does not exist
- But MMX CLI actually calls **api.minimaxi.com**/v1/image_generation, NOT image.minimaxi.com

### Step 2: Confirm Actual Endpoint
```bash
mmx image generate "test" --verbose
```
Check the POST URL in output

### Step 3: Test global region
```bash
mmx config set region global && mmx image generate "test" && mmx config set region cn
```
- `code 1: invalid api key` on global = key is CN-region specific
- Same failure on global = same conclusion

### Step 4: Verify text API works
```bash
mmx text "hello"
```

### Step 5: Fallback - pollinations.ai
```bash
curl -sI "https://image.pollinations.ai/prompt/test.png"
# Expect HTTP/2 200
```
No API key, free, VPS-accessible.
URL format: `https://image.pollinations.ai/prompt/<URL-encoded-prompt>.png`

## Known Failure Modes

| Error Code | Meaning | Action |
|------------|---------|--------|
| code 6 Network request failed | Server-side image API down | pollinations.ai fallback |
| code 1 invalid api key | Key not valid for this region | Use correct region |
| image.minimaxi.com NXDOMAIN | Separate domain, unrelated to CLI | Ignore |

## Root Cause（2026-04-27 更新）
**图片生成 API 在 CN 端根本不存在**，不是服务端宕机。

| 端点 | 图片生成 API | 文字/语音 API |
|------|------------|-------------|
| `api.minimaxi.com`（CN） | ❌ 不存在此端点 | ✅ 可用 |
| `api.minimax.io`（Global） | ✅ 存在 | ✅ 可用 |

- MMX CLI 的 "dual region" 支持**仅针对文本模型**，图片生成始终走 Global 端
- CN key 无法跨区调用 Global API（账号区域绑定）
- `image.minimaxi.com` 的 NXDOMAIN 与图片 API 无关（它是另一个独立域名）

## 解法

1. **必须有 Global key**：注册 minimax.io 账号获取 Global API key
2. **或继续用 pollinations.ai**（免费，无需 key，生产方案）
3. **CN key 完全无法用于图片生成**，无论怎么换 region/mcp 配置

## 验证结论（2026-04-27）

```bash
# Global 端 curl 测试
curl -X POST "https://api.minimax.io/v1/image_generation" \
  -H "Authorization: Bearer $MINIMAX_API_KEY" \
  -d '{"model":"image-01","prompt":"a cute cat"}'

# → {"status_code":1004, "status_msg":"login fail"} 
#    key 未生效（CN key 本身可能被拒，或环境变量注入失败）
```

**官方文档明确**：图片生成 API 只有 Global 端，示例 curl 也是 `api.minimax.io`。

## Changelog
- 2026-04-26: Created after debugging MiniMax image API failure
- 2026-04-27: 深度调研确认——图片 API 仅存在于 Global 端，CN 端不存在该服务；MMX CLI dual region 不覆盖图片；pollinations.ai 仍是最优免费方案
