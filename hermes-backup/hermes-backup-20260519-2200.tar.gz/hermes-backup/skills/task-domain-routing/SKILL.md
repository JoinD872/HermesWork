---
name: task-domain-routing
description: 大佬 DM 实质任务 → 判断领域 → 分配给对应联邦 Agent
triggers:
  - 大佬 DM 一个实质任务（不是闲聊/问建议）
  - 任务涉及特定专业领域
risk: read-only
version: 1.0
created: 2026-04-28
---

# Task Domain Routing — 任务路由规则

## 核心原则

> 小H 是路由 + 调度，不是执行者。
> 专业任务交给专业 Agent，结果回填给用户。

## 路由表

| 任务领域 | 目标 Agent | 飞书群 |
|---------|-----------|--------|
| 游戏策划 / UE5 / 攻防博弈 / 经济系统 | 小策 | oc_5a883cbe523b1a93ee269bba2f8536a0 |
| 健康 / 颈椎 / 腰椎 / 胃炎 / 睡眠 / 营养 | 小健 | oc_6dbf15aa718c29adca8d085017930a71 |
| AI/ML 论文 / LLM / 推理优化 / 算力 / 微调 | 小研 | oc_ec9adb3139cd38ac706cd7a54c4d059d |
| VPS / 隧道 / Xray / Docker / Linux 运维 | 老V | oc_cc9c8289c9520ff326578703ff17392c |
| 架构 / 跨 Agent / 飞书配置 / 通用开发 | 小H 自己 | DM / Home |

## 触发条件

**必须路由**，当满足以下全部时：
1. 大佬 DM 发来实质任务（不是闲聊）
2. 任务属于上表某一领域
3. 不是"你看看/你评估一下/你觉得"这种反馈型任务

**可以直接执行**，当满足任一时：
1. 任务跨多个领域（需要小H整合）
2. 用户明确说"你自己做"
3. 5 分钟以内能完成的简单查询类任务
4. 当前对话已是某 Agent 的延续（比如小策 群里接的任务）

## 执行流程

```
收到任务
↓
判断：是否命中领域 Agent？
├─ 否 → 主 Agent 自执行
└─ 是
    ↓
    默认路由（禁止跳过）
    ↓
    写入 pending/{task_id}.json
    飞书通知目标 Agent 群
    ↓
    目标 Agent 执行 → 写 callbacks/{task_id}.json
    ↓
    小H 扫描 callbacks → 回填结果给用户
    ↓
    完成
```

### Bypass：允许主 Agent 直接执行，不路由

满足以下任一条件，**主 Agent 可直接执行，不写 pending**：

| 条件 | 举例 |
|------|------|
| **用户明确要求主 Agent 自己做** | "你自己研究"/"不用分配"/"先别叫小策" |
| **联邦 Agent 不可用** | callback timeout / pending 队列阻塞 / Agent unavailable |
| **极小任务** | 单句解释 / 定义解释 / 非深度研究（5 分钟内完成） |

**禁止**：主动问用户"要不要走联邦"。路由是默认行为，不是可选项。

### cross_domain_federation：跨多领域拆分规则

当任务同时命中多个领域时，小H **不得全量自执行**，必须：

1. **拆分任务**：拆成各自领域的子任务
2. **分发**：分别写入各自 `pending/`，通知对应 Agent
3. **等待**：等待所有 callbacks
4. **汇总冲突点**：不同 Agent 结论矛盾时标注
5. **输出整合结论**：小H 只做整合，不得替子 Agent 做领域研究

示例场景：

```
UE5 + AI 研究
├─ 小策：玩法 / 蓝图 / UE5 技术实现
└─ 小研：AI 工具 / 模型 / 论文 / 竞品分析
小H：整合输出 + 冲突标注

VPS + API 部署
├─ 老V：部署 / 网络 / Docker / DNS
└─ 小研：API 文档 / 模型能力对比
小H：整合执行顺序 + 风险标注
```

每次路由决策时记录原因，用于审计：

```json
{
  "routing_reason": "matched_domain",
  "matched_agent": "小策",
  "domain": "UE5/游戏"
}
```

可能的值：

| 值 | 含义 |
|----|------|
| `matched_domain` | 命中单一领域，默认路由 |
| `explicit_user_bypass` | 用户明确要求主 Agent 执行 |
| `agent_unavailable` | 联邦 Agent 不可用（timeout / 队列阻塞 / unavailable）|
| `trivial_task` | 极小任务，无需路由 |
| `cross_domain_federation` | 跨多领域，小H 拆分 + 分发 + 整合，不得全量自执行 |

## 写入 pending 的格式

```json
{
  "task_id": "task_YYYYMMDD_HHMMSS",
  "source": "DM from 大佬",
  "source_chat_id": "oc_8391fa2b38acbd759ff75ab3616d5d1f",
  "owner_agent": "小策",
  "goal": "具体任务目标",
  "priority": "high / medium / low",
  "created_at": "YYYY-MM-DD HH:MM:SS",
  "status": "pending"
}
```

## 禁止事项

- ❌ 收到 UE5/游戏任务后自己用搜索完成
- ❌ 收到健康问题后自己查医学资料回答（应→小健）
- ❌ 收到 AI 论文任务后自己读摘要（应→小研）
- ❌ 收到 VPS 问题后自己敲命令（应→老V）
- ❌ 不写 pending 就直接在群里 @ 目标 Agent
