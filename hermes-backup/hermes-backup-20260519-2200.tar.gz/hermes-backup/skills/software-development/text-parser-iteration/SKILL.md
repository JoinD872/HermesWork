---
name: text-parser-iteration
description: 调试文本解析器（正则提取）的迭代方法 — 从原始文本中提取结构化字段时的常见坑与解法
category: software-development
tags: [debugging, regex, parser, text-processing]
risk: read-only
version: 1.0
---

# 文本解析器迭代方法

## 定位

当需要从用户输入的自然语言/半结构化文本中提取结构化字段时使用。特别适合：打卡系统、表单解析、混合格式输入处理。

## 核心原则

1. **先让基本路径跑通，再处理边界**
2. **每次只改一个变量，验证后再继续**
3. **测试用例要从简单到复杂覆盖各种格式**

---

## 常见坑点清单

### 坑1：时间格式干扰数字提取

**问题：** `"02:30"` 中的 `2` 和 `30` 会被误认为字段数字。

**现象：** 输入 `02:30 / 6 / 5 / 4` → 精力变成 2 而不是 6。

**解法：** 提取数字之前，先把时间格式替换成空格：
```python
text_clean = re.sub(r'\d{1,2}:\d{2}', ' ', text)
```

### 坑2：序号干扰字段值

**问题：** `"1. 精力：6"` 中的 `1` 会混入数字列表。

**解法：** 移除序号模式：
```python
text_clean = re.sub(r'\b\d+\.\s*', '', text_clean)
```

### 坑3：数字字段没有范围校验

**问题：** 健康评分 1-10，但 `02:30` 贡献了 30。

**解法：** 过滤出有效范围：
```python
valid_numbers = [int(n) for n in numbers if 1 <= int(n) <= 10]
```

### 坑4：多行格式的文本行优先级

**问题：** 如何从多行中正确找到"问题描述"字段？

**现象：** 纯分隔符格式 `"时间 / 数 / 数 / 数 / 问题文本"` 中问题文本是最后一个 `/` 分隔的部分。但多行格式中问题可能在中间行。

**解法：** 分格式处理，多行格式用逆序扫描：
```python
# 分隔符格式：取最后一个非纯数字部分
if '/' in text:
    parts = [p.strip() for p in text.split('/')]
    for part in reversed(parts):
        if part and not re.match(r'^[\d\s:]+$', part):
            data["top_issue"] = part
            break

# 多行格式：从最后一行往前扫，跳过纯数字/时间行
lines = text.split('\n')
for line in reversed(lines):
    if re.match(r'^[\d\s:/\.]+$', line):  # 跳过纯数字/时间行
        continue
    if re.search(r'关键词[：:]\s*(.+)', line):  # 优先匹配"问题：xxx"
        data["top_issue"] = match.group(1)
        break
    if len(line) > 3:  # 取第一个非数字文本行
        data["top_issue"] = line
        break
```

### 坑5：自动补全时睡眠质量推断不对

**问题：** 快速打卡只有睡觉时间，需要推断入睡困难和睡眠质量。

**解法：** 按上床时间区间推断：
```python
def infer_sleep(latency_minutes: int) -> int:
    """入睡困难分钟数 → 睡眠质量评分"""
    if latency_minutes > 90:
        return 3
    elif latency_minutes > 60:
        return 5
    elif latency_minutes > 30:
        return 7
    else:
        return 8
```

---

## 迭代顺序（推荐）

每轮只改一个变量，验证后再继续：

```
1. 时间格式去干扰  → print(numbers) 确认只有字段数字
2. 序号清理        → 同上验证
3. 范围过滤        → print(valid_numbers) 确认都是1-10
4. 文本提取        → print(top_issue) 确认文字正确
5. 补全逻辑        → 写完整数据文件验证
```

## 测试用例模板

```python
TEST_CASES = [
    # 格式1: 纯分隔符
    ("02:30 / 6 / 5 / 4 / 躺下很久睡不着", 
     {"bed_time": "02:30", "energy": 6, "brain_fog": 5, "stomach_discomfort": 4, "top_issue": "躺下很久睡不着"}),
    
    # 格式2: 带序号多行
    ("1. 睡觉时间：02:30\n2. 精力：6\n3. 脑雾：5\n4. 胃状态：4\n5. 今日问题：白天头晕",
     {"bed_time": "02:30", "energy": 6, "brain_fog": 5, "stomach_discomfort": 4, "top_issue": "白天头晕"}),
    
    # 边界: 只有时间和数字，无文本
    ("01:00 / 3 / 8 / 2",
     {"bed_time": "01:00", "energy": 3, "brain_fog": 8, "stomach_discomfort": 2}),
]

def run_tests():
    for input_text, expected in TEST_CASES:
        result = parse_quick(input_text)
        for key in expected:
            assert result.get(key) == expected[key], \
                f"Key {key}: expected {expected[key]}, got {result.get(key)}"
        print(f"✅ PASS: {input_text[:30]}...")
```

## 关键正则速查

| 场景 | 正则 |
|------|------|
| 提取 HH:MM 时间 | `r'\d{1,2}:\d{2}'` |
| 移除 "1." 序号 | `r'\b\d+\.\s*'` |
| 纯数字行判断 | `r'^[\d\s:/\.]+$'` |
| "关键词：xxx" | `r'关键词[：:]\s*(.+)'` |
| 1-10 数字 | `r'\b(\d+)\b'` 之后再过滤 |

## 验证命令

```bash
# 快速验证（直接打印解析结果）
python3 /root/.hermes/scripts/xiaojian-parse-checkin.py "02:30 / 6 / 5 / 4 / 测试问题"

# 语法检查
python3 -m py_compile script.py && echo "语法OK"

# 查看完整解析后的数据文件
cat ~/.hermes/profiles/health-advisor/data/daily_YYYY-MM-DD.json
```
