---
name: vps-ssh-noninteractive-auth
description: VPS SSH 非交互式登录问题修复 — 当自动化终端无法使用密码认证时的解决方案
category: devops
risk: read-only
---

# VPS SSH 非交互式认证问题

## 触发条件

自动化终端（cron/脚本/Agent）SSH 连接 VPS 时反复 `Permission denied (publickey,password)`，调试输出包含：
```
read_passphrase: can't open /dev/tty: No such device or address
```

## 根因

SSH 密码认证需要交互式 TTY（`/dev/tty`），非交互式环境（cron、后台脚本、headless terminal）无法弹出密码输入窗口，导致认证必然失败。

## 诊断命令

```bash
# 本地测试，观察 debug 输出
ssh -v -o ConnectTimeout=5 -p 2222 -o PreferredAuthentications=password -o PubkeyAuthentication=no root@<ip> "echo TEST" 2>&1 | grep -E "read_passphrase|Permission denied"
```

## 解决方案：VNC + 公钥认证

### Step 1：通过 VNC/Serial Console 登录 VPS
RackNerd 控制面板 → 产品页 → Serial Console / Root Shell - Advanced

### Step 2：生成 SSH 密钥对（如尚无）
```bash
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N "" -C "hermes-vps"
cat ~/.ssh/id_ed25519.pub
```

### Step 3：写入 authorized_keys
```bash
mkdir -p ~/.ssh && chmod 700 ~/.ssh
echo "<本步骤输出的公钥内容>" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
systemctl restart ssh
```

### Step 4：自动化端用私钥登录
```bash
ssh -i ~/.ssh/id_ed25519 -p 2222 root@<ip> "echo OK"
```

## 坑点记录

| 日期 | 坑点 | 解法 |
|------|------|------|
| 2026-05-03 | 公钥 echo 命令拼错（cho → echo） | 仔细核对拼写 |
| 2026-05-03 | sshpass 在非交互环境同样失效 | 不尝试 sshpass，直接走公钥 |

## 相关场景

- `sshpass` 也需要 TTY，非交互环境同样失败
- 任何自动化 SSH 管理都必须用公钥认证
- VNC/Serial Console 是唯一的"人工介入"通道
