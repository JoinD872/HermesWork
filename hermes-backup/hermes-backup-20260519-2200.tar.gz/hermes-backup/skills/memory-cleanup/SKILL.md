---
---
name: memory-cleanup
description: Memory 文件清理流程 — 在修改 global_knowledge.md / MEMORY.md 前，必须先备份、扫描、输出分类预案、获取确认，再执行。防止误删已验证结论。
tags: [hermes, memory, process, governance]
category: hermes
risk: write-dangerous
---

# Memory 清理流程

## 触发条件
- 用户要求"清理 Memory"或"审核 Memory"时
- 发现 Memory 内容过时/重复/错误时

## 核心原则
1. **不直接删除**：任何修改前必须先输出分类预案，等用户确认
2. **先备份**：所有修改操作前必须先 `cp` 备份
3. **不删已验证根因**：即使旧了，只要根因正确就不删，只标记为"已被新结论取代"
4. **重复项只留一份**：MEMORY 和 global_knowledge 的重复内容，合并到一处

## 分类标准

| 动作 | 判断标准 |
|------|---------|
| **保留** | 长期稳定、影响未来行为、不依赖特定项目 |
| **合并** | 多处重复，选择一处保留，其他删除 |
| **删除** | 临时猜测、一次性报错、过期路径、未验证结论、已失效方案 |
| **降级为项目文档** | 项目特定配置、一次性排障过程、历史调研笔记 |

## 流程步骤

### Step 1：备份
```bash
mkdir -p ~/.hermes/project_notes
cp ~/.hermes/global_knowledge.md \
   ~/.hermes/project_notes/global_knowledge-backup-$(date +%Y-%m-%d).md
cp ~/.hermes/memories/MEMORY.md \
   ~/.hermes/project_notes/MEMORY-backup-$(date +%Y-%m-%d).md
```

### Step 2：扫描全文
逐条读取，标记：
- 是否长期稳定（>3个月不过期）
- 是否影响行为决策
- 是否与其他条目重复
- 是否依赖特定项目/环境

### Step 3：输出分类预案
给用户的格式：
```
| 位置 | 原内容摘要 | 建议动作 | 理由 | 新版本/处理方式 |
```

分类必须逐条说明理由，不可只写"重复"。

### Step 4：等用户确认
- 明确确认范围（如"仅 global_knowledge，MEMORY 不动"）
- 用户可能要求调整分类，调整后再执行
- **不执行未经确认的删除**

### Step 5：执行清理
- 降级项先写 `project_notes/*.md`，不要直接丢失
- 删除项物理删除，不留残留注释
- 合并项确认目标文件已有再删源

### Step 6：输出清理报告
必须包含：
1. 备份确认（含校验）
2. 实际删除了哪些（位置+原因）
3. 实际降级到哪些 project_notes 文件
4. 是否有失败项
5. 如何回滚（复制备份命令）

## 降级文件命名规范
```
~/.hermes/project_notes/{主题}-{日期}.md
```

## 回滚命令
```bash
# global_knowledge 回滚
cp ~/.hermes/project_notes/global_knowledge-backup-{日期}.md \
   ~/.hermes/global_knowledge.md
```

## 已知坑点
- 表格在飞书渲染慢/截断 → 输出预案时避免大表格，拆成列表
- 用户可能不回复确认 → 必须等用户明确说"可以执行"才开始
- GPT 可能给出过激清理建议 → 保留/删除判断以用户确认为准，不以 GPT 为准
