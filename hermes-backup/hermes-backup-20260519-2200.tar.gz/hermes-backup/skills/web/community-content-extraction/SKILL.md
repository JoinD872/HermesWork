---
name: community-content-extraction
description: 从国内外在线社区/内容平台提取内容的能力矩阵和方法 — 知乎/B站/小红书/掘金/V2EX/Reddit/GitHub/Discord/X
risk: read-only
version: 1.0
created: 2026-05-18
---

# 社区内容提取 — 能力矩阵

从 Hermes VPS（洛杉矶 RackNerd）环境出发，各社区的可抓取性差异很大。本 skill 记录每种平台的最佳获取方式和已知限制。

## 总览表

| 平台 | 公开内容可抓? | 最佳方式 | 限制 |
|------|-------------|---------|------|
| **V2EX** | ✅ 完美 | curl 直接取（SSR） | 无 |
| **B站** | ✅ 完美 | 公开 REST API | 部分 API 需要 cookie |
| **Reddit** | ✅ 完美 | JSON API（`.json` 后缀） | 无需认证即可取热帖 |
| **GitHub** | ✅ 完美 | REST API + curl | 匿名 API 有 60 req/h 限制（需 token）|
| **知乎** | ⚠️ 可间接取 | SearXNG 搜索 `site:zhihu.com` | 直接 curl 403，无法取正文全文 |
| **X/Twitter** | ⚠️ 有限 | 需登录/API | 未登录只能拿主页骨架 |
| **小红书** | ❌ 不可取 | — | SPA + 反爬，VPS 浏览器不可达 |
| **掘金** | ❌ 不可取 | — | SPA + 反爬，VPS 浏览器不可达 |
| **Discord** | ❌ 不可取 | — | 需登录认证，没有公开 API |

## 各平台提取方法

### ✅ V2EX

**URL:** `https://www.v2ex.com/`
**方式:** 直接 curl，服务器端渲染，内容完整写入 HTML

```bash
curl -s --connect-timeout 10 --max-time 15 \
  -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -L "https://www.v2ex.com/" | \
  python3 -c "
import sys, re
html = sys.stdin.read()
topics = re.findall(r'<a[^>]*href=\"/t/\d+[^>]*>([^<]+)</a>', html)
for t in topics:
    print(t.strip())
"
```

**特点:** SSR，无需 API key，无需 Cookie，零门槛。标题全部在 HTML 内。

---

### ✅ B站

**方式 1: 公开 API（推荐）**
```bash
curl -s "https://api.bilibili.com/x/web-interface/popular?ps=10" \
  -H "Referer: https://www.bilibili.com/" | \
  python3 -c "
import sys, json
data = json.loads(sys.stdin.read())
for v in data['data']['list']:
    s = v['stat']
    print(f\"[{v['aid']}] {v['title']} - ★{s['like']} 播放{s['view']}\")
"
```

**方式 2: 搜索 API**
```bash
curl -s "https://api.bilibili.com/x/web-interface/search/all/v2?keyword=游戏策划" \
  -H "Referer: https://search.bilibili.com/" \
  -H "Cookie: b_lsid=YOUR_COOKIE"  # 部分 API 需 cookie
```

**特点:** 公开 API 的门槛很低。`/x/web-interface/popular` 甚至无需 cookie。
热门视频列表含 aid、标题、点赞/播放/评论数。

---

### ✅ Reddit

**方式: JSON API（加 `.json` 后缀）**
```bash
curl -s -A "Mozilla/5.0" \
  "https://www.reddit.com/r/gamedev/hot.json?limit=10" | \
  python3 -c "
import sys, json
data = json.loads(sys.stdin.read())
for p in data['data']['children']:
    d = p['data']
    print(f\"[{d['score']}↑] {d['title']}\")
    print(f\"  → {d.get('url','')}\")
"
```

**特点:** Reddit 的所有页面都支持 `.json` 后缀（`/r/subreddit/.json`、`/comments/.json`）。
无需 OAuth 即可获取热帖标题、分数、链接、评论数。
返回结构化 JSON，无需 HTML 解析。

---

### ✅ GitHub

**方式 1: REST API**
```bash
curl -s -H "Accept: application/vnd.github+json" \
  "https://api.github.com/search/repositories?q=created:>2026-05-01&sort=stars&order=desc&per_page=5"
```
**注意:** 匿名 API 限流 60 req/h。用 token（`-H "Authorization: Bearer ghp_xxx"`）可升到 5000 req/h。

**方式 2: Trending 页面**
```bash
curl -s -A "Mozilla/5.0" "https://github.com/trending" | \
  python3 -c "
import sys, re
html = sys.stdin.read()
repos = re.findall(r'href=\"/([^\"]+)\"[^>]*class=\"[^\"]*h3[^\"]*\"', html)
"
```
HTML 解析稍复杂，推荐优先用 REST API。

---

### ⚠️ 知乎（间接取）

**直接方式:** ❌ curl 返回 403（JS 反爬检测），browser 超时

**间接方式（推荐）:** ✅ SearXNG 搜索
```bash
# 在本地 SearXNG 实例搜索知乎内容
curl -s "http://localhost:8888/search?q=site:zhihu.com+游戏策划+UE5&format=json" | \
  python3 -c "
import sys, json
data = json.loads(sys.stdin.read())
for r in data.get('results', [])[:5]:
    print(f\"{r['title']}\\n  {r['url']}\\n  {r.get('content','')[:150]}\\n\")
"
```

**局限:** 只能拿到 Google 索引的内容摘要，拿不到全文。适合发现有趣的帖子/专栏，不适合深度爬取。

---

### ⚠️ X/Twitter（需登录）

**未登录状态:** 页面重定向到登录页（`/i/flow/login`），只能拿标题骨架。

**推荐:** 使用 SearXNG 搜索 `site:twitter.com` 或 `site:x.com` 作为替代（同样只能拿摘要）。

**已登录方案（Web 内部 API 方式）:**

X 网页版使用三个关键凭证：
1. **Bearer Token** — 固定的公共值: `AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA`（X 网页版内置，非用户专属）
2. **`auth_token` Cookie** — 用户登录后生成，需从浏览器 Cookie 中提取
3. **`ct0` Cookie** — CSRF token，用户登录后生成

使用方式：
```bash
# 获取用户时间线 / trending
curl -s "https://x.com/i/api/2/guide.json?count=10" \
  -H "Authorization: Bearer AAAA...ANRILg..." \
  -H "X-CSRF-Token: {ct0值}" \
  -H "Cookie: auth_token={auth_token}; ct0={ct0}" \
  -H "X-Twitter-Client-Language: zh-CN" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -H "Origin: https://x.com" \
  -H "Referer: https://x.com/"
```

X 内部 API 端点：
| 用途 | 端点 |
|------|------|
| Trending | `x.com/i/api/2/guide.json?count=10` |
| 用户时间线 | `x.com/i/api/graphql/{hash}/UserTimeline?variables=...` |
| 帖子详情 | `x.com/i/api/graphql/{hash}/TweetDetail?variables=...` |

**⚠️ 注意事项：**
- 官方 API v2（`api.twitter.com`）需要注册开发者账号，公共 Bearer Token 在此处被拒绝
- 内部 API（`x.com/i/api/`）需要 Bearer + Cookie 组合
- Cookie 中的 `auth_token` 和 `ct0` 会定期刷新，长期抓取需更新 Cookie
- 单个 Bearer Token（不带 Cookie 和 CSRF）对内部 API 返回空响应

---

### ❌ 当前不可取

**小红书:** SPA（React），curl 仅返回 JS 壳（~572KB），VPS 浏览器到国内超时。

**三层降级通道均已验证失败：**
1. VPS agent-browser → 超时/EPIPE崩溃（高丢包时）
2. Windows 桌面 Edge headless（上海 IP） → 返回「安全限制 300012」— headless fingerprint 检测，与 IP 无关
3. Edge `--user-data-dir` 复用 360ChromeX 用户登录态 → 同样返回「安全限制」— headless 自身特征暴露

**最后手段（仅有的可行方案）：** 用户在本机已登录浏览器打开页面，按 F12 → Console → 输入 `allow pasting`（Chrome 安全策略）→ 粘贴 `copy(document.body.innerText)` → 把结果发给 Agent。见 `vps-domestic-site-access` 的 `references/user-assisted-manual-extraction.md`。

**掘金:** 同上，重度 SPA + 国内反爬。VPS 浏览器返回空页面。

**Discord:** 需登录 + 无公开 API。即使通过 browser 也需要 Discord 账号登录。

---

## 常见场景组合

### 监控热点/趋势
```
V2EX (今日热帖) + B站 (热门视频) + Reddit (subreddit hot) + GitHub Trending
```
四条命令并行跑，几分钟就能拿到四大平台的头部内容。

### 技术社区搜索
```
SearXNG + site:zhihu.com + site:juejin.cn + site:v2ex.com + site:reddit.com
```
一个 searxng_search 搞定多个站点的内容发现，然后针对 V2EX/Reddit 直接提取全文。

---

## 注意事项

- **VPS 浏览器对国内站超时**是已知限制，不要反复重试浪费时间
- 需要国内 SPA 站的内容时，考虑 SSH 到上海 Windows 桌面（黑翼）抓取
- 小红书/掘金/Discord 是当前三大"盲区"，如有需要建议推进住宅代理方案
- SearXNG 的搜索结果依赖 Google 索引时效性，最新内容可能搜不到
