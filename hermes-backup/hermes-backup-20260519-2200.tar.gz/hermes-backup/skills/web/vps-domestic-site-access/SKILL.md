---
name: vps-domestic-site-access
description: VPS 访问国内网站诊断与解决方案 — 百度/知乎/bilibili/小红书/微博等
tags: [network, proxy, vps, china, domestic]
version: 2026-05-18-v2
risk: read-only
---

# VPS 访问国内网站 — 诊断与解决方案

## 已知问题
RackNerd 洛杉矶 HostPapa IP 被部分国内网站屏蔽，curl 有时能通（DNS 轮询到可用 IP），browser tool 始终超时。

## 当前可用能力

完整测试报告见 `references/community-scraping-test-20260518.md`。

| 站点 | 状态 | 方式 | 备注 |
|------|------|------|------|
| **B站** | ✅ 完美 | curl 直取首页（42KB）+ **公开API可取热门/视频详情** | API: `api.bilibili.com/x/web-interface/popular` 无需cookie |
| **V2EX** | ✅ 完美 | curl 直接拿服务器渲染HTML | 可提取50条帖子标题，完全无限制 |
| **知乎** | ⚠️ 间接可拿 | curl 403 → SearXNG 搜索 `site:zhihu.com` | 通过SearXNG的Google索引可拿专栏/问题内容的摘要，但全文不可直接提取 |
| **小红书** | ⚠️ 不稳定（三层降级通道） | VPS browser → 桌面 Edge headless → 桌面已登录浏览器 | **见下方详细说明**，含完整的降级策略 |
| **掘金** | ❌ 不可抓 | curl JS壳 + browser 超时 | 重度 SPA，前端Vue渲染，从VPS无法获取实际内容 |
| **17173新闻** | ✅ 可用 | curl 直接拿服务器渲染HTML | 游戏新闻门户（news.17173.com），curl 可直接提取完整文章内容，是游戏研究的主力可靠来源 |
| **新浪财经/科技** | ✅ 可用 | curl 直接拿服务器渲染HTML | 新浪财经/科技频道（finance.sina.com.cn），curl 可提取完整文章内容，适合游戏行业新闻 |
| **网易UU加速器博客** | ✅ 可用 | curl 直接拿服务器渲染HTML | uu.163.com/blog，游戏加速器官方博客，常发游戏评测/测试公告，curl 可正常提取 |
| **什么值得买** | ⚠️ 部分block | curl 返回空 + browser 超时 | post.m.smzdm.com — 虽然搜索引擎有摘要，但实际全文 curl 不可提取 |
| **搜狐** | ⚠️ 部分block | curl 返回空内容 | m.sohu.com / www.sohu.com — 多数curl请求返回空HTML壳，但部分深度链接可用（需尝试） |
| **腾讯新闻** | ⚠️ 部分block | curl 返回空内容 | news.qq.com — 与搜狐类似，curl 无法直接提取 |
| **百度** | ✅ | curl 200 | 无限制 |
| **Discord** | ❌ | SSH 页面认证 | 需登录，无可公开 API |

### 总体策略

```
VPS agent-browser → 不行 → SSH 连 Windows 桌面 Edge headless → 不行 → 需要桌面端非 headless 已登录浏览器
```

由于小红书 JS 极重（~572KB），并且对 headless 浏览器有检测，需要按优先级逐级尝试。

### 第一层：VPS agent-browser（主路由）

> ⚠️ **依赖当天网络质量**：小红书 JS 极重（~572KB），当 VPS→中国方向丢包 > 5% 时，浏览器会因 JS 文件加载不全而崩溃（EPIPE 或白屏）。网络正常时通过重试 1-2 次可成功加载。

### 访问特征
| 特征 | 表现 |
|------|------|
| 探索页 | ✅ `browser_navigate` 可能首次超时，但页面实际已加载。等几秒后用 `browser_snapshot` 或 `browser_console` 可获取完整内容 |
| 帖子详情页 | ✅ 点击列表中的帖子链接进入详情页，可抓取完整全文、标签、作者信息 |
| 图片 | ✅ 页面内图片可正常展示（截图发送给用户） |
| 评论区 | ⚠️ 未登录状态下可能无法完整加载评论 |
| 反爬机制 | 小红书使用 `as.xiaohongshu.com` 安全脚本做 JS 反爬检测，headless 浏览器可能被延迟加载 |

### 场景速查
| 场景 | 行为 |
|------|------|
| 网络正常（丢包 < 1%） | browser_navigate 可加载探索页，获取20+条帖子列表，点击进入详情页抓取全文 |
| 网络差（丢包 > 5%） | 浏览器超时/EPIPE崩溃。高丢包下JS文件加载不全导致白屏 |
| curl | 永远只能拿572KB JS壳，无法提取实际内容 |

### 标准工作流
```yaml
1. browser_navigate("https://www.xiaohongshu.com/explore")
   → 可能超时1-2次，再试一次往往就能成功
2. wait 5-10s（JS渲染慢）
3. browser_snapshot()  → 获取帖子列表
4. browser_click(具体帖子) → 进入详情页
5. browser_snapshot(full=true) → 获取全文、标签、作者
```

### 注意事项
- 首次 `browser_navigate` 超时是正常的，页面实际已在加载
- 页面 JS 非常重，需要耐心等待渲染完成
- 未登录状态下功能有限（无点赞/评论/关注），但公开内容可正常读取
- 内容列表中的帖子卡片是可点击的，可直接导航到详情页
- 连续3次超时说明当天网络质量不行，不要继续重试
- **无法做到的**：点赞数/评论数/评论内容（需登录）、私密帖子、私信
- 截图可用，但 vision 分析依赖模型是否支持 image_url 格式

### 第二层：Windows 桌面 Edge headless（Tailscale SSH）

当 VPS 浏览器连续超时时，通过 SSH 跳板到上海桌面（`100.86.150.37`）的浏览器。

详细命令用法见 `references/windows-desktop-scraping-via-ssh.md`。

#### 已知限制

**小红书对 headless 浏览器有主动检测**，即使从中国 IP（上海桌面）发起连接，headless Edge/Chrome 也会被拦截：

```
返回页面标题: "安全限制"
提示信息: "IP存在风险，请切换可靠网络环境后重试"
错误码: 300012
```

所以这层经常失败——headless 浏览器的 WebGL fingerprint 暴露了是自动化工具。不适用于反爬严格的 SPA 站。

对于反爬较弱的站（如普通新闻站），Edge --dump-dom 是一个有效方案。

### 第三层：Windows 桌面已登录的本机浏览器

需要复用用户已有的小红书登录态，通过远程控制桌面上已打开、已登录的 Chrome/Edge 窗口。

#### 尝试：--user-data-dir 复用登录态（失败）

```bash
# 尝试用 Edge 加载 360ChromeX 用户目录（含登录态 Cookie）
msedge.exe --headless --dump-dom --user-data-dir="C:\Users\JoinD\AppData\Local\360ChromeX\Chrome\User Data\Default" --no-sandbox --disable-blink-features=AutomationControlled https://www.xiaohongshu.com/explore
```

**结果**：仍然返回「安全限制 300012」。headless 自身的 WebGL/Canvas fingerprint 特征太明显，即使用户数据目录加载了登录 Cookie，小红书的反爬仍会在 JS 层拦截。

#### 可行方案：用户协助手动提取

当所有自动化方案都失败时（VPS browser → 桌面 headless → 桌面 --user-data-dir），最后一层是让用户手动操作：

**步骤**（见 `references/user-assisted-manual-extraction.md`）：
1. 用户在已打开的登录浏览器中导航到目标页面
2. F12 → Console → 粘贴 `copy(document.body.innerText)`
3. 粘贴结果发给 Agent

| 层级 | 条件 | 成功率 | 适用场景 |
|------|------|--------|----------|
| VPS agent-browser | 国际链路质量好（丢包 < 1%） | ⭐⭐⭐ 高 | 绝大多数情况 |
| 桌面 Edge headless | Tailscale 可达 + 目标站无反爬检测 | ⭐⭐ 中 | 反爬较弱的站 |
| 桌面已登录浏览器 | 需实现 Session 复用 | ⭐⭐⭐⭐⭐ 理论 | 所有站，包括需登录内容 |

## 关键结论（经验证，排除法）
- 不是 MTU 问题（MTU 1400 试过无效）
- curl 和 browser tool 走不同网络路径，有时 curl 通 browser 不通
- Windows 代理 WSL2 无法 reach（Connection timed out）

## 诊断二分法：网络层 vs JS 层

| 类型 | curl 结果 | browser tool 结果 | 原因 | 解法 |
|------|-----------|-------------------|------|------|
| **网络层封禁** | 超时 000 | 超时 | TCP 连接被墙 | 必须住宅代理 |
| **JS 层检测** | ✅ 200/302 | ❌ 空白/拦截 | WebGL/Canvas fingerprint + IP 黑名单 | 住宅代理，修改 fingerprint 治标不治本 |

### 验证步骤
```bash
# 1. curl 测试
curl -s -m 5 -o /dev/null -w "%{http_code}" https://目标网站

# 2. 结果判断
# 000 或 timeout → 网络层封禁
# 200/302 → JS 层检测，继续 browser tool 测试
```

### JS 层检测原理
- WebGL renderer 显示 "llvmpipe" / "Software" — 数据中心特征
- Canvas/WebRTC fingerprint 不匹配真实浏览器
- 后端 API 校验出口 IP 在数据中心黑名单
- 无鼠标轨迹、headless 特征明显

## 方案一：住宅代理服务（JS 层 / 网络层封禁均有效）

| 提供商 | 价格 | 起购量 | IP 池 | 特点 |
|--------|------|--------|-------|------|
| **Scrapeless** | **$0.40/GB** | 无 | 9000万 | 最便宜，支持 SOCKS5 |
| **DataImpulse** | $1/GB | 5GB | 500万 | 低于 $1 被点名不推荐 |
| **LunaProxy** | $1.65/GB | 100GB+ | 2亿 | 无限并发 |
| **OmegaProxy** | ~$0.8-2/GB | 未公布 | 6200万 | 无共享子网，稳定性好 |
| **国内静态住宅** | ¥9.9/IP/月 | 1个IP | 静态 | 适合长期固定 IP |

> 注：$0.40/GB 的 Scrapeless 适合偶发需求；免费代理不可靠，不建议使用。

### 集成方式
config.yaml browser section 添加：
```yaml
browser:
  proxy: "http://IP:PORT"
```

## 方案二：手机做代理（长期稳定，成本低）

适合"长久方案"——用手机 4G/5G IP 作为出口，无法被识别为数据中心 IP。

### 方案 A：Localtonet 反向 SSH 隧道（更简单）

**原理：** 手机装 Localtonet App → 建立反向 SSH 隧道 → 手机流量暴露为公网 SOCKS5 代理

- **价格：** $2/隧道/月（仅运行时计费），免费版有流量限制
- **支持：** HTTP + SOCKS5，不需要 root
- **官网：** https://localtonet.com
- **下载：** Google Play 搜 "Localtonet"
- **步骤：**
  1. 手机装 App + 网站注册
  2. 创建 Proxy Server，获得 `hostname:port`
  3. VPS browser 配置该代理地址
- **限制：** 手机需联网且 App 保持运行；手机关机 = 代理失效

### 方案 B：NekoBox + 链式代理（更稳定，主流跨境方案）

**原理：** 手机装 NekoBox → 通过机场节点转发 → 最终出口 IP 是手机卡 4G/5G IP

```
VPS → 手机 NekoBox → 机场节点 → 手机住宅IP出口 → 目标网站
```

**适合场景：** 需要长期稳定的住宅 IP（如账号养号、广告验证、内容采集）

**步骤（手机端）：**
1. 手机装 [NekoBox](https://nekobox.pro/)（安卓代理客户端，开源免费）
2. 导入一个机场订阅（¥10-30/月，作为转发跳板）
3. 添加一个 SOCKS5 住宅代理（购买的服务商）
4. 配置前置代理：住宅代理走机场节点转发（链式代理）
5. 开启连接，手机成为代理出口

**成本：**
| 项目 | 费用 |
|------|------|
| NekoBox | 免费 |
| 机场订阅 | ¥10-30/月 |
| 住宅代理 | ¥9.9/IP/月 起 |
| **合计** | **约 ¥20-40/月** |

**VPS 侧配置：** 浏览器代理地址填手机 NekoBox 暴露的 SOCKS5 端口

### 方案对比

| 方案 | 成本 | 稳定性 | 难度 | 适合场景 |
|------|------|--------|------|----------|
| 商业住宅代理 | $0.40-2/GB | 高 | 低 | 偶发采集 |
| Localtonet 手机隧道 | $2/月 | 中 | 低 | 临时测试 |
| NekoBox + 机场 + 住宅代理 | ¥20-40/月 | 高 | 中 | 长期运营 |

## 知乎间接访问（通过 SearXNG）

知乎对 VPS 出口 IP 返回 403（反爬 JS 检测），无法直接 curl 或 browser 访问。但可通过 SearXNG 搜索 `site:zhihu.com` 间接获取知乎内容。

### 搜索语法
```bash
# 搜索知乎
curl -s "http://localhost:8888/search?q=site:zhihu.com+关键词&format=json&pageno=1"

# 搜索知乎专栏
curl -s "http://localhost:8888/search?q=site:zhuanlan.zhihu.com+关键词&format=json"

# 示例：搜索游戏策划相关
curl -s "http://localhost:8888/search?q=site:zhihu.com+游戏策划+UE5&format=json&pageno=1"
```

### 工作原理
SearXNG 通过 Google/Bing 等搜索引擎的索引拿到知乎页面的摘要内容，绕过知乎的直接反爬。但：
- 只能拿到 **搜索摘要**（title + snippet），不是知乎专栏全文
- 时效性取决于搜索引擎索引更新频率
- 特定技术关键词能召回约20条结果，直接相关的5-6条

### 适用场景
- 了解某个话题在知乎上的讨论概况
- 获取知乎专栏的 title + snippet 做快速调研
- 不适合需要全文精读的场景

## 验证命令

```bash
# 检查出口 IP
curl -s ifconfig.me

# 测试国内网站
curl -s --max-time 8 -o /dev/null -w "%{http_code}\n" https://www.baidu.com

# 测试 B站 API
curl -s --max-time 8 "https://api.bilibili.com/x/web-interface/popular?ps=3" | python3 -c "import sys,json; d=json.load(sys.stdin); [print(f\"{v['title']} ★{v['stat']['like']}\") for v in d.get('data',{}).get('list',[])]"

# 测试 V2EX
curl -s --max-time 8 "https://www.v2ex.com/" | python3 -c "import sys,re; topics=re.findall(r'<a[^>]*href=\\\"/t/\\d+[^>]*>([^<]+)</a>', sys.stdin.read()); [print(t.strip()) for t in topics[:5]]"

# SearXNG 搜索知乎
curl -s "http://localhost:8888/search?q=site:zhuanlan.zhihu.com+游戏策划&format=json&pageno=1" | python3 -c "import sys,json; [print(f\\\"{r['title']}\\n  {r['url']}\\n  {r['content'][:80]}\\n\\\") for r in json.load(sys.stdin).get('results',[])[:3]]"

## X/Twitter 内部 API（auth_token + ct0 Cookie）

通过用户浏览器 Cookie + 公共 Bearer Token 调用 X 网页版内部 API。

| 凭证 | 来源 | 说明 |
|------|------|------|
| Bearer Token | X 网页内嵌，公共值 | `AAAA...ANRILg...`（固定，非用户专属）|
| auth_token | 用户 Cookie | 从 `document.cookie` 提取 |
| ct0 | 用户 Cookie | CSRF token |

### ✅ 已验证可用的端点

```bash
# 首页 Timeline（已验证）
curl -s "https://x.com/i/api/2/timeline/home.json?count=10" \
  -H "Authorization: Bearer AAAA...ANRILg..." \
  -H "X-CSRF-Token: {ct0值}" \
  -H "X-Twitter-Auth-Type: OAuth2Session" \
  -H "Cookie: auth_token={auth_token}; ct0={ct0}" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -H "Origin: https://x.com" \
  -H "Referer: https://x.com/"
```

**返回字段**：`globalObjects.tweets`（推文含 text/full_text, retweet_count, favorite_count, user_id_str, created_at），`globalObjects.users`（含 screen_name）

### ❌ 不工作的端点
| 端点 | 原因 |
|------|------|
| `api.twitter.com/2/tweets` | 官方 API v2，需注册开发者账号，公共 Bearer 被拒 |
| `x.com/i/api/graphql/*` | Query ID 频繁轮换 |
| `x.com/i/api/1.1/search/tweets.json` | 返回 code 34 |
| `x.com/i/api/2/guide.json` | 返回空响应 |

详见 `references/x-twitter-internal-api.md`。

**重要：** 官方 API v2（`api.twitter.com`）需要注册开发者账号，公共 Bearer 被拒绝。**必须用 `x.com/i/api/` 内部端点**。Bearer Token 单独使用（无 Cookie 和 CSRF）返回空响应，`X-Twitter-Auth-Type: OAuth2Session` 头不可少。

从浏览器提取 Cookie 的步骤（用 Application 面板最省事）：
```text
F12 → Application → Cookies → x.com
    → 找 auth_token 行，复制 Value
    → 找 ct0 行，复制 Value
```

## PowerShell SSH 中文编码问题

通过 SSH 向 Windows 桌面执行 PowerShell 时，中文在传输中会被截断。使用 `-EncodedCommand` 配合 Python base64 编码解决：

```python
# Python 端编码脚本
python3 -c "
import base64
ps_code = '''Write-Output '测试成功'
\$r = Invoke-WebRequest -Uri 'https://目标网址' -UseBasicParsing
Write-Output \$r.StatusCode
'''
bytes_data = ps_code.encode('utf-16-le')
print(base64.b64encode(bytes_data).decode())
"
```

```bash
# SSH 端执行
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 \
  powershell -EncodedCommand "<base64编码结果>"
```

### 更稳定的方案：scp 传脚本
```bash
scp -i /root/.ssh/id_ed25519 /tmp/script.ps1 joind@100.86.150.37:E:\\Hermes\\script.ps1
ssh -i /root/.ssh/id_ed25519 joind@100.86.150.37 \
  powershell -ExecutionPolicy Bypass -File "E:\Hermes\script.ps1"
```

## 用户交互偏好

当爬取自动化反复受挫（headless 被拦、多层降级策略都无效），用户倾向直接放弃自动化，切到**用户协助手动提取**（`references/user-assisted-manual-extraction.md`）。不要劝说再试其他方案。直接说：
```
帮个小忙：F12 → Console → 输入 allow pasting → 粘贴 copy(document.body.innerText) → 发我
```
```
