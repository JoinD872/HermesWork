# Global Knowledge — 跨任务经验沉淀

> 主 Agent 上下文是宝贵资源，每一次塞入的记忆都必须是经过提纯的高价值情报。
> 本文件记录"踩过的坑"和"已验证的解决方案"，按主题分类，供每次任务开始前快速扫一眼。

---

## 飞书消息发送

### send_message 必须加 `feishu:` 前缀
- **错误**：`send_message(..., target="oc_xxx")` → `Unknown platform: oc_xxx`
- **正确**：`send_message(..., target="feishu:oc_xxx")`
- 飞书 chat_id 全部以 `oc_` 开头，发送前必须手动加 `feishu:` 前缀

### Cron 自动投递与 send_message 重复
- cron job 的 final response 会自动投递到 `deliver` 目标
- 不要对同一目标既用 send_message 又依赖 auto-delivery，会重复
- DM 目标（`oc_8391fa2b38acbd759ff75ab3616d5d1f`）通常走 auto-delivery，不需要额外 send_message

---

## 图片理解

### 统一走 MMX CLI，不走 MCP
- `vision_analyze` 已禁用
- **正确方式**：`mmx vision describe <图片路径>`
- MiniMax MCP `understand_image` 有平台级 404 bug，不要用

---

## 搜索

### 搜索入口优先级（已验证最优）
1. **SearXNG** (`localhost:8888`) — 集大成，搜索质量最高
2. **mcp_searxng_search** — MCP 工具方式
3. **mcp_minimax_plan_web_search** — 备用
4. **Browser 搜索** — 以上全部失败时用

### 死磕一条路不变通是 Agent 共性缺陷
- 遇到报错/卡点：官方文档 → GitHub Issues → Reddit → Discord → 社区论坛
- 不能只靠一个搜索入口，要换关键词、换引擎

---

## 多 Agent 协作

### delegate_task 何时用
- ✅ **用**：推理密集型任务、多独立工作流（Research A + B 并行）、需专业子 Agent 的任务
- ❌ **不用**：简单机械操作、单步查询、需人工干预的交互任务

### 上下文传递规范（已验证）
- 将任务目标 + 约束 + 输出格式要求 **全量** 传入 `context` 字段
- leaf 子 Agent **不能再委派**（默认 role='leaf'）
- 结果聚合由主控 Agent 负责最终综合

---

## 任务持久化

### checkpoint 规范（已固化）
- 多步骤任务：每步完成后**立即**写入，不等 reset
- **双写**：`~/.hermes/task_checkpoint.json` + `memory` 工具
- 重启 Gateway 前必须写 checkpoint（任务状态 + 下一步 + 改动文件）
- 重启后必须发飞书通知

### 重启 Gateway 防护 SOP（P0）
1. 写 checkpoint（任务状态 + 改动文件 + 下一步）
2. 确认用户明确同意（禁止擅自重启）
3. 执行重启
4. 重启后飞书通知用户

---

## Session Reset

### 重置后必须立即做的事
1. 读取 `~/.hermes/task_checkpoint.json` 确认任务状态
2. 发送飞书通知告知用户已重连
3. 如有 pending 任务，从 checkpoint 恢复

---

## Cron 任务

### 时区设置
- 设置 cron 必须用**用户当地时间**（GMT+8）
- 换算：凌晨 3 点触发 = `cron` 设 `19:00 UTC`（不是 03:00 UTC）

### 执行超时
- 建议 5 分钟作为单个任务执行上限
- 超时后标记失败状态，写入 checkpoint，等待用户介入

---

## MiniMax 图片生成 API 区域限制（2026-04-27 最终结论）

- **根本原因**：图片生成 API **仅在 Global 端 `api.minimax.io` 可用**，CN 域名 `api.minimaxi.com` 完全没有此 API
- **CN Key 格式**：`sk-cp-1N...`（仅限 CN 区域）
- **Global Key 格式**：`sk-gl-1N...`（可访问图片 API）
- **错误码**：`404 Page not found` = CN 端无此 API；`2049 invalid api key` = CN key 无法认证 Global 端
- **解法**：
  1. **推荐**：`https://image.pollinations.ai/prompt/<prompt>.png`（免费，无需 key）
  2. **需要 Global key**：注册 minimax.io 账号获取 Global API key
- **不更新原则**：此为最终结论，除非 MiniMax 官方变更 API 架构，否则不修改

---

## 联邦架构（V3.0.1-FINAL）

### 原子写入保护（Lock & Append）
- **检测锁**：检查 `global_knowledge.lock` 是否存在
- **重试逻辑**：若锁存在，随机等待 0.2s-0.5s 后重试，上限 3 次
- **上锁写入**：
  1. 创建锁文件，内容写入：`[Agent名]_PID_[RandomID]`
  2. 执行 Append（追加入文件末尾）
  3. 立即删除锁文件
- **降级处理**：若 3 次均失败，将经验标注 `[PENDING_ARCHIVE]` 附加在任务结果 summary 中

### 经验归档模板（Strict Schema）
```
## [<领域标签>] <简练的坑点标题> / <核心关键字>
- 现象：<报错原文或异常行为描述>
- 解法：<验证有效的 CLI 指令、代码片段或逻辑操作>
- 时间：<YYYY-MM-DD> | 贡献者：<Agent名>
```

### Pending 文件闭环规则（必须遵守）
- 闭环后**必须**执行 `os.remove(pending_file)`
- 严禁保留已完成任务在 pending 队列（防止幽灵任务）
- pending 文件状态改为 done 后必须物理删除

### emit_result 时间戳规范
- 统一使用 Unix Epoch（`int(time.time())`）
- 严禁使用 strftime/ISO 格式

### 僵尸任务心跳超时
- 主 Agent 扫描时检测 `status==processing && locked_at > 30分钟`，强制重置为 waiting

### 三条军规（V3.0.1-FINAL）
1. 原子性第一：严禁在未更新 `status: "processing"` 的情况下开始逻辑推理
2. Unix Epoch 唯一性：严禁使用任何 strftime/ISO 格式，全系统只认整数 Unix 时间戳
3. 结果归口：`emit_result()` 是唯一任务终结手段，未调用前严禁在群里回复「Done」

---

## 订阅配置（项目参考）

### 美国订阅账单地址（OpenAI Plus 等）
- 格式：`3500 S Las Vegas Blvd, Las Vegas, NV 89109, USA`
- State 下拉选 `NV`，Postal Code 填 `89109`
- 内华达州免消费税
- 国内银行卡大概率失败，需虚拟卡（Depay/义乌尼）

---

*最后更新：2026-04-27*
*备份位置：`~/.hermes/project_notes/global_knowledge-backup-2026-04-27.md`*
*project_notes 归档：`~/.hermes/project_notes/`*
