# cn-scraper-mcp VPS 部署与调试记录（2026-08-05 实测）

## 部署步骤（VPS Ubuntu 24.04）

```bash
cd /opt && git clone --depth 1 https://github.com/goesByhc/cn-scraper-mcp.git
cd cn-scraper-mcp && python3 -m venv .venv && source .venv/bin/activate
pip install -e .          # 依赖轻: fastmcp + curl_cffi + websockets
apt-get install chromium-browser   # snap 版可用, headless 正常
```

环境变量：
```bash
export XHS_PROXY="socks5://127.0.0.1:10808"      # 家宽隧道
export CHROME_BIN="/usr/bin/chromium-browser"
```

## 必须的两处 patch（原版不支持代理）

**`src/cn_scraper_mcp/engines/cdp.py`** — `launch_chrome` 加 proxy 参数：

```python
def launch_chrome(port, profile_dir, url="about:blank", headless=False, proxy=None):
    ...
    if proxy:
        args.append(f"--proxy-server={proxy}")
    # 反检测参数(已合并进默认 args):
    # --disable-features=AutomationControlled --disable-infobars --lang=zh-CN
```

**`src/cn_scraper_mcp/engines/xiaohongshu.py`** — `ensure_browser()` 里
`launch_chrome(...)` 调用加 `proxy=os.environ.get("XHS_PROXY")`；文件头补 `import os`。

## 关键实测结论（含一个大坑）

| 页面 | 结果 | 结论 |
|---|---|---|
| 小红书首页 explore | ✅ 完整加载 | 家宽 IP + Chrome = 正常用户 |
| 搜索页 search_result | ❌ 300012 "IP at risk" | **不是 IP 问题！** |
| curl 走隧道搜搜索页 | ✅ 723KB __INITIAL_STATE__ | 游客能拿数据但需解析 |

**大坑：搜索页对匿名访问报 `300012 IP at risk` 是误导性的** —— 家宽 IP 下首页
完美加载，证明 IP 干净；搜索页是因为**游客无登录 cookie** 才拦截。README 也印证：
"Results arrive via signed XHR (x-s/x-t headers), NOT server-side rendered"。

**因此：搜索必须有小红书网页版登录 cookie**（APP 登录态无效，两套体系隔离）：
`web_session, a1, webId, gid, abRequestId, xsecappid, webBuild`
存到 `~/.cn-scraper-cookies/xiaohongshu.json`（或 `$XHS_COOKIES_FILE`）。

获取方式（二选一）：
1. **浏览器导出**：电脑登录 xiaohongshu.com → F12 → Application → Cookies → 导出 JSON
2. **guided_login（远程扫码）**：工具启动本地 Chrome 显示二维码，用户手机扫码，CDP 自动抓 HttpOnly cookie

## 无显示器 VPS 跑登录页（方式 2 实测）

`headless=False` 在无显示器 VPS 上启动失败（launch 返回 False）。必须：
1. 起虚拟显示：`Xvfb :99 -screen 0 1280x1000x24 &`（background）
2. `DISPLAY=:99` 运行引擎 → headful Chrome 能起来
3. 导航 `https://www.xiaohongshu.com/login`（登录页有二维码：左扫码/右手机号）
4. CDP `Page.captureScreenshot` 截图发用户扫码（二维码 1-2 分钟时效，过期重截）
5. 登录后 cookie 在 profile 目录（/tmp/xhs_profile_*），用 CDP `Network.getAllCookies` 抓取存 `~/.cn-scraper-cookies/xiaohongshu.json`

**截图取数坑**：`Page.captureScreenshot` 返回的 base64 在 `r.get('data')` 或
`r.get('result', {}).get('data')` 两层嵌套都出现过——用
`data = r.get('data') or (r.get('result') or {}).get('data')` 一次拿对。

## 调试陷阱

- `ensure_browser()` 是**同步函数**，别用 `asyncio.to_thread` 包装调用（返回异常结果）
- `CDPClient.connect(url_hint="xiaohongshu.com")` 要求 page target URL 包含该串；
  启动后若 target 是 about:blank 会报 `No page target found`
- 验证浏览器出口：导航到 `https://ifconfig.me/ip` 看 body（fetch 返回 `{}` 是
  evaluate 序列化问题，用导航方式）
- Chrome snap 版 dbus/AppArmor 报错是噪音，不影响 headless 功能
- 杀 Chrome：用 `ss -tlnp | grep <port>` 取 PID 再 kill（pkill -f 会自伤）

## 与 camoufox 的取舍

- 需要**登录态搜索** → cn-scraper-mcp（cookie + 签名 XHR 解析）
- 只需要**匿名浏览首页/详情** → camoufox 走隧道即可（已实测 200）
