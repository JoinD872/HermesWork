---
name: scrape-js-rendered-docs
description: 从 JS 渲染型文档站（如 Mintlify/Nextra）提取结构化数据的标准化方法——当 curl 返回空内容时，用浏览器控制台 JS 执行绕过动态渲染。
tags: [web, scraping, browser, mintlify, documentation, SPA]
category: web
risk: read-only
---

# JS 渲染型文档站抓取方法（browser_console JS 提取）

## 适用场景
- `curl` / `wget` 抓取返回裸 HTML（只有 `<div id="__next">` 或空壳）
- 文档站用 Mintlify、Nextra、Docusaurus 等 SPA 框架
- 需要提取日期标题、卡片内容、API 条目等结构化数据

## 核心方法：browser_console JS 提取

```javascript
// 方法1：按 data-component-part 属性提取卡片内容
const cards = document.querySelectorAll('.card');
let results = [];
cards.forEach(card => {
    const titleEl = card.querySelector('[data-component-part="card-title"]');
    const contentEl = card.querySelector('[data-component-part="card-content"]');
    const h4 = card.closest('div').previousElementSibling;
    const date = h4 ? h4.textContent.replace('Navigate to header', '').trim() : 'unknown';
    if(titleEl && contentEl) {
        results.push(date + ' | ' + titleEl.textContent + ' | ' + contentEl.textContent.substring(0, 200));
    }
});
results.join('\n');
```

```javascript
// 方法2：按 h2/h4 标题 + ul>li 列表提取 API 更新
const headings = document.querySelectorAll('h2');
let results = [];
headings.forEach(h => {
    if(h.textContent.includes('2025') || h.textContent.includes('2024')) {
        const date = h.textContent;
        const listItems = h.nextElementSibling ? Array.from(h.nextElementSibling.querySelectorAll('li')).map(li => li.textContent) : [];
        results.push(date + ' | ' + listItems.join('; '));
    }
});
results.join('\n');
```

## 标准抓取流程

1. **browser_navigate** → 目标 URL
2. **browser_click** → 展开需要交互的元素（如 "Learn More" 链接或 section 标题）
3. **browser_console** → 执行 JS 提取表达式（比 browser_snapshot 更精确）
4. **browser_vision** → 视觉验证（如需截图确认）
5. 对比上次记录 → 判断是否有新增

## 已知坑点

| 坑 | 根因 | 解法 |
|----|------|------|
| curl 只返回 HTML 壳 | Next.js SPA 未执行 JS 渲染 | 用 browser_navigate + browser_console |
| browser_snapshot 截断 | 长页面只显示前 N 行 | 用 browser_console JS 表达式按需提取 |
| 点击 "Learn More" 跳走 | 链接实际指向详情页 | 用 h.closest('div').previousElementSibling 取日期标题 |
| SPA 内容加载时序 | 元素在 DOM 中但未填充 | 在 browser_navigate 后等 snapshot 稳定 |

## 验证步骤
1. 提取结果包含预期的日期 + 标题 + 摘要
2. 与上次扫描记录对比，确认无遗漏
3. 视觉确认关键条目（如新版模型发布）在页面可见
