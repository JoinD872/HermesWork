---
name: hermes-internals
description: Hermes Agent 内部机制核心知识 — 基于官方文档。Frozen Snapshot Pattern、字符限制、Skills 三级加载、OpenClaw 迁移、DeepSeek 缓存架构。
version: 1.1.0
metadata:
  hermes:
    tags: [hermes, internals, memory, skills, openclaw, migration, caching, deepseek]
risk: read-only
---

# Hermes Internals

## ❄️ Frozen Snapshot Pattern（最重要）

**Session 期间对 MEMORY.md 的修改，下个 session 才生效。**

> "The system prompt injection is captured once at session start and never changes mid-session. When the agent adds/removes memory entries during a session, the changes are persisted to disk immediately but won't appear in the system prompt until the next session starts."

**实际影响**：
- `memory` 工具的 add/replace 操作 → disk 立即写入，下次 session 生效
- 我现在 session 里更新的记忆，刷新页面/重连后才能在 prompt 里看到
- 每次 session 开始时 prompt 里显示的 `%` 利用率是**上个 session 结束时**的快照

## 📏 Memory 字符限制（bounded memory）

- `MEMORY.md` 上限：**2,200 chars**
- `USER.md` 上限：**1,375 chars**
- 满了会自动 consolidation（合并/替换旧记忆）
- 当前利用率在每次 session 启动时显示，如：`[67% — 1,478/2,200 chars]`

**记忆必须精简**，不能往里塞大量原始内容。

## 📚 Skills 三级加载（Progressive Disclosure）

```
Level 0: skills_list() → [{name, description, category}, ...] (~3k tokens)
Level 1: skill_view(name) → 完整内容 + metadata（实际使用时才加载）
Level 2: skill_view(name, path) → 具体引用文件（最细粒度）
```

agent 调用 skill 时按需加载，不是全量加载。

## 🆕 Skills 新字段（我的 skills 缺的）

SKILL.md 支持但我目前没用到的字段：

```yaml
platforms: [macos, linux]        # OS 限制
metadata:
  hermes:
    fallback_for_toolsets: [web]  # 条件激活
    requires_toolsets: [terminal]  # 依赖条件
    config:                        # 安装时用户配置
      - key: my.setting
        description: "..."
        default: "value"
        prompt: "Prompt for setup"
```

## 🗂️ OpenClaw 迁移状态

**重要发现**：OpenClaw workspace 文件夹没有自动迁移。

```
OpenClaw 旧数据:  ~/.openclaw/workspace/knowledge/
  deep-learning.md   ← 还在这里！
  network.md         ← 还在这里！

Hermes skills:      ~/.hermes/skills/knowledge/  ← 不存在，未迁移
```

如果要从 OpenClaw 迁移 knowledge 文件，需要手动复制到 `~/.hermes/skills/`。

迁移命令 `hermes claw migrate` 只迁移人格/记忆/技能/消息配置/凭据，不迁移 workspace 普通文件。

## 🖼️ 视觉识别（2026-05-09 更新 — MiniMax 迁移后）

**主流模型切换**：主力模型从 MiniMax 切换为 **DeepSeek V4**。
MiniMax MCP server（`minimax-coding-plan-mcp`）已全部移除，包括 `understand_image` 和 `web_search`（均为平台级 404）。

**当前 Vision 方案（按优先级）**：

| 方式 | 状态 | 说明 |
|------|------|------|
| `vision_analyze` tool | ✅ 可用 | 走独立 vision 路由链（主 provider → OpenRouter → Nous）。通过 `vision_analyze(image_url, question)` 调用 |
| `mmx vision describe` CLI | ⬜ 备用 | 仅当 `vision_analyze` 不可用时降级使用（注意可能报 `input sensitive`） |
| `mcp_minimax_plan_understand_image` | ❌ 已移除 | MiniMax MCP 网关 endpoint 404，MCP server 已从 config 移除 |

**`vision_analyze` 机制**：独立于主模型路由。通过 `task="vision"` 走 `resolve_vision_provider_client()` 链：
1. 主 provider 的 vision 模型（DeepSeek V4）
2. → fallback OpenRouter
3. → fallback Nous Portal

**有效文件判断**：`file /root/.hermes/image_cache/img_xxx.jpg` 返回有效 JPEG（文件本身没坏）

## 💾 DeepSeek 缓存架构（关键知识）

DeepSeek 的 Context Caching on Disk 是**服务端自动触发**的 byte 级前缀匹配缓存，无需 API 标记。

### 与 Hermes 交互的关键点

| 模块 | 状态 | 代码位置 |
|------|------|---------|
| `_cached_system_prompt` 会话内 frozen | ✅ 正确 | `run_agent.py:6056-6281` |
| 工具 schema 通过 `tools` 参数传递（不在 system prompt 文本中） | ⚠️ 常被误解 | `run_agent.py:10025-10028` |
| `_format_tools_for_system_message()` 只用于 trajectory | ⚠️ 容易误认 | `run_agent.py:4803-4825` |
| `/compress` → 必然破坏缓存 | 权衡（防 OOM > 缓存） | `run_agent.py:10722-10724` |
| `_deterministic_call_id` 防 UUID 破坏缓存 | ✅ 已做 | `run_agent.py:6655-6663` |
| `extract_cache_stats()` 读缓存统计 | 取决于 DeepSeek 是否返回字段 | `chat_completions.py:615-627` |

详见 `references/deepseek-caching.md`（含完整机制说明、代码位置索引、常见误解纠正、实测数据、跨频道缓存共享分析）

## 🔬 缓存诊断工作流（2026-05-17 实测验证）

当需要验证 DeepSeek（或其他 OpenAI 兼容 provider）的缓存是否生效时：

### 1. 确认 toolsets 一致
```python
from model_tools import get_tool_definitions
tools = get_tool_definitions(enabled_toolsets=["hermes-cli", "browser"], quiet_mode=True)
names = sorted(t["function"]["name"] for t in tools)
```
- `registry.get_definitions()` 内部用 `sorted(tool_names)` — 注册顺序跨会话稳定
- 各 profile 的 toolsets 必须完全一致，否则 system prompt 中的 skills 索引不同 → 前缀不同

### 2. 运行 `--verbose` 观察缓存统计
```bash
hermes chat -q "调用一次工具任务" --verbose
```
关键日志行：
```
API Response received - Model: deepseek-v4-flash
  Usage: CompletionUsage(..., prompt_tokens=20225, ...,
    prompt_tokens_details=PromptTokensDetails(cached_tokens=640),
    prompt_cache_hit_tokens=640,
    prompt_cache_miss_tokens=19585)
```

### 3. 解读缓存数据

| 轮次 | 典型命中率 | 说明 |
|------|-----------|------|
| 第 1 轮（冷启动）| ~3% | 仅共享前缀（默认 SOUL.md 路由规则 ~2.1KB 中已被缓存的部分）|
| 第 2 轮（同会话）| **~100%** | system prompt + 历史全部命中，仅新增 tool result 未命中 |
| 跨频道同 profile | 共享 ~2.1KB 前缀 | 频道独有 SOUL.md 需各自冷却 |

实测数据（2026-05-17, deepseek-v4-flash）：
```
Call #1: cache=640/20225 (3% hit) — cold start
Call #2: cache=20352/20420 (100% hit) — prefix fully cached, only 68 miss tokens
```

### 4. 跨频道缓存共享模型

各频道（小策/黑翼/小研/老V）运行在同一 default profile 下，共享：
```
[default SOUL.md (2.1KB, 路由规则)]  ← 所有频道共享
[per-profile SOUL.md (3.5-4.3KB)]    ← 频道独有
[per-profile MEMORY.md (0.4-3KB)]    ← 频道独有
[volatile: timestamp + memory snap]  ← 每次 session 不同
```

Feishu adapter：per-profile SOUL.md + MEMORY.md 通过 `channel_prompt` 机制注入为 `ephemeral_system_prompt`，拼接到 `_cached_system_prompt` 尾部（`feishu.py:2258-2285`）。详见 `hermes-per-channel-profile-injection` skill。

### 5. 失败模式速查

| 现象 | 原因 |
|------|------|
| 全程 0% 命中 | toolsets 不一致 / provider 不支持缓存 |
| 第 2 轮仍 < 50% | system prompt 在轮次间被重建（检查是否切换模型/重载工具）|
| 跨频道 < 10% 共享 | 频道独有 SOUL.md 不同 → 前缀从该处开始分叉 |
| 压缩后 0% | 必然行为（见 `_invalidate_system_prompt`），压缩和缓存不可兼得 |

## 💰 费用追踪

Hermes TUI 层内置 `show_cost` 配置项（当前 `config.yaml: show_cost: false`），但实际计费追踪需要对接 provider 的余额 API。

另见独立 skill `api-cost-tracking`（含 DeepSeek 余额 API 实现、V4 Flash/V4 Pro 定价表、人民币计价报告格式）。