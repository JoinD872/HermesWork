# 每日日记系统 — Daily Diary Automation

> Phase 1.5 component. Automated daily journaling with Google Docs integration.

## Overview

Creates a daily journal file at **Shanghai 08:00**, uploaded to Google Drive as a native Google Doc (editable on mobile). User writes in the early morning hours (凌晨); unfilled entries auto-delete the next day. Filled entries sync back to Obsidian Vault as `.md`.

## User Context

- Writes diary at **凌晨 (2-6am Shanghai time)**
- Uses **Google Docs app on mobile** — cannot create .txt/.md files on Drive mobile
- Template must be minimal, no form-filling pressure
- Diaries that aren't filled are auto-deleted (no guilt)
- Diary doubles as idea/inspiration capture (same file, bottom section)
- User explicitly rejected structured templates (gratitude/CBT/mood-tracker)

## Components

1. **Diary template** — `~/.hermes/ObsidianVault/模板/日记模板.md`
2. **Creation script** — `~/.hermes/scripts/daily_diary.sh`
3. **Cleanup + pull-back** — Same script, runs next day
4. **Cron job** — `0 0 * * *` UTC (= Shanghai 08:00), `no_agent=true`

## Template Format

```markdown
---
title: "{{date}} 日记"
date: {{date}}
type: diary
status: draft
---

# {{date}}
                              ← free-write area (user writes anything)

# 灵感、想法                  ← ideas section below
```

Keep it to just a date header + free write + ideas section. No structured prompts.

### ⚠️ MONTH_DIR Variable Scoping Bug (2026-06-02)

The original script used `MONTH_DIR` as a global variable at the top of the file:
```bash
MONTH_DIR=$(TZ=$TZ date +%Y-%m)
```

But the cleanup loop **overwrote** it:
```bash
for INBOUND_FILE in ...; do
  ...
  MONTH_DIR=$(basename "$DIRNAME")    # ← OVERWRITES the global!
  VAULT_FILE="..."
done
```

After the loop, `MONTH_DIR` was still `2026-05` (from the last processed file), so the new diary creation later used the wrong month. Example: June 2's diary was created in `2026-05/2026-06-02-日记.md`.

**Fix**: Use a separate variable inside the loop:
```bash
INBOUND_MONTH=$(basename "$DIRNAME")
VAULT_FILE="$VAULT_DIR/$DIARY_SUB/$INBOUND_MONTH/$BASE"
...
rm -f "$VAULT_DIR/$DIARY_SUB/$INBOUND_MONTH/$BASE" "$INBOUND_FILE"
```

This ensures the top-level `MONTH_DIR` (used for creating today's diary) is never corrupted by loop processing.

## Google Docs Conversion

### Creation (VPS → Drive)

```bash
rclone copy "$LOCAL_DIARY.md" "mydrive:日记/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-import-formats md \
  -q
```

- `--drive-import-formats md` converts `.md` → native Google Doc
- Google Docs show as `-1` size in `rclone ls` (expected)

### Pull-back (Drive → VPS, for cleanup check)

```bash
rclone copy "mydrive:日记/$DATE-日记.md" "$STAGE/" \
  --drive-root-folder-id "$FOLDER_ID" \
  --drive-export-formats md \
  --size-only -q
```

Frontmatter may be flattened to single line on re-export — acceptable.

## Cleanup Logic

The current `daily_diary.sh` uses **Python regex content detection** (not `wc -c` / `wc -l`):

```bash
HAS_CONTENT=$(python3 -c "
import re
with open('$INBOUND_FILE') as f:
    content = f.read()
# Find content after the first # YYYY-MM-DD heading
m = re.search(r'# \d{4}-\d{2}-\d{2}\n\n(.+)', content, re.DOTALL)
if m:
    body = m.group(1).strip()
    # Remove template-only section headers (like '# 灵感、想法')
    body = re.sub(r'# [^\n]+', '', body)
    real = re.sub(r'\s+', '', body)
    print('true' if len(real) > 10 else 'false')
else:
    print('false')
")

if [ "$HAS_CONTENT" = true ]; then
  cp "$INBOUND_FILE" "$VAULT_FILE"
  echo "✅ 日记已填写: $BASE"
else
  # Empty — delete from Drive + local
  rclone delete "mydrive:$DIARY_SUB/$INBOUND_MONTH/$BASE" \\\n    --drive-root-folder-id "$FOLDER_ID" -q 2>&1 || true\n  rm -f "$VAULT_DIR/$DIARY_SUB/$INBOUND_MONTH/$BASE" "$INBOUND_FILE"
fi
```

The template content structure is:
```
---
(empty line)
## title: "{{date}} 日记" date: {{date}} type: diary status: draft
(empty line)
# {{date}}
(empty line)
(empty line)
# 灵感、想法
```

User content goes between `# {{date}}` and `# 灵感、想法`. The regex finds text after the date heading, strips template section headers, and counts real characters (after removing whitespace). Threshold > 10 chars = has content.

### ⚠️ Critical Pitfall: Line count (`wc -l`) and byte comparison (`wc -c`) both fail for this template

The exported .md from Drive preserves the same **line count** as the template because user content is written between existing lines. `wc -l` returns identical values for empty and filled diaries.

**`wc -c` also fails** because template metadata (like the date) varies by day — `2026-05-24` vs `2026-06-02` has different byte counts, making a fixed threshold unreliable.

**Current fix**: Python regex that finds actual text after the date heading and determines if it's meaningful (>10 non-whitespace chars). This is robust against:
- Template format changes (field additions, renames)
- Date-length variations (single vs double-digit months)
- Frontmatter format variations (inline vs multi-line YAML)

## Disaster Recovery: Restoring Deleted Diaries from Drive Trash

`rclone delete` moves files to **Google Drive trash** (not permanent deletion). Diaries can be recovered for up to 30 days.

### Recovery Procedure

1. **List trashed files**:
   ```bash
   rclone ls "mydrive:日记/" --drive-trashed-only --drive-root-folder-id "$FOLDER_ID"
   ```
   Files with `-1` size are Google Docs placeholders. Files with positive sizes are exported `.md` snapshots (likely contain user content).

2. **Locate content**:
   Look for `日记MD/` subdirectory (created by `--drive-export-formats md` during copy). Files with `size > 112` bytes contain real content.

3. **Restore individual files**:
   ```bash
   rclone copy "mydrive:日记/日记MD/$FILENAME" /tmp/recovery/ \
     --drive-root-folder-id "$FOLDER_ID" \
     --drive-trashed-only
   ```
   Target specific file paths to avoid timeout from deeply nested trash directories.

4. **Copy to Vault**:
   ```bash
   cp /tmp/recovery/*-日记.md ~/.hermes/ObsidianVault/日记/2026-05/
   ```

### ⚠️ Deep Nesting Pitfall

The export process can create recursive `日记MD/日记MD/日记MD/...` directories in trash. These cause `rclone ls --drive-trashed-only` to timeout when listing the entire directory. Always target specific file paths rather than wildcard listings when recovering from trash.

## Cron Job

```json
{
  "schedule": "0 0 * * *",
  "name": "每日日记 — 创建+清理",
  "script": "daily_diary.sh",
  "no_agent": true,
  "deliver": "local"
}
```

Must run AFTER `pull_user_notes.sh` (or combined) so yesterday's diary is pulled before cleanup.

## Google Drive Folder

```
FOLDER_ID="1XvPIqFqftMhG_4QSC9LnApxue_ayvAmg"
```

Targets the user's existing Obsidian vault folder on Drive.
