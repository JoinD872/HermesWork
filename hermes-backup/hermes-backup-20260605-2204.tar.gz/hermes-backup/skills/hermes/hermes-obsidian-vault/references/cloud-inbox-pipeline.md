# Cloud Inbox Pipeline — Google Drive → Obsidian Vault

> Phase 1.5 component. Implemented after Phase 1 stability verified.

## Overview

Bridge Google Drive (as a cloud inbox) into the Hermes Obsidian Vault. Users drop `.md`/`.txt` files **or create Google Docs** in a Drive folder; a scheduled cron job pulls them, adds Obsidian frontmatter, and places them in the Vault's inbox directory for processing.

## Components

1. **rclone remote** — Google Drive remote with `export_formats = md,txt,docx` to auto-export Google Docs as Markdown
2. **Pull script** — `~/.hermes/scripts/pull_cloud_inbox.sh`
3. **Cron job** — `*/30 * * * *`, `no_agent=true`

## rclone Config

The remote must include `export_formats`. Google Docs (`.gdoc`) are auto-exported to the **first format** in the list (`md`):

```ini
[mydrive]
type = drive
token = <OAuth token>
team_drive = 
export_formats = md,txt,docx
```

## Pull Script (`pull_cloud_inbox.sh`)

```bash
# Include ALL source extensions, including .gdoc
rclone move "$REMOTE_INBOX" "$STAGE/" \
  --include "*.md" \
  --include "*.txt" \
  --include "*.gdoc" \
  --delete-empty-src-dirs \
  -v 2>&1

# Process each file: add Obsidian frontmatter, rename with date prefix
find "$STAGE" -type f \( -name "*.md" -o -name "*.txt" \) | while read -r f; do
  base="$(basename "$f" | sed 's/\.[^.]*$//')"
  dest="$VAULT/00_收件箱-人工/$(date +%Y%m%d)-$base.md"
  {
    printf -- "---\n"
    printf "created: %s\n" "$(date -Iseconds)"
    printf "source: cloud-inbox\n"
    printf "status: unprocessed\n"
    printf "promotion_required: true\n"
    printf -- "---\n\n"
    cat "$f"
    printf "\n"
  } > "$dest"
  rm -f "$f"
done
```

**Critical: include `*.gdoc` in the filter.** Google Docs appear as `.gdoc` files in Drive listings. Without this, they're silently skipped.

## Cron Job

```json
{
  "schedule": "*/30 * * * *",
  "no_agent": true,
  "script": "pull_cloud_inbox.sh",
  "deliver": "local"
}
```

Use `no_agent=true` since pure bash; `deliver=local` to avoid chat spam.

## Pitfalls Fixed During Implementation

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| Missing `.gdoc` in filter | Google Docs silently skipped | Add `--include "*.gdoc"` |
| `--delete-empty-src-dirs` | HermesInbox folder accidentally deleted | Remove the parameter |
| `deliver: origin` | User receives notification on every pull | Change to `deliver: local` |
| Script always outputs something | Wastes tokens even with no new files | Add check: only output when files are found |

## OAuth Configuration

See `references/rclone-headless-oauth.md` for headless VPS OAuth setup. Key points:
- OAuth must run ON the VPS (Los Angeles), not on the user's GFW'd Windows desktop
- Google's token exchange (`oauth2.googleapis.com/token`) is blocked inside China
- Use socat port forwarding + manual URL correction

## File Lifecycle

1. User creates a Google Doc or uploads `.md`/`.txt` to the Drive inbox folder
2. Cron runs (every 30 min) → `rclone move` pulls files to VPS staging
3. Script adds frontmatter (`created`, `source: cloud-inbox`, `status: unprocessed`)
4. Files placed in `00_收件箱-人工/` with date prefix
5. AI agent picks up for organization into permanent Vault directories
