# 记忆清理启发式策略（2026-06-01 确立）

## 清理决策标准

当 memory 使用率 > 80% 时，按以下优先级清理：

### 第一优先级：删除
- 一次性修复记录（"bug修复：修复了X" → 放 git commit/skill）
- 版本升级记录（"从vA升级到vB" → 放 changelog）
- 极低频工具知识（ChatGPT续费方式、crawl4ai安装路径等 → 放对应skill或删除）
- 特定偏好的完整表述（→ 压缩为一句或放skill）

### 第二优先级：迁移到 skill 索引
将长流程/工作流说明替换为一行 skill 索引：
- `宠物技能设计：skill pet-skill-design-workflow`
- 原条目占 ~400 chars → 索引占 ~80 chars

### 第三优先级：合并同类项
- 同一主题的多条 entry → 合并为一条
  - Windows设备信息 + SSH信息 + 小红书限制 → 合并为 Windows/黑翼
  - 无事通知偏好 + Vault被动 → 合并为通知与日记偏好
  - VPS事实 + cron脚本规则 → 合并为 VPS/cron自动化

## 目标
memory 保持在 2,000-2,500 chars（40-50%），留出至少 50% 增长空间。

## 不能删除的类型
- 凭证/密钥位置
- 关键机器/VPS/SSH 连接信息
- 核心协作规则
- 用户高频行为偏好
- 重要 API/工具入口
