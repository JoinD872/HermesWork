---
name: cron-no-agent-script-rule
description: no_agent=true 的 cron 的 script 字段必须只写文件名，不加 shell 前缀。重复踩坑史 + 验证清单 + API 层防护说明。
risk: read-only
version: 1.0.0
---

# Cron no_agent Script Rule

当 `no_agent=true` 创建或更新 cron job 时，script 字段的值被调度器视为 `~/.hermes/scripts/` 下的文件路径，通过 shebang 直接执行——**不经过 shell 解析**。

## 规则（违反必报错）

```
✅ 正确：script="daily_diary.sh"         # 只写文件名
✅ 正确：script="vault_ingest.py"         # .py 文件同理
❌ 错误：script="bash daily_diary.sh"     # 被当作路径：~/scripts/bash daily_diary.sh → Script not found
❌ 错误：script="python3 vault_ingest.py" # 被当作路径：~/scripts/python3 vault_ingest.py → Script not found
```

## 为什么会踩坑（历史记录）

同一个 bug 修了 3 次才彻底根除：
1. 第 1 次：修了表层拼接逻辑，没查所有引用点
2. 第 2 次：补了另一处遗漏，但没扫描源文档
3. 第 3 次：Codex 发现「5 处技能文档」中写死了错误示例——每次加载 skill 创建 cron 时会复制粘贴错误格式

**根因**：毒源在 5 处 skill 文档中（`obsidian/SKILL.md` 等），修一次漏一次直到全盘扫描为止。

## 三层防护（2026-05-26 实施）

| 层 | 措施 | 效果 |
|----|------|------|
| 源头 | 修正 5 处技能文档中的错误示例 | 以后创建 cron 不会抄错 |
| API | `_validate_cron_script_path()` 新增 shell 前缀检测 | 即使 AI 忘了，API 直接拒绝 |
| 知识 | 本 skill | 创建 cron 时自动加载检查清单 |

## 校验清单

创建/修改 no_agent=true 的 cron job 时逐项检查：

- [ ] script 字段**只包含文件名**（如 `daily_diary.sh`）
- [ ] 不以 `bash`、`python3`、`python`、`sh`、`node` 等前缀开头
- [ ] 文件确实存在于 `~/.hermes/scripts/` 下
- [ ] 文件有 shebang（`.sh` 需 `#!/usr/bin/env bash`，`.py` 需 `#!/usr/bin/env python3`）
- [ ] `deliver` 已显式设置（no_agent cron 默认不设会发到用户聊天）

## 解释器自动选择

调度器根据文件扩展名自动选择：
- `.sh` / `.bash` → `/bin/bash`
- `.py` ／ 其他 → `sys.executable`（当前 Python）
