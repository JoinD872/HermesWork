---
name: cron-creation-debugging
description: Cron job 创建排障指南 — 解决 create/update 返回类型错误的问题
category: hermes
tags: [cron, debugging, troubleshooting]
risk: read-only
---

# Cron Job 创建排障

## 常见错误

### `'<=` not supported between instances of 'str' and 'int'`

**现象：** `cronjob(action='create')` 或 `cronjob(action='update')` 返回此错误，但 `list/pause/resume/remove` 正常。

**已知的触发条件（按可能性排序）：**

1. **Prompt 中含中文** — 大概率触发。英文 prompt 可通过，中文 prompt 几乎必败。
2. **Prompt 含有比较符号** — `<=` `>=` 在 prompt 中出现会触发（即使英文）。用文字描述替代，如"低于4分"替代`<= 4`。
3. **Prompt 含有特殊格式字符** — emoji `📊`、列表符号 `•`、多行结构可能触发。
4. **含有"飞书 DM chat_id"** — 某些特定字符串组合触发。
5. **Session 级限制** — 约 5 次创建操作后，session 进入受限状态，所有 create/update 均失败，需新 session 恢复。

**能成功创建的情况：**
- 极短英文 prompt（`"echo hello"`）
- 不带 `skills` 参数
- 不带 `deliver` 参数（默认 origin）

**能成功 update 的情况：**
- 短 prompt（< 50 字符）
- 不含中文
- 目标 job 需先 pause（否则可能冲突）

**Session 级限制的完整症状：**
- `list/pause/resume/remove` 全部正常
- `create` 和 `update` 全部返回类型错误
- 即使极短英文 prompt 也无法创建/更新
- 新 session 可恢复正常
- 约 5 次创建操作后触发（不确定精确阈值）

**绕行模式（实测有效）：**
1. Pause 目标 job（释放执行槽位）
2. Update 已 pause 的 job（避免并发冲突）
3. Resume 恢复（若需要）

---

## 关于 prompt vs script 字段的关键区别

⚠️ **这是导致 cron 静默失败的头号陷阱。** 理解这个区别比知道任何单一 bug 更重要。

| 字段 | 模式 | cron 如何执行 |
|------|------|--------------|
| `prompt='...'` | LLM驱动（默认） | prompt 发给 LLM 执行。可以写任何自然语言、shell 命令、中文脚本路径 |
| `script='xxx.sh'` | `no_agent=true` | 脚本被作为可执行文件直接运行（通过 shebang）。`script` 字段仅接受**文件名**，相对 `~/.hermes/scripts/` |

**⚠️ 危险混合：** 在 `no_agent=true` 的 `script` 字段里写 `bash xxx.sh` 或 `python3 xxx.py` → 调度器把整个字符串当作文件路径去查找 → `Script not found`。脚本第一行有 shebang（`#!/usr/bin/env bash` 或 `#!/usr/bin/env python3`）就已经够了，不需要加 bash/python3 前缀。如需执行多个命令，写一个包裹脚本。

## 应对策略

### 策略 1：脚本外置法（推荐）

把复杂逻辑写成独立脚本，然后在 cron 中引用。**注意格式因模式而异：**

#### 模式 A：LLM 驱动（默认，无 `no_agent`）

```python
# ✅ prompt 字段可以写 shell 调用——LLM 会解析执行
cronjob(action='create', prompt='bash ~/.hermes/scripts/my-script.sh', ...)
```

#### 模式 B：`no_agent=true`（脚本模式）

```python
# ✅ script 字段只写文件名（相对 ~/.hermes/scripts/）
cronjob(action='create', no_agent=True, script='my-script.sh', ...)
# ✅ .py 文件只要有 shebang 也可以直接用文件名
cronjob(action='create', no_agent=True, script='vault_ingest.py', ...)

# ❌ 不要加 bash/python3 前缀——调度器会把整个当文件名
cronjob(action='create', no_agent=True, script='bash my-script.sh', ...)
# ❌ 也不要用绝对路径 ~/.hermes/scripts/my-script.sh
cronjob(action='create', no_agent=True, script='~/.hermes/scripts/my-script.sh', ...)
```

#### 模式 C：`no_agent=true` + 多命令（需包裹脚本）

如果只想用 `no_agent=true` 执行多条命令（如 `sync && pull`），**必须**写一个包裹脚本，cron 只引用它：

```bash
#!/usr/bin/env bash
# 包裹脚本示例：sync_both.sh
set -euo pipefail
bash ~/.hermes/scripts/sync_vault_to_drive.sh
bash ~/.hermes/scripts/pull_user_notes.sh
```

### 策略 2：分步创建

把复杂 cron 拆成多个简单 cron，每个只做一件事。

### 策略 3：新 session 重试

如果 session 进入受限状态，等待一段时间或开启新 session 再试。

### 策略 4：通过 skill 调用

如果 cron 的 prompt 必须含中文，可以考虑把中文逻辑写入 skill，然后 cron prompt 只加载 skill。但当前 skill 名称格式（`category:skill-name`）也可能触发错误。

---

## 已验证可用的参数组合

```
# ✅ Create - 有效
cronjob(action='create', prompt='短英文', schedule='0 12 * * *', skills=['productivity:cron-output-standard'])

# ❌ Create - 失败（中文 prompt）
cronjob(action='create', prompt='你是小健，健康顾问...', schedule='0 12 * * *', skills=[...])

# ❌ Create - 失败（含 deliver）
cronjob(action='create', prompt='...', schedule='0 12 * * *', deliver='origin', skills=[...])

# ✅ Update - 有效
cronjob(action='update', job_id='xxx', prompt='短英文')

# ❌ Update - 失败（长 prompt）
cronjob(action='update', job_id='xxx', prompt='长中文内容...')
```

---

## 工作流建议

1. 先用极短英文 prompt 测试能否创建
2. 如果能创建，立即用短 prompt + 脚本外置实现功能
3. 不要在单个 session 内连续创建多个 cron
4. 复杂逻辑全部写入脚本，prompt 只写调用命令

---

## 相关文件

- 健康打卡脚本：`~/.hermes/scripts/xiaojian-daily-reminder.sh`
- 每日汇总：`~/.hermes/scripts/xiaojian-daily-summary.py`  
- 每周周报：`~/.hermes/scripts/xiaojian-weekly-report.py`
