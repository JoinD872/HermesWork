---
name: codex
description: Default collaboration partner for ALL work — coding, research, analysis, review, brainstorming. Run Codex CLI to get a different perspective on any task. GPT-5.5 via ChatGPT Plus — no extra billing.
version: 1.3.0
risk: write-dangerous
metadata:
  hermes:
    tags: [Collaboration-Agent, Codex, OpenAI, Code-Review, Refactoring, Research, Analysis, Brainstorming]
    related_skills: [claude-code, hermes-agent, software-development:code-repair-loop, software-development:plan]
---

# Codex CLI

Delegate coding tasks to [Codex](https://github.com/openai/codex) via the Hermes terminal. Codex is OpenAI's autonomous coding agent CLI.

## Prerequisites

- Codex installed: `npm install -g @openai/codex`
- **Authentication (one of two modes)**:
  - **API key mode**: set `OPENAI_API_KEY` env var
  - **ChatGPT Plus mode** (no API key needed): Codex stores session tokens in `~/.codex/auth.json` with `auth_mode: "chatgpt"`. Tokens auto-refresh via ChatGPT Plus session.
- **Must run inside a git repository** — Codex refuses to run outside one
- Use `pty=true` in terminal calls — Codex is an interactive terminal app

## One-Shot Tasks

```
terminal(command="codex exec 'Add dark mode toggle to settings'", workdir="~/project", pty=true)
```

For scratch work (Codex needs a git repo):
```
terminal(command="cd $(mktemp -d) && git init && codex exec 'Build a snake game in Python'", pty=true)
```

## Background Mode (Long Tasks)

```
# Start in background with PTY
terminal(command="codex exec --full-auto 'Refactor the auth module'", workdir="~/project", background=true, pty=true)
# Returns session_id

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send input if Codex asks a question
process(action="submit", session_id="<id>", data="yes")

# Kill if needed
process(action="kill", session_id="<id>")
```

## Key Flags

| Flag | Effect |
|------|--------|
| `exec "prompt"` | One-shot execution, exits when done |
| `--full-auto` | Sandboxed but auto-approves file changes in workspace |
| `--yolo` | No sandbox, no approvals (fastest, most dangerous) |

## PR Reviews

Clone to a temp directory for safe review:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && gh pr checkout 42 && codex review --base origin/main", pty=true)
```

## Parallel Issue Fixing with Worktrees

```
# Create worktrees
terminal(command="git worktree add -b fix/issue-78 /tmp/issue-78 main", workdir="~/project")
terminal(command="git worktree add -b fix/issue-99 /tmp/issue-99 main", workdir="~/project")

# Launch Codex in each
terminal(command="codex --yolo exec 'Fix issue #78: <description>. Commit when done.'", workdir="/tmp/issue-78", background=true, pty=true)
terminal(command="codex --yolo exec 'Fix issue #99: <description>. Commit when done.'", workdir="/tmp/issue-99", background=true, pty=true)

# Monitor
process(action="list")

# After completion, push and create PRs
terminal(command="cd /tmp/issue-78 && git push -u origin fix/issue-78")
terminal(command="gh pr create --repo user/repo --head fix/issue-78 --title 'fix: ...' --body '...'")

# Cleanup
terminal(command="git worktree remove /tmp/issue-78", workdir="~/project")
```

## Batch PR Reviews

```
# Fetch all PR refs
terminal(command="git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'", workdir="~/project")

# Review multiple PRs in parallel
terminal(command="codex exec 'Review PR #86. git diff origin/main...origin/pr/86'", workdir="~/project", background=true, pty=true)
terminal(command="codex exec 'Review PR #87. git diff origin/main...origin/pr/87'", workdir="~/project", background=true, pty=true)

# Post results
terminal(command="gh pr comment 86 --body '<review>'", workdir="~/project")
```

## Usage Rules (This User)

These rules were established through explicit user direction. Follow them strictly.

### 1. Default workflow: draft v0 → Codex → v1 (NEVER solo-output)

**Do not produce output to the user before Codex has seen it.** My draft is always v0. Codex reviews/iterates before it reaches v1.

Flow:
```
用户需求 → 我出draft v0 → Codex审查/碰撞 → 我收敛成v1 → 输出给用户
```

The user's exact words (2026-06-01): *"平时要向codex多学学，因为它有不同的理解角度"*

**The core value of Codex is not "another pair of hands" — it is "a different perspective."** My blind spots and Codex's blind spots are different. Codex catches things I would never catch even on a second or third review, because the errors are rooted in how my model sees the problem. This is not about Codex being "better" — it is about Codex being **different**.

This applies to **every class of work**:
- **Coding**: implementation, refactoring, debugging
- **Analysis & Summary**: diary/journal analysis, data pattern recognition, report synthesis
- **Review & Audit**: code review, config audit, security check, skill/library scan
- **Brainstorming**: 方案碰撞、验证假设、补充遗漏
- **Research/knowledge work**: domain guides, game build guides, technical documentation

**Concrete failure mode to avoid (PoE2 guide case):**
I wrote a 539-line game build guide entirely solo — web searched, compiled, formatted, uploaded. Never once thought to involve Codex. The result had 4 real errors (wrong data, wrong mechanic descriptions, broken links) that Codex caught on first read. The user's reaction was: "Why do I have to TELL you to use Codex? You should default to it." The root cause was a hidden mental gating: "Codex is for coding, not for knowledge work."

**Pre-commit checklist (before any user-facing output):**
- [ ] Has Codex seen this? (If no → pause and loop them in)
- [ ] Is this a plan/proposal/decision about what to do, not just a final output? (If yes → Codex must see it BEFORE the user, not after)
- [ ] Am I subconsciously gating Codex into a "coding only"/"execution only" box? (If yes → stop that)
- [ ] Did I remember to involve Codex BEFORE finishing, not after the user points it out?

**Hard rule: If you realize mid-task that you haven't looped in Codex, stop and loop them in. Do NOT finish solo and "remember" after the fact.**

Only skip Codex if it actively reports quota exhaustion. Do not preemptively conserve quota.

### 7. "Plan decision" fallacy (2026-06-03)

**New failure mode:** I presented a technical plan ("should we rewrite daily_diary.sh as Python?") to the user *before* involving Codex. The user caught it: "问过CODEX了嘛？"

The existing rule *says* "Do not produce output to the user before Codex has seen it" — but I mentally exempted "plans and proposals" from "output" because I subconsciously gated Codex as an *executor* (writes the code) rather than an *advisor* (reviews the plan).

**Root cause:** I internalized the rule as "Codex reviews my final output before the user sees it" when the actual rule is "Codex participates in every stage — including strategic decisions about what to do."

**Fix — explicit expansion of what counts as "output":**
- A **plan** I intend to propose to the user = output → Codex must see it first
- A **diagnosis** of what's wrong = output → Codex must see it first  
- A **decision** between approaches (rewrite vs patch, tool A vs tool B) = output → Codex must see it first
- A **proposed architecture** or design = output → Codex must see it first

**Trigger for self-audit:** Any time I'm about to type a response that starts with a proposal, recommendation, or "we should..." — STOP. Delegate to Codex first with the full context. The user should never receive a plan I haven't pressure-tested with Codex.

**Concrete failure chain from this session:**
1. User asked "这个CRON，每次修，每次都会有新问题；怎么办？" → I immediately formulated a plan (rewrite as Python) and started presenting it
2. I never once thought to pause and ask Codex "is rewriting the right call, and if so, what should the design look like?"
3. User had to prompt me: "问过CODEX了嘛？"
4. Codex then produced a much deeper analysis (discovered the 26-layer Drive nesting I had completely missed) that fundamentally changed the scope of the work

**The key insight:** If I had gone to Codex FIRST, I would have discovered the Drive data pollution *before* presenting any plan. The user would have seen a more complete picture from the start.

### 2. Reasoning depth

| Level | When |
|-------|------|
| `medium` | Default. Use for all routine tasks. |
| `high` | Complex logic, multi-file refactors, non-trivial debugging. |
| `xhigh` | Deep reasoning problems, architecture design, algorithmic work. |

**NOTE**: `--reasoning-effort` flag is NOT supported in Codex v0.133.0. Remove it if using non-standard flags errors out. The `-c` flag variant may also fail — test once before relying on it.
```
# ❌ This will error in v0.133.0:
codex --reasoning-effort high exec "..."

# ✅ Just exec without it:
codex exec "..."
```

### 3. Quota management

Codex CLI doesn't expose remaining quota via CLI. Check empirically:
- If Codex runs without error → quota is fine
- If Codex errors with quota-related message → skip it for this session, fall back to DeepSeek
- Do not track or log quota state in memory — it changes frequently

### 4. Always verify before answering

**This is a hard rule.** Before answering any integration question about Codex, load this skill AND run a terminal check:
```bash
which codex && codex --version && cat ~/.codex/auth.json | python3 -c "import json,sys; d=json.load(sys.stdin); print('auth:', d.get('auth_mode'))"
```
Do NOT reason from general knowledge or past experience. The user has explicitly corrected this behaviour.

### 5. Privacy model (2026-05-27)

Codex CLI **has no separate privacy/data-sharing setting**—it's a local CLI tool. The only privacy control is in ChatGPT Settings:
```
Settings → Data Controls → Improve the model for everyone → OFF
```
- When OFF: new conversations (including Codex requests) are not used for model training
- OpenAI still retains data for safety/abuse detection (unavoidable compliance requirement)
- Codex uses the same ChatGPT auth as the browser session, so the same toggle applies
- `runtime_metrics` feature (the only potential telemetry) is `under development` + **disabled by default**
- Session history is stored locally in `~/.codex/sessions/`, not sent externally

### 6. Anti-compression audit (2026-06-01)

When the user asks you (Codex) to review or analyze something involving rules, roles, processes, or data that 小H defined, you MUST also audit whether 小H has compressed multi-dimensional rules into single-dimension labels.

**Audit checklist (run alongside the primary task):**
1. Has 小H taken a 2D rule (e.g. 职能+领域) and flattened it to 1D (只剩领域)?
2. Has 小H downgraded a "must/always/every" constraint to "when relevant"?
3. Has 小H written unverified specific values (攻略/配置/参数) instead of marking them "待核验"?
4. Did 小H miss a participant or process step the user specified?
5. Did 小H replace user-defined terminology with common-sense reinterpretation?

Findings go directly into the response — this is not extra advice, it is the standard check.

### Pitfall: "Compression distortion" in task routing

**I have a stable pattern of compressing multi-dimensional rules into single-dimension labels, then executing from the compressed version as if it were the original.** This is NOT limited to Codex — it affects agent routing, data accuracy, and process compliance.

The specific pattern for Codex:
- **Original rule**: "Every task, without exception, must involve Codex for analysis, review, and brainstorming — not just coding."
- **Compressed version in my head**: "Codex = coding tool, call when writing code."
- **Failure mode**: I completed a 539-line game build guide entirely solo (PoE2), never thinking to involve Codex. Codex then caught 4 real errors + 6 optimizations on first read.
- **Pattern**: When I've used Codex most often for coding, I subconsciously redefine "Codex = coding tool" even though the explicit rule says "every task." This is NOT a memory failure — it's semantic compression distortion.

**Prevention**: Before any task output, run the compression check from `low-cost-federation` skill's "防压缩失真" section. Question \#2 is specifically: "Did I downgrade a must/always rule ('every task') to conditional-on-relevance ('coding only')?"

## Pitfalls (other)** — check `~/.codex/auth.json` to see if it uses API key or ChatGPT tokens before claiming a setup cost. On this VPS it uses ChatGPT Plus tokens, not a separate API key.
- **Don't assume it's not installed** — check `which codex` and `npm list -g @openai/codex` before claiming it needs setup. On this VPS it's already at `/usr/bin/codex`.
- **Always verify before answering integration questions** — load this skill and check the actual environment (installed, auth mode, version) instead of reasoning from general knowledge. The user will notice if you skip this step.
- **When the user says your analysis is wrong/bad → delegate to Codex immediately.** Do NOT try to fix it yourself first. The correct pattern is: gather all context you already have → feed it to Codex with the user's criticism and any new constraints → let Codex do a fresh deep dive → merge insights into your final answer. This applies especially to domain-specific knowledge (game mechanics, esoteric tool chains, obscure APIs) where you're operating at the edge of your training data. The user's signal is clear: "流放之路2的问题，我觉得你分析的不好，让codex试试" — stop iterating alone, loop in Codex with full context.

## References

- `references/poe2-guide-review.md` — Concrete example of Codex catching errors I never would have (4 real errors + 6 optimizations in a 539-line game guide). Demonstrates the "different perspectives" value that is the core philosophy of this skill.
- `references/vps-optimization-case.md` — Real-world example of multi-round convergence (VPS network optimization). Demonstrates Codex catching false assumptions and preventing wasted effort.
- `references/session-memory-model.md` — Codex has NO persistent memory; every `exec` is fresh. Key difference from Hermes memory system.
- `references/vps-setup.md` — VPS setup reference.
