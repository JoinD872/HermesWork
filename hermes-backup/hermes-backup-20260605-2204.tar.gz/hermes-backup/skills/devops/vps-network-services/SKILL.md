---
name: vps-network-services
description: VPS 网络服务搭建与管理 — 包含 OAuth 代理（socat 端口转发）和 Xray VLESS+REALITY 节点配置。防火墙、端口检查、服务管理等通用 VPS 基础设施操作。
tags:
  - vps
  - network
  - oauth
  - xray
  - reality
  - vless
  - proxy
  - socat
risk: write-safe
---

# VPS 网络服务搭建

本技能覆盖在 headless VPS 上搭建和配置各类网络服务的通用模式。当前包含两种常见服务：

- **OAuth 代理** — 使用 socat 端口转发在无浏览器 VPS 上完成 CLI 工具 OAuth 授权
- **Xray VLESS+REALITY 节点** — 添加新的 VLESS+REALITY 入站节点

## 通用前置条件

- VPS 已安装 root 或 sudo 权限
- SSH 可访问
- UFW 防火墙已安装

## OAuth 代理（无浏览器环境下的授权方法）

### 适用场景

VPS 没有图形界面和浏览器，但 CLI 工具（rclone、gcloud、aws、gh CLI 等）的首次授权需要打开浏览器完成 OAuth 流程。

### 核心思路

利用 VPS 的公网 IP + 端口转发工具（socat），将 OAuth 本地回环服务器暴露到公网，用户从自己的机器访问并完成授权。

### 通用步骤

#### 1. 安装 socat（如未安装）

```bash
which socat || apt-get install -y socat
```

#### 2. 放行端口（UFW）

```bash
ufw allow <端口号>/tcp comment "OAuth temp"
```

#### 3. 启动 OAuth 授权 + socat 转发

```
步骤 A：启动 CLI 工具的 OAuth 授权命令
        → 它会监听在 127.0.0.1:<端口>（通常是 53682 或 8080）
步骤 B：启动 socat，把 0.0.0.0:<公网端口> 转发到 127.0.0.1:<OAuth端口>
        socat TCP-LISTEN:<公网端口>,reuseaddr,fork TCP:127.0.0.1:<OAuth端口>
```

#### 4. 给用户授权链接

```
http://<VPS公网IP>:<公网端口>/auth?state=...
```

#### 5. 用户操作流程

1. 打开上面的链接 → 跳转到 Google/GitHub/其他 OAuth 提供方的登录页
2. 登录账户，点击「允许」
3. 授权后会跳转到 `http://127.0.0.1:<OAuth端口>/auth?code=...`（页面打不开）
4. **用户手动修改浏览器地址栏**：把 `127.0.0.1:<OAuth端口>` 改成 `<VPS公网IP>:<公网端口>`
5. 按回车 → 授权完成，页面显示「Success!」

#### 6. 收尾

```bash
# 移除 UFW 规则
ufw delete allow <公网端口>/tcp
# 关闭 socat 和 OAuth 进程
kill %1 %2 2>/dev/null
```

### rclone Google Drive 具体实战

完整流程参见 `references/rclone-gdrive-config.md`。关键命令序列：

```bash
# 1. 后台启动 rclone 授权
rclone authorize "drive" > /tmp/rclone_auth.log 2>&1 &

# 2. 确认端口已监听
sleep 2
ss -tlnp | grep 53682

# 3. 放行 UFW
ufw allow 53683/tcp comment "rclone OAuth temp"

# 4. socat 转发（公网端口 53683 → VPS 127.0.0.1:53682）
socat TCP-LISTEN:53683,reuseaddr,fork TCP:127.0.0.1:53682 &

# 5. 提取授权 URL
cat /tmp/rclone_auth.log | grep "go to the following link"

# 6. 用户访问 http://192.3.241.244:53683/auth?state=...

# 7. 完成后清理
ufw delete allow 53683/tcp
pkill -f "rclone authorize" 2>/dev/null
pkill -f "socat.*53683" 2>/dev/null
```

### ⚠️ GFW 关键坑

OAuth 授权进程（`rclone authorize "drive"`）**必须在 VPS 上运行**，不能在 GFW 内用户本地机器上跑。

**原因**：OAuth 流程分两步：
1. 用户授权（浏览器 → accounts.google.com）— GFW 内可访问
2. Token exchange（CLI → oauth2.googleapis.com/token）— **GFW 拦截**

Token exchange 需要直连 Google 服务器，上海（GFW 内）的 Windows 无法完成。VPS（洛杉矶）无此问题。

### 常见陷阱

| 陷阱 | 说明 | 解法 |
|------|------|------|
| socat 端口冲突 | rclone 已占 53682，socat 无法 bind 同一端口 | socat 用不同端口（如 53683），让用户修正 URL 时一起改端口号 |
| UFW 拦截 | INPUT 策略 DROP，未放行的端口外部不可达 | `ufw allow <端口>` 或限制来源 IP |
| iptables DNAT 失效 | PREROUTING DNAT 到 127.0.0.1 回程路由异常 | 改用 socat 端口转发，更可靠 |
| OAuth 超时 | 授权码有效期短（通常 5-10 分钟） | 提前准备好所有步骤，用户操作要连贯 |

### 替代方案

| 方案 | 优点 | 缺点 |
|------|------|------|
| socat 端口转发 | 轻量、无需额外工具 | 用户需手动修正 URL |
| Cloudflare Tunnel 代理 | 无需暴露额外端口 | 配置复杂，需修改 tunnel yaml |
| 用户本地装 CLI 授权 | 流程最顺畅 | 用户需在自己机器安装对应 CLI |
| SSH 端口转发 | 安全 | 用户需 SSH 客户端和 VPS 私钥 |

---

## Xray VLESS+REALITY 节点

在已有 Xray 的 VPS 上，新增一个 VLESS+REALITY 入站节点，用于 Shadowrocket (iOS) 和 V2RayN (Windows) 双端代理。

### 前置条件

- VPS 已安装 Xray（`/usr/local/bin/xray`）
- Xray systemd 服务已启用
- root 或 sudo 权限
- 目标端口未被占用

### 步骤

#### 1. 检查现有配置

```bash
cat /usr/local/etc/xray/config.json     # 查看现有 inbounds
ss -tlnp | grep -E '(xray|443|8443)'    # 检查端口占用
ufw status                               # 检查防火墙放行
```

#### 2. 生成密钥对

```bash
xray x25519                              # PrivateKey + PublicKey
xray uuid                                # 客户端 UUID
```

#### 3. 选择伪装目标域名

REALITY 会将非代理流量转发到目标网站。推荐：`www.apple.com`、`www.microsoft.com`、`www.amazon.com`、`www.cloudflare.com`

验证目标域名可达：
```bash
echo "" | openssl s_client -connect www.apple.com:443 -servername www.apple.com 2>&1 | grep "subject="
```

#### 4. 编辑 Xray 配置

在 `config.json` 的 `inbounds` 数组中添加新节点。配置模板见 `templates/reality-inbound-template.json`。

**关键参数说明**：

| 参数 | 值 | 说明 |
|------|-----|------|
| port | 443 或 8443 | 推荐443（伪装HTTPS）或高位端口 |
| flow | xtls-rprx-vision | REALITY 推荐 flow，改善 UDP 性能 |
| shortIds | 短 hex 串（如 6ba8e4f03d） | 可设多个，客户端任选一个 |
| serverNames | www.apple.com | 必须与 dest 域名匹配 |
| fingerprint | chrome | TLS 指纹伪装成 Chrome 浏览器 |

#### 5. 重启 Xray

```bash
systemctl restart xray
sleep 2
systemctl status xray --no-pager -l | head -15
ss -tlnp | grep xray    # 确认新端口在监听
```

#### 6. 伪装验证

```bash
# 验证证书伪装
echo "" | openssl s_client -connect <VPS_IP>:443 -servername www.apple.com 2>&1 | grep -E "subject=|issuer="

# 验证 HTTP 请求转发
curl -sk --connect-timeout 5 https://<VPS_IP>:443/ 2>&1 | head -5
```

预期：openssl 返回目标网站 EV 证书；curl 返回目标服务器的响应。

#### 7. 防火墙

```bash
ufw allow 443/tcp
```

#### 8. 生成客户端配置

**Shadowrocket (iOS)** vless:// URI：
```
vless://<UUID>@<SERVER_IP>:<PORT>?type=tcp&security=reality&pbk=<PUBLIC_KEY>&fp=chrome&sni=<SERVER_NAME>&sid=<SHORT_ID>&flow=xtls-rprx-vision#<NAME>
```

**V2RayN (Windows)** 手动配置：

| 字段 | 值 |
|------|-----|
| 地址 | VPS IP |
| 端口 | 443 |
| 用户ID | UUID |
| 加密方式 | none |
| 传输协议 | tcp |
| 伪装类型 | none |
| 安全 | reality |
| PublicKey | 生成的 PublicKey |
| ShortId | 如 6ba8e4f03d |
| ServerName | 如 www.apple.com |
| Fingerprint | chrome |
| Flow | xtls-rprx-vision |

### 坑与注意事项

1. **端口冲突**：443 已被 nginx 占用时，改用其他端口或先停 nginx
2. **Xray 配置语法**：`flow` 放在 `settings.clients[].flow` 中，不在 `streamSettings` 层
3. **shortIds 冲突**：不同节点用不同的 shortId
4. **fingerprint 必须指定**：REALITY 节点缺省 fingerprint 会导致客户端连接失败
5. **sniffing 开启**：建议开启 sniffing + destOverride 改善 DNS
6. **V2RayN 版本**：旧版可能不支持 `xtls-rprx-vision`，可降级为 `xtls-rprx-direct`

## 参考文档

- `references/rclone-gdrive-config.md` — rclone Google Drive OAuth 完整配置记录（含 GFW 关键坑）
- `templates/reality-inbound-template.json` — Xray REALITY 入站配置模板
