---
name: security-preflight
description: 任何系统改动前的安全检查清单 — 端口/密钥/权限/持久化/回滚/连通性。输出结构化风险矩阵，拦截高风险操作
version: 1.0.0
risk: write-dangerous
---

# Security Preflight

在**任何系统改动前**加载此 skill。逐项检查，全部通过后才能执行改动。

## 风险矩阵

```
## 风险矩阵

| 检查项 | 状态 | 风险等级 | 缓解措施 |
|--------|------|---------|---------|
| 端口变动 | ⬜ | 高/中/低 | ... |
| 密钥暴露 | ⬜ | 高/中/低 | ... |
| 权限提升 | ⬜ | 高/中/低 | ... |
| 持久化 | ⬜ | 高/中/低 | ... |
| 回滚路径 | ⬜ | 高/中/低 | ... |
| 连通性变化 | ⬜ | 高/中/低 | ... |
| 验证命令 | ⬜ | 高/中/低 | ... |

决策: PROCEED / BLOCKED / USER_APPROVAL_REQUIRED
```

## 检查清单

### 1. 端口变动

改前记录：`ss -tlnp`
改后对比：`ss -tlnp`

- [ ] 是否有端口被打开？如果是，是否需要认证/firewall/TLS？
- [ ] 是否有端口被关闭？如果是，是否影响依赖服务？
- [ ] 新端口是否仅限内网或需要公网？

### 2. 密钥/凭据暴露

- [ ] API Key / Token / 密码 是否会出现在 Git、日志、shell history、进程参数、世界可读文件中？
- [ ] 配置文件中是否硬编码了凭据？
- [ ] `.env` 文件权限是否正确（600）？

### 3. 权限提升

- [ ] 是否需要 sudo？具体哪个命令？
- [ ] 服务是否以 root 运行？能否降权？
- [ ] 文件权限是否被放宽？

### 4. 持久化

- [ ] 改动在重启后是否保留？
- [ ] 如果是 systemd 服务：`systemctl enable`？
- [ ] 如果是 CRON：`crontab -l` 确认持久？
- [ ] 如果是 Docker：`--restart always` / docker-compose 配置？

### 5. 回滚路径

- [ ] 回滚命令是否已知且可执行？
- [ ] 备份是否已完成？（`cp file file.bak.$(date +%s)`）
- [ ] 如果回滚不可行，标记为 BLOCKED 直到用户确认风险

回滚命令示例：
```bash
# Rollback
cp /path/to/file.bak.XXXXXXX /path/to/file
systemctl restart SERVICE
```

### 6. 外部连通性变化

- [ ] 是否改变了 DNS、TLS、反向代理、webhook、API 调用目标？
- [ ] 是否改变了出站规则？
- [ ] 验证：`curl -I https://TARGET`、`dig DOMAIN`、`sudo nginx -t`

### 7. 验证命令

- [ ] 存在一个可执行的、具体的验证命令
- [ ] 验证命令有明确的 Pass/Fail 判断标准
- [ ] 验证命令不依赖人工检查（自动判断）

## 拦截规则

出现以下任一情况，**BLOCK 执行**直到问题解决：

1. 公网端口被打开但没有认证/firewall/TLS 计划
2. 密钥可能暴露在 Git/log/shell history/world-readable 文件中
3. 需要提权但不清楚具体提权操作
4. 需要持久化但未配置/验证
5. 破坏性改动或生产改动没有回滚路径
6. 外部连通性改变未知或未验证
7. 没有可执行的验证命令

## 执行后

改动执行完成后，重新运行验证命令，更新状态为 Pass/Fail。

最终输出：
```
## 改动后验证
| 检查项 | 命令 | 结果 | 证据 |
|--------|------|------|------|
| ... | ... | Pass/Fail | 输出摘要 |

最终状态: PASS / FAIL / ROLLED BACK
```
