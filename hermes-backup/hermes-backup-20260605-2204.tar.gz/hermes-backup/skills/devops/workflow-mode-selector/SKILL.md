---
name: workflow-mode-selector
description: 三分工作流模式 — quick(小H单独)/converge(小H+Codex一轮)/deep(多轮Codex高推理+全收敛)。每次任务先选模式再开工
version: 1.0.0
risk: read-only
---

# Workflow Mode Selector

每次收到任务，先判断工作模式。

## Mode 1: quick

**小H独立完成，单步执行，不调 Codex。**

### 触发条件（全部满足才选 quick）
- [ ] 只需要读取、搜索、解释、回答
- [ ] 单步操作（读文件、查状态、跑一条命令）
- [ ] 不涉及系统改动
- [ ] 不需要 Codex 级别的代码执行

### 示例
- 查文件内容、查状态
- 解释配置含义
- 展示当前系统信息
- 简单问答

### Quick 流程
1. 理解需求
2. 直接用我（DeepSeek）的工具执行
3. 返回结果

### Quick 约束
- ❌ 不用 Codex
- ❌ 不走规划循环
- ❌ 不做系统改动（除非升级模式）

### 升级到 converge 的条件
- 需要多步实现
- 验证失败
- 触及系统配置
- 需要 Codex 级别的代码/调试
- 风险不明确

---

## Mode 2: converge

**小H独立出判断→Codex验证/补漏→小H审查→可循环一轮。**

> ⚠️ **关键纪律：小H先出判断，再调 Codex。** 每次 converge 模式开始前，小H必须先用自己的分析形成初步方案或判断方向，再用 Codex 验证、查漏、执行细节。
>
> 反例（2026-05-23 纠正）：小H直接让 Codex 开第一枪出方案→小H只是评审/微调→导致方案立意被 Codex 主导。
> 正确做法：小H先说出自己的思路→Codex补充或反驳→小H做最终决定。
>
> 🧠 **Codex 无持久记忆** — 每次派发给 Codex 是全新会话。它不知道用户的偏好、不知道我的 skill 库、不知道项目上下文。因此在派发 prompt 中必须明确附带：用户风格偏好、相关 skill 知识、历史教训等关键背景。

### 触发条件（任一满足即可）
- [ ] 需要跨文件的代码改动
- [ ] 需要调试和测试
- [ ] 需要 VPS/服务/配置改动
- [ ] 涉及 systemd/nginx/Docker/cron/firewall/包管理/部署/env 变量
- [ ] 需要 Codex 执行但不是多轮独立研究
- [ ] 风险中等但有明确的预期结果
- [ ] 用户要求实现/修复/配置/部署/安装/验证

### 示例
- 修复路由、编辑配置、加 cron、改 nginx
- 安装并配置服务、写脚本并测试
- 调试测试、加功能、部署步骤验证

### Converge 流程
1. 小H确定范围 → 选择验证标准
2. 如涉及系统改动 → 加载 security-preflight
3. 小H派发有界任务给 Codex
4. 加载 codex-execution-contract
5. Codex 返回执行合约
6. 小H审查 → ACCEPT/RETRY/REJECT
7. 小H汇报最终结果

### Converge 派发前置输出
```markdown
Mode: converge
Reason:
Goal:
Allowed scope:
Verification:
Rollback expectation:
```

### 循环规则
- 正常情况下 Codex 一轮
- 验证失败或小了漏时允许第二轮
- 超过两轮 → 升级到 deep

---

## Mode 3: deep

**多轮 Codex + 高推理 + 完整收敛循环。高风险/模糊/多阶段/架构级任务。**

### 触发条件（任一满足即选）
- [ ] 可能影响生产可用性
- [ ] 可能影响安全边界
- [ ] 可能暴露或轮换密钥
- [ ] 改动 SSH/firewall/认证/TLS/DNS/备份/数据库/基础设施
- [ ] 需要多轮 Codex + 中间审查
- [ ] 需要高推理、架构分析、迁移规划、分阶段实施
- [ ] 当前状态不明确
- [ ] 需要破坏性操作
- [ ] 涉及数据迁移、服务替换、故障恢复
- [ ] 用户明确要求深度调查

### Deep 流程
1. 小H声明 deep mode 原因
2. 小H只读收集当前状态
3. 小H构建风险感知计划
4. 加载 security-preflight（如需系统改动）
5. 加载 codex-execution-contract
6. 小H派发有界任务给 Codex（使用 -c reasoning_effort="high"）
7. Codex 返回执行合约
8. 小H审查 → ACCEPT/RETRY/REJECT
9. 小H独立验证最终状态
10. 小H返回最终状态、证据、残余风险、回滚路径

### Deep 轮次类型
```
Round 1: Discovery — 只读，输出发现/风险/计划
Round 2: Implementation — 指定文件/服务，输出完整合约
Round 3: Verification/Fix — 验证+限定修复
```

### Deep 闸门
在 discovery → implementation 之前，必须确认：
- [ ] 当前状态已知
- [ ] 期望最终状态已知
- [ ] 受影响的文件/服务已知
- [ ] 风险矩阵已输出
- [ ] 回滚路径存在
- [ ] 验证命令存在
- [ ] 破坏性改动已获用户批准

---

## 模式选择规则

1. 取最高所需模式：同时符合 quick 和 converge → 选 converge
2. 同时符合 converge 和 deep → 选 deep
3. 不确定时选更高的安全模式
4. **修过 2 次以上的 bug 自动升一级**：即使表面看起来是 quick，但历史复发记录表明你没找到根因 → 至少 converge

## 常见陷阱

### 陷阱1：过度依赖 Codex

**现象**：小H把问题直接丢给 Codex 开第一枪 → Codex 出方案 → 小H只做评审/微调。结果方案立意被 Codex 主导。

**根源**：Codex 高模型输出质量高、速度快，容易让人偷懒先让它跑。

**修正**：
- 每个 converge/deep 任务开始前，**小H先写自己的初步判断**（哪怕只有 2-3 句观点）
- 然后再用 Codex 来验证、补漏、执行具体细节
- 最终决策权在**小H**，不是 Codex

### 陷阱2：低估任务、未充分使用 Codex

**现象**：小H自己处理了本应让 Codex 参与的任务，用户提醒「让 Codex 看看」。这通常是因为小H把任务评为「低难度」就不再深挖，结果只修了症状没动根因。

**信号**（满足任一就要警觉）：
- 同一个 bug 你修了 2 次以上还遇到 → 你没找到根因，让 Codex 来诊断
- 用户说「让 Codex 看看」→ 你已经错过了自我纠正的机会，立刻找 Codex
- 你准备评「低难度」但心里隐隐觉得「可能还有别的地方也这样」→ 查全盘，让 Codex 验证
- 修复只改了当前文件/当前字段，没检查相关文档和技能 → Codex 做全盘扫描

**修正**：
- 凡是修过 2 次以上的 bug，不允许 self-execute，必须 escalate 到 converge 或 deep
- 先在 prompt 中告诉 Codex 你的初步诊断，让它验证或反驳
- Codex 跑完后认真审查它发现的额外问题——它挖出来的「5 处源文档毒源」是我自己没查到的

### 陷阱3：忘记 Codex 没有记忆

**现象**：派发任务给 Codex 时假设它知道用户偏好、项目上下文、技能信息。结果 Codex 输出风格/格式/方向偏移。

**修正**：
- 每次派发必须附带关键上下文：用户风格偏好、相关的 skill 知识、历史教训
- 不能假设 Codex 记得任何之前的信息
- 格式参考 `codex-execution-contract` skill

### 陷阱3：未遵循安全预检

**现象**：系统改动前没加载 `security-preflight`，直接派给 Codex 执行，改完后发现端口/密钥/回滚考虑不周。

**修正**：
- 任何系统改动前强制加载 `security-preflight`
- 不改系统时不用加载

## 停止条件

以下任一情况，停止并询问用户：
- 需要破坏性数据改动
- 回滚路径缺失
- 密钥暴露风险
- Codex 越过了允许范围
- 验证连续失败 2 次
- 生产可用性可能受影响
- 当前系统状态与计划矛盾
- 请求的改动不安全或模糊
