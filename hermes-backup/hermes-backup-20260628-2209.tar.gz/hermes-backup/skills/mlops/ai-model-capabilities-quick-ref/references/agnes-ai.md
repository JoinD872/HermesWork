# Agnes AI (Sapiens AI) 全模态模型速查

> 来源：2026-06-09 对话中用户要求评估 3 个模型是否可用、免费、有限制
> 官网：https://agnes-ai.com ｜ API 平台：https://platform.agnes-ai.com
> 新加坡 AI 实验室，Google Cloud 合作方，6 个月 500 万+ 注册用户

## 免费政策

**2026-06-01 起永久免费**。官方声明 "Agnes 2.0 is free. Indefinitely. No waitlist."
无需绑信用卡，注册即用。无 SLA 保证。

## 模型清单

### Agnes-2.0-Flash — 聊天/Agent 模型

| 属性 | 值 |
|------|-----|
| 版本 | 2.0（用户提到的 2.1/v2.0 是版本号命名混淆，当前最新是 2.0） |
| 能力 | 聊天、Agent 工作流、Tool Calling、编程、推理、多轮对话、图片理解 |
| 上下文 | 128K tokens |
| 基准 | Claw-Eval #9（Pass³ 60.9%） |
| API | OpenAI 兼容 `/v1/chat/completions` |
| 定价 | **免费**（正常价 $0.1/1M 输入，当前 $0） |
| 限制 | 20 RPM |

### Agnes-Image-2.1-Flash — 图片生成

| 属性 | 值 |
|------|-----|
| 版本 | 2.1（比 2.0 更新，注意用户问的是 2.1 不是 2.0） |
| 能力 | 文生图、图生图（img2img）、图片理解/视觉识别 |
| 基准 | Artificial Analysis 全球 Top 10（图片编辑榜）|
| 统计 | 上线以来已生成 200 万+ 张图片 |
| API | OpenAI 兼容 `/v1/images/generations` |
| 定价 | **免费**（正常价 $0.008/张） |
| 限制 | 20 RPM |

### Agnes-Video-V2.0 — 视频生成

| 属性 | 值 |
|------|-----|
| 发布日期 | 2026-03-18（用户标注的 3/18 即此日期） |
| 能力 | 文生视频、图生视频、多图视频、原生音频生成 |
| 基准 | Artificial Analysis 文生视频排行榜（最近新增） |
| 统计 | 已生成 200 万+ 秒视频 |
| API | 可通过统一 API 调用 |
| 定价 | **免费**（正常价 ~$0.30/分钟，极低价） |
| 限制 | 20 RPM |

## 免费限制

| 限制项 | 数值 |
|--------|------|
| RPM（每分钟请求数）| **20** |
| TPS | Basic 限制 + fair-use 配额 |
| SLA | 无 |
| 适用场景 | 个人开发、Demo、中小规模自动化 |

## 实用提示

- 三个模型共享同一个 API Key 和同一个 20 RPM 配额
- 全部走同一个 Base URL（`https://agnes-ai.com/v1`），用不同的模型名区分
- OpenAI 兼容，现有 Hermes 或代码无需大改即可接入
- 新加坡机房，VPS（洛杉矶）直连延迟低
- 相比 DeepSeek V4 Flash：Agent 能力弱一些（#9 vs DeepSeek #1-3），但免费且有多模态
