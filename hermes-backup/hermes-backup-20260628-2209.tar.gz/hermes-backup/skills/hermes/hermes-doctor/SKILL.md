---
name: hermes-doctor
description: Hermes 技能级健康自检系统 — 一键检查所有关键能力（搜索/社区/API/系统/工具），输出结构化报告 + 历史趋势追踪 + 渠道路由探测
risk: read-only
version: 1.1.0
created: 2026-06-14
---

# Hermes Doctor v1.1 — 技能级健康自检

## 概述

Hermes Doctor 是 Agent-Reach 的 `doctor` 机制在 Hermes 系统中的移植。v1.1 增加了 Channel Doctor（多后端路由探测）。

## 触发方式

```bash
# 正常输出（人类可读）
python3 ~/.hermes/scripts/doctor.py

# JSON 输出（cron / 程序消费）
python3 ~/.hermes/scripts/doctor.py --json

# 带历史追踪（保存 + 趋势分析）
python3 ~/.hermes/scripts/doctor.py --history
```

## 自动运行

Cron Job `0e08c8ce16e2` 每12小时（0:00 / 12:00 UTC）自动运行：
- 无状态变化 → 静默（不发消息）
- 状态变化 → 自动告警到 origin

## Doctor v1.1 变化

### 新增：Channel Doctor（渠道路由探测）

多后端探测，记录每个后端成功/失败 + 延迟。

| 渠道 | 后端1 | 后端2 | 后端3 |
|------|-------|-------|-------|
| **YouTube** | yt-dlp (字幕) | Browser (Playwright) | Jina Reader |
| **GitHub** | gh CLI | API (repo) | API (search) |
| **Reddit** | old.reddit JSON | Jina Reader | crawl4ai |

### 输出示例（Channel Doctor 部分）

```
── 📡 渠道路由探测 ──

  📺 YouTube:
    ⬢ yt-dlp          ✅    2.6s  字幕可用
    ⬢ Browser         ✅    2.2s  Playwright 可用
    ⬡ Jina            ⚠️    0.1s  403 Forbidden
    🏆 推荐: Browser (2.2s)

  📺 GitHub:
    ⬢ gh CLI          ✅    0.4s  gh view HermesWork OK
    ⬢ API (repo)      ✅    0.1s  200
    ⬢ API (search)    ✅    0.1s  200
    🏆 推荐: API (search) (0.12s)

  📺 Reddit:
    ⬡ old.reddit      ⚠️    0.1s  403 Blocked
    ⬡ Jina            ⚠️    0.1s  403 Forbidden
    ⬡ crawl4ai        ⚠️    9.2s  FETCH failed
    🏆 推荐: 无可用后端
```

## 当前基线（2026-06-14）

| 类别 | 项 | 状态 |
|------|-----|------|
| 🔧 基础设施 | SearXNG | ✅ |
| 🔧 基础设施 | DeepSeek API | ✅ |
| 🔧 基础设施 | Browser/Playwright | ✅ |
| 📺 社区 | YouTube | ✅ |
| 📺 社区 | Hacker News | ✅ |
| 📺 社区 | V2EX | ✅ |
| 📺 社区 | 掘金 | ✅ |
| 📺 社区 | 知乎 | ✅ |
| 📺 社区 | GitHub API | ✅ |
| 📺 社区 | gh CLI | ✅ |
| 🖥️ 系统 | VPS SSH | ✅ |
| 🖥️ 系统 | Windows SSH | ⚠️ |
| 🖥️ 系统 | 磁盘 23/43GB | ✅ |
| 🖥️ 系统 | 内存 | ✅ |
| 📡 路由 | YouTube: yt-dlp ✅ | |
| 📡 路由 | GitHub: all 3 OK | |
| 📡 路由 | Reddit: ALL FAIL | ⚠️ |

## 已知的待改进

### Reddit 完全不可达
三个后端全部失败（403/403/crawl4ai FETCH失败）。需要更长远的方案：
- 选项A: 通过 Windows 桌面代理访问（Tailscale 修好后的方案）
- 选项B: 通过新的 VPS 出口 IP
- 选项C: 放弃 Reddit，转用 Hacker News + Twitter 替代

### Jina Reader 403
VPS IP 被 Jina Reader 或目标站点封锁。对实际工作影响小，因为 yt-dlp 和 gh CLI 是主力。

## 计划中的改进

- [ ] **渠道扩展**：增加更多后端探测（HN, V2EX, 掘金）
- [ ] **健康感知路由**：Doctor 输出 → 路由自动跳过不可用后端
- [ ] **延迟监控**：长期记录每个后端的 P50/P95 延迟
- [ ] **Webhook 告警**：连续 N 次异常 → 飞书通知

## 响应医生结果的工作流

当用户运行 doctor 看到 ⚠️/❌ 时：
1. 对于基础设施（SearXNG, DeepSeek, SSH）— 优先修复
2. 对于渠道（YouTube/GitHub/Reddit）— 检查单后端或多后端失效
3. 查看历史趋势判断是否遗留问题还是新发
4. 对于新发异常 → 立即诊断；对于已知持续问题 → 评估是否换方案
