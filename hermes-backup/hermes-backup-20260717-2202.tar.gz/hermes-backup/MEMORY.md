GitHub PAT 实际位置在 /root/.hermes/scripts/hermes-backup.sh（不在 .env），用户 JoinD872，仓库 JoinD872/HermesWork（私人），Token 前缀 ghp_6q...XGvJ。以后查 GitHub 认证先看 backup.sh。
§
用户云端迭代工作流 — 主力走 GitHub：文件放 JoinD872/HermesWork/workspace/，用户在网页版改，我读+改+提交推送。不走百度网盘/飞书云盘。补充：Google Drive 用于 Obsidian Cloud Inbox（HermesInbox/ 文件夹，每30min拉取到 Vault 收件箱），仅做灵感投递不用于代码迭代。
§
## 低频流程索引（详情查对应 skill）
宠物技能设计：skill `pet-skill-design-workflow` | crawl4ai：skill `community-scraping` | 日记格式：skill `obsidian`
§
图片理解：主力 OpenCode Go minimax-m3（视觉），备用 GitHub Models gpt-4o（免费）。不用 DeepSeek 直连（用户要求非订阅付费 API 不用）。
§
VPS 隧道架构（2026-07-17）：Docker-tunnel = systemd 服务（`cloudflared-docker-tunnel.service`），服务于 `proxy.cloudjoind.com` 翻墙代理；JoinD-tunnel = Docker 容器（`cloudflared-joined`）。两者独立不冲突。Docker 容器有 IPv6 DNS 超时问题（不影响功能）。
§
知乎已升级为官方API：ZHIHU_ACCESS_SECRET存于.env，developer.zhihu.com，每天1000次免费搜索。
§
## 通知与日记偏好
无事不通知；cron 用 silent script + deliver=local。Vault/日记默认被动，不主动读/写，等用户问再说。日记路径：~/.hermes/ObsidianVault/日记/ | 模板在 模板/日记模板.md
§
AI 偏好：Gemini "回答简短、语言贫乏、刻意迎合"；GPT "内容衍生多、思维更广"。不要 yes-man，要能发散碰撞的对话伙伴。
§
Codex CLI 当前版本 0.133.0（2026-05-23 升级）。Codex 无持久记忆——每次 exec 独立会话，需显式附带上下文。高推理模式：`codex exec -c 'reasoning_effort="high"'`。
§
## VPS 隧道架构（2026-07-17 修正）
- **Docker-tunnel** = systemd 服务（`cloudflared-docker-tunnel.service`），用 `systemctl restart cloudflared-docker-tunnel`，**服务于 `proxy.cloudjoind.com` 翻墙代理**
- **JoinD-tunnel** = Docker 容器（`cloudflared-joined`），用 `docker restart cloudflared-joined`
- 两者 token 不同，各自连 JoinD 后台不同隧道条目，**互不冲突**
- 关键依赖链：nginx(8080) → cloudflared tunnel → proxy.cloudjoind.com，nginx 挂了则 tunnel 530 → V2RayN 全挂
- Docker 容器有 IPv6 DNS 超时问题（不影响功能）
§
## 协作模型 V2（2026-07-15 更新）
小H（主控）、Codex（外脑）、小策（方案官）、朵朵（个人认知/知识库）、黑翼（风控官）、老V（执行官）。小研已于2026-07-15被替换为朵朵。Codex强默认前置参与所有任务。
§
## 运维信条
应用层连接错误 ≠ 应用本身故障。排查顺序：① DNS(/etc/resolv.conf + resolvectl) → ② TCP → ③ 代理/出口(WARP/Tailscale) → ④ 服务 → ⑤ 配置 → ⑥ 业务逻辑。网络组件修改必须 Before→Snapshot→Modify→HealthCheck→Rollback。Tailscale 不只是 VPN，它还管理 DNS (MagicDNS)。WARP warp 模式 (全流量隧道) 会触发 Tailscale DNS 接管，只允许 proxy 模式。
§
优选 IP 测试规则：VPS 只能验证隧道连通性（curl --resolve + HTTP 400=通），VPS 端的延迟数字对中国用户无参考价值。严禁报 VPS 侧测速结果（如"这个 IP 只要 72ms"）给用户做优选依据。用户必须自己从 Windows 侧 ping 或 CloudflareSpeedTest 测速。
§
MoA 参考顾问模型：用户偏好用 mimo-v2.5（非 pro 版）。mimo-v2.5 在 OpenCode Go 上可用，mimo-v2.5-pro 是更重量的版本，用户不需要。
§
朵朵知识库独立于主Obsidian Vault，Google Drive folder ID: 1oLAY4-63zFm5vFSM5UiNycMuFChuYAnt，目录结构：01_人生系统/02_家庭育儿/03_聊天归档/Draft/。写入流程：用户确认后放 Draft/（纯 .md，不用 --drive-import-formats md），用户自行晋升。
§
小研（researcher profile）已于2026-07-15被替换为「朵朵」（duoduo profile）。朵朵定位：个人认知管理助手，核心职责思维整理/决策辅助/情绪支持/家庭育儿/知识库沉淀。不负责工作设计/游戏策划/Hermes工程。知识库写入需用户确认。旧researcher归档至archive/researcher_old/。