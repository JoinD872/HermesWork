---
name: vps-health-check
description: VPS 性能与安全完整诊断 — 详细网络安全分析（防火墙/SSH暴破/UFW拦截日志/fail2ban）+ 详细机器状态（CPU/内存/磁盘I/O/服务连接/Cloudflare Tunnel日志）+ DNS 健康检查（Tailscale 劫持检测）
version: 2.2.0
tags: [vps, security, network, linux, monitoring, dns]
risk: read-only
---

# VPS 完整健康检查

## 报告结构规范

大佬要求的报告必须包含两大块：

### 一、网络安全（详细）
- 防火墙状态 + 规则
- SSH 暴力破解来源（失败日志）
- UFW 实时拦截记录
- fail2ban 状态
- Cloudflare Tunnel 错误日志
- 外部连接分析（目的 IP 归属）

### 二、机器使用状况（详细）
- CPU 型号 + 核心数 + 当前负载详情
- 内存使用（含 swap 详情）
- 磁盘使用 + I/O 状态
- 服务连接数
- DNS 健康检查（Tailscale 劫持检测）
- AppArmor/SELinux 状态

---

## 完整巡检命令组

### 网络安全

```bash
# ===== 防火墙状态 =====
ufw status verbose
sudo iptables -L -n

# ===== SSH 暴力破解 =====
sudo lastb -30  # 失败登录（需要 root）
last -20        # 成功登录
# 分析攻击来源 IP 和常用用户名

# ===== fail2ban =====
sudo fail2ban-client status
sudo fail2ban-client status sshd

# ===== UFW 实时拦截日志 =====
sudo tail -100 /var/log/ufw.log | grep "UFW.*BLOCK"
# 分析来源 IP、目标端口、威胁类型

# ===== Cloudflare Tunnel 错误日志 =====
sudo journalctl -u cloudflared-docker-tunnel --since "1 hour ago" | grep -i "ERR\|error"
# 检查 nginx connection refused 等错误

# ===== Cloudflared 多实例冲突检测 =====
# cloudflared 同时跑多个进程（不同 token）会导致 QUIC 连接竞争 → Application error 0x0
# 检查是否存在两个不同的 cloudflared 进程：
ps aux | grep cloudflared | grep tunnel | grep -v grep
echo "--- 检查 token 是否相同 ---"
ps aux | grep cloudflared | grep tunnel | grep -oP 'token \K\S+' | sort -u
# 如果输出两行不同 token → 两个独立隧道实例在运行，可能冲突
# 如果输出一行相同 token → 正常冗余连接，无冲突
# 检查 Docker 容器中是否也有 cloudflared 在跑：
docker ps --format '{{.Names}} {{.Status}}' | grep -i cloud

# ===== WARP 是否真正在使用？ =====
# warp-svc 可能已安装但从未注册/启用，白白消耗 RAM + Swap
# 三步判断法：
# 1. 检查进程是否存在
ps aux | grep warp | grep -v grep
# 2. 检查 Cloudflare trace 显示 warp 是否启用
curl -s https://www.cloudflare.com/cdn-cgi/trace | grep -E "warp=|gateway="
# 3. 检查注册状态（registration was none = 从未注册）
journalctl -u warp-svc --since "-7 days" --no-pager | grep -i "registration was none\|error\|fail" | tail -5
# 4. 验证实际出口 IP = VPS 原生 IP（非 WARP IP）
curl -s ifconfig.me && echo ""
# WARP 未注册(registration was none) + warp=off + 出口 IP 不变 = 空跑，可以安全停用

# ===== 外部连接分析 =====
ss -tnp                          # 活跃连接 + 进程
# 查外部连接目的 IP 归属：
for ip in $(ss -tnp | awk 'NR>2{print $5}' | cut -d: -f1 | sort -u); do
  echo -n "$ip: "; curl -s --max-time 3 "https://ipinfo.io/$ip" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('org','?'),'|',d.get('city','?'),'|',d.get('country','?'))" 2>/dev/null || echo "解析失败"
done
```

### 机器使用状况

```bash
# ===== CPU 详情 =====
lscpu | grep -E "Model name|CPU\(s\)|Thread|Core|Socket|CPU MHz|Cache"
top -bn1 | head -5
vmstat 1 3 | tail -1

# ===== 内存详情 =====
free -h
# 看 available 而不是只看 free，available > 1GB 通常 OK

# ===== Swap 压力分析 =====
echo "--- Swap 占用 ---"
swapon --show
echo "--- swappiness ---"
cat /proc/sys/vm/swappiness
echo "--- Swap 占用 TOP 进程 ---"
for f in /proc/*/status; do
  swap=$(awk '/VmSwap/{print $2}' $f 2>/dev/null)
  name=$(awk '/Name/{print $2}' $f 2>/dev/null)
  pid=$(basename $(dirname $f))
  if [ -n "$swap" ] && [ "$swap" -gt 0 ] 2>/dev/null; then
    echo "$swap kB  PID=$pid  $name"
  fi
done | sort -rn | head -10
echo "--- Swap 活跃度（si/so）---"
vmstat 1 3 | tail -1
# Swap 过载判定标准:
# - Swap 使用 > 60% 且 swappiness=60（默认）→ 建议降到 10（优先丢缓存而非换出进程）
# - Swap 占用 TOP1 是核心服务（如 hermes）→ 降低 swappiness 可显著改善响应

# ===== 磁盘使用 =====
df -h | grep -E "^/dev"

# ===== 磁盘 I/O =====
iostat -x 1 2 | tail -20

# ===== 服务连接数 =====
ss -tnp | grep nginx | wc -l
ss -tnp | grep xray | wc -l

# ===== AppArmor =====
apparmor_status | head -15

# ===== 路由表 =====
ip route | head -5

# ===== DNS 健康检查（Tailscale 劫持检测） =====
# 2026-07-08 事故后新增
# WARP warp 模式会触发 Tailscale MagicDNS 接管系统 DNS
#
# ⚠️ DNS 分裂状态：resolvectl 可能显示正常但 /etc/resolv.conf 已被覆写
# 必须同时检查三个层面才能发现：

# 第一层：/etc/resolv.conf 所有权
ls -la /etc/resolv.conf
# ✅ symlink -> /run/systemd/resolve/resolv.conf
# ❌ 普通文件（Tailscale 生成，内容含 tailscale/100.100.100.100）

# 第二层：内容中的 DNS 服务器
cat /etc/resolv.conf | grep nameserver
# ✅ 1.1.1.1 / 8.8.8.8 → 正常
# ❌ 100.100.100.100 → Tailscale 劫持

# 第三层：systemd-resolved 真实状态（可能和 /etc/resolv.conf 不一致）
resolvectl status | grep "DNS Servers"

# 验证实际解析（测多个关键服务）
nslookup open.feishu.cn
nslookup github.com
nslookup api.deepseek.com
```

### 服务状态汇总

```bash
ps aux | grep -E "nginx|xray|docker|cloudflared|searxng" | grep -v grep
systemctl status nginx xray cloudflared-docker-tunnel --no-pager
docker ps
```

---

## 安全判断标准

| 检查项 | 正常 | 需关注 |
|--------|------|--------|
| SSH 暴破 | fail2ban 在 jail 中，被拦截 | 有成功登录记录不在你名下 |
| UFW 日志 | 大量 BLOCK 记录（正常扫描） | 有未拦截的可疑流量 |
| 内存 | available > 1GB | available 接近 0 |
| Swap | 使用 < 40% 或 swappiness ≤ 10 | 使用 > 60% + swappiness=60（默认）→ 推荐降至 10 |
| 磁盘 | < 85% | > 85% |
| Cloudflare Tunnel | 无 ERR 日志 | 有 connection refused |
| Cloudflared 实例 | 唯一进程（或同 token 多连接）| 两个不同 token 的进程 → 竞争冲突 |
| WARP | 未安装 / 已注册且正常使用 | 已安装但 `registration was none` + `warp=off` → 空耗内存可停用 |
| 外部连接 | 已知服务 IP | 未知 IP 连接内网端口 |
| DNS | symlink + 1.1.1.1/8.8.8.8 | Tailscale DNS 劫持 |

## 已知正常情况

- UFW 拦截大量 3389(RDP)/23(Telnet)/21(FTP)/5555 等端口扫描 → 正常，说明防火墙在工作
- Apr 25 nginx 重启导致 cloudflared tunnel 瞬时 connection refused → 正常，已恢复
- VPS 出口 IP（192.3.241.244）被知乎/部分国内网站屏蔽 → 正常现象
- YouTube transcript API 被拒 → 云服务商 IP 被 YouTube 封锁，正常

## 参考

- `devops/vps-network-services` — WARP + Tailscale 配置详情及高危警告
- `~/.hermes/scripts/doctor.py` — 自动化的 Network Health 巡检（Network Health 模块）
- `references/tailscale-dns-hijack-20260708.md` — 完整事故复盘故障链与根因分析
- `devops/security-preflight` — 网络组件修改保护规则（修改前必须加载）
