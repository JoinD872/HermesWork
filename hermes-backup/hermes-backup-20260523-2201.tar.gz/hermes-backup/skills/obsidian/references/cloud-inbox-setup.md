# Cloud Inbox 实现 — rclone + Google Drive 投递管道

## 架构

```
用户手机/电脑 → Google Drive HermesInbox/ → rclone pull (每30min) → VPS staging → frontmatter注入 → Obsidian Vault/00_收件箱-人工/
```

## 前置条件

- VPS 有公网 IP（用于 OAuth 回调）
- rclone 已安装（`curl https://rclone.org/install.sh | bash` → `/usr/bin/rclone`）

## OAuth 授权（headless VPS 关键步骤）

rclone 的 `rclone authorize "drive"` 会启动一个本地 HTTP 服务（默认 127.0.0.1:53682），等待 Google 回调。headless VPS 无法弹出浏览器，需要：

### 方案：socat 端口转发 + 用户手动修改回调 URL

```bash
# 1. 启动 socat 转发（公网端口 → 本地 rclone 端口）
socat TCP-LISTEN:53683,fork,reuseaddr TCP:127.0.0.1:53682 &

# 2. 放行端口
iptables -A INPUT -p tcp --dport 53683 -j ACCEPT

# 3. 启动授权（先开 socat，再跑这个）
rclone authorize "drive"

# 4. 终端会输出一个 Google 授权链接（形如 https://accounts.google.com/o/oauth2/auth?...&redirect_uri=http://127.0.0.1:53682/...）
#    用户需要：
#    a) 在本地浏览器打开这个链接
#    b) Google 重定向到 http://127.0.0.1:53682/...
#    c) URL 栏中的 127.0.0.1:53682 → 手动改为 VPS 公网 IP:53683
#    d) 回车，回调到达 VPS → rclone 收到 token

# 5. token 自动写入 ~/.config/rclone/rclone.conf
```

**坑点**：Google OAuth 重定向地址是固定的 `127.0.0.1:53682`，无法修改。所以必须通过外部端口转发 + 用户手动编辑 URL 中的 IP:port。

## 配置 Google Docs 导出

默认 rclone 只同步原生文件（`.md`/`.txt`），不处理 Google Docs（`.gdoc`）。需两步：

### 1. rclone config 加 export_formats

在 `~/.config/rclone/rclone.conf` 的 `[mydrive]` section 追加：
```ini
export_formats = md,txt,docx
```

这告诉 rclone：遇到 Google Docs 时优先导出为 Markdown，其次 txt，最后 docx。

### 2. 拉取脚本 include .gdoc

同步命令必须同时匹配 `.gdoc` 扩展名（Drive 列表中的 Google Docs 以 `.gdoc` 显示）：
```bash
rclone move "$REMOTE_INBOX" "$STAGE/" \
  --include "*.md" \
  --include "*.txt" \
  --include "*.gdoc" \
  --delete-empty-src-dirs \
  -v
```

rclone 在传输时自动将 `.gdoc` 导出为 `.md`，本地看到的是 `文件名.md`。

## 拉取脚本设计（pull_cloud_inbox.sh）

完整脚本：`~/.hermes/scripts/pull_cloud_inbox.sh`

关键设计：
- **no_agent=true 的 cron job**：脚本直接输出，跳过 LLM，省 token
- **staging → Vault 两阶段**：先 rclone 拉到 staging 目录，再逐个处理 + 注入 frontmatter
- **frontmatter 注入**：每条笔记自动加 `created/source/status/promotion_required`，方便后续整理
- **文件名格式化**：`YYYYMMDD-原始文件名.md`，避免重名冲突

```bash
rclone move "$REMOTE_INBOX" "$STAGE/" --include "*.md" --include "*.txt" --include "*.gdoc" --delete-empty-src-dirs -v

find "$STAGE" -type f \( -name "*.md" -o -name "*.txt" \) | while read -r f; do
  base="$(basename "$f" | sed 's/\.[^.]*$//')"
  dest="$VAULT/00_收件箱-人工/$(date +%Y%m%d)-$base.md"
  {
    printf -- "---\n"
    printf "created: %s\n" "$(date -Iseconds)"
    printf "source: cloud-inbox\n"
    printf "status: unprocessed\n"
    printf "promotion_required: true\n"
    printf -- "---\n\n"
    cat "$f"
    printf "\n"
  } > "$dest"
  rm -f "$f"
done
```

## Cron 配置

```bash
# 创建 job：每 30 分钟拉取，no_agent=true（脚本直接输出）
cronjob action=create \
  name="Cloud Inbox 回拉" \
  script=pull_cloud_inbox.sh \
  no_agent=true \
  schedule="*/30 * * * *"
```

no_agent=true 时 cron 直接执行脚本 stdout 作为输出，零 token 消耗。

## 日常使用流程

1. 用户在手机 Google Drive App 进入 `HermesInbox/`
2. 可选方式：
   - **上传文件**：点 + → 上传 → 选 `.md`/`.txt` 文件
   - **新建 Google Docs**：点 + → Google 文档 → 写灵感（系统自动导出为 `.md`）
3. 最长等待 30 分钟，脚本自动拉回 Vault
4. 文件落 `00_收件箱-人工/`，小H在下一次对话中读取并整理

## 验证命令

```bash
# 手动触发拉取
bash ~/.hermes/scripts/pull_cloud_inbox.sh

# 查看收件箱
ls ~/.hermes/ObsidianVault/00_收件箱-人工/

# 查看 Drive 上待拉取文件
rclone ls mydrive:HermesInbox

# 检查导出版本是否生效
rclone config show mydrive | grep export_formats
```
