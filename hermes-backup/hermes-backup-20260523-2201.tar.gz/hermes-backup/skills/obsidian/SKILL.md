---
name: obsidian
description: Obsidian Vault 知识库管理 — 架构设计/目录规则/写入控制/Callback管道/模板体系，含 Hermes × Obsidian Vault 单主库多入口架构
version: 2.1.0
tags: [obsidian, knowledge-base, vault, note-taking, knowledge-management]
risk: write-safe
related_skills:
  - federation-protocol-v320
  - low-cost-federation
---

# Obsidian Skill

管理 Hermes Agent 的 Obsidian Vault 知识库。以 **VPS 单主库 + 白名单写入 + Cloud Inbox 投递 + callback 沉淀** 为核心架构。

## 架构概览

```
你（飞书/手机） → 聊天 or Cloud Inbox → 小H处理
                                                       ↓
                  ┌──────────────────────────────────┐
                  │      VPS 单主库（canonical）        │
                  │  ~/.hermes/ObsidianVault/         │
                  └──────────┬───────────────────────┘
                             │
              ┌──────────────┼──────────────┐
              ▼              ▼              ▼
     vault_ingest.py   cron 输出       federation
     (2h, no_agent)    早报/巡检      callback/研究
              │
              ▼
     Google Drive （用户仓库文件夹）
              │   Google Drive 桌面版自动同步
              ▼
     Windows 本地 → 你在 Obsidian 中打开
```

详细架构见 `references/hermes-vault-architecture.md`。

## 目录规则（中文名优先）

所有目录名用中文，Linux 原生支持 UTF-8 路径：

```
~/.hermes/ObsidianVault/
├── 00_收件箱-AI/          # 小H自动写入 + 草稿（frontmatter标注target_dir）
├── 00_收件箱-人工/        # Cloud Inbox 回拉
├── 10_文献笔记/           # 小研报告、外部摘要 → 自动写
├── 20_项目文档/           # → 仅出草稿
├── 30_永久笔记/           # → 仅出草稿（人工晋升）
├── 40_复盘归档/           # 排障/复盘/callback → 自动写
├── 50_Hermes架构/         # → 仅出草稿
├── 灵感创意/              # → 仅出草稿
└── 模板/                  # 固定模板
```

## 写入权限规则

| 目录 | 自动写 | 出草稿 |
|------|:-----:|:------:|
| 00_收件箱-AI/ | ✅ | — |
| 00_收件箱-人工/ | ✅ 拉取 | — |
| 10_文献笔记/ | ✅ | — |
| 40_复盘归档/ | ✅ | — |
| 20_项目文档/ | ❌ | ✅ → 写收件箱-AI/ |
| 30_永久笔记/ | ❌ | ✅ → 写收件箱-AI/ |
| 50_Hermes架构/ | ❌ | ✅ → 写收件箱-AI/ |
| 灵感创意/ | ❌ | ✅ → 写收件箱-AI/ |

草稿统一写 `00_收件箱-AI/`，frontmatter 含：
```yaml
status: draft
target_dir: "灵感创意"
promotion_required: true
```

## 输出标准化

每条 Markdown 含 frontmatter（title/date/source/tags/type/status）+ 正文 + 双链候选 + 标签。

模板文件在 `模板/` 目录：
- `复盘模板.md` — 排障、巡检、复盘
- `文献模板.md` — 研究报告、资料摘要
- `收件箱模板.md` — 灵感、待整理草稿（自带 target_dir 字段）

## Phase 2 — Vault Ingest Pipeline（vault_ingest.py）

**自动将 cron 输出 + 联邦回执写入 Vault**，两条管道汇总到单主库。

### 架构

```
cron 输出目录 (~/.hermes/cron/output/)            federation 回执 (~/.hermes/federation/callbacks/)
         │                                                     │
         ▼                                                     ▼
    vault_ingest.py（每 2 小时，no_agent=true，零 token 成本）
         │
         ├── 40_复盘归档/    ← 早报/VPS巡检/备份日志
         ├── 10_文献笔记/    ← 小研研究报告（research callback）
         └── 00_收件箱-AI/  ← 其他回执兜底
```

### 核心设计

- **状态跟踪**：`~/.hermes/config/vault-ingest-state.json` 记录已处理的 cron 文件名 + callback task_id，不重复写入
- **静默退出**：无新增内容时输出为空，no_agent cron 不触发任何通知
- **宽松匹配**：cron 输出仅处理有名字映射的 job（早报/巡检/备份），旧 job 输出自动忽略
- **回执分类**：根据 task_id 前缀自动路由（MINIMAX/PAIN → research, SCAN/PATROL → log）
- **frontmatter 注入**：每条笔记带 title/type/source/created/status

### 实施步骤

```bash
# 1. 写入 vault_ingest.py → ~/.hermes/scripts/vault_ingest.py
# 2. 创建 cron job（no_agent=true，每 2 小时）
cronjob action=create \
  name="Vault Ingest — Cron+回调入库" \
  script="python3 ~/.hermes/scripts/vault_ingest.py" \
  no_agent=true \
  schedule="0 */2 * * *" \
  deliver=local
```

### 回执分类规则

| task_id 前缀 | 目标目录 | 说明 |
|:---|:---|:---|
| MINIMAX_DAILY | 10_文献笔记 | MiniMax 动态追踪 |
| MINIMAX_SCAN | 10_文献笔记 | MiniMax 扫描报告 |
| UE5WP / UE5 | 10_文献笔记 | UE5 技术研究 |
| RESEARCH | 10_文献笔记 | 综合研究报告 |
| PAIN | 10_文献笔记 | 健康研究 |
| PATROL | 40_复盘归档 | VPS 巡检回执 |
| 其他 | 00_收件箱-AI | 兜底 |

### 回执 JSON 格式要求

```json
{
  "task_id": "RESEARCH_20260505",
  "assignee": "小研",
  "status": "done",
  "payload": {
    "summary": "Markdown 正文摘要",
    "key_findings": ["发现1", "发现2"],
    "action_items": ["行动项1"]
  },
  "completed_at": 1778007779
}
```

## Phase 2b — Vault 同步到用户桌面（Google Drive 中转）

将 VPS Vault 同步到用户的本机 Obsidian。首选方法是通过 **Google Drive 中转**：VPS 用 rclone 推送到用户的 Drive 文件夹，用户在电脑上安装 Google Drive 桌面版自动同步到本地。

### 为什么不用 SSH 直推？

初期尝试通过 Tailscale SSH (SFTP) 直接同步到 Windows 桌面。但 Tailscale 使用 DERP relay 中继（延迟 ~180ms），单次 81 文件的 checksum 同步耗时 >100s，用户体验差且依赖桌面开机。Google Drive 中转方案：
- 不依赖桌面在线（离线时文件先到 Drive，开机后 Google Drive 桌面版自动同步）
- Google Drive 桌面版双向同步，用户在 Obsidian 编辑的笔记可回传
- VPS → Drive 走 Google 直连，快且稳定

### 同步链路

```
VPS ~/.hermes/ObsidianVault/
  │   rclone copy (每30min, no_agent, 零 token)
  ▼
Google Drive 目标文件夹（--drive-root-folder-id）
  │   Google Drive 桌面版自动同步
  ▼
用户本机 (如 C:\Users\用户名\Google Drive\)
  │   Obsidian "打开文件夹作为仓库"
  ▼
用户在本地 Obsidian 中看到 Hermes 的所有内容
```

### 关键设计决策

详见 `references/drive-sync-setup.md`（含完整的分步配置、rclone 命令、用户侧 Obsidian 设置），核心要点：

- **`--drive-root-folder-id` 定位**：永远用 folder ID 而非路径名，避免路径绑定断裂
- **`rclone copy` 而非 `sync`**：copy 只增补更新，永不删除目标文件。当 Hermes Vault 内容需要合并到用户已有的 Obsidian 仓库时，这是安全的选择。用户原有的笔记不会被误删
- **静默离线处理**：no_agent=true，sync 脚本在无新内容时输出为空，零 token；Google Drive 桌面版在后台持续同步，用户无感知
- **`--size-only`**：比 `--checksum` 快（Google Drive API 侧只需比对大小+修改时间）

### 配置步骤

```bash
# 1. 用户指定 Google Drive 上的目标文件夹，获取 folder_id（来自 URL）
#    https://drive.google.com/drive/folders/{folder_id}

# 2. 写 sync 脚本 ~/.hermes/scripts/sync_vault_to_drive.sh
#    核心命令：rclone copy "$VAULT/" "mydrive:" --drive-root-folder-id "$FOLDER_ID" --size-only --timeout 120s -q

# 3. 创建 no_agent cron job
cronjob action=create \
  name="Vault 同步 → Google Drive" \
  script="bash ~/.hermes/scripts/sync_vault_to_drive.sh" \
  no_agent=true \
  schedule="*/30 * * * *"

# 4. 用户在 Windows 安装 Google Drive 桌面版
#    https://dl.google.com/drive-file-stream/
#    登录后等待目标文件夹同步到本地
#    打开 Obsidian → "打开文件夹作为仓库" → 指向同步后的本地文件夹
```

### 已知问题

- **Windows 同步是单向的（VPS → Drive）**：用户在本地 Obsidian 上的编辑通过 Google Drive 桌面版会回传到云端 Drive，但不再回传至 VPS。如需从 Windows 向 VPS 投递内容，仍走 Cloud Inbox

## Cloud Inbox（用户投递入口）

Google Drive 作为云收件箱，用户从手机/电脑投递 → rclone 定时拉取 → Vault 收件箱。

**完整实施步骤见** `references/cloud-inbox-setup.md`，涵盖：
- Headless VPS 上 rclone OAuth 授权的 socat 端口转发方案
- Google Docs → Markdown 自动导出配置（`export_formats = md,txt,docx`）
- 拉取脚本设计（frontmatter 注入 + no_agent cron）
- 日常使用流程

## Phase 1 最小闭环

首次搭建只做：建中文目录 → 配写权限 → 写模板 → 测试写入 → tar 打包备份。
不做 rclone crypt / Syncthing / Git，待稳定后再逐级加。

## 已知限制与边界

- **同步流向**：VPS → Drive → 用户桌面（单向）。用户在本地 Obsidian 上的编辑通过 Google Drive 桌面版回传到云端 Drive，但不会自动回传至 VPS。如需从 Windows 向 VPS 投递内容，走 Cloud Inbox
- **桌面端同步依赖 Google Drive 桌面版持续运行**：关掉 Drive 桌面版则停止同步，重新打开后自动恢复
- **vault_ingest.py 只处理有名称映射的 cron job**：旧/已删除 job 的输出目录不处理
- **回执状态必须为 "done"**：未完成或失败的回执不会写入 Vault
- **子 Agent 需在 emit_result() 中保证 summary 字段**：回执无 summary 则 vault_ingest 无法写入
