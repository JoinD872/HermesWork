---
name: community-content-scraping
description: 多社区内容抓取 — X/Twitter、Discord、V2EX、B站、Reddit、GitHub、知乎的可用方案与凭据管理
tags: [scraping, twitter, discord, reddit, github, bilibili, v2ex, zhihu]
version: 1.1.0
risk: write-safe
---

# 多社区内容抓取

## 抓取策略（降级链）

```
VPS 直取 ──成功──→ ✅ 返回结果
  │ 失败
  ↓
SearXNG 间接搜索 ──成功──→ ✅ 
  │ 失败
  ↓
黑翼 SSH 桌面浏览器 ──成功──→ ✅ 
  │ 失败
  ↓
用户手动配合 ──→ 指导用户 F12 → Console 操作
```

## 社区可用性矩阵

| 社区 | 方式 | 状态 | 额外要求 |
|------|------|:----:|---------|
| **V2EX** | `curl` 直接提取 | ✅ | 无 |
| **B站** | 公开 API | ✅ | 无 |
| **Reddit** | JSON API | ⚠️ VPS IP 被封锁（2026-05-23 起） | HTTP 403 — 服务器级网络策略，非凭据问题 |
| **GitHub** | REST API | ✅ | 无，匿名也可搜 |
| **X/Twitter** | 内部 API | ✅ | 需 auth_token + ct0 cookie + Bearer Token |
| **Discord** | Bot API | ✅ | 需有效 Bot Token |
| **知乎** | 官方 API (developer.zhihu.com) | ✅ | `ZHIHU_ACCESS_SECRET` 存于 .env，每天 1000 次免费搜索 |
| **小红书** | 无自动化方案 | ❌ | headless 全拦截（VPS + 桌面），仅用户手动浏览器可行 |
| **掘金** | 无有效方案 | ❌ | SPA 渲染 + 无 API |

## 凭据管理

所有社区凭据统一存于 `/root/.hermes/credentials/social_scraper.json`，格式：
```json
{
  "x": {
    "bearer_token": "...",
    "auth_token": "...",
    "ct0": "..."
  },
  "discord": {
    "bot_token": "...",
    "guild_id": "...",
    "channels": { "name": "channel_id" }
  }
}
```

### X/Twitter 凭据获取

用户需从 browser F12 → Application → Cookies → x.com 复制：
- `auth_token` — 会话认证
- `ct0` — CSRF 保护 Token
- Bearer Token 是公开的：`AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA`

### Discord Bot Token 获取

用户需在 Discord Developer Portal 创建/重置 Bot Token，Bot 需已加入目标服务器。

## 知乎官方 API 抓取

知乎数据开放平台 `developer.zhihu.com` 提供官方 API，`ZHIHU_ACCESS_SECRET` 存于 `.env`。

### 可用接口

| 接口 | 端点 | 说明 |
|------|------|------|
| 知乎搜索 | `GET /api/v1/content/zhihu_search` | 站内内容搜索，Query 必填，Count 最大 10 |
| 全网搜索 | `GET /api/v1/content/global_search` | 全网+知乎双源搜索 |
| 知乎热榜 | `GET /api/v1/content/hot_list` | 实时热榜，固定返回 30 条 |
| 直答 | 相关接口 | Agent 对话式查询 |

### 请求头

```bash
-H "Authorization: Bearer <ZHIHU_ACCESS_SECRET>"
-H "X-Request-Timestamp: $(date +%s)"     # 秒级Unix时间戳
-H "Content-Type: application/json"
```

### 调用示例

```bash
# 知乎搜索
curl -s -G 'https://developer.zhihu.com/api/v1/content/zhihu_search' \
  --data-urlencode 'Query=虚幻引擎5' \
  -d 'Count=5' \
  -H "Authorization: Bearer $ZHIHU_ACCESS_SECRET" \
  -H "X-Request-Timestamp: $(date +%s)" \
  -H 'Content-Type: application/json'

# 知乎热榜
curl -s -G 'https://developer.zhihu.com/api/v1/content/hot_list' \
  -H "Authorization: Bearer $ZHIHU_ACCESS_SECRET" \
  -H "X-Request-Timestamp: $(date +%s)" \
  -H 'Content-Type: application/json'
```

### 响应格式

```json
{
  "Code": 0,
  "Message": "success",
  "Data": { ... }
}
```

搜索响应中 `Data.Items[]` 包含：`Title`, `ContentText`, `Url`, `AuthorName`, `VoteUpCount`, `CommentCount`, `EditTime` 等。

热榜响应中 `Data.Items[]` 包含：`Title`, `Url`, `ThumbnailUrl`, `Summary`。

### 免费额度

注册即送：每天 1000 次搜索 + 10 次热榜/直答。

### 错误码

| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| 10001 | 参数错误 |
| 20001 | 鉴权失败 |
| 30001 | 频率限制 |
| 90001 | 内部错误 |

## X/Twitter 抓取

### 可用端点

| 端点 | 用途 | 说明 |
|------|------|------|
| `/i/api/2/timeline/home.json?count=N` | 首页 Timeline | ✅ 可用，返回 tweets + users |
| `/i/api/graphql/<QueryID>/QueryName` | GraphQL 操作 | ❌ Query ID 频繁变更，不可靠 |
| 其他 v1.1/v2 REST 端点 | 搜索等 | ❌ 返回 34/NotFound |

### 请求头要求

```bash
-H "Authorization: Bearer <公开 Bearer Token>"
-H "x-csrf-token: <ct0 cookie 值>"
-H "x-twitter-auth-type: OAuth2Session"
-H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
-H "Cookie: auth_token=<auth_token>; ct0=<ct0>"
-H "Origin: https://x.com"
-H "Referer: https://x.com/"
```

### 响应解析

响应体包含 `globalObjects.tweets`（推文字典）和 `globalObjects.users`（用户字典），以及 `timeline.instructions`（排序指令）。从 `timeline.instructions` 中提取推文 ID 列表，再到 `globalObjects.tweets` 中获取详情。

每个推文包含：`text`/`full_text`、`created_at`、`user_id_str`、`retweet_count`、`favorite_count`、`entities.urls` 等。

### 局限性

- timeline endpoint 能正常拉取首页推文（已验证）
- 搜索（搜索推文/用户）和 GraphQL 端点无法稳定使用
- `auth_token` 和 `ct0` 会过期，需要用户重新提供

## Discord 抓取

### 可用端点

```bash
# 获取 Bot 基本信息
curl -s "https://discord.com/api/v10/users/@me"
  -H "Authorization: Bot <token>"

# 获取 Bot 所在的服务器
curl -s "https://discord.com/api/v10/users/@me/guilds"

# 获取服务器频道列表
curl -s "https://discord.com/api/v10/guilds/<guild_id>/channels"

# 读取频道消息（最近 N 条）
curl -s "https://discord.com/api/v10/channels/<channel_id>/messages?limit=N"
```

### 消息解析

返回的消息数组按时间倒序（最新的在前），每条包含：`content`、`author.username`、`timestamp`、`mentions` 等。

### 局限性

- 只能读取 Bot 已加入的服务器和频道的消息
- Google 反查: Discord 内容不公开索引，无法用搜索引擎间接获取

## 爬取验证工具

### 国内站连通性快速测试

```bash
# 测一条看看
for site in "https://www.v2ex.com/" "https://www.bilibili.com/" "https://juejin.cn/"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 -A "Mozilla/5.0" -L "$site")
  echo "$site → $code"
done
```

### 国外站连通性

```bash
for site in "https://www.reddit.com/" "https://github.com/" "https://x.com/" "https://discord.com/"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 -A "Mozilla/5.0" -L "$site")
  echo "$site → $code"
done
```

## V2EX 解析模式（CSS + 正则 Fallback）

V2EX 首页是服务端渲染 HTML，提取话题链接时需要做**二级降级解析**，因为纯 CSS 选择器可能因页面微调而失败：

```python
# 第一级：CSS 提取（优先）
# 匹配 item_title 类中的链接
grep -oP 'item_title.*?href="\K/t/[0-9]+' file.html

# 第二级：正则 fallback（降级）
# 如果 CSS 提取数量 < 5，降级到全量正则
grep -Eo 'href="/t/[0-9]+"' file.html | sort -u

# 第三级：debug 保存
# 如果前两级都 < 3 条，保存头 2000 字符供排查
head -c 2000 file.html > /tmp/v2ex_debug.html
```

**关键原则**：不要因为 CSS 选择器失效就直接报 🔴。禁止"一步解析失败 = 该源不可用"。V2EX 的 /t/ 链接格式是稳定的，正则 fallback 通常能兜住。

## 异常分级系统

不要用二进制 ✅/❌ 来判定每个源。使用 4 级分类：

| 情况 | 级别 | 说明 |
|------|:----:|------|
| HTTP 200 + 正常返回数据 | ✅ | 正常绿 |
| HTTP 200 + 返回数据量少 | 🟢 | 如实汇报即可，不标记异常 |
| HTTP 200 + 空结果（技术无相关内容） | 🟡 | "今日无相关更新" |
| HTTP 4xx/5xx 请求失败 | 🟡 | 请求异常，非数据异常 |
| 解析失败但原始 HTML/JSON 存在 | 🟡 | "解析异常，已保存 debug" |
| 网络不可达（timeout/DNS 失败） | 🔴 | "服务不可达" |
| 凭据过期（401） | 🟡 | "凭据需更新" |
| rate limit（429 或 HTTP 403） | 🟡 | "已限流" |

**核心规则**：只有网络层不可达才标 🔴。其他全部降级为 🟡 或更低。

## SearXNG 端点验证

知乎搜索依赖本地 SearXNG 服务。不要假设端口是多少——先验证：

```bash
# 1. 确认 Docker 中 SearXNG 的实际端口
docker ps --format 'table {{.Names}}\t{{.Ports}}' | grep searx

# 2. 测试搜索
curl -sS --max-time 15 "http://127.0.0.1:8888/search?q=site:zhihu.com+DeepSeek&format=json"

# 3. 如果首次搜索无结果，换一个关键词重试
# 不要单次无结果就报失败
```

**已知**：实际端口 8888（Docker 映射）。不要写死 localhost:8080。

## GitHub PAT 安全注意事项

**不要**复用备份脚本、日志文件或聊天记录中已出现的 GitHub PAT。如果 token 出现在以下任一位置，应视为已泄露：
- 备份脚本（如 hermes-backup.sh）
- 聊天对话
- 输出日志
- Memory 记录

正确做法：
1. 去 https://github.com/settings/tokens 创建**新 PAT**
2. 只给最小权限（如 `public_repo` 只读）
3. 写入环境变量 `GITHUB_TOKEN`，不要写死进脚本
4. 新 token 不要在聊天中明文输出
5. 旧 token 立即撤销

## 用户配合模式（小红书/掘金等 blocking 站点）

当所有自动化方案都失败时，指导用户在浏览器（非 headless）中操作：

1. 打开目标页面
2. F12 → Console（控制台）
3. 输入 `allow pasting` 回车（安全提示确认）
4. 粘贴 `copy(document.body.innerText)` 回车
5. 将粘贴板内容发回
