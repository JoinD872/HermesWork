**Name/称呼：** 大佬
**职业：** 游戏技术策划（UE5）
**时区：** Asia/Hong_Kong (GMT+8)
**联系方式：** 飞书
**偏好：**
- 给链接时直接整理完整内容，不需要他自己点进去
- 信息要完整详细，不接受粗略摘要
- 周四版本更新日最忙
§
**AI 协作偏好**：小H 用 Gemini 指导工作流迭代（V2.0→V2.1-Patch），认为 Gemini 推进力强；ChatGPT 用于信息整理，可读性好但深度有限。用户主动参与技术讨论，不做甩手掌柜。
§
小H，健康助手群用户，游戏技术策划（UE5），住上海宝山。核心健康问题：腰5骶1椎盘突出、慢性萎缩性胃炎（到胃角）、疑似颈椎供血不足（B12/铁可能缺）。习惯凌晨2点睡。有胃药但经常不吃。工作忙但双休有时间。购物在山姆上海宝山店。偏好：具体可执行的建议，不接受笼统答案；希望小健和小研协同研究他的健康问题；遇到我访问不了的网站要我去联系DM帮忙。
§
报告偏好：详细全面，用「架构图/表格/分点」形式，信息密度高，分类清晰。不要三句话敷衍。
§
早餐固定两个方案轮换：燕麦+白煮蛋+香蕉，或刀切馒头+白煮蛋+香蕉。对重复吃不腻，不需要经常换方案。
§
图片生成流程：先出中文草案给用户确认方向，确认后再用英文生成（pollinations.ai 或 MMX CLI）。不接受直接跳英文 prompt。
§
正在申请 ChatGPT Plus 套餐（免费1个月试用链接 + 国内银行卡订阅）。VPS IP（192.3.241.244, RackNerd/洛杉矶）作为梯子出口，OpenAI 目前未封，可以正常使用 ChatGPT。支付环节仍有风险，建议备好 Depay 虚拟卡。
§
游戏技术策划（UE5），住上海宝山。4月27日刚成功领取 ChatGPT Plus 1个月免费试用（免费链接）。国内银行卡被 OpenAI 支付系统拒绝，正在用 pollinations.ai 作为图片生成备用方案。对 MiniMax 有持续关注兴趣，建了每日动态监控任务。
§
资源搜索标准：只找最顶配版本（最高画质/最大文件体积/最完整音轨），不接受凑合的替代版本。
§
飞书渲染链接有问题，链接必须用纯文本形式发送，不能用Markdown链接格式。
§
使用 Google Sheets 管理游戏角色技能美术设计需求（PG2宠物需求），表格有18个工作表，每个宠物一个Sheet，结构统一为：宠物名称/技能名称/技能属性/攻击数量/技能描述/动作描述/特效描述/备注。偏好在线直接编辑表格，不需要本地软件。
§
Windows 桌面是主要工作机（desktop-tg4loen），还有一台 Windows 笔记本（laptop-fof8llrf，已离线约30天未用）。Tailscale 账号 w619151721@。
§
**工作风格**：务实派。如果某个方案反复搞不定不想继续折腾，宁可放弃切换方案也不浪费时间死磕。偏好先用现有工具快速试，不行就换路子。

**Windows 桌面环境**：上海宝山，Tailscale IP 100.86.150.37。装了 Edge（`C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`）和 360ChromeX（`C:\Users\JoinD\AppData\Local\360ChromeX\`）。平时主要用 360ChromeX 浏览器访问国内社区。
§
用户偏好分阶段保守推进（最小闭环先跑通 → 观察稳定 → 再扩功能），不接受一次铺太大。每个Phase必须有明确的验证清单和回滚方案。
§
用户要求审计报告的可写目录标注必须与config配置完全一致，不允许标称不一致。
§
Strongly prefers Chinese directory/file names (中文) over English. 所有路径名必须用中文，如 00_收件箱-AI/、40_复盘归档/。Linux UTF-8 原生支持。禁止缩写或中英混写。名字必须与 config 配置完全一致，不一致会被拒。
§
Token cost sensitive — 对一次性大量 token 消耗有顾虑。基础设施搭建（rclone/OAuth/Phase 2）要一次搞定，日常运行尽量零成本（no_agent脚本）。新功能上线前评估 token 成本，优先选低耗方案。
§
Self-aware about not having knowledge base habits — 自己承认"脑袋空白，平时也没有建立知识库的习惯"。确认由我（小策/小H）来维护知识库，他只负责聊想法和用飞书提需求。不要期望他主动整理知识或维护笔记。
§
Obsidian vault on Windows at C:\Users\JoinD\Documents\Obsidian Vault. Google Drive folder (ID: 1XvPIqFqftMhG_4QSC9LnApxue_ayvAmg) acts as sync intermediary: VPS pushes to Drive, Google Drive Desktop syncs to Windows. One-way copy (never deletes user's existing notes).
§
On mobile, prefers to write ideas as Google Docs (not .txt/.md files) in HermesInbox, since Drive mobile can't create text files. Also comfortable just telling me ideas directly in Feishu chat.
§
Expects me to consolidate inbox notes over time: new ideas from HermesInbox → I should read, process, and fold into structured Vault content rather than letting files pile up in 收件箱.