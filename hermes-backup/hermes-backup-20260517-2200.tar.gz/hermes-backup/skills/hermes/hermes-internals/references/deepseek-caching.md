# DeepSeek V4 缓存机制与 Hermes 交互参考

> 基于 2026-05-17 的实际代码审计验证（v0.14.0 / v2026.5.16）

## 核心机制

DeepSeek 的缓存是**服务端自动触发的**，无需在 API 请求中添加 cache_control 标记：

- **触发方式**：基于 byte-level 前缀匹配，64-token chunk 粒度
- **计算单元**：Sliding Window Attention 下的 "缓存前缀单元"（完整独立单元）
- **匹配规则**：后续请求必须**完全匹配**一个已持久化的缓存前缀单元
- **持久化**：分布式磁盘缓存，自动跨请求持续
- **价格**：命中 $0.028/M tokens vs 未命中 $0.28/M（省 90%）

**官网来源**：`https://api-docs.deepseek.com/guides/kv_cache`

## 缓存前缀的构建时机

DeepSeek 在以下时机自动持久化缓存前缀单元：

1. **每次请求**：产生两个新的缓存前缀单元
2. **检测到共同前缀**：当系统发现多个请求共享某前缀时，持久化该前缀为独立单元
3. **长输入/长输出**：自动从长序列中划出独立缓存单元

## Hermes 当前架构的关键交互点

### ① System Prompt 缓存（会话内 — 已正确实现）

`AIAgent._build_system_prompt()` → 缓存在 `self._cached_system_prompt`：

```
稳定层（stable）：身份 + 工具指导 + skills 索引 + 环境提示
上下文层（context）：context files + 调用方 system_message
易变层（volatile）：memory 快照 + 用户画像 + 时间戳
```

- 会话内 `_cached_system_prompt` **永不重建**（除非压缩）
- 注释原文：_"Hermes never rebuilds or reinjects parts of it mid-session — that's the only way to keep upstream prompt caches warm across turns."_

**交叉验证代码位置**：`run_agent.py:6056-6281`

### ② 工具 Schema 传递方式（与常见假设不同）

**关键发现**：工具 schema **不嵌入 system prompt 文本**，而是通过 OpenAI 兼容的 `tools` 参数**独立传递**。

正确的数据流：
```
self.tools = get_tool_definitions(...)       # 加载
→ _build_api_kwargs() → tools=tools_for_api  # 构建
→ ChatCompletionsTransport.build_kwargs()     # 包装
→ client.chat.completions.create(tools=...)   # 发送
```

`_format_tools_for_system_message()` 函数（常被误认为缓存关键点）**只用于 trajectory 格式保存**，不影响运行时缓存。

**代码位置**：`run_agent.py:4803-4825`（trajectory 专用），`run_agent.py:10025-10028`（实际 API 调用）

### ③ /compress 会必然破坏缓存

`_compress_context()` 调用链：
```python
self._invalidate_system_prompt()          # _cached_system_prompt = None
self._build_system_prompt(system_message)  # 重建（volatile 变化）
self._cached_system_prompt = new_prompt
```

重建后的 system prompt 即使 stable 部分相同，volatile 部分（memory 快照 + 新时间戳）也会变化。DeepSeek 的 byte 级匹配要求下，**缓存必然不命中**。

这是设计上的取舍：压缩是为了防止 OOM，代价是缓存重置。

**代码位置**：`run_agent.py:10722-10724`，`_invalidate_system_prompt` at `run_agent.py:6644-6653`

### ④ Deterministic Call IDs（已做对的优化）

Hermes 已经实现了 `_deterministic_call_id()` 来避免工具调用 ID 破坏缓存：

```python
def _deterministic_call_id(fn_name, arguments, index):
    """Deterministic IDs prevent cache invalidation — random UUIDs would
    make every API call's prefix unique, breaking OpenAI's prompt cache."""
```

**代码位置**：`run_agent.py:6655-6663`

### ⑤ 缓存统计读取（取决于 DeepSeek 是否返回字段）

`ChatCompletionsTransport.extract_cache_stats()` 读取 `prompt_tokens_details.cached_tokens`：

```python
def extract_cache_stats(self, response):
    usage = getattr(response, "usage", None)
    details = getattr(usage, "prompt_tokens_details", None)
    cached = getattr(details, "cached_tokens", 0)
    written = getattr(details, "cache_write_tokens", 0)
```

**已确认**：DeepSeek V4 文档没有明确承诺返回 `prompt_tokens_details`。如果该字段为 None，需要从其他渠道推算缓存率。

**代码位置**：`agent/transports/chat_completions.py:615-627`

## 跨会话缓存的关键变量

| 变量 | 影响程度 | 说明 |
|------|---------|------|
| `memory`/`USER.md` 内容 | **高** | 每次 session 快照不同 → volatile 尾部变化 |
| 时间戳 | **中** | 只在 volatile 最尾部，sliding window 下影响较小 |
| 工具集不变 | **高** | 同 profile + 同 toolsets → tools 参数不变 |
| skills 索引 | **低** | 由 `build_skills_system_prompt()` 双层缓存保障一致性 |
| provider/model 不变 | **高** | base_url / model 不同 → 缓存完全独立 |

## 真实世界的缓存命中率参考

Reasonix 框架（DeepSeek 专属，TypeScript）实测数据：

| 场景 | 模型 | 轮次 | 缓存命中率 |
|------|------|------|-----------|
| 多轮对话 | deepseek-v4 | 5 | **87.5%** |
| 工具调用（计算器） | deepseek-v4 | 2 | **93.1%** |
| R1 推理 + 收割 | deepseek-reasoner | 1 | **72.7%** |

来源：https://dev.to/esengine/how-a-deepseek-only-agent-framework-hit-85-prefix-cache-rate-and-saved-93-vs-claude-5c9g

## 常见误解纠正

| 常见说法 | 实际情况 |
|---------|---------|
| "固定工具 schema 序列化能提升缓存" | 工具 schema 在 API `tools` 参数中，不在 messages 前缀内 |
| "压缩后缓存仍能命中" | `_invalidate_system_prompt` 会清除缓存，rebuild 后 byte 级偏移 |
| "按字段顺序固定 json.dumps 输出" | `json.dumps` 在 Python 3.7+ 中顺序已按 dict 定义保证 |
