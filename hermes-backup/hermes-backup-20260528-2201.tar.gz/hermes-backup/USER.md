**称呼：** 大佬
**身份：** 普通的互联网打工人，别用UE5/策划/游戏相关头衔称呼或刻意提及
§
AI 协作偏好：我出方案→Codex高模型验证/扩充→我落地。反复搞不定的问题主动找Codex。早报偏好（2026-05-27）：去掉Discord/B站/Reddit。扩大知乎用量（1000次/天免费）。新增HackerNews/HF Papers/掘金。自纠偏好：难度评级用量化公式，反复bug自动升一级。费用追踪必须和官网一致。
§
小H，健康助手群用户，游戏技术策划（UE5），住上海宝山。核心健康问题：腰5骶1椎盘突出、慢性萎缩性胃炎（到胃角）、疑似颈椎供血不足（B12/铁可能缺）。习惯凌晨2点睡。有胃药但经常不吃。工作忙但双休有时间。购物在山姆上海宝山店。偏好：具体可执行的建议，不接受笼统答案；希望小健和小研协同研究他的健康问题；遇到我访问不了的网站要我去联系DM帮忙。
§
报告偏好：详细全面，用「架构图/表格/分点」形式，信息密度高，分类清晰。不要三句话敷衍。
§
早餐固定两个方案轮换：燕麦+白煮蛋+香蕉，或刀切馒头+白煮蛋+香蕉。对重复吃不腻，不需要经常换方案。
§
图片生成流程：先出中文草案给用户确认方向，确认后再用英文生成（pollinations.ai 或 MMX CLI）。不接受直接跳英文 prompt。
§
分析风格偏好（2026-05-23 确立）：喜欢GPT的维度方式——上具体数据（价格/数值/机制细节）、直击痛点（不止说"玩家不满"而是说清楚"什么机制导致什么后果"）、给出可做决策的依据。不要泛泛的"氪金味重"这类笼统判断，要具体到"绑金vs抵用券"这个层面。
§
资源搜索标准：只找最顶配版本（最高画质/最大文件体积/最完整音轨），不接受凑合的替代版本。
§
飞书渲染链接有问题，链接必须用纯文本形式发送，不能用Markdown链接格式。
§
使用 Google Sheets 管理游戏角色技能美术设计需求（PG2宠物需求），表格有18个工作表，每个宠物一个Sheet，结构统一为：宠物名称/技能名称/技能属性/攻击数量/技能描述/动作描述/特效描述/备注。偏好在线直接编辑表格，不需要本地软件。
§
Windows 桌面是主要工作机（desktop-tg4loen），还有一台 Windows 笔记本（laptop-fof8llrf，已离线约30天未用）。Tailscale 账号 w619151721@。
§
**工作风格**：务实派。如果某个方案反复搞不定不想继续折腾，宁可放弃切换方案也不浪费时间死磕。偏好先用现有工具快速试，不行就换路子。

**Windows 桌面环境**：上海宝山，Tailscale IP 100.86.150.37。装了 Edge（`C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`）和 360ChromeX（`C:\Users\JoinD\AppData\Local\360ChromeX\`）。平时主要用 360ChromeX 浏览器访问国内社区。
§
用户要求审计报告的可写目录标注必须与config配置完全一致，不允许标称不一致。
§
文件与结构偏好：中文目录名（如 日记/日记MD/）、嵌套层级结构、配置与路径精确一致。审计/可写目录标注必须与config完全匹配，不一致会拒。
§
Self-aware about not having knowledge base habits — 自己承认"脑袋空白，平时也没有建立知识库的习惯"。确认由我（小策/小H）来维护知识库，他只负责聊想法和用飞书提需求。不要期望他主动整理知识或维护笔记。
§
Obsidian vault on Windows at C:\Users\JoinD\Documents\Obsidian Vault. Google Drive folder (ID: 1XvPIqFqftMhG_4QSC9LnApxue_ayvAmg) acts as sync intermediary: VPS pushes to Drive, Google Drive Desktop syncs to Windows. One-way copy (never deletes user's existing notes).
§
On mobile, prefers to write ideas as Google Docs (not .txt/.md files) in HermesInbox, since Drive mobile can't create text files. Also comfortable just telling me ideas directly in Feishu chat.
§
Expects me to consolidate inbox notes over time: new ideas from HermesInbox → I should read, process, and fold into structured Vault content rather than letting files pile up in 收件箱.
§
Personal: has young daughter, struggles with feeling lost/anxious, feels inadequate beyond income. Writes diary 凌晨 (2-6am) to process. I should read his diary entries as ongoing personal context for better support.
§
隐私/被动偏好：不主动读他的日记/笔记内容。等他说「写好了」或提问需要查时才读。保持「不偷看、不主动分析」态度。
跨平台：iOS用Shadowrocket，Windows用V2RayN，两端协议需兼容。
决策节奏：给选项后需要时间考虑（分钟~小时级），不催。