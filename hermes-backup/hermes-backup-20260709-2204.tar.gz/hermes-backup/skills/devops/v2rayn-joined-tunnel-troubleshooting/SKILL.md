---
name: v2rayn-joined-tunnel-troubleshooting
description: V2RayN 连接失败系统性排查 + 延迟异常诊断 — 当 JoinD Cloudflare Tunnel 域名无法连接或延迟异常时的排查流程
version: 1.2.0
author: Hermes Agent
tags: [v2ray, xray, proxy, network, joined, latency]
risk: write-dangerous
---

# V2RayN + JoinD Tunnel 故障排查

## ⚠️ 修改操作前置要求

| 操作类型 | 要求 |
|---------|------|
| 修改 nginx 配置（`/etc/nginx/`） | **必须先** `cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak-$(date +%F-%H%M%S)` |
| 修改 Xray 配置 | **必须先** `cp /usr/local/etc/xray/config.json /usr/local/etc/xray/config.json.bak-$(date +%F-%H%M%S)` |
| `systemctl restart nginx` / `systemctl restart xray` | 确认备份存在后再执行 |
| Docker 操作（`docker stop/restart`） | 记录当前容器ID和运行状态后再操作 |

**回滚命令**：`sudo cp /etc/nginx/nginx.conf.bak-* /etc/nginx/nginx.conf && sudo nginx -s reload`（nginx 配置回滚后 reload 而非 restart）

---

## 快速诊断决策树

```
V2RayN 显示延迟-1 / 502 / 连不上
├── ⚠️ 先排除 DNS 问题！（2026-07-08 新增）
│   ├── VPS 上执行：nslookup proxy.cloudjoind.com
│   │   ├── 解析失败 → 检查 /etc/resolv.conf 是否被 Tailscale 劫持
│   │   │   └── cat /etc/resolv.conf | grep nameserver
│   │   │       ├── 100.100.100.100 → Tailscale 劫持，需修复
│   │   │       └── 1.1.1.1 或 8.8.8.8 → 正常
│   │   └── 解析正常 → 继续走下面决策树
│   │
│   ├── 症状：之前能用，今天突然不行（IP 没换）
│   └── 先排除丢包假性断连！
│       ├── 开 V2RayN 跑 speedtest → 看丢包率
│       │   ├── 丢包 > 5% → ISP 国际出口高峰期拥堵，不是 IP 问题
│       │   │   └── 凌晨低谷再试，如果恢复则确认为高峰期行为
│       │   └── 丢包 < 1% → 继续走下面决策树
│       └── 关 V2RayN 直连跑 speedtest → 区分本地宽带 vs 国际出口
│           ├── 直连丢包 < 1% → 你家宽带到局端正常，问题在国际出口段
│           └── 直连丢包 > 5% → 你家宽带/路由器/光猫有问题
│
├── VPS Xray 端口通吗？（nc/vs 公网IP）
│   ├── 不通 → Xray 没监听公网 → 检查 config.json listen 字段
│   └── 通但 502 → 可能是 CDN 域名问题 → 走下面
│
├── V2RayN 用的是 CDN 域名（proxy.cloudjoind.com）还是 VPS IP？
│   ├── CDN 域名 → curl https://proxy.cloudjoind.com
│   │   ├── 502 → JoinD Tunnel 回源问题
│   │   │   ├── nginx 停了？→ systemctl restart nginx
│   │   │   ├── cloudflared 进程在跑吗？→ ps aux | grep cloudflared
│   │   │   └── tunnel token 有效吗？→ JoinD 后台检查
│   │   │
│   │   └── 200 → VPS 端正常，客户端配置问题
│   │
│   ├── 优选 IP（108.162.x.x）→ 对比测试域名直连
│   │   ├── 域名直连 OK 但优选 IP 不行 → 该优选 IP 可能已失效，换一个
│   │   └── 域名直连也丢包 → 国际出口问题，非 IP 问题
│   │
│   └── VPS IP 直连 → curl -x http://VPS_IP:端口
│       ├── 不通 → 防火墙/端口/监听地址问题
│       └── 通但 V2RayN 连不上 → UUID/传输/路径不匹配
```

## 核心知识点

### JoinD Tunnel 架构
- V2RayN 客户端连的不是 VPS IP，而是 **JoinD Cloudflare CDN 域名**
- CDN → Cloudflare Tunnel → VPS 本地 nginx（8080）→ Xray（8081）
- **任意环节断了都导致 502**

### 洛杉矶 VPS 端口分布（大佬环境）
| 端口 | 服务 | 监听 |
|------|------|------|
| 8080 | nginx（回源必经） | 127.0.0.1 |
| 8081 | Xray vless/ws | 0.0.0.0（修复后）|
| 2222 | sshd | 0.0.0.0 |
| 8888 | SearXNG | 0.0.0.0 |

### JoinD 两个 Tunnel 进程区分
```
Docker-tunnel（systemd）→ systemctl restart cloudflared-docker-tunnel
JoinD-tunnel（Docker）  → docker restart cloudflared-joined
```

## 排查命令清单

```bash
# 1. VPS 公网端口连通性
nc -v 192.3.241.244 8081
nc -v proxy.cloudjoind.com 443

# 2. CDN 域名健康检查
curl -s --connect-timeout 5 -I https://proxy.cloudjoind.com
# 200 = 正常，502 = 回源问题

# 3. nginx 状态（回源依赖）
systemctl status nginx
ss -tlnp | grep 8080

# 4. Xray 状态和监听
systemctl status xray
ss -tlnp | grep 8081

# 5. cloudflared 进程
ps aux | grep cloudflared | grep -v grep

# 6. nginx 日志（502 原因）
journalctl -u nginx --no-pager -n 20

# 7. cloudflared 日志（JoinD tunnel 报错）
journalctl -u cloudflared-docker-tunnel --no-pager -n 10
docker logs cloudflared-joined --tail 20
```

## 修复命令

```bash
# nginx 停了
sudo systemctl restart nginx

# Xray 没监听公网（配置文件）
sudo patch /usr/local/etc/xray/config.json \
  '"listen": "127.0.0.1"' '"listen": "0.0.0.0"'
sudo systemctl restart xray
sudo ufw allow 8081/tcp comment "V2Ray-Xray"
```

## 常见错误码

| 现象 | 原因 |
|------|------|
| 延迟 -1 | TCP 三次握手失败（端口不通/防火墙/监听地址） |
| 延迟 -1 + IP 端口能 curl 通 | ⚠️ **高丢包假性断连** — 不是 IP 坏了，是国际出口丢包 > 10% 导致 V2RayN 探测超时 |
| 502 Bad Gateway | Cloudflare Tunnel 回源失败（nginx 停了/tunnel 断了）|
| 200 但实际连不上 | CDN 通了但 Xray 配置不匹配（UUID/路径等）|
| 400 Bad Request | Xray 在跑但 WebSocket 握手参数不对 |

## 延迟异常高诊断（非断连场景）

当 V2RayN 能连接但延迟从正常 130-200ms 上升到 300ms+ 时：

### 关键新指标：丢包率 > 延迟
高丢包（>5%）比高延迟（300ms+）破坏性更大。即使延迟只到 199ms，如果丢包率到 14.6%，TCP 连接会反复重传超时，导致 V2RayN 显示「连接失败」或「延迟 -1」。

**诊断方法：用 speedtest 测**，关注丢包率参数：
```
丢包率 < 1% → 正常
丢包率 1-5% → 轻微异常，可接受
丢包率 5-10% → 严重，连接体验差
丢包率 > 10% → 致命，会误判为「IP 不可用」
```
在用户环境中，14.6% 丢包导致 `162.159.39.141` 显示「不能用了」，但实际该 IP 的 HTTP 端口仍正常（200）。

### 根本原因检查清单
```bash
# 1. VPS 本身是否健康 — 确认问题不是 VPS 端
uptime
curl -s --max-time 5 -o /dev/null -w "Google: %{time_total}s\n" https://www.google.com

# 2. 测试回中国方向延迟
curl -s --max-time 15 -o /dev/null -w "阿里云上海: %{time_total}s\n" https://oss-cn-shanghai.aliyuncs.com
curl -s --max-time 15 -o /dev/null -w "百度北京: %{time_total}s\n" https://www.baidu.com

# 3. 识别用户 ISP 和路由
curl -s https://ipinfo.io/<用户出口IP>/json 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'ISP: {d[\"org\"]} / City: {d[\"city\"]}')"

# 4. MTR 追踪路由
mtr -r -c 3 -n <用户出口IP> | head -20
```

### 常见原因

| 现象 | 典型原因 |
|------|---------|
| VPS 到百度/Aliyun > 500ms | **中国电信国际出口拥堵**（工作日白天高峰最常见）|
| VPS 到 Google < 200ms 正常 | 确认问题是回中国方向，不是 VPS 本身 |
| 凌晨回落到 130-200ms | 确认是**中国 ISP 高峰期行为**，非配置故障 |
| 高峰期 300ms+，低谷期正常 | ISP 国际带宽饱和，非 VPS/Xray 问题 |

### 诊断要点
- **区分 VPS 端和用户端**：VPS 到 Google 正常 → VPS 端没问题；用户测延迟高 → 用户 ISP 方向
- **区分 CDN 域名直连和 VPS IP 直连**：CDN 域名走的路径可能不同
- **确认用户 ISP**：中国电信（AS4812/AS4134）的国际出口拥堵最普遍，中国联通（AS4837/CUII）次之
- **确认时间段**：北京时间 09:00-18:00 工作日为高峰，凌晨 01:00-07:00 为低谷

---

## 丢包导致假性断连诊断

高丢包是 V2RayN 诊断中最容易被忽视的原因。用户说"这个 IP 不能用了"时，实际上可能是链路丢包严重导致 V2RayN 的超时探测失败。

### 丢包 vs 断连的鉴别方法

| 测试 | 命令 | 判断 |
|------|------|------|
| HTTPS 连通性 | `curl -sI --connect-timeout 5 https://proxy.cloudjoind.com` | 返回 200 → IP 活着，VPS 正常 |
| HTTP 80 直测 | `curl -s -o /dev/null -w "%{http_code}" -H "Host: proxy.cloudjoind.com" http://优选IP/` | 200 → 该 IP 至少还能路由到 CF |
| 开代理跑 speedtest | 开 V2RayN → speedtest.net/cli | 看丢包率（packet loss），> 5% 即为链路问题 |
| **关代理跑 speedtest** | 关 V2RayN → speedtest.net/cli | 丢包 < 1% → 本地正常，问题在国际段 |
| 凌晨复测 | 凌晨 02:00-05:00 重复上述测试 | 丢包和延迟恢复正常 → 确认是高峰期行为 |

### 典型场景：162.159.x.x 类 IP 的"突然失效"

Cloudflare 的 Anycast 网络会动态调整 Tunnel 入口 IP 池。某些 IP 段（如 `162.158.0.0/15`）可能曾经承担 Tunnel 入口功能，但被逐步收窄到 `108.162.x.x` 段。

**验证方法**：
```bash
# 如果一个优选 IP 看起来失效了，分别测 80 和 443
# 80 通但 443 不通 → 该 IP 的 TLS/Tunnel 终止功能已被 CF 收回
curl -s -o /dev/null -w "80: %{http_code}\n" -H "Host: proxy.cloudjoind.com" http://162.159.x.x/
curl -s -o /dev/null -w "443: %{http_code}\n" -H "Host: proxy.cloudjoind.com" https://162.159.x.x/
```

如果 80 返回 200 但 443 报 TLS 握手失败（exit 35），说明该 IP 不再处理 Tunnel 连接，需要换回 `108.162.x.x` 段。

### 速度测试开关代理的意义

| 代理状态 | 测试链路 | 典型延迟 | 定位目标 |
|---------|---------|---------|---------|
| 开 V2RayN | 上海→CF Tunnel→LA VPS | 130-200ms | 判断代理链路整体质量 |
| 关 V2RayN（直连） | 上海→电信局端 | 5-15ms | 判断本地宽带线路是否正常 |

用户感到代理"卡/断"时，**先关代理测一次直连**，排除自家宽带问题再往国际出口方向查。
